import React, { useState, useEffect } from 'react';
import { Product, CartItem, FidelityMode } from './types';
import { audioEngine } from './utils/audio';
import { CADBURY_PRODUCTS } from './data/cadburyData';

// Components
import { LoadingExperience } from './components/LoadingExperience';
import { Navbar } from './components/Navbar';
import { ChocolateFountain3D } from './components/ChocolateFountain3D';
import { BreakSquareExperience } from './components/BreakSquareExperience';
import { ChocolateFactoryExperience } from './components/ChocolateFactoryExperience';
import { BournvilleHeritageWorld } from './components/BournvilleHeritageWorld';
import { ProductCollectionGallery } from './components/ProductCollectionGallery';
import { GiftingConfigurator } from './components/GiftingConfigurator';
import { SustainabilityGlobe } from './components/SustainabilityGlobe';
import { FutureOfChocolate } from './components/FutureOfChocolate';
import { CartDrawer } from './components/CartDrawer';
import { SearchModal } from './components/SearchModal';
import { Footer } from './components/Footer';
import { CustomCursor } from './components/CustomCursor';

export default function App() {
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [cart, setCart] = useState<CartItem[]>([
    {
      product: CADBURY_PRODUCTS[0], // Prepopulate with classic Dairy Milk for rich preview
      quantity: 2,
    },
  ]);
  const [isCartOpen, setIsCartOpen] = useState<boolean>(false);
  const [isSearchOpen, setIsSearchOpen] = useState<boolean>(false);
  const [isMuted, setIsMuted] = useState<boolean>(true);
  const [fidelity, setFidelity] = useState<FidelityMode>('high');

  // Handle adding product to bag
  const handleAddToCart = (product: Product) => {
    setCart((prev) => {
      const existing = prev.find((item) => item.product.id === product.id && !item.customMessage);
      if (existing) {
        return prev.map((item) =>
          item.product.id === product.id && !item.customMessage
            ? { ...item, quantity: item.quantity + 1 }
            : item
        );
      }
      return [...prev, { product, quantity: 1 }];
    });
    setIsCartOpen(true);
  };

  // Handle custom gift item addition
  const handleAddGiftToBag = (giftItem: {
    product: Product;
    quantity: number;
    customMessage: string;
    giftBoxStyle: string;
  }) => {
    setCart((prev) => [...prev, giftItem]);
    setIsCartOpen(true);
  };

  const handleUpdateQuantity = (productId: string, delta: number) => {
    setCart((prev) =>
      prev
        .map((item) => {
          if (item.product.id === productId) {
            const newQty = item.quantity + delta;
            return newQty > 0 ? { ...item, quantity: newQty } : null;
          }
          return item;
        })
        .filter(Boolean) as CartItem[]
    );
  };

  const handleRemoveItem = (productId: string) => {
    setCart((prev) => prev.filter((item) => item.product.id !== productId));
  };

  const handleClearCart = () => {
    setCart([]);
  };

  const handleToggleMute = () => {
    const newMuteState = audioEngine.toggleMute();
    setIsMuted(newMuteState);
  };

  const scrollToSection = (sectionId: string) => {
    const el = document.getElementById(sectionId);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const totalCartCount = cart.reduce((sum, item) => sum + item.quantity, 0);

  return (
    <div className="relative min-h-screen bg-[#1a0033] text-[#f5f2ed] font-serif selection:bg-[#d4af37] selection:text-[#1a0033] overflow-x-hidden">
      {/* Ambient Dotted Gold Grid Overlay from Elegant Dark Theme */}
      <div
        className="fixed inset-0 pointer-events-none opacity-20 z-0 bg-elegant-grid"
        style={{
          backgroundImage: 'radial-gradient(#d4af37 0.5px, transparent 0.5px)',
          backgroundSize: '40px 40px',
        }}
      />

      {/* Diagonal Luxury Sheen */}
      <div
        className="fixed inset-0 pointer-events-none z-0"
        style={{
          background: 'linear-gradient(45deg, rgba(212,175,55,0.03) 0%, transparent 40%, transparent 60%, rgba(212,175,55,0.03) 100%)',
        }}
      />

      {/* Custom Gold Magnetic Cursor */}
      <CustomCursor />

      {/* Cinematic Loading Experience */}
      {isLoading && <LoadingExperience onComplete={() => setIsLoading(false)} />}

      {/* Main Luxury Navigation */}
      <Navbar
        cartCount={totalCartCount}
        onOpenCart={() => setIsCartOpen(true)}
        onOpenSearch={() => setIsSearchOpen(true)}
        onNavigate={scrollToSection}
        isMuted={isMuted}
        onToggleMute={handleToggleMute}
      />

      <div className="relative z-10">
        {/* Hero: 3D Molten Chocolate Fountain */}
        <section id="hero">
          <ChocolateFountain3D
            fidelity={fidelity}
            onExploreClick={() => scrollToSection('collection')}
            onStoryClick={() => scrollToSection('heritage')}
          />
        </section>

        {/* Signature Tactile Interaction: Break A Square */}
        <section id="break-square">
          <BreakSquareExperience onAddToCart={handleAddToCart} />
        </section>

        {/* Modern High-Precision Factory Experience */}
        <section id="factory">
          <ChocolateFactoryExperience onShopClick={() => scrollToSection('collection')} />
        </section>

        {/* Bournville Digital World & Heritage Time Machine */}
        <section id="heritage">
          <BournvilleHeritageWorld onExploreProducts={() => scrollToSection('collection')} />
        </section>

        {/* Product Collection & 3D Chocolate Gallery */}
        <ProductCollectionGallery
          onAddToCart={handleAddToCart}
          onSelectProductForDeepDive={(product) => {
            handleAddToCart(product);
          }}
        />

        {/* Personalised Gifting Configurator: "MAKE IT PERSONAL" */}
        <GiftingConfigurator onAddGiftToBag={handleAddGiftToBag} />

        {/* Liquid Sustainability Data & 3D Cocoa Globe */}
        <SustainabilityGlobe />

        {/* Future of Chocolate (1824 → 2124) */}
        <section id="future">
          <FutureOfChocolate onDiscoverClick={() => scrollToSection('collection')} />
        </section>

        {/* Cinematic Footer */}
        <Footer onNavigate={scrollToSection} />
      </div>

      {/* Cart Drawer Slide-over */}
      <CartDrawer
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        items={cart}
        onUpdateQuantity={handleUpdateQuantity}
        onRemoveItem={handleRemoveItem}
        onClearCart={handleClearCart}
      />

      {/* Ambient Search Modal */}
      <SearchModal
        isOpen={isSearchOpen}
        onClose={() => setIsSearchOpen(false)}
        onSelectProduct={(product) => handleAddToCart(product)}
        onSelectSection={scrollToSection}
      />
    </div>
  );
}
