import React, { useState } from 'react';
import { TIMELINE_ERAS } from '../data/cadburyData';
import { audioEngine } from '../utils/audio';
import { TimelineEra } from '../types';
import { History, Compass, Sparkles, Quote, MapPin, Building, ChevronLeft, ChevronRight } from 'lucide-react';

interface HeritageProps {
  onExploreProducts?: () => void;
}

export const BournvilleHeritageWorld: React.FC<HeritageProps> = ({ onExploreProducts }) => {
  const [selectedEraIndex, setSelectedEraIndex] = useState<number>(0);
  const [activeTab, setActiveTab] = useState<'timeline' | 'bournville'>('timeline');
  const [selectedLandmark, setSelectedLandmark] = useState<string | null>('factory');

  const currentEra: TimelineEra = TIMELINE_ERAS[selectedEraIndex];

  const handleEraChange = (index: number) => {
    setSelectedEraIndex(index);
    audioEngine.playHover();
  };

  const handleNext = () => {
    if (selectedEraIndex < TIMELINE_ERAS.length - 1) {
      handleEraChange(selectedEraIndex + 1);
    }
  };

  const handlePrev = () => {
    if (selectedEraIndex > 0) {
      handleEraChange(selectedEraIndex - 1);
    }
  };

  return (
    <section className="relative w-full py-28 px-6 md:px-12 bg-[#1a0033] text-[#f5f2ed] overflow-hidden border-t border-[#d4af37]/15">
      {/* Background Ambience & Dotted Grid */}
      <div
        className="absolute inset-0 pointer-events-none opacity-15"
        style={{
          backgroundImage: 'radial-gradient(#d4af37 0.5px, transparent 0.5px)',
          backgroundSize: '40px 40px',
        }}
      />

      <div className="max-w-7xl mx-auto relative z-10">
        
        {/* Section Header with View Toggle */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-16 gap-6">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 border border-[#d4af37]/30 bg-[#330066]/30 text-[#d4af37] text-[10px] font-sans tracking-[0.3em] uppercase mb-3">
              <History className="w-3 h-3 text-[#d4af37]" />
              <span>Chapter IV — Heritage Archives</span>
            </div>
            <h2 className="text-4xl sm:text-5xl md:text-6xl font-editorial font-light tracking-tight text-[#f5f2ed]">
              SINCE <span className="italic font-serif text-[#d4af37]">1824</span>
            </h2>
            <p className="max-w-xl text-sm sm:text-base text-[#f5f2ed]/70 font-sans font-light mt-3 leading-relaxed">
              From John Cadbury’s Bull Street apothecary to the utopian garden village of Bournville. Explore the milestones that transformed chocolate forever.
            </p>
          </div>

          {/* Toggle between Time Machine and Bournville Garden Village */}
          <div className="flex items-center p-1 bg-[#0e001f] border border-[#d4af37]/30 text-[10px] font-sans uppercase tracking-[0.25em]">
            <button
              onClick={() => {
                setActiveTab('timeline');
                audioEngine.playHover();
              }}
              className={`px-5 py-2 transition-all duration-300 ${
                activeTab === 'timeline'
                  ? 'bg-gradient-to-r from-[#330066] to-[#1a0033] border border-[#d4af37] text-[#f5f2ed] shadow-md'
                  : 'text-[#f5f2ed]/70 hover:text-[#f5f2ed]'
              }`}
            >
              Time Machine (1824–2124)
            </button>
            <button
              onClick={() => {
                setActiveTab('bournville');
                audioEngine.playHover();
              }}
              className={`px-5 py-2 transition-all duration-300 ${
                activeTab === 'bournville'
                  ? 'bg-gradient-to-r from-[#330066] to-[#1a0033] border border-[#d4af37] text-[#f5f2ed] shadow-md'
                  : 'text-[#f5f2ed]/70 hover:text-[#f5f2ed]'
              }`}
            >
              Bournville Garden Village
            </button>
          </div>
        </div>

        {activeTab === 'timeline' ? (
          /* ================= TIMELINE / TIME MACHINE ================= */
          <div>
            {/* Horizontal Timeline Scrubber / Eras */}
            <div className="w-full overflow-x-auto pb-6 scrollbar-none mb-12">
              <div className="flex items-center justify-between min-w-[700px] relative px-4">
                {/* Connecting gold line */}
                <div className="absolute left-6 right-6 top-1/2 -translate-y-1/2 h-px bg-[#d4af37]/30 z-0" />

                {TIMELINE_ERAS.map((era, idx) => {
                  const isSelected = idx === selectedEraIndex;

                  return (
                    <button
                      key={era.year}
                      onClick={() => handleEraChange(idx)}
                      className="relative z-10 flex flex-col items-center group cursor-pointer"
                    >
                      <div
                        className={`
                          w-12 h-12 rounded-full flex items-center justify-center font-sans text-xs font-bold transition-all duration-500
                          ${
                            isSelected
                              ? 'bg-[#d4af37] text-[#1a0033] scale-125 shadow-[0_0_25px_rgba(212,175,55,0.8)]'
                              : 'bg-[#1a0033] border border-[#d4af37]/40 text-[#d4af37] group-hover:border-[#d4af37] group-hover:scale-110'
                          }
                        `}
                      >
                        {era.year.slice(2)}
                      </div>
                      <span
                        className={`text-[10px] font-sans uppercase tracking-[0.2em] mt-2 transition-colors ${
                          isSelected ? 'text-[#d4af37] font-bold' : 'text-[#f5f2ed]/50 group-hover:text-[#f5f2ed]'
                        }`}
                      >
                        {era.year}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Selected Era Feature Stage */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch bg-[#0e001f]/85 border border-[#d4af37]/25 p-6 sm:p-10 shadow-2xl backdrop-blur-xl">
              
              {/* Archival Imagery Transformation & Vignette */}
              <div className="lg:col-span-5 relative overflow-hidden min-h-[340px] border border-[#d4af37]/30 group">
                <img
                  src={currentEra.image}
                  alt={currentEra.title}
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105 filter saturate-90 brightness-90"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#0e001f] via-transparent to-transparent opacity-80" />
                
                {/* Year Stamp */}
                <div className="absolute top-4 left-4 px-3 py-1 bg-[#1a0033]/90 backdrop-blur-md border border-[#d4af37]/40 font-sans text-[9px] uppercase tracking-[0.25em] text-[#d4af37]">
                  Archival Record • {currentEra.year}
                </div>

                {/* Milestone Pill */}
                <div className="absolute bottom-4 left-4 right-4 p-3 bg-[#0e001f]/90 backdrop-blur-md border border-[#d4af37]/30 text-xs font-sans text-[#d4af37]">
                  <span className="text-[9px] text-[#f5f2ed]/60 uppercase tracking-[0.2em] block mb-0.5">Milestone</span>
                  {currentEra.milestone}
                </div>
              </div>

              {/* Editorial Narrative & Historical Impact */}
              <div className="lg:col-span-7 flex flex-col justify-between p-2 sm:p-4">
                <div>
                  <div className="text-[10px] font-sans uppercase tracking-[0.3em] text-[#d4af37] mb-2">
                    {currentEra.subtitle}
                  </div>
                  <h3 className="text-3xl sm:text-4xl md:text-5xl font-editorial font-light text-[#f5f2ed] mb-4">
                    {currentEra.title}
                  </h3>

                  <p className="text-sm sm:text-base text-[#f5f2ed]/85 font-sans font-light leading-relaxed mb-6">
                    {currentEra.description}
                  </p>

                  {/* Quote block */}
                  {currentEra.quote && (
                    <div className="relative pl-6 py-2 border-l-2 border-[#d4af37] mb-6">
                      <Quote className="absolute -top-1 -left-3 w-5 h-5 text-[#d4af37] bg-[#0e001f]" />
                      <p className="text-sm italic font-serif text-[#d4af37]">
                        {currentEra.quote}
                      </p>
                    </div>
                  )}

                  {/* Archival Statistic */}
                  {currentEra.stat && (
                    <div className="p-3.5 bg-[#1a0033]/60 border border-[#d4af37]/20 inline-flex items-center gap-3">
                      <Sparkles className="w-3.5 h-3.5 text-[#d4af37]" />
                      <span className="text-[10px] font-sans uppercase tracking-[0.2em] text-[#f5f2ed]">
                        {currentEra.stat}
                      </span>
                    </div>
                  )}
                </div>

                {/* Navigation Controls */}
                <div className="flex items-center justify-between pt-8 border-t border-[#d4af37]/20 mt-8">
                  <div className="flex items-center gap-2">
                    <button
                      onClick={handlePrev}
                      disabled={selectedEraIndex === 0}
                      className="p-2.5 border border-[#d4af37]/30 hover:border-[#d4af37] hover:bg-[#d4af37]/15 disabled:opacity-30 transition-all"
                    >
                      <ChevronLeft className="w-4 h-4 text-[#d4af37]" />
                    </button>
                    <button
                      onClick={handleNext}
                      disabled={selectedEraIndex === TIMELINE_ERAS.length - 1}
                      className="p-2.5 border border-[#d4af37]/30 hover:border-[#d4af37] hover:bg-[#d4af37]/15 disabled:opacity-30 transition-all"
                    >
                      <ChevronRight className="w-4 h-4 text-[#d4af37]" />
                    </button>
                    <span className="text-[10px] font-sans uppercase tracking-[0.25em] text-[#d4af37] ml-3">
                      {selectedEraIndex + 1} of {TIMELINE_ERAS.length} Eras
                    </span>
                  </div>

                  <button
                    onClick={() => {
                      audioEngine.playChocolateSnap();
                      onExploreProducts?.();
                    }}
                    className="px-5 py-2.5 bg-[#330066]/40 border border-[#d4af37] hover:bg-[#d4af37] hover:text-[#1a0033] text-[#f5f2ed] font-sans text-[10px] uppercase tracking-[0.25em] transition-all"
                  >
                    Explore Heritage Range →
                  </button>
                </div>

              </div>

            </div>
          </div>
        ) : (
          /* ================= BOURNVILLE DIGITAL WORLD ================= */
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch">
            
            {/* Interactive Miniature Architectural Map */}
            <div className="lg:col-span-8 p-8 bg-[#0e001f]/85 border border-[#d4af37]/30 shadow-2xl relative min-h-[460px] flex flex-col justify-between overflow-hidden">
              
              {/* Map Atmosphere */}
              <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_rgba(77,0,153,0.3)_0%,_transparent_70%)] pointer-events-none" />

              <div>
                <div className="flex items-center justify-between text-[10px] font-sans uppercase tracking-[0.3em] text-[#d4af37] mb-4">
                  <span>Village Grid • Birmingham, UK</span>
                  <span>Est. 1879</span>
                </div>
                <h3 className="text-3xl font-editorial text-[#f5f2ed] mb-2">
                  The Factory in a Garden
                </h3>
                <p className="text-xs sm:text-sm text-[#f5f2ed]/70 font-sans max-w-md">
                  Click the historical landmarks to uncover George & Richard Cadbury's revolutionary architectural vision for human welfare.
                </p>
              </div>

              {/* Landmark Pins Map UI */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 my-8 relative z-10">
                {[
                  { id: 'factory', name: 'Historic Factory', role: 'Chocolate Manufacturing & Pipelines' },
                  { id: 'resthouse', name: 'Bournville Rest House', role: 'Village Green Memorial' },
                  { id: 'cottages', name: 'Arts & Crafts Cottages', role: 'Model Worker Housing' },
                  { id: 'lab', name: 'Future Sensory Lab', role: '2124 Confectionery Atelier' }
                ].map((landmark) => {
                  const isActive = selectedLandmark === landmark.id;
                  return (
                    <button
                      key={landmark.id}
                      onClick={() => {
                        setSelectedLandmark(landmark.id);
                        audioEngine.playHover();
                      }}
                      className={`
                        p-4 text-left border transition-all duration-300
                        ${
                          isActive
                            ? 'bg-[#330066]/40 border-[#d4af37] shadow-[0_0_20px_rgba(212,175,55,0.3)]'
                            : 'bg-[#1a0033]/60 border-[#d4af37]/20 hover:border-[#d4af37]/60'
                        }
                      `}
                    >
                      <Building className={`w-5 h-5 mb-2 ${isActive ? 'text-[#d4af37]' : 'text-[#d4af37]/60'}`} />
                      <div className="font-sans text-[10px] font-bold uppercase tracking-[0.2em] text-[#f5f2ed]">{landmark.name}</div>
                      <div className="text-[9px] text-[#f5f2ed]/60 font-sans mt-1">{landmark.role}</div>
                    </button>
                  );
                })}
              </div>

              {/* Bottom Quote Banner */}
              <div className="p-4 bg-[#1a0033]/80 border border-[#d4af37]/20 text-xs font-serif italic text-[#d4af37]">
                “No man ought to be condemned to live in a place where a rose cannot grow.” — George Cadbury, 1879
              </div>

            </div>

            {/* Landmark Details Showcase */}
            <div className="lg:col-span-4 p-8 bg-[#0e001f]/90 border border-[#d4af37]/30 shadow-2xl flex flex-col justify-between">
              <div>
                <div className="text-[10px] font-sans uppercase tracking-[0.3em] text-[#d4af37] mb-2">
                  Landmark Architecture
                </div>
                <h4 className="text-2xl font-editorial text-[#f5f2ed] mb-3">
                  {selectedLandmark === 'factory' && 'The Historic Bournville Factory'}
                  {selectedLandmark === 'resthouse' && 'The Bournville Rest House'}
                  {selectedLandmark === 'cottages' && 'Arts & Crafts Model Cottages'}
                  {selectedLandmark === 'lab' && '2124 Precision Chocolate Lab'}
                </h4>

                <p className="text-xs sm:text-sm text-[#f5f2ed]/80 font-sans font-light leading-relaxed mb-6">
                  {selectedLandmark === 'factory' &&
                    'Set beside the Bourn brook in 1879, the factory featured heated dining rooms, on-site medical facilities, open-air heated swimming pools, and dedicated gardens.'}
                  {selectedLandmark === 'resthouse' &&
                    'Built on the village green to celebrate George and Elizabeth Cadbury’s Silver Wedding anniversary in 1914, modeled after a 17th-century Carillon bell tower.'}
                  {selectedLandmark === 'cottages' &&
                    'Over 300 architect-designed Arts & Crafts homes with private apple orchards and low-density planning, inspiring the global garden city movement.'}
                  {selectedLandmark === 'lab' &&
                    'The ultra-modern innovation wing where quantum crystal tempering and sustainable packaging grown from cocoa fibers are developed today.'}
                </p>

                <div className="p-3 bg-[#1a0033]/60 border border-[#d4af37]/20 text-[10px] font-sans uppercase tracking-[0.2em] text-[#d4af37] space-y-1">
                  <div className="flex items-center gap-2">
                    <MapPin className="w-3.5 h-3.5" />
                    <span>Bournville, Birmingham, B30 2LU</span>
                  </div>
                  <div>Open to Visitors: Cadbury World Experience</div>
                </div>
              </div>

              <div className="mt-8 pt-6 border-t border-[#d4af37]/20">
                <button
                  onClick={() => {
                    audioEngine.playHover();
                    onExploreProducts?.();
                  }}
                  className="w-full py-3 bg-gradient-to-r from-[#330066] to-[#1a0033] border border-[#d4af37]/60 text-[#f5f2ed] font-sans text-[10px] uppercase tracking-[0.3em] transition-all hover:border-[#d4af37]"
                >
                  Book Cadbury World Tickets →
                </button>
              </div>
            </div>

          </div>
        )}

      </div>
    </section>
  );
};
