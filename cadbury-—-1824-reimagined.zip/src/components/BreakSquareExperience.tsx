import React, { useState, useRef } from 'react';
import confetti from 'canvas-confetti';
import { audioEngine } from '../utils/audio';
import { Product } from '../types';

interface BreakSquareProps {
  onAddToCart?: (product: Product) => void;
  product?: Product;
}

export const BreakSquareExperience: React.FC<BreakSquareProps> = ({
  onAddToCart,
  product = {
    id: 'cadbury-dairy-milk-break',
    name: 'Cadbury Dairy Milk Silk',
    tagline: 'Pure Tactile Indulgence — Break & Share',
    category: 'bars',
    price: 3.50,
    weight: '200g',
    cocoaPercentage: 38,
    description: 'The golden standard of British chocolate. Created with fresh British and Irish milk for an unmistakable silky melt.',
    tastingNotes: ['Creamy Fresh Milk', 'Floral Cocoa', 'Madagascan Vanilla'],
    ingredients: ['Milk', 'Sugar', 'Cocoa Butter', 'Cocoa Mass'],
    image: 'https://images.unsplash.com/photo-1549007994-cb92caebd54b?auto=format&fit=crop&w=800&q=80',
    accentColor: '#23085a',
    origin: 'Bournville, England'
  }
}) => {
  const [brokenSquares, setBrokenSquares] = useState<{ [key: number]: boolean }>({ 0: false, 1: false, 2: false, 3: false, 4: false, 5: false });
  const [selectedSquare, setSelectedSquare] = useState<number | null>(null);
  const [isBroken, setIsBroken] = useState<boolean>(false);
  const containerRef = useRef<HTMLDivElement>(null);

  const triggerCrumbShower = (event?: React.MouseEvent) => {
    // Chocolate crumb particle explosion
    const rect = containerRef.current?.getBoundingClientRect();
    const x = event && rect ? (event.clientX / window.innerWidth) : 0.5;
    const y = event && rect ? (event.clientY / window.innerHeight) : 0.5;

    confetti({
      particleCount: 35,
      spread: 60,
      origin: { x, y },
      colors: ['#441e0d', '#291106', '#5c2b14', '#c9a050'],
      shapes: ['square'],
      ticks: 120,
      gravity: 1.4,
      scalar: 0.7,
      disableForReducedMotion: true,
    });
  };

  const handleBreakSquare = (index: number, e: React.MouseEvent) => {
    audioEngine.playChocolateSnap();
    triggerCrumbShower(e);
    
    setBrokenSquares((prev) => ({
      ...prev,
      [index]: true,
    }));
    setSelectedSquare(index);
    setIsBroken(true);
  };

  const handleResetBar = () => {
    audioEngine.playChocolateRipple();
    setBrokenSquares({ 0: false, 1: false, 2: false, 3: false, 4: false, 5: false });
    setSelectedSquare(null);
    setIsBroken(false);
  };

  const squares = [0, 1, 2, 3, 4, 5];

  return (
    <section className="relative w-full py-28 px-6 md:px-12 bg-[#1a0033] text-[#f5f2ed] overflow-hidden border-t border-[#d4af37]/15">
      {/* Background Ambience */}
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_rgba(212,175,55,0.06)_0%,_transparent_70%)] pointer-events-none" />

      <div className="max-w-6xl mx-auto flex flex-col items-center">
        {/* Section Header */}
        <div className="text-center mb-14">
          <div className="inline-flex items-center gap-2 px-3 py-1 border border-[#d4af37]/30 bg-[#330066]/30 text-[#d4af37] text-[10px] font-sans tracking-[0.3em] uppercase mb-3">
            <span>Chapter II — The Fracture</span>
          </div>
          <h2 className="text-4xl md:text-6xl font-editorial font-light text-[#f5f2ed] tracking-tight">
            BREAK A <span className="italic font-serif text-[#d4af37]">SQUARE</span>
          </h2>
          <p className="max-w-md mx-auto mt-3 text-sm md:text-base text-[#f5f2ed]/70 font-sans font-light leading-relaxed">
            Feel the clean, resonant acoustic snap of perfectly tempered Beta-V crystal chocolate. Click or tap any square to fracture.
          </p>
        </div>

        {/* Chocolate Bar Container */}
        <div
          ref={containerRef}
          className="relative p-8 md:p-12 bg-[#0e001f]/90 border border-[#d4af37]/25 shadow-[0_20px_60px_rgba(0,0,0,0.8)] backdrop-blur-xl flex flex-col items-center w-full max-w-2xl"
        >
          {/* Packaging Sleeve / Gold Foil Wrapper Behind */}
          <div className="absolute -top-3 left-6 right-6 h-6 bg-gradient-to-r from-[#d4af37] via-[#f5e6b3] to-[#b38a3a] opacity-90 shadow-md flex items-center justify-center">
            <span className="font-sans text-[9px] tracking-[0.3em] uppercase text-[#1a0033] font-bold">
              Cadbury Bournville Atelier • 100% Sustainably Sourced
            </span>
          </div>

          {/* Chocolate Tablet Grid (2x3 Bevelled Engraved Blocks) */}
          <div className="grid grid-cols-2 gap-3 md:gap-4 p-4 md:p-6 bg-[#1a0902] border border-[#3d1808] shadow-2xl select-none mt-2">
            {squares.map((idx) => {
              const broken = brokenSquares[idx];
              const isSelected = selectedSquare === idx;

              return (
                <div
                  key={idx}
                  onClick={(e) => handleBreakSquare(idx, e)}
                  className={`
                    relative group w-32 h-28 sm:w-44 sm:h-36 cursor-pointer transition-all duration-500 transform
                    ${broken ? 'translate-y-4 scale-95 opacity-90 rotate-2' : 'hover:-translate-y-1 hover:scale-[1.02]'}
                    ${isSelected ? 'ring-2 ring-[#d4af37] shadow-[0_10px_25px_rgba(212,175,55,0.3)]' : ''}
                    chocolate-bevel flex flex-col items-center justify-center p-3
                  `}
                >
                  {/* Glossy Reflective Highlight */}
                  <div className="absolute inset-1 bg-gradient-to-br from-white/15 via-transparent to-black/40 pointer-events-none" />

                  {/* Embossed Cadbury Script Logo */}
                  <div className="relative z-10 text-center text-2xl sm:text-3xl text-[#4a220e] drop-shadow-[1px_1px_1px_rgba(255,255,255,0.15)] group-hover:text-[#612c12] transition-colors" style={{ fontFamily: '"Georgia", serif' }}>
                    Cadbury
                  </div>
                  <span className="relative z-10 text-[8px] uppercase font-sans tracking-[0.25em] text-[#5c2b14] mt-1">
                    Dairy Milk
                  </span>

                  {/* Fracture Lines Visual State */}
                  {broken && (
                    <div className="absolute inset-0 bg-red-950/20 border border-dashed border-[#d4af37]/60 flex items-center justify-center">
                      <span className="bg-[#330066]/90 px-2 py-0.5 text-[9px] font-sans text-[#d4af37] tracking-[0.2em] uppercase">
                        SNAP!
                      </span>
                    </div>
                  )}
                </div>
              );
            })}
          </div>

          {/* Dynamic Action / Tasting Drawer below Bar */}
          <div className="w-full mt-8 flex flex-col sm:flex-row items-center justify-between gap-4 pt-6 border-t border-[#d4af37]/15">
            <div className="text-center sm:text-left">
              <span className="text-[10px] uppercase tracking-[0.3em] text-[#d4af37] font-sans">
                {isBroken ? 'Square Fractured • Ready to Taste' : 'Intact Bar • 200g'}
              </span>
              <p className="text-xs sm:text-sm font-sans text-[#f5f2ed]/80 mt-0.5">
                {isBroken
                  ? 'Velvety British dairy with a clean roasted cocoa finish.'
                  : 'Tap or click any segment above to snap a piece.'}
              </p>
            </div>

            <div className="flex items-center gap-3">
              {isBroken && (
                <button
                  onClick={handleResetBar}
                  className="px-4 py-2.5 text-[10px] font-sans tracking-[0.25em] uppercase text-[#d4af37] border border-[#d4af37]/40 hover:bg-[#d4af37]/15 transition-all"
                >
                  Re-fuse Bar
                </button>
              )}

              <button
                onClick={() => {
                  audioEngine.playChocolateSnap();
                  onAddToCart?.(product);
                }}
                className="px-6 py-2.5 bg-gradient-to-r from-[#330066] to-[#1a0033] border border-[#d4af37]/60 text-[#f5f2ed] font-sans text-[10px] tracking-[0.25em] uppercase transition-all hover:border-[#d4af37] hover:shadow-[0_0_20px_rgba(212,175,55,0.4)] flex items-center gap-2"
              >
                <span>Add Bar • £3.50</span>
                <span className="text-[#d4af37]">→</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
