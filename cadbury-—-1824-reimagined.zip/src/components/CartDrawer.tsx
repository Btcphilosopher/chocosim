import React, { useState } from 'react';
import { CartItem } from '../types';
import { audioEngine } from '../utils/audio';
import { X, Trash2, Plus, Minus, Gift, ShoppingBag, ShieldCheck, Check } from 'lucide-react';

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  items: CartItem[];
  onUpdateQuantity: (productId: string, delta: number) => void;
  onRemoveItem: (productId: string) => void;
  onClearCart: () => void;
}

export const CartDrawer: React.FC<CartDrawerProps> = ({
  isOpen,
  onClose,
  items,
  onUpdateQuantity,
  onRemoveItem,
  onClearCart,
}) => {
  const [isCheckingOut, setIsCheckingOut] = useState(false);
  const [orderComplete, setOrderComplete] = useState(false);

  if (!isOpen) return null;

  const subtotal = items.reduce((acc, item) => acc + item.product.price * item.quantity, 0);
  const freeShippingThreshold = 40.0;
  const progressToFreeShipping = Math.min(100, (subtotal / freeShippingThreshold) * 100);

  const handleCheckout = () => {
    setIsCheckingOut(true);
    audioEngine.playGoldChime();
    setTimeout(() => {
      setIsCheckingOut(false);
      setOrderComplete(true);
      onClearCart();
    }, 1600);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-hidden">
      {/* Backdrop */}
      <div
        onClick={onClose}
        className="absolute inset-0 bg-black/80 backdrop-blur-sm transition-opacity"
      />

      {/* Drawer */}
      <div className="absolute inset-y-0 right-0 max-w-full flex pl-10">
        <div className="w-screen max-w-md bg-[#0e001f] border-l border-[#d4af37]/30 p-6 flex flex-col justify-between shadow-2xl relative overflow-hidden text-[#f5f2ed]">
          
          {/* Subtle molten background */}
          <div className="absolute top-0 right-0 w-64 h-64 bg-[#330066]/30 rounded-full blur-3xl pointer-events-none" />

          {/* Header */}
          <div className="relative z-10">
            <div className="flex items-center justify-between pb-4 border-b border-[#d4af37]/20">
              <div className="flex items-center gap-2">
                <ShoppingBag className="w-4 h-4 text-[#d4af37]" />
                <h3 className="font-sans text-xs font-bold text-[#f5f2ed] tracking-[0.25em] uppercase">
                  Your Chocolate Bag
                </h3>
              </div>
              <button
                onClick={onClose}
                className="p-1 border border-[#d4af37]/20 hover:border-[#d4af37] text-[#f5f2ed]/60 hover:text-[#f5f2ed] transition-colors"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Free Luxury Packaging / Shipping Progress Bar */}
            <div className="mt-4 p-3 bg-[#1a0033] border border-[#d4af37]/20 text-[10px] font-sans uppercase tracking-wider">
              <div className="flex justify-between text-[#d4af37] mb-1.5">
                <span>
                  {subtotal >= freeShippingThreshold
                    ? '★ Free Express Temperature-Controlled Delivery Unlocked!'
                    : `Add £${(freeShippingThreshold - subtotal).toFixed(2)} more for Free Express Delivery`}
                </span>
                <span className="text-[#f5f2ed]">{Math.round(progressToFreeShipping)}%</span>
              </div>
              <div className="w-full h-1 bg-[#330066] overflow-hidden">
                <div
                  className="h-full bg-[#d4af37] transition-all duration-500"
                  style={{ width: `${progressToFreeShipping}%` }}
                />
              </div>
            </div>
          </div>

          {/* Cart Item List */}
          <div className="flex-1 overflow-y-auto py-6 space-y-4 relative z-10">
            {orderComplete ? (
              <div className="text-center py-12 space-y-4">
                <div className="w-14 h-14 bg-[#330066] text-[#d4af37] border border-[#d4af37] mx-auto flex items-center justify-center">
                  <Check className="w-6 h-6" />
                </div>
                <h4 className="font-editorial text-2xl text-[#f5f2ed]">
                  Generations of Joy on Their Way!
                </h4>
                <p className="text-xs text-[#f5f2ed]/70 font-sans max-w-xs mx-auto">
                  Your bespoke Cadbury confectionery is being hand-tempered and packed in thermal insulated gold foil at Bournville.
                </p>
                <button
                  onClick={() => {
                    setOrderComplete(false);
                    onClose();
                  }}
                  className="px-6 py-2.5 bg-[#d4af37] hover:bg-[#ebd89b] text-[#1a0033] font-sans font-bold text-[10px] uppercase tracking-[0.25em]"
                >
                  Continue Exploring
                </button>
              </div>
            ) : items.length === 0 ? (
              <div className="text-center py-16 space-y-3">
                <Gift className="w-10 h-10 text-[#d4af37]/40 mx-auto" />
                <h4 className="font-editorial text-xl text-[#f5f2ed]">Your Bag is Empty</h4>
                <p className="text-xs text-[#f5f2ed]/60 font-sans">
                  Discover our iconic Dairy Milk bars or craft a bespoke personalised gift box.
                </p>
              </div>
            ) : (
              items.map((item) => (
                <div
                  key={item.product.id}
                  className="p-4 bg-[#1a0033]/80 border border-[#d4af37]/20 flex gap-4 items-center"
                >
                  <img
                    src={item.product.image}
                    alt={item.product.name}
                    className="w-16 h-16 object-cover border border-[#d4af37]/30"
                  />
                  <div className="flex-1 min-w-0">
                    <h5 className="font-editorial text-base text-[#f5f2ed] truncate">
                      {item.product.name}
                    </h5>
                    <span className="text-xs text-[#d4af37] font-sans block">
                      £{item.product.price.toFixed(2)}
                    </span>
                    {item.customMessage && (
                      <span className="text-[10px] text-[#f5f2ed]/80 font-serif italic line-clamp-1">
                        Dedication: {item.customMessage}
                      </span>
                    )}

                    {/* Quantity controls */}
                    <div className="flex items-center gap-3 mt-2">
                      <div className="flex items-center border border-[#d4af37]/30 bg-[#0e001f] text-xs">
                        <button
                          onClick={() => {
                            audioEngine.playHover();
                            onUpdateQuantity(item.product.id, -1);
                          }}
                          className="px-2 py-0.5 text-[#d4af37] hover:bg-[#330066]"
                        >
                          <Minus className="w-3 h-3" />
                        </button>
                        <span className="px-2 text-[#f5f2ed] font-sans text-xs">{item.quantity}</span>
                        <button
                          onClick={() => {
                            audioEngine.playHover();
                            onUpdateQuantity(item.product.id, 1);
                          }}
                          className="px-2 py-0.5 text-[#d4af37] hover:bg-[#330066]"
                        >
                          <Plus className="w-3 h-3" />
                        </button>
                      </div>

                      <button
                        onClick={() => {
                          audioEngine.playHover();
                          onRemoveItem(item.product.id);
                        }}
                        className="text-[#f5f2ed]/40 hover:text-rose-400 p-1"
                        title="Remove"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>

          {/* Footer Checkout */}
          {!orderComplete && items.length > 0 && (
            <div className="pt-4 border-t border-[#d4af37]/20 relative z-10 space-y-4">
              <div className="flex justify-between items-center text-xs font-sans uppercase tracking-[0.2em]">
                <span className="text-[#f5f2ed]/70">Estimated Subtotal</span>
                <span className="text-xl font-bold text-[#f5f2ed]">£{subtotal.toFixed(2)}</span>
              </div>

              <div className="flex items-center gap-2 text-[10px] font-sans text-[#d4af37] bg-[#1a0033] p-2 border border-[#d4af37]/20 uppercase tracking-wider">
                <ShieldCheck className="w-3.5 h-3.5" />
                <span>Insulated thermal pack included for peak snap & shine</span>
              </div>

              <button
                onClick={handleCheckout}
                disabled={isCheckingOut}
                className="w-full py-3.5 bg-[#d4af37] hover:bg-[#ebd89b] text-[#1a0033] font-sans font-bold text-[10px] uppercase tracking-[0.3em] shadow-[0_0_25px_rgba(212,175,55,0.4)] active:scale-98 transition-all flex items-center justify-center gap-2"
              >
                {isCheckingOut ? (
                  <span>Securing Bournville Dispatch...</span>
                ) : (
                  <span>Proceed to Checkout • £{subtotal.toFixed(2)}</span>
                )}
              </button>
            </div>
          )}

        </div>
      </div>
    </div>
  );
};
