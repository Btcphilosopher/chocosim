import React, { useState } from 'react';
import { FACTORY_STEPS } from '../data/cadburyData';
import { audioEngine } from '../utils/audio';
import { FactoryStep } from '../types';
import { 
  Flame, 
  Layers, 
  Droplets, 
  RotateCw, 
  Sparkles, 
  Grid, 
  PackageCheck, 
  Leaf,
  Thermometer,
  Clock,
  Activity,
  ArrowRight
} from 'lucide-react';

interface FactoryProps {
  onShopClick?: () => void;
}

export const ChocolateFactoryExperience: React.FC<FactoryProps> = ({ onShopClick }) => {
  const [activeStepIndex, setActiveStepIndex] = useState<number>(3); // Default to Milk Blending
  const [conchingSpeed, setConchingSpeed] = useState<number>(85);
  const [temperingTemp, setTemperingTemp] = useState<number>(31.5);
  const [isMouldingActive, setIsMouldingActive] = useState<boolean>(false);

  const activeStep: FactoryStep = FACTORY_STEPS[activeStepIndex];

  const handleStepSelect = (index: number) => {
    setActiveStepIndex(index);
    audioEngine.playChocolateRipple();
  };

  const getStepIcon = (iconName: string) => {
    switch (iconName) {
      case 'Flame': return <Flame className="w-5 h-5" />;
      case 'Layers': return <Layers className="w-5 h-5" />;
      case 'Droplets': return <Droplets className="w-5 h-5" />;
      case 'RotateCw': return <RotateCw className="w-5 h-5" />;
      case 'Sparkles': return <Sparkles className="w-5 h-5" />;
      case 'Grid': return <Grid className="w-5 h-5" />;
      case 'PackageCheck': return <PackageCheck className="w-5 h-5" />;
      default: return <Leaf className="w-5 h-5" />;
    }
  };

  const triggerMouldingDemo = () => {
    setIsMouldingActive(true);
    audioEngine.playChocolateRipple();
    setTimeout(() => {
      audioEngine.playChocolateSnap();
      setIsMouldingActive(false);
    }, 2800);
  };

  return (
    <section className="relative w-full py-28 px-6 md:px-12 bg-[#1a0033] text-[#f5f2ed] overflow-hidden border-t border-[#d4af37]/15">
      {/* Background Ambience & Dotted Grid */}
      <div
        className="absolute inset-0 pointer-events-none opacity-15"
        style={{
          backgroundImage: 'radial-gradient(#d4af37 0.5px, transparent 0.5px)',
          backgroundSize: '40px 40px',
        }}
      />

      <div className="max-w-7xl mx-auto relative z-10">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-16 gap-6">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 border border-[#d4af37]/30 bg-[#330066]/30 text-[#d4af37] text-[10px] font-sans tracking-[0.3em] uppercase mb-3">
              <Activity className="w-3 h-3 text-[#d4af37]" />
              <span>Chapter III — Continuous Pipeline</span>
            </div>
            <h2 className="text-4xl sm:text-5xl md:text-6xl font-editorial font-light tracking-tight text-[#f5f2ed]">
              THE CHOCOLATE <span className="italic font-serif text-[#d4af37]">FACTORY</span>
            </h2>
            <p className="max-w-xl text-sm sm:text-base text-[#f5f2ed]/70 font-sans font-light mt-3 leading-relaxed">
              Journey through the 8 stages of mastery. Observe continuous molten pipelines, precision Form V crystal tempering, and high-frequency acoustic de-aeration.
            </p>
          </div>

          {/* Quick Metrics Badge */}
          <div className="flex items-center gap-6 p-4 bg-[#0e001f]/80 border border-[#d4af37]/25 text-[10px] font-sans uppercase tracking-[0.25em]">
            <div>
              <span className="text-[#d4af37] block text-base font-bold">18 µm</span>
              <span className="text-[#f5f2ed]/60">Fineness</span>
            </div>
            <div className="w-px h-8 bg-[#d4af37]/20" />
            <div>
              <span className="text-[#d4af37] block text-base font-bold">1.5 Pints</span>
              <span className="text-[#f5f2ed]/60">Milk / Half-Lb</span>
            </div>
            <div className="w-px h-8 bg-[#d4af37]/20" />
            <div>
              <span className="text-[#d4af37] block text-base font-bold">100%</span>
              <span className="text-[#f5f2ed]/60">Sustainable</span>
            </div>
          </div>
        </div>

        {/* Live Pipeline Stepper Ribbon */}
        <div className="w-full overflow-x-auto pb-4 scrollbar-none mb-12">
          <div className="flex items-center min-w-max gap-3 p-2 bg-[#0e001f]/90 border border-[#d4af37]/20">
            {FACTORY_STEPS.map((step, idx) => {
              const isCurrent = idx === activeStepIndex;
              const isPast = idx < activeStepIndex;

              return (
                <button
                  key={step.id}
                  onClick={() => handleStepSelect(idx)}
                  className={`
                    flex items-center gap-3 px-4 py-3 transition-all duration-300 font-sans text-[10px] uppercase tracking-[0.25em]
                    ${isCurrent
                      ? 'bg-gradient-to-r from-[#330066] to-[#1a0033] border border-[#d4af37] text-[#f5f2ed] shadow-[0_0_20px_rgba(212,175,55,0.3)]'
                      : isPast
                      ? 'bg-[#330066]/30 text-[#d4af37] hover:bg-[#330066]/50'
                      : 'bg-white/5 text-[#f5f2ed]/50 hover:bg-white/10 hover:text-[#f5f2ed]'}
                  `}
                >
                  <div className={`p-1.5 ${isCurrent ? 'text-[#d4af37]' : 'text-white/60'}`}>
                    {getStepIcon(step.icon)}
                  </div>
                  <div className="text-left">
                    <span className="text-[8px] block opacity-70">Stage {step.number}</span>
                    <span className="truncate max-w-[120px]">{step.name.split(' ')[0]}</span>
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Active Stage Interactive Showcase Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch">
          
          {/* Left Column: Stage Detail & Live Viscosity/Temperature Chamber */}
          <div className="lg:col-span-7 flex flex-col justify-between p-8 md:p-10 bg-[#0e001f]/85 border border-[#d4af37]/25 shadow-2xl relative overflow-hidden">
            
            {/* Ambient Flow Background */}
            <div className="absolute top-0 right-0 w-72 h-72 bg-[#330066]/30 rounded-full blur-3xl pointer-events-none" />

            <div>
              <div className="flex items-center justify-between text-[10px] font-sans uppercase tracking-[0.3em] text-[#d4af37] mb-4">
                <span>Process Stage {activeStep.number} of 08</span>
                <span className="flex items-center gap-1.5 bg-[#1a0033] px-3 py-1 border border-[#d4af37]/30">
                  <span className="w-1.5 h-1.5 rounded-full bg-[#d4af37] animate-pulse" />
                  Active In Bournville
                </span>
              </div>

              <h3 className="text-3xl md:text-4xl font-editorial font-light text-[#f5f2ed] mb-2">
                {activeStep.name}
              </h3>
              <p className="text-sm md:text-base text-[#d4af37] italic font-light tracking-wide mb-6">
                "{activeStep.tagline}"
              </p>

              <p className="text-sm md:text-base text-[#f5f2ed]/80 font-sans font-light leading-relaxed mb-8">
                {activeStep.description}
              </p>

              {/* Stage Parameters */}
              <div className="grid grid-cols-3 gap-4 p-4 bg-[#1a0033]/80 border border-[#d4af37]/20 text-[10px] font-sans uppercase tracking-[0.2em] mb-8">
                <div>
                  <div className="flex items-center gap-1.5 text-[#d4af37] mb-1">
                    <Thermometer className="w-3.5 h-3.5" />
                    <span>Temperature</span>
                  </div>
                  <span className="text-sm sm:text-base font-bold text-[#f5f2ed]">{activeStep.temperature}</span>
                </div>
                <div>
                  <div className="flex items-center gap-1.5 text-[#d4af37] mb-1">
                    <Clock className="w-3.5 h-3.5" />
                    <span>Duration</span>
                  </div>
                  <span className="text-sm sm:text-base font-bold text-[#f5f2ed]">{activeStep.duration}</span>
                </div>
                <div>
                  <div className="flex items-center gap-1.5 text-[#d4af37] mb-1">
                    <Activity className="w-3.5 h-3.5" />
                    <span>State</span>
                  </div>
                  <span className="text-sm sm:text-base font-bold text-[#d4af37] truncate block">{activeStep.flowState}</span>
                </div>
              </div>
            </div>

            {/* Interactive Stage Controls */}
            <div className="pt-6 border-t border-[#d4af37]/20 flex flex-col sm:flex-row items-center justify-between gap-4">
              <div className="w-full sm:w-auto flex-1">
                <div className="flex justify-between text-[10px] font-sans uppercase tracking-[0.25em] text-[#d4af37] mb-2">
                  <span>Acoustic Conching Frequency</span>
                  <span className="text-[#f5f2ed]">{conchingSpeed} RPM</span>
                </div>
                <input
                  type="range"
                  min="30"
                  max="120"
                  value={conchingSpeed}
                  onChange={(e) => {
                    setConchingSpeed(Number(e.target.value));
                    audioEngine.playHover();
                  }}
                  className="w-full h-1.5 bg-[#330066] appearance-none cursor-pointer accent-[#d4af37]"
                />
              </div>

              <div className="flex items-center gap-3 w-full sm:w-auto">
                <button
                  onClick={() => handleStepSelect((activeStepIndex + 1) % FACTORY_STEPS.length)}
                  className="w-full sm:w-auto px-6 py-3 bg-[#330066]/40 border border-[#d4af37]/60 text-[#f5f2ed] font-sans text-[10px] uppercase tracking-[0.3em] hover:bg-[#d4af37] hover:text-[#1a0033] transition-all flex items-center justify-center gap-2"
                >
                  <span>Next Stage</span>
                  <ArrowRight className="w-3.5 h-3.5 text-[#d4af37]" />
                </button>
              </div>
            </div>
          </div>

          {/* Right Column: Live Transparent Pipeline & Moulding Simulation */}
          <div className="lg:col-span-5 flex flex-col justify-between p-8 bg-[#0e001f] border border-[#d4af37]/20 shadow-2xl relative">
            <div>
              <div className="flex items-center justify-between text-[10px] font-sans uppercase tracking-[0.3em] text-[#d4af37] mb-6">
                <span>Live Pipeline</span>
                <span>Glass Conduit #4</span>
              </div>

              {/* Transparent Pipe with Molten Chocolate Fluid Stream */}
              <div className="relative h-64 w-full bg-[#05000c] border border-[#d4af37]/30 overflow-hidden flex items-center justify-center p-4">
                {/* Glowing fluid reflections */}
                <div className="absolute inset-x-0 h-16 top-1/2 -translate-y-1/2 bg-gradient-to-r from-[#240e06] via-[#38160a] to-[#240e06] shadow-[0_0_40px_rgba(56,22,10,0.8)] flex items-center justify-around overflow-hidden">
                  <div className="absolute inset-0 bg-[linear-gradient(90deg,transparent_0%,rgba(212,175,55,0.3)_50%,transparent_100%)] animate-[chocolateFlow_4s_infinite_linear] bg-[length:200%_100%]" />
                  <div className="w-2.5 h-2.5 rounded-full bg-[#d4af37]/40 animate-ping" />
                  <div className="w-3.5 h-3.5 rounded-full bg-[#d4af37]/20 animate-pulse delay-150" />
                  <div className="w-2 h-2 rounded-full bg-[#d4af37]/50 animate-bounce delay-300" />
                </div>

                {/* Status Overlay */}
                <div className="relative z-10 text-center bg-[#1a0033]/90 backdrop-blur-md px-6 py-4 border border-[#d4af37]/40">
                  <span className="text-[9px] font-sans uppercase tracking-[0.3em] text-[#d4af37] block mb-1">
                    Continuous Flow Stream
                  </span>
                  <span className="font-editorial text-2xl text-[#f5f2ed]">
                    {isMouldingActive ? 'Mould Depositing...' : activeStep.flowState}
                  </span>
                </div>
              </div>

              {/* Moulding Sequence CTA */}
              <div className="mt-6 text-center">
                <button
                  onClick={triggerMouldingDemo}
                  disabled={isMouldingActive}
                  className="w-full py-3.5 bg-gradient-to-r from-[#330066] to-[#1a0033] border border-[#d4af37]/50 hover:border-[#d4af37] text-[#f5f2ed] font-sans text-[10px] uppercase tracking-[0.3em] transition-all hover:shadow-[0_0_25px_rgba(212,175,55,0.3)] disabled:opacity-50"
                >
                  {isMouldingActive ? '★ Crystallising in Thermal Tunnel...' : 'Trigger Moulding & Crystallisation →'}
                </button>
              </div>
            </div>

            {/* Bottom Section Link */}
            <div className="mt-8 pt-6 border-t border-[#d4af37]/20 flex items-center justify-between text-[10px] font-sans uppercase tracking-[0.25em]">
              <span className="text-[#f5f2ed]/60">Finished bars exit to dispatch</span>
              <button
                onClick={() => {
                  audioEngine.playHover();
                  onShopClick?.();
                }}
                className="text-[#d4af37] hover:text-[#f5f2ed] transition-colors flex items-center gap-1"
              >
                <span>Explore Products</span>
                <span>→</span>
              </button>
            </div>

          </div>

        </div>

      </div>
    </section>
  );
};
