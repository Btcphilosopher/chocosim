import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { audioEngine } from '../utils/audio';

interface ChocolateFountainProps {
  fidelity?: 'ultra' | 'high' | 'mobile' | 'reduced-motion';
  onExploreClick?: () => void;
  onStoryClick?: () => void;
}

export const ChocolateFountain3D: React.FC<ChocolateFountainProps> = ({
  fidelity = 'high',
  onExploreClick,
  onStoryClick,
}) => {
  const mountRef = useRef<HTMLDivElement>(null);
  const [rippleCount, setRippleCount] = useState<number>(0);
  const [isInteracting, setIsInteracting] = useState<boolean>(false);

  useEffect(() => {
    if (!mountRef.current) return;
    const container = mountRef.current;
    const width = container.clientWidth || window.innerWidth;
    const height = container.clientHeight || window.innerHeight;

    // Scene
    const scene = new THREE.Scene();
    scene.fog = new THREE.FogExp2(0x12002b, 0.045);

    // Camera
    const camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 100);
    camera.position.set(0, 2.2, 5.8);
    camera.lookAt(0, 0.4, 0);

    // Renderer
    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true, powerPreference: 'high-performance' });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, fidelity === 'ultra' ? 2 : 1.5));
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.2;
    container.appendChild(renderer.domElement);

    // Lighting
    const ambientLight = new THREE.AmbientLight(0x23085a, 1.4);
    scene.add(ambientLight);

    const goldKeyLight = new THREE.DirectionalLight(0xe5c378, 3.5);
    goldKeyLight.position.set(3, 6, 4);
    scene.add(goldKeyLight);

    const purpleRimLight = new THREE.PointLight(0x7b1158, 4.0, 15);
    purpleRimLight.position.set(-4, 3, -2);
    scene.add(purpleRimLight);

    const bottomWarmLight = new THREE.PointLight(0xd4af37, 2.5, 8);
    bottomWarmLight.position.set(0, -0.5, 2);
    scene.add(bottomWarmLight);

    // Materials
    const chocolateMaterial = new THREE.MeshPhysicalMaterial({
      color: 0x220b04,
      emissive: 0x0f0402,
      roughness: 0.15,
      metalness: 0.1,
      clearcoat: 1.0,
      clearcoatRoughness: 0.1,
      reflectivity: 0.9,
    });

    const goldMaterial = new THREE.MeshStandardMaterial({
      color: 0xc9a050,
      roughness: 0.25,
      metalness: 0.85,
    });

    // Fountain Pedestal & Architectural Tiers
    const fountainGroup = new THREE.Group();

    // Base Pool Rim
    const baseRimGeo = new THREE.TorusGeometry(1.6, 0.08, 16, 64);
    baseRimGeo.rotateX(Math.PI / 2);
    const baseRimMesh = new THREE.Mesh(baseRimGeo, goldMaterial);
    baseRimMesh.position.y = -0.7;
    fountainGroup.add(baseRimMesh);

    // Liquid Pool Surface
    const poolGeo = new THREE.CircleGeometry(1.58, 64);
    poolGeo.rotateX(-Math.PI / 2);
    const poolMesh = new THREE.Mesh(poolGeo, chocolateMaterial);
    poolMesh.position.y = -0.7;
    fountainGroup.add(poolMesh);

    // Middle Tier Bowl
    const midTierBowlGeo = new THREE.CylinderGeometry(0.9, 0.5, 0.3, 32, 1, true);
    const midTierBowl = new THREE.Mesh(midTierBowlGeo, goldMaterial);
    midTierBowl.position.y = 0.2;
    fountainGroup.add(midTierBowl);

    const midPoolGeo = new THREE.CircleGeometry(0.88, 32);
    midPoolGeo.rotateX(-Math.PI / 2);
    const midPoolMesh = new THREE.Mesh(midPoolGeo, chocolateMaterial);
    midPoolMesh.position.y = 0.3;
    fountainGroup.add(midPoolMesh);

    // Top Crown Spout
    const topSpoutGeo = new THREE.CylinderGeometry(0.4, 0.2, 0.4, 32);
    const topSpout = new THREE.Mesh(topSpoutGeo, goldMaterial);
    topSpout.position.y = 1.1;
    fountainGroup.add(topSpout);

    // Central Pillar
    const pillarGeo = new THREE.CylinderGeometry(0.18, 0.24, 2.2, 32);
    const pillar = new THREE.Mesh(pillarGeo, goldMaterial);
    pillar.position.y = 0.2;
    fountainGroup.add(pillar);

    // Flowing Chocolate Streams (Layered Morphing Cylinders / Domes)
    const stream1Geo = new THREE.CylinderGeometry(0.42, 0.88, 0.8, 32, 16, true);
    const stream1 = new THREE.Mesh(stream1Geo, chocolateMaterial);
    stream1.position.y = 0.7;
    fountainGroup.add(stream1);

    const stream2Geo = new THREE.CylinderGeometry(0.92, 1.58, 0.95, 32, 16, true);
    const stream2 = new THREE.Mesh(stream2Geo, chocolateMaterial);
    stream2.position.y = -0.22;
    fountainGroup.add(stream2);

    // Floating Gold Dust / Chocolate Sparkle Particles
    const particleCount = fidelity === 'ultra' ? 240 : 120;
    const particleGeo = new THREE.BufferGeometry();
    const particlePositions = new Float32Array(particleCount * 3);
    const particleScales = new Float32Array(particleCount);

    for (let i = 0; i < particleCount; i++) {
      particlePositions[i * 3] = (Math.random() - 0.5) * 6;
      particlePositions[i * 3 + 1] = Math.random() * 4 - 1;
      particlePositions[i * 3 + 2] = (Math.random() - 0.5) * 4;
      particleScales[i] = Math.random() * 0.05 + 0.015;
    }

    particleGeo.setAttribute('position', new THREE.BufferAttribute(particlePositions, 3));
    particleGeo.setAttribute('scale', new THREE.BufferAttribute(particleScales, 1));

    const particleMat = new THREE.PointsMaterial({
      color: 0xe5c378,
      size: 0.05,
      transparent: true,
      opacity: 0.75,
      blending: THREE.AdditiveBlending,
    });

    const particles = new THREE.Points(particleGeo, particleMat);
    fountainGroup.add(particles);

    scene.add(fountainGroup);

    // Mouse Interaction
    let mouseX = 0;
    let mouseY = 0;
    let targetX = 0;
    let targetY = 0;

    const handleMouseMove = (e: MouseEvent) => {
      const rect = container.getBoundingClientRect();
      const x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
      const y = -(((e.clientY - rect.top) / rect.height) * 2 - 1);
      targetX = x * 0.45;
      targetY = y * 0.25;
    };

    window.addEventListener('mousemove', handleMouseMove);

    // Animation Loop
    let animationFrameId: number;
    let clock = new THREE.Clock();

    const animate = () => {
      animationFrameId = requestAnimationFrame(animate);
      const elapsedTime = clock.getElapsedTime();

      // Smooth camera / group parallax
      mouseX += (targetX - mouseX) * 0.05;
      mouseY += (targetY - mouseY) * 0.05;

      fountainGroup.rotation.y = elapsedTime * 0.12 + mouseX * 0.4;
      fountainGroup.position.x = mouseX * 0.2;
      fountainGroup.position.y = mouseY * 0.15;

      // Flowing Chocolate Morphing Wave simulation
      const stream1Pos = stream1Geo.attributes.position;
      for (let i = 0; i < stream1Pos.count; i++) {
        const u = stream1Pos.getY(i);
        const angle = Math.atan2(stream1Pos.getZ(i), stream1Pos.getX(i));
        const wave = Math.sin(u * 12 - elapsedTime * 5 + angle * 3) * 0.012;
        const radius = (0.42 + (0.88 - 0.42) * (0.4 - u) / 0.8) + wave;
        stream1Pos.setX(i, Math.cos(angle) * radius);
        stream1Pos.setZ(i, Math.sin(angle) * radius);
      }
      stream1Pos.needsUpdate = true;

      const stream2Pos = stream2Geo.attributes.position;
      for (let i = 0; i < stream2Pos.count; i++) {
        const u = stream2Pos.getY(i);
        const angle = Math.atan2(stream2Pos.getZ(i), stream2Pos.getX(i));
        const wave = Math.sin(u * 10 - elapsedTime * 4.5 + angle * 4) * 0.018;
        const radius = (0.92 + (1.58 - 0.92) * (0.47 - u) / 0.95) + wave;
        stream2Pos.setX(i, Math.cos(angle) * radius);
        stream2Pos.setZ(i, Math.sin(angle) * radius);
      }
      stream2Pos.needsUpdate = true;

      // Liquid pool ripple
      const poolPos = poolGeo.attributes.position;
      for (let i = 0; i < poolPos.count; i++) {
        const dist = Math.sqrt(poolPos.getX(i) ** 2 + poolPos.getY(i) ** 2);
        poolPos.setZ(i, Math.sin(dist * 9 - elapsedTime * 4) * 0.025);
      }
      poolPos.needsUpdate = true;

      // Particle floating
      const pPositions = particleGeo.attributes.position.array as Float32Array;
      for (let i = 0; i < particleCount; i++) {
        pPositions[i * 3 + 1] += 0.003;
        if (pPositions[i * 3 + 1] > 3) {
          pPositions[i * 3 + 1] = -0.8;
        }
      }
      particleGeo.attributes.position.needsUpdate = true;

      // Light pulsing
      goldKeyLight.position.x = 3 + Math.sin(elapsedTime * 0.8) * 0.8;
      purpleRimLight.intensity = 3.5 + Math.sin(elapsedTime * 1.5) * 0.6;

      renderer.render(scene, camera);
    };

    animate();

    const handleResize = () => {
      if (!container) return;
      const w = container.clientWidth;
      const h = container.clientHeight;
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
    };

    window.addEventListener('resize', handleResize);

    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('resize', handleResize);
      cancelAnimationFrame(animationFrameId);
      if (container.contains(renderer.domElement)) {
        container.removeChild(renderer.domElement);
      }
      renderer.dispose();
    };
  }, [fidelity]);

  const handleFountainClick = () => {
    setRippleCount((prev) => prev + 1);
    setIsInteracting(true);
    audioEngine.playChocolateRipple();
    setTimeout(() => setIsInteracting(false), 800);
  };

  return (
    <div className="relative w-full min-h-[92vh] md:min-h-screen flex items-center justify-center overflow-hidden bg-[#1a0033] text-[#f5f2ed]">
      
      {/* Background Dotted Radial Grid */}
      <div
        className="absolute inset-0 pointer-events-none opacity-20 z-0"
        style={{
          backgroundImage: 'radial-gradient(#d4af37 0.5px, transparent 0.5px)',
          backgroundSize: '40px 40px',
        }}
      />

      {/* Atmospheric Vignette */}
      <div className="absolute inset-0 z-0 pointer-events-none opacity-40 bg-[radial-gradient(ellipse_at_center,_rgba(77,0,153,0.3)_0%,_rgba(26,0,51,0.9)_70%)]" />

      {/* Watermarked Background Headline */}
      <h1 className="text-[90px] sm:text-[140px] md:text-[170px] leading-[0.8] font-bold tracking-tighter opacity-10 select-none absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 whitespace-nowrap text-[#f5f2ed] pointer-events-none z-0 font-serif">
        GENERATIONS
      </h1>

      {/* Left Chapter Badge Indicator (Desktop) */}
      <div className="hidden lg:flex absolute left-12 top-1/2 -translate-y-1/2 flex-col gap-8 z-20 pointer-events-auto">
        <div className="flex flex-col">
          <span className="text-[10px] font-sans uppercase tracking-[0.4em] text-[#d4af37] mb-2">
            Chapter I
          </span>
          <span className="text-4xl font-light italic font-editorial text-[#f5f2ed]">
            The Fountain
          </span>
        </div>
        <div className="w-px h-32 bg-gradient-to-b from-[#d4af37] to-transparent ml-2" />
      </div>

      {/* Right "Next Experience" Anchor (Desktop) */}
      <div className="hidden lg:flex absolute right-12 bottom-28 flex-col items-end gap-6 z-20 pointer-events-auto">
        <div
          onClick={() => {
            audioEngine.playChocolateSnap();
            const el = document.getElementById('break-square');
            el?.scrollIntoView({ behavior: 'smooth' });
          }}
          className="group cursor-pointer text-right"
        >
          <div className="text-[10px] font-sans uppercase tracking-[0.2em] text-[#d4af37]/70 mb-1">
            Next Experience
          </div>
          <div className="text-2xl italic font-light flex items-center gap-4 text-[#f5f2ed] group-hover:text-[#d4af37] transition-colors">
            <span>The 3D Fracture</span>
            <span className="w-12 h-px bg-[#d4af37] group-hover:w-16 transition-all" />
          </div>
        </div>
      </div>

      {/* Central Architectural Arched Portal with 3D WebGL Canvas */}
      <div className="relative z-10 w-full max-w-7xl mx-auto px-6 py-12 flex flex-col items-center justify-between min-h-[85vh]">
        
        {/* Top Tagline */}
        <div className="w-full flex items-center justify-between text-[10px] tracking-[0.35em] uppercase text-[#d4af37] font-sans mb-6">
          <div className="flex items-center gap-3">
            <span className="w-8 h-px bg-[#d4af37]/60" />
            <span>Liquid Architecture</span>
          </div>
          <div className="hidden sm:flex items-center gap-3">
            <span>52.4297° N, 1.9351° W — Bournville</span>
            <span className="w-8 h-px bg-[#d4af37]/60" />
          </div>
        </div>

        {/* The Grand Arched Portal */}
        <div className="relative my-auto flex flex-col items-center">
          <div
            className="w-[320px] sm:w-[420px] md:w-[460px] h-[480px] sm:h-[540px] mx-auto rounded-t-full bg-gradient-to-b from-[#330066] to-[#1a0033] border border-[#d4af37]/30 relative overflow-hidden shadow-[0_20px_60px_rgba(0,0,0,0.8)] group cursor-pointer"
            onClick={handleFountainClick}
          >
            {/* Subtle Inner Tint & Glow */}
            <div className="absolute inset-0 bg-[#000]/20 pointer-events-none z-10" />
            <div className="absolute top-0 left-1/2 -translate-x-1/2 w-1 h-full bg-gradient-to-b from-[#d4af37] via-[#d4af37]/40 to-transparent opacity-60 pointer-events-none z-10" />
            <div className="absolute top-1/4 left-1/2 -translate-x-1/2 w-[280px] h-[350px] bg-gradient-to-b from-[#4d0099] to-transparent rounded-full blur-3xl opacity-35 pointer-events-none z-10" />
            
            {/* 3D WebGL Canvas Layer */}
            <div ref={mountRef} className="absolute inset-0 z-10 cursor-pointer pointer-events-auto" />

            {/* Bottom Gradient Shade for Caption */}
            <div className="absolute bottom-0 w-full h-1/2 bg-gradient-to-t from-[#1a0033] via-[#1a0033]/70 to-transparent z-20 pointer-events-none" />

            {/* Bottom Caption inside Arch */}
            <div className="absolute bottom-8 sm:bottom-12 left-1/2 -translate-x-1/2 text-center z-30 w-full px-6 pointer-events-none">
              <p className="text-[10px] sm:text-[11px] font-sans uppercase tracking-[0.5em] mb-2 text-[#d4af37]">
                Liquid Architecture
              </p>
              <p className="text-base sm:text-lg italic font-light text-[#f5f2ed] max-w-xs mx-auto leading-relaxed">
                A continuous flow of pure joy, reimagined for a digital century.
              </p>
            </div>
          </div>

          {/* Golden Horizontal Glow Line Beneath Arch */}
          <div className="w-[300px] sm:w-[500px] md:w-[600px] h-1 bg-[#d4af37] opacity-40 blur-sm mt-1" />

          {/* Interactive Actions Beneath Arch */}
          <div className="flex flex-wrap items-center justify-center gap-4 mt-8 pointer-events-auto z-20">
            <button
              onClick={() => {
                audioEngine.playChocolateSnap();
                onExploreClick?.();
              }}
              className="px-8 py-3.5 bg-gradient-to-r from-[#330066] to-[#1a0033] border border-[#d4af37]/60 text-[#f5f2ed] font-sans text-[10px] tracking-[0.3em] uppercase transition-all duration-300 hover:border-[#d4af37] hover:shadow-[0_0_25px_rgba(212,175,55,0.4)] flex items-center gap-3"
            >
              <span>Explore Collection</span>
              <span className="text-[#d4af37]">→</span>
            </button>

            <button
              onClick={() => {
                audioEngine.playHover();
                onStoryClick?.();
              }}
              className="px-8 py-3.5 border border-[#d4af37]/30 text-[#f5f2ed]/80 font-sans text-[10px] tracking-[0.3em] uppercase bg-[#1a0033]/80 backdrop-blur-md transition-all duration-300 hover:border-[#d4af37] hover:text-[#f5f2ed] flex items-center gap-3"
            >
              <span>Our Story</span>
              <span className="text-[#d4af37]">→</span>
            </button>
          </div>
        </div>

        {/* Bottom Interactive Dial & Coordinates Row */}
        <div className="w-full flex items-center justify-between text-[10px] font-sans uppercase tracking-[0.3em] text-[#d4af37] pt-6 border-t border-[#d4af37]/15">
          <div className="flex items-center gap-3">
            <button
              onClick={handleFountainClick}
              className="flex items-center gap-2 px-3 py-1.5 rounded-full border border-[#d4af37]/30 bg-[#330066]/30 hover:border-[#d4af37] hover:text-[#f5f2ed] transition-colors"
            >
              <span className="inline-block w-1.5 h-1.5 rounded-full bg-[#d4af37] animate-pulse" />
              <span>Ripple Fountain ({rippleCount})</span>
            </button>
          </div>

          <div className="flex items-center gap-6">
            <div className="hidden sm:flex items-center gap-3 text-[#f5f2ed]/60">
              <span>Modernist Digital House</span>
            </div>
            <div
              onClick={() => {
                audioEngine.playGoldChime();
                onExploreClick?.();
              }}
              className="w-10 h-10 rounded-full border border-[#d4af37]/40 flex items-center justify-center relative group cursor-pointer overflow-hidden hover:border-[#d4af37]"
              title="Enter Atelier Space"
            >
              <div className="absolute inset-0 bg-[#d4af37]/10 translate-y-full group-hover:translate-y-0 transition-transform duration-500" />
              <span className="text-[9px] font-sans text-[#d4af37] relative z-10">✦</span>
            </div>
          </div>
        </div>

      </div>
    </div>
  );
};
