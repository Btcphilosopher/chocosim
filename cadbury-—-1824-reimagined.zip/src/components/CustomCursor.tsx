import React, { useEffect, useState } from 'react';

export const CustomCursor: React.FC = () => {
  const [position, setPosition] = useState({ x: -100, y: -100 });
  const [cursorText, setCursorText] = useState<string>('');
  const [isHovering, setIsHovering] = useState<boolean>(false);
  const [isTouchDevice, setIsTouchDevice] = useState<boolean>(false);

  useEffect(() => {
    // Check touch device
    if (typeof window !== 'undefined' && ('ontouchstart' in window || navigator.maxTouchPoints > 0)) {
      setIsTouchDevice(true);
      return;
    }

    const handleMouseMove = (e: MouseEvent) => {
      setPosition({ x: e.clientX, y: e.clientY });

      // Check hovered element
      const target = e.target as HTMLElement | null;
      if (target) {
        if (target.closest('button') || target.closest('a')) {
          setIsHovering(true);
          setCursorText('');
        } else if (target.closest('.chocolate-bevel')) {
          setIsHovering(true);
          setCursorText('SNAP');
        } else if (target.closest('[id="collection"]')) {
          setIsHovering(false);
          setCursorText('TASTE');
        } else {
          setIsHovering(false);
          setCursorText('');
        }
      }
    };

    window.addEventListener('mousemove', handleMouseMove);
    return () => window.removeEventListener('mousemove', handleMouseMove);
  }, []);

  if (isTouchDevice) return null;

  return (
    <div
      className="fixed pointer-events-none z-50 transition-transform duration-75 ease-out -translate-x-1/2 -translate-y-1/2"
      style={{ left: `${position.x}px`, top: `${position.y}px` }}
    >
      <div
        className={`
          flex items-center justify-center border border-[#d4af37] transition-all duration-300
          ${
            cursorText
              ? 'w-16 h-16 bg-[#0e001f]/90 backdrop-blur-md shadow-[0_0_20px_rgba(212,175,55,0.6)] scale-100'
              : isHovering
              ? 'w-10 h-10 bg-[#330066]/60 backdrop-blur-xs scale-125'
              : 'w-3 h-3 bg-[#d4af37] scale-100'
          }
        `}
      >
        {cursorText && (
          <span className="font-sans text-[8px] tracking-[0.25em] text-[#d4af37] font-bold uppercase">
            {cursorText}
          </span>
        )}
      </div>
    </div>
  );
};
