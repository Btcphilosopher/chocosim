import React, { useState } from 'react';
import { audioEngine } from '../utils/audio';
import { Sparkles, ArrowRight, ShieldCheck, Heart } from 'lucide-react';

interface FooterProps {
  onNavigate: (sectionId: string) => void;
}

export const Footer: React.FC<FooterProps> = ({ onNavigate }) => {
  const [email, setEmail] = useState('');
  const [subscribed, setSubscribed] = useState(false);
  const [squareSplit, setSquareSplit] = useState(false);

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) return;
    audioEngine.playGoldChime();
    setSubscribed(true);
  };

  const handleSquareClick = () => {
    audioEngine.playChocolateSnap();
    setSquareSplit(!squareSplit);
  };

  return (
    <footer className="relative w-full bg-[#0e001f] border-t border-[#d4af37]/20 text-[#f5f2ed] pt-24 pb-12 px-6 md:px-12 overflow-hidden">
      
      {/* Background Ambience & Dotted Grid */}
      <div
        className="absolute inset-0 pointer-events-none opacity-15"
        style={{
          backgroundImage: 'radial-gradient(#d4af37 0.5px, transparent 0.5px)',
          backgroundSize: '40px 40px',
        }}
      />

      <div className="max-w-7xl mx-auto relative z-10">
        
        {/* Top Newsletter & Confectionery Club */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 pb-20 border-b border-[#d4af37]/15">
          <div className="lg:col-span-6">
            <div className="inline-flex items-center gap-2 px-3 py-1 border border-[#d4af37]/30 bg-[#330066]/30 text-[#d4af37] text-[10px] font-sans tracking-[0.3em] uppercase mb-4">
              <Sparkles className="w-3 h-3 text-[#d4af37]" />
              <span>The Cadbury Tasting Salon</span>
            </div>
            <h3 className="text-3xl sm:text-4xl font-editorial font-light text-[#f5f2ed] mb-3">
              Receive Invitations to Private Bournville Reserves
            </h3>
            <p className="text-sm text-[#f5f2ed]/70 font-sans font-light max-w-md">
              Enjoy complimentary seasonal release tastings, masterclass invitations, and exclusive personalised gift privileges.
            </p>
          </div>

          <div className="lg:col-span-6 flex flex-col justify-center">
            {subscribed ? (
              <div className="p-4 bg-[#330066]/40 border border-[#d4af37]/40 text-center">
                <span className="font-editorial text-lg text-[#d4af37]">
                  Welcome to the 1824 Confectionery Circle
                </span>
                <p className="text-xs text-[#f5f2ed]/70 mt-1 font-sans">
                  A verification invitation has been dispatched to your inbox.
                </p>
              </div>
            ) : (
              <form onSubmit={handleSubscribe} className="flex flex-col sm:flex-row gap-3">
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="Enter your email address..."
                  required
                  className="flex-1 px-5 py-3.5 bg-[#1a0033] border border-[#d4af37]/30 text-[#f5f2ed] font-sans text-xs uppercase tracking-wider focus:outline-none focus:border-[#d4af37]"
                />
                <button
                  type="submit"
                  className="px-8 py-3.5 bg-[#d4af37] hover:bg-[#ebd89b] text-[#1a0033] font-sans font-bold text-[10px] uppercase tracking-[0.3em] transition-all flex items-center justify-center gap-2 whitespace-nowrap active:scale-95"
                >
                  <span>Join Atelier</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </form>
            )}
            <span className="text-[9px] font-sans uppercase tracking-[0.2em] text-[#f5f2ed]/40 mt-3">
              By subscribing you agree to Cadbury UK terms and privacy policy. 100% spam-free.
            </span>
          </div>
        </div>

        {/* Middle Navigation Columns */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-8 py-16 text-[10px] font-sans tracking-[0.25em] uppercase">
          <div>
            <h4 className="text-[#d4af37] font-bold mb-4">The Collection</h4>
            <ul className="space-y-2.5 text-[#f5f2ed]/70">
              <li><button onClick={() => onNavigate('collection')} className="hover:text-[#d4af37] transition-colors">Dairy Milk Classic</button></li>
              <li><button onClick={() => onNavigate('collection')} className="hover:text-[#d4af37] transition-colors">Signature Grand Cru</button></li>
              <li><button onClick={() => onNavigate('collection')} className="hover:text-[#d4af37] transition-colors">1824 Heritage Dark 70%</button></li>
              <li><button onClick={() => onNavigate('collection')} className="hover:text-[#d4af37] transition-colors">Roses Keepsake Tins</button></li>
            </ul>
          </div>

          <div>
            <h4 className="text-[#d4af37] font-bold mb-4">Our Heritage</h4>
            <ul className="space-y-2.5 text-[#f5f2ed]/70">
              <li><button onClick={() => onNavigate('heritage')} className="hover:text-[#d4af37] transition-colors">Bull Street 1824</button></li>
              <li><button onClick={() => onNavigate('heritage')} className="hover:text-[#d4af37] transition-colors">Bournville Garden Village</button></li>
              <li><button onClick={() => onNavigate('heritage')} className="hover:text-[#d4af37] transition-colors">Quaker Welfare Model</button></li>
              <li><button onClick={() => onNavigate('future')} className="hover:text-[#d4af37] transition-colors">The Next 200 Years</button></li>
            </ul>
          </div>

          <div>
            <h4 className="text-[#d4af37] font-bold mb-4">Craft & Quality</h4>
            <ul className="space-y-2.5 text-[#f5f2ed]/70">
              <li><button onClick={() => onNavigate('factory')} className="hover:text-[#d4af37] transition-colors">Continuous Pipelines</button></li>
              <li><button onClick={() => onNavigate('factory')} className="hover:text-[#d4af37] transition-colors">Form V Crystal Tempering</button></li>
              <li><button onClick={() => onNavigate('sustainability')} className="hover:text-[#d4af37] transition-colors">Cocoa Life Programme</button></li>
              <li><button onClick={() => onNavigate('gifting')} className="hover:text-[#d4af37] transition-colors">Bespoke Gifting Studio</button></li>
            </ul>
          </div>

          <div>
            <h4 className="text-[#d4af37] font-bold mb-4">Visit Bournville</h4>
            <ul className="space-y-2.5 text-[#f5f2ed]/70">
              <li><a href="#visit" className="hover:text-[#d4af37] transition-colors">Cadbury World Tickets</a></li>
              <li><a href="#tours" className="hover:text-[#d4af37] transition-colors">Master Chocolatier Tours</a></li>
              <li><a href="#afternoon-tea" className="hover:text-[#d4af37] transition-colors">Chocolate Afternoon Tea</a></li>
              <li><a href="#directions" className="hover:text-[#d4af37] transition-colors">Getting to Birmingham</a></li>
            </ul>
          </div>
        </div>

        {/* Signature Cinematic Closing Crest with Interactive Split Square */}
        <div className="pt-16 pb-8 flex flex-col items-center text-center border-t border-[#d4af37]/15">
          
          {/* Falling Split Square Animation Element */}
          <div
            onClick={handleSquareClick}
            className="group cursor-pointer mb-6 flex items-center justify-center gap-1 p-3 bg-[#1a0033] border border-[#d4af37]/30 hover:border-[#d4af37] transition-all hover:scale-105"
            title="Click to snap chocolate square"
          >
            <div
              className={`w-6 h-6 bg-[#3a180b] border border-[#5c2b14] transition-transform duration-500 shadow-md ${
                squareSplit ? '-translate-x-2 -rotate-12' : ''
              }`}
            />
            <div
              className={`w-6 h-6 bg-[#3a180b] border border-[#5c2b14] transition-transform duration-500 shadow-md ${
                squareSplit ? 'translate-x-2 rotate-12' : ''
              }`}
            />
          </div>

          {/* Cadbury Script Signature */}
          <div className="font-editorial italic text-5xl sm:text-6xl text-[#f5f2ed] tracking-normal mb-1">
            Cadbury
          </div>

          {/* 1824 Seal */}
          <div className="font-sans text-[10px] tracking-[0.4em] uppercase text-[#d4af37] mb-4">
            1824 • BOURNVILLE • 2026
          </div>

          {/* Gold Drawing Line */}
          <div className="w-48 h-px bg-gradient-to-r from-transparent via-[#d4af37] to-transparent mb-6" />

          {/* Final Motto */}
          <div className="font-editorial text-2xl sm:text-3xl text-[#d4af37] font-light tracking-wide uppercase">
            Generations <span className="italic font-serif">of Joy</span>
          </div>

          <p className="text-[9px] font-sans uppercase tracking-[0.3em] text-[#f5f2ed]/40 mt-8">
            © 1824–2026 CADBURY UK • BOURNVILLE, BIRMINGHAM • MONDELEZ INTERNATIONAL
          </p>
        </div>

      </div>
    </footer>
  );
};
