import React from 'react';
import { Sparkles, Cpu, Recycle, Atom, ArrowRight } from 'lucide-react';
import { audioEngine } from '../utils/audio';

interface FutureProps {
  onDiscoverClick?: () => void;
}

export const FutureOfChocolate: React.FC<FutureProps> = ({ onDiscoverClick }) => {
  const pillars = [
    {
      icon: <Atom className="w-5 h-5 text-[#d4af37]" />,
      title: 'Precision Crystal Polymorphism',
      desc: 'Form VI super-stable cocoa butter lattices engineered at sub-nanometer scale for melting points calibrated precisely to human body temperature (37.0°C).',
    },
    {
      icon: <Recycle className="w-5 h-5 text-[#d4af37]" />,
      title: '100% Circular Cocoa Biomaterials',
      desc: 'Zero-waste production transforming 100% of discarded cocoa pod shells into biodegradable luxury packaging that naturally dissolves into soil nutrients in 14 days.',
    },
    {
      icon: <Cpu className="w-5 h-5 text-[#d4af37]" />,
      title: 'Acoustic Vacuum Conching',
      desc: 'Solar-powered sonic chambers purifying raw cocoa esters in minutes without thermal degradation, preserving delicate antioxidant flavonoids.',
    },
  ];

  return (
    <section className="relative w-full py-28 px-6 md:px-12 bg-[#1a0033] text-[#f5f2ed] overflow-hidden border-t border-[#d4af37]/15">
      
      {/* Background Ambience & Dotted Grid */}
      <div
        className="absolute inset-0 pointer-events-none opacity-15"
        style={{
          backgroundImage: 'radial-gradient(#d4af37 0.5px, transparent 0.5px)',
          backgroundSize: '40px 40px',
        }}
      />

      <div className="max-w-7xl mx-auto relative z-10">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-20">
          <div className="inline-flex items-center gap-2 px-3 py-1 border border-[#d4af37]/30 bg-[#330066]/30 text-[#d4af37] text-[10px] font-sans tracking-[0.3em] uppercase mb-3">
            <Sparkles className="w-3 h-3 text-[#d4af37]" />
            <span>Chapter VI — Sensory Horizons</span>
          </div>
          <h2 className="text-4xl sm:text-6xl md:text-7xl font-editorial font-light tracking-tight text-[#f5f2ed]">
            THE NEXT <span className="italic font-serif text-[#d4af37]">200 YEARS</span>
          </h2>
          <p className="text-sm sm:text-base md:text-lg text-[#f5f2ed]/70 font-sans font-light mt-4 leading-relaxed">
            Where British industrial craft merges with quantum confectionery science. Optimistic, sustainable, and uncompromisingly delicious.
          </p>
        </div>

        {/* 3 Futuristic Pillars */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
          {pillars.map((p, idx) => (
            <div
              key={idx}
              className="p-8 bg-[#0e001f]/85 border border-[#d4af37]/20 hover:border-[#d4af37]/60 transition-all duration-500 hover:-translate-y-1 hover:shadow-[0_0_30px_rgba(212,175,55,0.2)] flex flex-col justify-between group"
            >
              <div>
                <div className="w-12 h-12 bg-[#330066]/50 border border-[#d4af37]/30 flex items-center justify-center mb-6 group-hover:scale-105 transition-transform">
                  {p.icon}
                </div>
                <h3 className="text-2xl font-editorial text-[#f5f2ed] mb-3 group-hover:text-[#d4af37] transition-colors">
                  {p.title}
                </h3>
                <p className="text-xs sm:text-sm text-[#f5f2ed]/75 font-sans font-light leading-relaxed">
                  {p.desc}
                </p>
              </div>

              <div className="pt-6 border-t border-[#d4af37]/15 mt-8 flex items-center justify-between text-[10px] font-sans uppercase tracking-[0.25em] text-[#d4af37]">
                <span>Bournville Lab 2124</span>
                <span>Active Research</span>
              </div>
            </div>
          ))}
        </div>

        {/* Callout Banner */}
        <div className="p-8 md:p-12 bg-gradient-to-r from-[#330066]/80 via-[#1a0033] to-[#0e001f] border border-[#d4af37]/40 shadow-2xl flex flex-col md:flex-row items-center justify-between gap-6">
          <div>
            <span className="text-[10px] font-sans tracking-[0.3em] text-[#d4af37] uppercase block mb-1">
              Join the Sensory Vanguard
            </span>
            <h3 className="text-3xl font-editorial text-[#f5f2ed]">
              Experience the Future of Chocolate First
            </h3>
            <p className="text-xs sm:text-sm text-[#f5f2ed]/70 font-sans mt-1">
              Be invited to exclusive Bournville tasting laboratory previews and bespoke allocations.
            </p>
          </div>

          <button
            onClick={() => {
              audioEngine.playChocolateSnap();
              onDiscoverClick?.();
            }}
            className="px-8 py-3.5 bg-[#d4af37] hover:bg-[#ebd89b] text-[#1a0033] font-sans font-bold text-[10px] uppercase tracking-[0.3em] shadow-xl hover:scale-105 transition-all flex items-center gap-3 whitespace-nowrap"
          >
            <span>Explore The Signature Range</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

      </div>
    </section>
  );
};
