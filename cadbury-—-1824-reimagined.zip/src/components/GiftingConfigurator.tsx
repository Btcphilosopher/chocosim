import React, { useState } from 'react';
import { audioEngine } from '../utils/audio';
import { Product } from '../types';
import { Gift, Sparkles, Check, ArrowRight, Eye, RefreshCw } from 'lucide-react';

interface GiftingProps {
  onAddGiftToBag: (item: {
    product: Product;
    quantity: number;
    customMessage: string;
    giftBoxStyle: string;
  }) => void;
}

export const GiftingConfigurator: React.FC<GiftingProps> = ({ onAddGiftToBag }) => {
  const [step, setStep] = useState<number>(1);
  const [selectedAssortment, setSelectedAssortment] = useState<string>('grand-cru');
  const [selectedBox, setSelectedBox] = useState<string>('royal-purple');
  const [selectedRibbon, setSelectedRibbon] = useState<string>('molten-gold');
  const [customMessage, setCustomMessage] = useState<string>('With Love & Warmest Wishes');
  const [recipientName, setRecipientName] = useState<string>('Lady Eleanor');
  const [isUnboxingPreview, setIsUnboxingPreview] = useState<boolean>(false);

  const assortments = [
    {
      id: 'grand-cru',
      name: 'Grand Cru Ganache & Gianduja',
      desc: 'Single-origin Ghanaian cocoa, Piedmont roasted hazelnut & Cornish sea salt',
      pieces: '16 Artisan Chocolates',
      image: 'https://images.unsplash.com/photo-1548907040-4baa42d10919?auto=format&fit=crop&w=600&q=80',
    },
    {
      id: 'milk-silk',
      name: 'Dairy Milk Silk Heritage Truffles',
      desc: 'Iconic British milk cream centers dusted in fine cocoa velvet',
      pieces: '16 Artisan Chocolates',
      image: 'https://images.unsplash.com/photo-1549007994-cb92caebd54b?auto=format&fit=crop&w=600&q=80',
    },
    {
      id: 'dark-70',
      name: '1824 Reserve Dark 70% Medley',
      desc: 'Intense roasted notes, vanilla bean infusions & dark espresso ganache',
      pieces: '16 Artisan Chocolates',
      image: 'https://images.unsplash.com/photo-1606312619070-d48b4c652a52?auto=format&fit=crop&w=600&q=80',
    },
  ];

  const boxes = [
    { id: 'royal-purple', name: 'Cadbury Imperial Purple', hex: '#1a0033', border: '#d4af37', label: 'Signature Heritage' },
    { id: 'cream-gold', name: 'Bournville Ivory & Gold', hex: '#24103a', border: '#d4af37', textDark: false, label: 'Bespoke Atelier' },
    { id: 'midnight-noir', name: 'Midnight Velvet Noir', hex: '#0e001f', border: '#d4af37', label: 'Limited Reserve' },
  ];

  const ribbons = [
    { id: 'molten-gold', name: 'Molten Gold Satin', color: 'from-[#d4af37] to-[#997920]' },
    { id: 'royal-purple', name: 'Regal Purple Silk', color: 'from-[#4d0099] to-[#1a0033]' },
    { id: 'crimson-silk', name: 'Imperial Crimson', color: 'from-[#7c142c] to-[#3b0612]' },
    { id: 'champagne', name: 'Champagne Grosgrain', color: 'from-[#ebd89b] to-[#b89535]' },
  ];

  const handleStepClick = (targetStep: number) => {
    setStep(targetStep);
    audioEngine.playHover();
  };

  const handleUnbox = () => {
    setIsUnboxingPreview(true);
    audioEngine.playGiftOpen();
  };

  const handleAddToBag = () => {
    audioEngine.playChocolateSnap();
    const giftProduct: Product = {
      id: `custom-gift-${Date.now()}`,
      name: `Bespoke Cadbury Gift Box (${recipientName || 'Personalised'})`,
      tagline: `Tied in ${ribbons.find(r => r.id === selectedRibbon)?.name}`,
      category: 'gifting',
      price: 34.00,
      weight: '400g (16 Artisan Pieces)',
      cocoaPercentage: 50,
      description: `Bespoke gift box for ${recipientName}. Message: "${customMessage}". Assortment: ${assortments.find(a => a.id === selectedAssortment)?.name}`,
      tastingNotes: ['Artisan Handcrafted', 'Personalized Gold Foil Dedication'],
      ingredients: ['Custom selected confectionery ingredients'],
      image: 'https://images.unsplash.com/photo-1548907040-4baa42d10919?auto=format&fit=crop&w=800&q=80',
      accentColor: '#1a0033',
      origin: 'Crafted to Order, Bournville Atelier'
    };

    onAddGiftToBag({
      product: giftProduct,
      quantity: 1,
      customMessage: `${recipientName ? `To: ${recipientName} — ` : ''}${customMessage}`,
      giftBoxStyle: `${boxes.find(b => b.id === selectedBox)?.name} with ${ribbons.find(r => r.id === selectedRibbon)?.name}`
    });
  };

  return (
    <section id="gifting" className="relative w-full py-28 px-6 md:px-12 bg-[#1a0033] text-[#f5f2ed] overflow-hidden border-t border-[#d4af37]/15">
      
      {/* Background Ambience & Dotted Grid */}
      <div
        className="absolute inset-0 pointer-events-none opacity-15"
        style={{
          backgroundImage: 'radial-gradient(#d4af37 0.5px, transparent 0.5px)',
          backgroundSize: '40px 40px',
        }}
      />

      <div className="max-w-7xl mx-auto relative z-10">
        
        {/* Section Header */}
        <div className="text-center max-w-2xl mx-auto mb-16">
          <div className="inline-flex items-center gap-2 px-3 py-1 border border-[#d4af37]/30 bg-[#330066]/30 text-[#d4af37] text-[10px] font-sans tracking-[0.3em] uppercase mb-3">
            <Gift className="w-3 h-3 text-[#d4af37]" />
            <span>Chapter V — Bespoke Atelier</span>
          </div>
          <h2 className="text-4xl sm:text-5xl md:text-6xl font-editorial font-light tracking-tight text-[#f5f2ed]">
            MAKE IT <span className="italic font-serif text-[#d4af37]">PERSONAL</span>
          </h2>
          <p className="text-sm sm:text-base text-[#f5f2ed]/70 font-sans font-light mt-3 leading-relaxed">
            Design an exquisite Cadbury gift with hand-selected chocolates, hot-foil embossed messages, and hand-tied luxury satin ribbons.
          </p>
        </div>

        {/* 5-Step Stepper Navigation */}
        <div className="flex items-center justify-center gap-2 sm:gap-3 mb-12 overflow-x-auto pb-2">
          {[
            { num: 1, label: 'Chocolate' },
            { num: 2, label: 'Keepsake Box' },
            { num: 3, label: 'Satin Ribbon' },
            { num: 4, label: 'Dedication' },
            { num: 5, label: 'Preview' },
          ].map((s) => (
            <button
              key={s.num}
              onClick={() => handleStepClick(s.num)}
              className={`
                flex items-center gap-2 px-3 sm:px-4 py-2 text-[10px] font-sans tracking-[0.2em] uppercase transition-all
                ${
                  step === s.num
                    ? 'bg-gradient-to-r from-[#330066] to-[#1a0033] border border-[#d4af37] text-[#f5f2ed] shadow-md'
                    : 'bg-[#0e001f]/80 border border-[#d4af37]/20 text-[#f5f2ed]/60 hover:text-[#f5f2ed]'
                }
              `}
            >
              <span className="w-4 h-4 bg-black/40 flex items-center justify-center text-[9px] text-[#d4af37]">
                {s.num}
              </span>
              <span className="hidden sm:inline">{s.label}</span>
            </button>
          ))}
        </div>

        {/* Configurator Workspace Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
          
          {/* Left: Interactive Configurator Controls */}
          <div className="lg:col-span-7 p-6 sm:p-10 bg-[#0e001f]/85 border border-[#d4af37]/30 shadow-2xl backdrop-blur-xl">
            
            {/* STEP 1: CHOCOLATE ASSORTMENT */}
            {step === 1 && (
              <div>
                <h3 className="text-2xl font-editorial text-[#f5f2ed] mb-1">
                  1. Choose Your Chocolate Curation
                </h3>
                <p className="text-[10px] text-[#d4af37] font-sans uppercase tracking-[0.25em] mb-6">
                  Hand-finished in small batches by master chocolatiers
                </p>

                <div className="space-y-4">
                  {assortments.map((assortment) => (
                    <div
                      key={assortment.id}
                      onClick={() => {
                        setSelectedAssortment(assortment.id);
                        audioEngine.playHover();
                      }}
                      className={`
                        p-4 border transition-all cursor-pointer flex items-center gap-4
                        ${
                          selectedAssortment === assortment.id
                            ? 'bg-[#330066]/40 border-[#d4af37] shadow-[0_0_20px_rgba(212,175,55,0.25)]'
                            : 'bg-[#1a0033]/60 border-[#d4af37]/20 hover:border-[#d4af37]/50'
                        }
                      `}
                    >
                      <img
                        src={assortment.image}
                        alt={assortment.name}
                        className="w-16 h-16 object-cover border border-[#d4af37]/30"
                      />
                      <div className="flex-1">
                        <div className="flex items-center justify-between">
                          <h4 className="font-editorial text-lg text-[#f5f2ed]">{assortment.name}</h4>
                          <span className="text-[9px] font-sans uppercase tracking-[0.2em] text-[#d4af37] bg-[#1a0033] px-2 py-0.5 border border-[#d4af37]/30">
                            {assortment.pieces}
                          </span>
                        </div>
                        <p className="text-xs text-[#f5f2ed]/70 font-sans mt-1">{assortment.desc}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* STEP 2: BOX STYLE */}
            {step === 2 && (
              <div>
                <h3 className="text-2xl font-editorial text-[#f5f2ed] mb-1">
                  2. Select Luxury Presentation Box
                </h3>
                <p className="text-[10px] text-[#d4af37] font-sans uppercase tracking-[0.25em] mb-6">
                  Rigid board with magnetic snap and embossed gold foil seal
                </p>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  {boxes.map((box) => (
                    <div
                      key={box.id}
                      onClick={() => {
                        setSelectedBox(box.id);
                        audioEngine.playHover();
                      }}
                      className={`
                        p-5 border transition-all cursor-pointer text-center flex flex-col items-center justify-between h-44
                        ${
                          selectedBox === box.id
                            ? 'bg-[#330066]/40 border-[#d4af37] shadow-[0_0_20px_rgba(212,175,55,0.3)]'
                            : 'bg-[#1a0033]/60 border-[#d4af37]/20 hover:border-[#d4af37]/60'
                        }
                      `}
                    >
                      <div
                        className="w-14 h-14 border shadow-lg mb-2 flex items-center justify-center"
                        style={{ backgroundColor: box.hex, borderColor: box.border }}
                      >
                        <span className="font-serif italic text-xl text-[#d4af37]">C</span>
                      </div>
                      <div>
                        <span className="text-[9px] font-sans uppercase tracking-[0.2em] text-[#d4af37] block">{box.label}</span>
                        <h4 className="font-editorial text-sm text-[#f5f2ed] mt-0.5">{box.name}</h4>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* STEP 3: SATIN RIBBON */}
            {step === 3 && (
              <div>
                <h3 className="text-2xl font-editorial text-[#f5f2ed] mb-1">
                  3. Hand-Tied Satin Ribbon
                </h3>
                <p className="text-[10px] text-[#d4af37] font-sans uppercase tracking-[0.25em] mb-6">
                  Double-faced French satin tied in a signature jeweler’s knot
                </p>

                <div className="grid grid-cols-2 gap-4">
                  {ribbons.map((ribbon) => (
                    <div
                      key={ribbon.id}
                      onClick={() => {
                        setSelectedRibbon(ribbon.id);
                        audioEngine.playHover();
                      }}
                      className={`
                        p-4 border transition-all cursor-pointer flex items-center gap-3
                        ${
                          selectedRibbon === ribbon.id
                            ? 'bg-[#330066]/40 border-[#d4af37] shadow-[0_0_20px_rgba(212,175,55,0.3)]'
                            : 'bg-[#1a0033]/60 border-[#d4af37]/20 hover:border-[#d4af37]/50'
                        }
                      `}
                    >
                      <div className={`w-8 h-8 rounded-full bg-gradient-to-r ${ribbon.color} shadow-md`} />
                      <span className="font-sans text-[10px] uppercase tracking-[0.2em] text-[#f5f2ed]">{ribbon.name}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* STEP 4: DEDICATION MESSAGE */}
            {step === 4 && (
              <div>
                <h3 className="text-2xl font-editorial text-[#f5f2ed] mb-1">
                  4. Hot-Foil Gold Dedication
                </h3>
                <p className="text-[10px] text-[#d4af37] font-sans uppercase tracking-[0.25em] mb-6">
                  Embossed in 24k gold foil onto a heavy cotton letterpress card
                </p>

                <div className="space-y-4">
                  <div>
                    <label className="block text-[10px] font-sans uppercase tracking-[0.25em] text-[#d4af37] mb-2">
                      Recipient Name
                    </label>
                    <input
                      type="text"
                      value={recipientName}
                      onChange={(e) => setRecipientName(e.target.value)}
                      placeholder="e.g. Lady Eleanor"
                      className="w-full px-4 py-3 bg-[#1a0033] border border-[#d4af37]/30 text-[#f5f2ed] font-sans text-sm focus:outline-none focus:border-[#d4af37]"
                    />
                  </div>

                  <div>
                    <label className="block text-[10px] font-sans uppercase tracking-[0.25em] text-[#d4af37] mb-2">
                      Personal Message
                    </label>
                    <textarea
                      rows={3}
                      value={customMessage}
                      onChange={(e) => setCustomMessage(e.target.value)}
                      placeholder="Write your personal message..."
                      className="w-full px-4 py-3 bg-[#1a0033] border border-[#d4af37]/30 text-[#f5f2ed] font-sans text-sm focus:outline-none focus:border-[#d4af37]"
                    />
                  </div>
                </div>
              </div>
            )}

            {/* STEP 5: PREVIEW */}
            {step === 5 && (
              <div>
                <h3 className="text-2xl font-editorial text-[#f5f2ed] mb-1">
                  5. Review Your Bespoke Creation
                </h3>
                <p className="text-[10px] text-[#d4af37] font-sans uppercase tracking-[0.25em] mb-6">
                  Ready to be hand-packed in our Bournville Atelier
                </p>

                <div className="p-4 bg-[#1a0033]/80 border border-[#d4af37]/30 space-y-2 text-[10px] font-sans uppercase tracking-[0.2em]">
                  <div className="flex justify-between">
                    <span className="text-[#d4af37]">Box Style:</span>
                    <span className="text-[#f5f2ed]">{boxes.find(b => b.id === selectedBox)?.name}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-[#d4af37]">Ribbon:</span>
                    <span className="text-[#f5f2ed]">{ribbons.find(r => r.id === selectedRibbon)?.name}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-[#d4af37]">Chocolates:</span>
                    <span className="text-[#f5f2ed]">{assortments.find(a => a.id === selectedAssortment)?.name}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-[#d4af37]">Dedicated To:</span>
                    <span className="text-[#f5f2ed]">{recipientName}</span>
                  </div>
                </div>

                <div className="mt-6 flex gap-3">
                  <button
                    onClick={handleUnbox}
                    className="flex-1 py-3 bg-[#330066]/40 border border-[#d4af37]/50 hover:border-[#d4af37] text-[#f5f2ed] font-sans text-[10px] uppercase tracking-[0.3em] transition-all flex items-center justify-center gap-2"
                  >
                    <Eye className="w-4 h-4 text-[#d4af37]" />
                    <span>Watch Unboxing Sequence</span>
                  </button>
                </div>
              </div>
            )}

            {/* Stepper Footer Buttons */}
            <div className="flex items-center justify-between pt-8 border-t border-[#d4af37]/20 mt-8">
              <button
                onClick={() => handleStepClick(Math.max(1, step - 1))}
                disabled={step === 1}
                className="px-4 py-2 text-[10px] font-sans uppercase tracking-[0.25em] text-[#d4af37] disabled:opacity-30"
              >
                ← Back
              </button>

              {step < 5 ? (
                <button
                  onClick={() => handleStepClick(step + 1)}
                  className="px-6 py-2.5 bg-gradient-to-r from-[#330066] to-[#1a0033] border border-[#d4af37] text-[#f5f2ed] font-sans text-[10px] uppercase tracking-[0.3em] transition-all flex items-center gap-2"
                >
                  <span>Next Step</span>
                  <ArrowRight className="w-3.5 h-3.5 text-[#d4af37]" />
                </button>
              ) : (
                <button
                  onClick={handleAddToBag}
                  className="px-8 py-3 bg-[#d4af37] hover:bg-[#ebd89b] text-[#1a0033] font-sans font-bold text-[10px] uppercase tracking-[0.3em] shadow-[0_0_25px_rgba(212,175,55,0.6)] active:scale-95 transition-all flex items-center gap-2"
                >
                  <span>Add Gift to Bag • £34.00</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              )}
            </div>

          </div>

          {/* Right: Live Dynamic 3D/Visual Gift Box Preview */}
          <div className="lg:col-span-5 relative flex flex-col items-center justify-center p-8 bg-[#0e001f] border border-[#d4af37]/30 shadow-2xl min-h-[460px] overflow-hidden">
            
            {/* Ambient Lighting */}
            <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_rgba(212,175,55,0.1)_0%,_transparent_70%)] pointer-events-none" />

            {/* The Visual Gift Box */}
            <div className="relative w-64 sm:w-72 h-64 shadow-2xl flex flex-col items-center justify-center transition-all duration-700 transform hover:rotate-1"
              style={{
                backgroundColor: boxes.find(b => b.id === selectedBox)?.hex || '#1a0033',
                border: `1px solid ${boxes.find(b => b.id === selectedBox)?.border || '#d4af37'}`
              }}
            >
              {/* Crossed Satin Ribbon */}
              <div
                className={`absolute inset-y-0 w-8 bg-gradient-to-r ${ribbons.find(r => r.id === selectedRibbon)?.color} shadow-md opacity-90`}
              />
              <div
                className={`absolute inset-x-0 h-8 bg-gradient-to-b ${ribbons.find(r => r.id === selectedRibbon)?.color} shadow-md opacity-90`}
              />

              {/* Central Bow / Seal */}
              <div className="relative z-10 w-16 h-16 rounded-full bg-gradient-to-br from-[#ebd89b] to-[#d4af37] p-1 shadow-2xl flex items-center justify-center border border-white/40">
                <span className="font-serif italic text-2xl text-[#1a0033] font-bold">C</span>
              </div>

              {/* Personalized Nameplate */}
              <div className="absolute bottom-4 inset-x-4 bg-[#0e001f]/90 backdrop-blur-md px-3 py-1.5 border border-[#d4af37]/40 text-center">
                <span className="text-[8px] font-sans uppercase text-[#d4af37] tracking-[0.25em] block">Bespoke Dedication</span>
                <span className="text-xs font-serif italic text-[#f5f2ed] truncate block">
                  {recipientName ? `“${recipientName}”` : '“Generations of Joy”'}
                </span>
              </div>
            </div>

            {/* Unboxing Modal Overlay */}
            {isUnboxingPreview && (
              <div className="absolute inset-0 bg-[#0e001f]/95 backdrop-blur-md p-6 flex flex-col items-center justify-between text-center z-20 animate-fade-in">
                <div className="text-[10px] font-sans text-[#d4af37] tracking-[0.3em] uppercase">
                  Unboxing Simulation
                </div>

                <div className="my-auto space-y-4">
                  <div className="w-16 h-16 mx-auto rounded-full bg-[#330066] flex items-center justify-center border border-[#d4af37]">
                    <Sparkles className="w-7 h-7 text-[#d4af37]" />
                  </div>
                  <h4 className="text-2xl font-editorial text-[#f5f2ed]">
                    The Lid Gently Lifts...
                  </h4>
                  <div className="p-4 bg-[#1a0033] border border-[#d4af37]/30 max-w-xs mx-auto">
                    <p className="text-xs font-serif italic text-[#d4af37]">
                      “{customMessage}”
                    </p>
                    <span className="text-[9px] font-sans uppercase tracking-[0.2em] text-[#f5f2ed]/70 mt-2 block">
                      — For {recipientName}
                    </span>
                  </div>
                </div>

                <button
                  onClick={() => setIsUnboxingPreview(false)}
                  className="px-4 py-2 border border-[#d4af37]/40 text-[10px] font-sans uppercase tracking-[0.2em] text-[#d4af37] hover:bg-[#330066]"
                >
                  Close Preview
                </button>
              </div>
            )}

            <div className="mt-6 text-center">
              <span className="text-[9px] font-sans uppercase tracking-[0.25em] text-[#f5f2ed]/60">
                Includes handwritten embossed card & presentation gift sleeve
              </span>
            </div>

          </div>

        </div>

      </div>
    </section>
  );
};
