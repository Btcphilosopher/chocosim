import React, { useEffect, useState } from 'react';
import { audioEngine } from '../utils/audio';

interface LoadingProps {
  onComplete: () => void;
}

export const LoadingExperience: React.FC<LoadingProps> = ({ onComplete }) => {
  const [phase, setPhase] = useState<number>(0);

  useEffect(() => {
    // Stage 1: Gold 1824 appears
    const t1 = setTimeout(() => setPhase(1), 400);
    // Stage 2: Molten chocolate stream pours
    const t2 = setTimeout(() => {
      setPhase(2);
      audioEngine.playChocolateRipple();
    }, 1100);
    // Stage 3: Logo & Generations of Joy emerges
    const t3 = setTimeout(() => {
      setPhase(3);
      audioEngine.playGoldChime();
    }, 2000);
    // Stage 4: Liquid recedes & complete
    const t4 = setTimeout(() => {
      setPhase(4);
      setTimeout(onComplete, 600);
    }, 3200);

    return () => {
      clearTimeout(t1);
      clearTimeout(t2);
      clearTimeout(t3);
      clearTimeout(t4);
    };
  }, [onComplete]);

  return (
    <div
      className={`fixed inset-0 z-50 flex flex-col items-center justify-center bg-[#12002b] transition-opacity duration-700 ${
        phase === 4 ? 'opacity-0 pointer-events-none' : 'opacity-100'
      }`}
    >
      {/* Background Molten Chocolate Fluid Stream Wave */}
      <div
        className={`absolute inset-0 bg-[#2b1007] transition-transform duration-1000 ease-in-out pointer-events-none ${
          phase >= 2 && phase < 4 ? 'translate-y-0 opacity-100' : '-translate-y-full opacity-0'
        }`}
      >
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_rgba(201,160,80,0.15)_0%,_transparent_70%)]" />
      </div>

      {/* Center Cinematic Content */}
      <div className="relative z-10 text-center px-6 flex flex-col items-center">
        
        {/* Cadbury Script Logo */}
        <div
          className={`transition-all duration-700 transform ${
            phase >= 1 ? 'opacity-100 translate-y-0 scale-100' : 'opacity-0 translate-y-6 scale-95'
          }`}
        >
          <div className="font-editorial italic text-6xl sm:text-8xl md:text-9xl text-[#f5f2ed] drop-shadow-[0_4px_25px_rgba(212,175,55,0.4)]">
            Cadbury
          </div>
        </div>

        {/* 1824 Gold Badge */}
        <div
          className={`mt-2 flex items-center gap-4 transition-all duration-700 delay-150 ${
            phase >= 1 ? 'opacity-100' : 'opacity-0'
          }`}
        >
          <div className="w-12 h-px bg-[#d4af37]" />
          <span className="font-sans text-xs sm:text-sm tracking-[0.4em] uppercase text-[#d4af37]">
            1824 • Bournville
          </span>
          <div className="w-12 h-px bg-[#d4af37]" />
        </div>

        {/* Molten Chocolate Stream Line */}
        <div className="w-48 sm:w-64 h-1 bg-[#330066] overflow-hidden my-6 border border-[#d4af37]/30">
          <div
            className={`h-full bg-gradient-to-r from-[#d4af37] via-[#ebd89b] to-[#d4af37] transition-all duration-1000 ${
              phase >= 2 ? 'w-full' : 'w-0'
            }`}
          />
        </div>

        {/* GENERATIONS OF JOY Reveal */}
        <div
          className={`transition-all duration-700 transform ${
            phase >= 3 ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'
          }`}
        >
          <p className="font-editorial text-xl sm:text-2xl md:text-3xl tracking-[0.2em] uppercase text-[#f5f2ed] font-light">
            Generations <span className="italic font-serif text-[#d4af37]">of Joy</span>
          </p>
        </div>

      </div>

      {/* Skip Button */}
      <button
        onClick={onComplete}
        className="absolute bottom-8 right-8 text-xs font-cinzel tracking-widest text-[#c9a050]/70 hover:text-[#e5c378] transition-colors uppercase border border-[#c9a050]/30 px-3 py-1.5 rounded-full hover:bg-[#c9a050]/15"
      >
        Skip Intro →
      </button>
    </div>
  );
};
