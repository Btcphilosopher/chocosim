import React, { useState } from 'react';
import { ShoppingBag, Search, Volume2, VolumeX, Menu, X, Sparkles } from 'lucide-react';
import { audioEngine } from '../utils/audio';

interface NavbarProps {
  cartCount: number;
  onOpenCart: () => void;
  onOpenSearch: () => void;
  onNavigate: (sectionId: string) => void;
  isMuted: boolean;
  onToggleMute: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  cartCount,
  onOpenCart,
  onOpenSearch,
  onNavigate,
  isMuted,
  onToggleMute,
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navLinks = [
    { label: 'Collection', id: 'collection' },
    { label: 'The Fountain', id: 'hero' },
    { label: 'The Fracture', id: 'break-square' },
    { label: 'The Factory', id: 'factory' },
    { label: 'Heritage', id: 'heritage' },
    { label: 'Gifting', id: 'gifting' },
    { label: 'Impact', id: 'sustainability' },
  ];

  const handleLinkClick = (id: string) => {
    onNavigate(id);
    setMobileMenuOpen(false);
    audioEngine.playHover();
  };

  return (
    <header className="sticky top-0 z-40 w-full backdrop-blur-xl bg-[#1a0033]/90 border-b border-[#d4af37]/20 transition-all duration-300">
      
      {/* Top Announcement Ribbon */}
      <div className="w-full bg-[#0e001f] border-b border-[#d4af37]/15 py-2 px-6 sm:px-12">
        <div className="max-w-7xl mx-auto flex items-center justify-between text-[10px] font-sans uppercase tracking-[0.3em] text-[#d4af37]">
          <div className="flex items-center gap-2">
            <span className="w-1.5 h-1.5 rounded-full bg-[#d4af37] animate-pulse"></span>
            <span>Est. 1824 — Birmingham, UK</span>
          </div>
          <button
            onClick={() => handleLinkClick('sustainability')}
            className="hidden sm:inline-flex items-center gap-1.5 hover:text-[#f5f2ed] transition-colors"
          >
            <span>100% Sustainably Sourced Cocoa</span>
            <span className="text-xs">→</span>
          </button>
        </div>
      </div>

      {/* Main Navigation Bar */}
      <div className="max-w-7xl mx-auto px-6 sm:px-12 h-20 flex items-center justify-between">
        
        {/* Left: Cadbury Script Signature Logo */}
        <div className="flex items-center gap-3 cursor-pointer" onClick={() => handleLinkClick('hero')}>
          <span className="text-3xl sm:text-4xl tracking-tight text-[#f5f2ed] hover:text-[#d4af37] transition-colors" style={{ fontFamily: '"Georgia", serif' }}>
            Cadbury
          </span>
          <div className="hidden lg:flex flex-col text-[8px] font-sans tracking-[0.35em] text-[#d4af37] border-l border-[#d4af37]/30 pl-2.5 uppercase">
            <span>1824</span>
            <span className="text-[#f5f2ed]/80">Atelier</span>
          </div>
        </div>

        {/* Center: Desktop Nav Links */}
        <nav className="hidden md:flex items-center gap-8 text-[10px] font-sans uppercase tracking-[0.3em] text-[#f5f2ed]/85">
          {navLinks.map((link) => (
            <button
              key={link.id}
              onClick={() => handleLinkClick(link.id)}
              className="relative py-1 hover:text-[#d4af37] transition-colors group cursor-pointer"
            >
              <span>{link.label}</span>
              <span className="absolute bottom-0 left-0 w-0 h-0.5 bg-[#d4af37] transition-all duration-300 group-hover:w-full" />
            </button>
          ))}
        </nav>

        {/* Right: Sound, Search & Bag Trigger */}
        <div className="flex items-center gap-4 text-[10px] font-sans uppercase tracking-[0.3em]">
          
          {/* Sound Synthesizer Toggle */}
          <button
            onClick={onToggleMute}
            title={isMuted ? 'Enable Tactile Audio Experience' : 'Mute Audio'}
            className="p-2 rounded-full border border-[#d4af37]/30 hover:border-[#d4af37] text-[#d4af37] hover:text-[#f5f2ed] transition-all flex items-center gap-1.5"
          >
            {isMuted ? <VolumeX className="w-3.5 h-3.5" /> : <Volume2 className="w-3.5 h-3.5 text-[#d4af37]" />}
            <span className="hidden xl:inline text-[9px] uppercase tracking-[0.2em]">
              {isMuted ? 'Muted' : 'Sound'}
            </span>
          </button>

          {/* Search Trigger */}
          <button
            onClick={() => {
              audioEngine.playHover();
              onOpenSearch();
            }}
            className="p-2 rounded-full border border-[#d4af37]/30 hover:border-[#d4af37] text-[#f5f2ed]/80 hover:text-[#d4af37] transition-all flex items-center gap-1.5"
            title="Search Products & Heritage"
          >
            <Search className="w-3.5 h-3.5 text-[#d4af37]" />
            <span className="hidden lg:inline uppercase text-[9px] tracking-[0.2em]">Search</span>
          </button>

          {/* Cart Bag Drawer Trigger */}
          <button
            onClick={() => {
              audioEngine.playChocolateSnap();
              onOpenCart();
            }}
            className="relative px-4 py-2 bg-gradient-to-r from-[#330066] to-[#1a0033] border border-[#d4af37]/40 text-[#f5f2ed] text-[10px] uppercase tracking-[0.3em] flex items-center gap-2 hover:border-[#d4af37] hover:shadow-[0_0_20px_rgba(212,175,55,0.4)] transition-all"
          >
            <ShoppingBag className="w-3.5 h-3.5 text-[#d4af37]" />
            <span>Bag</span>
            <span className="w-4 h-4 rounded-full bg-[#d4af37] text-[#1a0033] text-[9px] font-bold flex items-center justify-center font-mono">
              {cartCount}
            </span>
          </button>

          {/* Mobile Menu Hamburger */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="md:hidden p-2 text-[#f5f2ed] hover:text-[#d4af37]"
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>

        </div>

      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-[#0e001f] border-b border-[#d4af37]/30 p-6 space-y-4 animate-fade-in">
          {navLinks.map((link) => (
            <button
              key={link.id}
              onClick={() => handleLinkClick(link.id)}
              className="block w-full text-left py-2 font-sans text-xs text-[#f5f2ed] hover:text-[#d4af37] tracking-[0.3em] uppercase border-b border-white/5"
            >
              {link.label}
            </button>
          ))}
          <div className="pt-2 flex items-center justify-between text-[10px] font-sans uppercase tracking-[0.3em] text-[#d4af37]">
            <span>1824 Bournville Heritage</span>
            <span>Sustainable Cocoa</span>
          </div>
        </div>
      )}

    </header>
  );
};
