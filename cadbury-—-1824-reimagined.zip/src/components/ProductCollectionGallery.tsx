import React, { useState } from 'react';
import { CADBURY_PRODUCTS } from '../data/cadburyData';
import { audioEngine } from '../utils/audio';
import { Product } from '../types';
import { ShoppingBag, Sparkles, Filter, Eye, Check } from 'lucide-react';

interface ProductGalleryProps {
  onAddToCart: (product: Product, event?: React.MouseEvent) => void;
  onSelectProductForDeepDive?: (product: Product) => void;
}

export const ProductCollectionGallery: React.FC<ProductGalleryProps> = ({
  onAddToCart,
  onSelectProductForDeepDive,
}) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [activeQuickView, setActiveQuickView] = useState<Product | null>(null);
  const [addedProductId, setAddedProductId] = useState<string | null>(null);

  const categories = [
    { id: 'all', label: 'All Confections' },
    { id: 'signature', label: 'Signature Grand Cru' },
    { id: 'bars', label: 'Classic & Velvet Bars' },
    { id: 'boxes', label: 'Keepsake Gift Boxes' },
    { id: 'heritage', label: '1824 Heritage Reserve' },
  ];

  const filteredProducts =
    selectedCategory === 'all'
      ? CADBURY_PRODUCTS
      : CADBURY_PRODUCTS.filter((p) => p.category === selectedCategory);

  const handleAdd = (product: Product, e: React.MouseEvent) => {
    e.stopPropagation();
    audioEngine.playChocolateSnap();
    onAddToCart(product, e);
    setAddedProductId(product.id);
    setTimeout(() => setAddedProductId(null), 1400);
  };

  return (
    <section id="collection" className="relative w-full py-24 px-6 md:px-12 bg-[#1a0033] text-[#f5f2ed] border-t border-[#d4af37]/20 overflow-hidden">
      {/* Background Ambience & Dotted Grid */}
      <div
        className="absolute inset-0 pointer-events-none opacity-20"
        style={{
          backgroundImage: 'radial-gradient(#d4af37 0.5px, transparent 0.5px)',
          backgroundSize: '36px 36px',
        }}
      />
      <div className="absolute top-1/3 left-1/2 -translate-x-1/2 w-[800px] h-[500px] bg-[#330066]/30 rounded-full blur-[140px] pointer-events-none" />

      <div className="max-w-7xl mx-auto relative z-10">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-16 gap-6">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 border border-[#d4af37]/30 bg-[#330066]/30 text-[#d4af37] text-[10px] font-sans tracking-[0.3em] uppercase mb-4">
              <Sparkles className="w-3 h-3 text-[#d4af37]" />
              <span>Artisanal British Confectionery</span>
            </div>
            <h2 className="text-4xl sm:text-5xl md:text-6xl font-editorial font-light tracking-tight">
              THE CHOCOLATE <span className="italic font-serif text-[#d4af37]">COLLECTION</span>
            </h2>
            <p className="max-w-xl text-sm sm:text-base text-[#f5f2ed]/70 font-sans font-light mt-3">
              Masterfully tempered chocolate bars, hand-finished grand cru pralines, and royal keepsake tins crafted in Bournville.
            </p>
          </div>

          {/* Category Filter Pills */}
          <div className="flex flex-wrap items-center gap-2 p-1.5 bg-[#0e001f] border border-[#d4af37]/25">
            {categories.map((cat) => (
              <button
                key={cat.id}
                onClick={() => {
                  setSelectedCategory(cat.id);
                  audioEngine.playHover();
                }}
                className={`
                  px-4 py-2 text-[10px] font-sans tracking-[0.2em] uppercase transition-all duration-300
                  ${
                    selectedCategory === cat.id
                      ? 'bg-[#d4af37] text-[#1a0033] font-bold'
                      : 'text-[#f5f2ed]/60 hover:text-[#f5f2ed] hover:bg-[#330066]/50'
                  }
                `}
              >
                {cat.label}
              </button>
            ))}
          </div>
        </div>

        {/* Product Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {filteredProducts.map((product) => {
            const isJustAdded = addedProductId === product.id;

            return (
              <div
                key={product.id}
                onClick={() => setActiveQuickView(product)}
                className="group relative flex flex-col justify-between bg-[#0e001f]/90 border border-[#d4af37]/20 hover:border-[#d4af37] p-5 transition-all duration-500 hover:-translate-y-1.5 hover:shadow-[0_15px_35px_rgba(0,0,0,0.7)] cursor-pointer overflow-hidden"
              >
                {/* Gold Gleam Effect */}
                <div className="absolute inset-0 bg-gradient-to-tr from-transparent via-[#d4af37]/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none" />

                {/* Badge (New / Bestseller) */}
                <div className="flex items-center justify-between text-[10px] font-sans uppercase tracking-[0.25em] text-[#d4af37] mb-3">
                  <span>{product.cocoaPercentage}% Cocoa</span>
                  {product.isBestseller && (
                    <span className="bg-[#330066] px-2 py-0.5 border border-[#d4af37]/40 text-[#d4af37]">
                      Iconic Bestseller
                    </span>
                  )}
                  {product.isNew && (
                    <span className="bg-[#1a0033] px-2 py-0.5 border border-[#d4af37] text-[#f5f2ed]">
                      New Release
                    </span>
                  )}
                </div>

                {/* Product Image Frame with Zoom Effect */}
                <div className="relative w-full h-56 overflow-hidden bg-[#1a0033] border border-[#d4af37]/20 mb-5 flex items-center justify-center p-3">
                  <img
                    src={product.image}
                    alt={product.name}
                    className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105 filter brightness-95 group-hover:brightness-105"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#0e001f]/80 via-transparent to-transparent opacity-60" />

                  {/* Hover Quick View Trigger */}
                  <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                    <span className="px-4 py-1.5 bg-[#0e001f]/95 border border-[#d4af37] text-[10px] font-sans text-[#d4af37] tracking-[0.3em] uppercase flex items-center gap-1.5 shadow-lg">
                      <Eye className="w-3 h-3" />
                      Explore
                    </span>
                  </div>
                </div>

                {/* Info Block */}
                <div>
                  <h3 className="text-xl font-editorial font-light text-[#f5f2ed] group-hover:text-[#d4af37] transition-colors leading-snug">
                    {product.name}
                  </h3>
                  <p className="text-xs text-[#f5f2ed]/60 font-sans line-clamp-2 mt-1 mb-3">
                    {product.tagline}
                  </p>

                  {/* Tasting Notes Tags */}
                  <div className="flex flex-wrap gap-1.5 mb-4">
                    {product.tastingNotes.slice(0, 2).map((note, i) => (
                      <span
                        key={i}
                        className="text-[9px] px-2 py-0.5 bg-[#1a0033] text-[#d4af37] font-sans uppercase tracking-wider border border-[#d4af37]/20"
                      >
                        {note}
                      </span>
                    ))}
                  </div>
                </div>

                {/* Price & Add to Bag CTA */}
                <div className="flex items-center justify-between pt-4 border-t border-[#d4af37]/15 mt-2">
                  <div>
                    <span className="text-[9px] uppercase font-sans tracking-widest text-[#f5f2ed]/50 block">Price</span>
                    <span className="text-lg font-bold font-sans text-[#f5f2ed]">
                      £{product.price.toFixed(2)}
                    </span>
                  </div>

                  <button
                    onClick={(e) => handleAdd(product, e)}
                    className={`
                      px-4 py-2 font-sans text-[10px] uppercase tracking-[0.25em] transition-all duration-300 flex items-center gap-1.5
                      ${
                        isJustAdded
                          ? 'bg-[#330066] text-[#d4af37] border border-[#d4af37]'
                          : 'bg-[#d4af37] hover:bg-[#ebd89b] text-[#1a0033] font-bold active:scale-95'
                      }
                    `}
                  >
                    {isJustAdded ? (
                      <>
                        <Check className="w-3.5 h-3.5" />
                        <span>Added!</span>
                      </>
                    ) : (
                      <>
                        <ShoppingBag className="w-3.5 h-3.5" />
                        <span>Add</span>
                      </>
                    )}
                  </button>
                </div>

              </div>
            );
          })}
        </div>

        {/* Quick View Modal */}
        {activeQuickView && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fade-in text-[#f5f2ed]">
            <div className="relative w-full max-w-3xl bg-[#0e001f] border border-[#d4af37]/40 p-6 sm:p-10 shadow-2xl overflow-hidden">
              <button
                onClick={() => setActiveQuickView(null)}
                className="absolute top-4 right-4 p-1.5 text-[#f5f2ed]/60 hover:text-[#f5f2ed] text-sm font-sans border border-[#d4af37]/20 hover:border-[#d4af37] w-8 h-8 flex items-center justify-center transition-colors"
              >
                ✕
              </button>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
                <div className="overflow-hidden border border-[#d4af37]/30 h-72 bg-[#1a0033] flex items-center justify-center p-2">
                  <img
                    src={activeQuickView.image}
                    alt={activeQuickView.name}
                    className="w-full h-full object-cover"
                  />
                </div>

                <div>
                  <div className="text-[10px] font-sans uppercase tracking-[0.3em] text-[#d4af37] mb-2">
                    {activeQuickView.origin} • {activeQuickView.weight}
                  </div>
                  <h3 className="text-3xl font-editorial text-[#f5f2ed] mb-2">
                    {activeQuickView.name}
                  </h3>
                  <p className="text-xs text-[#d4af37] font-sans uppercase tracking-wider mb-4">
                    {activeQuickView.tagline}
                  </p>
                  <p className="text-sm text-[#f5f2ed]/80 font-sans font-light leading-relaxed mb-6">
                    {activeQuickView.description}
                  </p>

                  <div className="mb-6">
                    <span className="text-[9px] uppercase font-sans tracking-widest text-[#d4af37] block mb-2">Tasting Palette</span>
                    <div className="flex flex-wrap gap-2">
                      {activeQuickView.tastingNotes.map((note, idx) => (
                        <span
                          key={idx}
                          className="px-3 py-1 bg-[#1a0033] border border-[#d4af37]/30 text-[10px] font-sans tracking-wider uppercase text-[#d4af37]"
                        >
                          {note}
                        </span>
                      ))}
                    </div>
                  </div>

                  <div className="flex items-center justify-between pt-4 border-t border-[#d4af37]/20">
                    <span className="text-2xl font-bold font-sans text-[#f5f2ed]">
                      £{activeQuickView.price.toFixed(2)}
                    </span>
                    <button
                      onClick={(e) => {
                        handleAdd(activeQuickView, e);
                        setActiveQuickView(null);
                      }}
                      className="px-6 py-3 bg-[#d4af37] hover:bg-[#ebd89b] text-[#1a0033] font-sans font-bold text-[10px] uppercase tracking-[0.3em] transition-all active:scale-95"
                    >
                      Add To Bag →
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

      </div>
    </section>
  );
};
