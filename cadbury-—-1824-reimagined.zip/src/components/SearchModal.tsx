import React, { useState } from 'react';
import { CADBURY_PRODUCTS, TIMELINE_ERAS, FACTORY_STEPS } from '../data/cadburyData';
import { Product } from '../types';
import { audioEngine } from '../utils/audio';
import { Search, X, Sparkles, ArrowRight } from 'lucide-react';

interface SearchModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectProduct: (product: Product) => void;
  onSelectSection: (sectionId: string) => void;
}

export const SearchModal: React.FC<SearchModalProps> = ({
  isOpen,
  onClose,
  onSelectProduct,
  onSelectSection,
}) => {
  const [query, setQuery] = useState('');

  if (!isOpen) return null;

  const filteredProducts = query.trim()
    ? CADBURY_PRODUCTS.filter(
        (p) =>
          p.name.toLowerCase().includes(query.toLowerCase()) ||
          p.description.toLowerCase().includes(query.toLowerCase()) ||
          p.tastingNotes.some((n) => n.toLowerCase().includes(query.toLowerCase()))
      )
    : CADBURY_PRODUCTS.slice(0, 4);

  const filteredEras = query.trim()
    ? TIMELINE_ERAS.filter(
        (e) =>
          e.title.toLowerCase().includes(query.toLowerCase()) ||
          e.year.includes(query) ||
          e.description.toLowerCase().includes(query.toLowerCase())
      )
    : [];

  return (
    <div className="fixed inset-0 z-50 flex flex-col bg-[#0e001f]/95 backdrop-blur-2xl p-6 md:p-16 overflow-y-auto animate-fade-in text-[#f5f2ed]">
      {/* Close button */}
      <button
        onClick={onClose}
        className="self-end p-2 border border-[#d4af37]/30 text-[#f5f2ed]/70 hover:text-[#f5f2ed] hover:border-[#d4af37] transition-colors"
      >
        <X className="w-5 h-5" />
      </button>

      <div className="max-w-4xl mx-auto w-full my-auto py-8">
        
        {/* Search Title */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center gap-2 text-[10px] font-sans tracking-[0.3em] text-[#d4af37] uppercase mb-2">
            <Sparkles className="w-3 h-3 text-[#d4af37]" />
            <span>Cadbury 1824 Knowledge & Confectionery Finder</span>
          </div>
          <h2 className="text-3xl md:text-5xl font-editorial font-light text-[#f5f2ed]">
            WHAT ARE YOU <span className="italic font-serif text-[#d4af37]">LOOKING FOR?</span>
          </h2>
        </div>

        {/* Search Bar Input */}
        <div className="relative mb-10">
          <input
            type="text"
            value={query}
            onChange={(e) => {
              setQuery(e.target.value);
              audioEngine.playHover();
            }}
            placeholder="Search Dairy Milk, 1824 Dark Reserve, Truffles, Bournville, Tempering..."
            autoFocus
            className="w-full px-6 py-4 bg-[#1a0033] border border-[#d4af37]/50 text-lg md:text-xl font-editorial text-[#f5f2ed] placeholder-[#f5f2ed]/30 focus:outline-none focus:border-[#d4af37] shadow-[0_0_30px_rgba(212,175,55,0.2)]"
          />
          <Search className="absolute right-5 top-1/2 -translate-y-1/2 w-5 h-5 text-[#d4af37]" />
        </div>

        {/* Quick Suggestion Pills */}
        {!query && (
          <div className="flex flex-wrap items-center justify-center gap-2 mb-12 text-[10px] font-sans uppercase tracking-[0.2em]">
            <span className="text-[#f5f2ed]/50 mr-2">Curated Searches:</span>
            {['Dairy Milk Silk', 'Grand Cru Box', 'Bournville 1879', 'Tempering Process', 'Personalised Gifts'].map((tag) => (
              <button
                key={tag}
                onClick={() => setQuery(tag)}
                className="px-3 py-1 bg-[#330066]/50 border border-[#d4af37]/30 text-[#d4af37] hover:bg-[#d4af37] hover:text-[#1a0033] transition-colors"
              >
                {tag}
              </button>
            ))}
          </div>
        )}

        {/* Results Container */}
        <div className="space-y-8">
          <div>
            <h4 className="font-sans text-[10px] uppercase tracking-[0.25em] text-[#d4af37] mb-4">
              Products ({filteredProducts.length})
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {filteredProducts.map((product) => (
                <div
                  key={product.id}
                  onClick={() => {
                    audioEngine.playChocolateSnap();
                    onSelectProduct(product);
                    onClose();
                  }}
                  className="p-4 bg-[#1a0033]/80 border border-[#d4af37]/20 hover:border-[#d4af37] transition-all cursor-pointer flex items-center gap-4 group"
                >
                  <img
                    src={product.image}
                    alt={product.name}
                    className="w-14 h-14 object-cover border border-[#d4af37]/30"
                  />
                  <div className="flex-1 min-w-0">
                    <h5 className="font-editorial text-base text-[#f5f2ed] group-hover:text-[#d4af37] transition-colors truncate">
                      {product.name}
                    </h5>
                    <p className="text-xs text-[#d4af37] font-sans">£{product.price.toFixed(2)}</p>
                    <span className="text-[10px] text-[#f5f2ed]/60 font-sans line-clamp-1">
                      {product.tagline}
                    </span>
                  </div>
                  <ArrowRight className="w-4 h-4 text-[#d4af37] group-hover:translate-x-1 transition-transform" />
                </div>
              ))}
            </div>
          </div>

          {filteredEras.length > 0 && (
            <div>
              <h4 className="font-sans text-[10px] uppercase tracking-[0.25em] text-[#d4af37] mb-4">
                Historical Milestones ({filteredEras.length})
              </h4>
              <div className="space-y-3">
                {filteredEras.map((era) => (
                  <div
                    key={era.year}
                    onClick={() => {
                      onSelectSection('heritage');
                      onClose();
                    }}
                    className="p-4 bg-[#1a0033]/80 border border-[#d4af37]/20 hover:border-[#d4af37] cursor-pointer"
                  >
                    <span className="text-xs font-sans uppercase tracking-wider text-[#d4af37]">{era.year} — {era.title}</span>
                    <p className="text-xs text-[#f5f2ed]/80 mt-1 font-sans font-light">{era.description}</p>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

      </div>
    </div>
  );
};
