import React, { useState, useEffect, useRef } from 'react';
import * as THREE from 'three';
import { SUSTAINABILITY_REGIONS } from '../data/cadburyData';
import { audioEngine } from '../utils/audio';
import { SustainabilityRegion } from '../types';
import { Globe, Leaf, Users, Trees, ShieldCheck, ArrowUpRight } from 'lucide-react';

export const SustainabilityGlobe: React.FC = () => {
  const mountRef = useRef<HTMLDivElement>(null);
  const [selectedRegionId, setSelectedRegionId] = useState<string>('ghana');
  const [activeTab, setActiveTab] = useState<string>('farmers');

  const selectedRegion: SustainabilityRegion =
    SUSTAINABILITY_REGIONS.find((r) => r.id === selectedRegionId) || SUSTAINABILITY_REGIONS[0];

  useEffect(() => {
    if (!mountRef.current) return;
    const container = mountRef.current;
    const width = container.clientWidth || 400;
    const height = container.clientHeight || 400;

    // Three.js 3D Cocoa Globe
    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 100);
    camera.position.set(0, 0, 4.2);

    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 1.5));
    container.appendChild(renderer.domElement);

    // Globe Sphere (Deep Purple with Gold Wireframe)
    const globeGroup = new THREE.Group();

    const sphereGeo = new THREE.SphereGeometry(1.4, 36, 36);
    const sphereMat = new THREE.MeshPhongMaterial({
      color: 0x1a0033,
      emissive: 0x330066,
      specular: 0xd4af37,
      shininess: 40,
      transparent: true,
      opacity: 0.9,
    });
    const globeMesh = new THREE.Mesh(sphereGeo, sphereMat);
    globeGroup.add(globeMesh);

    // Golden Latitude/Longitude Wireframe Lines
    const wireGeo = new THREE.WireframeGeometry(new THREE.SphereGeometry(1.41, 18, 18));
    const wireMat = new THREE.LineBasicMaterial({ color: 0xd4af37, transparent: true, opacity: 0.25 });
    const wireMesh = new THREE.LineSegments(wireGeo, wireMat);
    globeGroup.add(wireMesh);

    // Glowing Cocoa Hotspots (Ghana, Ivory Coast, Indonesia)
    const pinGroup = new THREE.Group();
    const pinCoords = [
      { lat: 6.6, lon: -1.6, color: 0xd4af37 }, // Ghana
      { lat: 5.3, lon: -6.6, color: 0xd4af37 }, // Ivory Coast
      { lat: -2.5, lon: 121.0, color: 0xd4af37 }, // Indonesia
    ];

    pinCoords.forEach((p) => {
      const phi = (90 - p.lat) * (Math.PI / 180);
      const theta = (p.lon + 180) * (Math.PI / 180);

      const x = -(1.44 * Math.sin(phi) * Math.cos(theta));
      const z = 1.44 * Math.sin(phi) * Math.sin(theta);
      const y = 1.44 * Math.cos(phi);

      const pinGeo = new THREE.SphereGeometry(0.06, 16, 16);
      const pinMat = new THREE.MeshBasicMaterial({ color: p.color });
      const pinMesh = new THREE.Mesh(pinGeo, pinMat);
      pinMesh.position.set(x, y, z);
      pinGroup.add(pinMesh);

      // Pulse ring
      const ringGeo = new THREE.RingGeometry(0.08, 0.12, 16);
      const ringMat = new THREE.MeshBasicMaterial({ color: 0xd4af37, side: THREE.DoubleSide, transparent: true, opacity: 0.7 });
      const ringMesh = new THREE.Mesh(ringGeo, ringMat);
      ringMesh.position.set(x, y, z);
      ringMesh.lookAt(0, 0, 0);
      pinGroup.add(ringMesh);
    });

    globeGroup.add(pinGroup);
    scene.add(globeGroup);

    // Lighting
    const light = new THREE.DirectionalLight(0xd4af37, 2.5);
    light.position.set(5, 3, 5);
    scene.add(light);

    const ambient = new THREE.AmbientLight(0x330066, 2.0);
    scene.add(ambient);

    // Animation
    let reqId: number;
    const animate = () => {
      reqId = requestAnimationFrame(animate);
      globeGroup.rotation.y += 0.003;
      globeGroup.rotation.x = Math.sin(Date.now() * 0.0005) * 0.1;
      renderer.render(scene, camera);
    };
    animate();

    const handleResize = () => {
      if (!container) return;
      const w = container.clientWidth;
      const h = container.clientHeight;
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
    };

    window.addEventListener('resize', handleResize);

    return () => {
      window.removeEventListener('resize', handleResize);
      cancelAnimationFrame(reqId);
      if (container.contains(renderer.domElement)) {
        container.removeChild(renderer.domElement);
      }
      renderer.dispose();
    };
  }, []);

  return (
    <section id="sustainability" className="relative w-full py-28 px-6 md:px-12 bg-[#1a0033] text-[#f5f2ed] overflow-hidden border-t border-[#d4af37]/15">
      
      {/* Background Ambience & Dotted Grid */}
      <div
        className="absolute inset-0 pointer-events-none opacity-15"
        style={{
          backgroundImage: 'radial-gradient(#d4af37 0.5px, transparent 0.5px)',
          backgroundSize: '40px 40px',
        }}
      />

      <div className="max-w-7xl mx-auto relative z-10">
        
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-16 gap-6">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 border border-[#d4af37]/30 bg-[#330066]/30 text-[#d4af37] text-[10px] font-sans tracking-[0.3em] uppercase mb-3">
              <Leaf className="w-3 h-3 text-[#d4af37]" />
              <span>Chapter VII — Cocoa Life & Planetary Stewardship</span>
            </div>
            <h2 className="text-4xl sm:text-5xl md:text-6xl font-editorial font-light tracking-tight text-[#f5f2ed]">
              LIQUID <span className="italic font-serif text-[#d4af37]">DATA & IMPACT</span>
            </h2>
            <p className="max-w-xl text-sm sm:text-base text-[#f5f2ed]/70 font-sans font-light mt-3 leading-relaxed">
              We believe great chocolate begins with thriving communities and healthy forests. 100% of our cocoa is verified sustainably sourced.
            </p>
          </div>

          <div className="flex items-center gap-2 text-[10px] font-sans uppercase tracking-[0.2em] text-[#d4af37] border border-[#d4af37]/30 px-3 py-1.5 bg-[#0e001f]">
            <ShieldCheck className="w-4 h-4 text-[#d4af37]" />
            <span>Cocoa Life $1B Global Commitment</span>
          </div>
        </div>

        {/* 4 Animated Impact Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-6 mb-16">
          {[
            { label: 'Sustainably Sourced', value: '100%', sub: 'Verified by FLOCERT' },
            { label: 'Farmers Empowered', value: '250,000+', sub: 'Across 6 Farming Nations' },
            { label: 'Shade Trees Planted', value: '4.4 Million', sub: 'Agroforestry Canopy' },
            { label: 'Zero Deforestation', value: '100% Mapped', sub: 'GPS Farm Polygonal Satellites' },
          ].map((stat, i) => (
            <div
              key={i}
              className="p-6 bg-[#0e001f]/85 border border-[#d4af37]/20 flex flex-col justify-between hover:border-[#d4af37]/60 transition-all duration-300 group"
            >
              <span className="text-[9px] font-sans uppercase tracking-[0.25em] text-[#d4af37] group-hover:text-[#f5f2ed]">
                {stat.label}
              </span>
              <div className="font-editorial text-3xl sm:text-4xl text-[#f5f2ed] my-2">
                {stat.value}
              </div>
              <span className="text-xs text-[#f5f2ed]/60 font-sans">{stat.sub}</span>
            </div>
          ))}
        </div>

        {/* 3D Globe & Region Explorer Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
          
          {/* Left: 3D Cocoa Globe WebGL Canvas */}
          <div className="lg:col-span-6 relative flex flex-col items-center justify-center p-6 bg-[#0e001f] border border-[#d4af37]/30 shadow-2xl min-h-[420px]">
            <div className="absolute top-4 left-6 text-[10px] font-sans text-[#d4af37] tracking-[0.25em] uppercase">
              Interactive 3D Cocoa Origin Globe
            </div>
            
            <div ref={mountRef} className="w-full h-80 flex items-center justify-center cursor-grab active:cursor-grabbing" />

            <div className="flex items-center gap-2 mt-4">
              {SUSTAINABILITY_REGIONS.map((r) => (
                <button
                  key={r.id}
                  onClick={() => {
                    setSelectedRegionId(r.id);
                    audioEngine.playHover();
                  }}
                  className={`
                    px-3 py-1 text-[10px] font-sans tracking-[0.2em] uppercase transition-all
                    ${
                      selectedRegionId === r.id
                        ? 'bg-gradient-to-r from-[#330066] to-[#1a0033] border border-[#d4af37] text-[#f5f2ed] shadow-md'
                        : 'bg-[#1a0033]/60 border border-[#d4af37]/20 text-[#f5f2ed]/70 hover:text-[#f5f2ed]'
                    }
                  `}
                >
                  {r.country}
                </button>
              ))}
            </div>
          </div>

          {/* Right: Regional Impact Story & Community Card */}
          <div className="lg:col-span-6 p-8 sm:p-10 bg-[#0e001f]/85 border border-[#d4af37]/30 shadow-2xl flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between text-[10px] font-sans uppercase tracking-[0.25em] text-[#d4af37] mb-2">
                <span>{selectedRegion.name}</span>
                <span>Active Programme Since 2008</span>
              </div>

              <h3 className="text-3xl font-editorial text-[#f5f2ed] mb-3">
                {selectedRegion.country} Sustainability Hub
              </h3>

              <p className="text-sm text-[#f5f2ed]/80 font-sans font-light leading-relaxed mb-6">
                {selectedRegion.impactStory}
              </p>

              <div className="grid grid-cols-2 gap-4 p-4 bg-[#1a0033] border border-[#d4af37]/20 text-xs font-sans mb-6">
                <div>
                  <div className="flex items-center gap-1.5 text-[#d4af37] mb-1">
                    <Users className="w-3.5 h-3.5" />
                    <span className="text-[10px] uppercase tracking-wider">Farmers Enrolled</span>
                  </div>
                  <span className="text-base font-bold text-[#f5f2ed]">{selectedRegion.farmersCount}</span>
                </div>
                <div>
                  <div className="flex items-center gap-1.5 text-[#d4af37] mb-1">
                    <Trees className="w-3.5 h-3.5" />
                    <span className="text-[10px] uppercase tracking-wider">Native Canopy Trees</span>
                  </div>
                  <span className="text-base font-bold text-[#d4af37]">{selectedRegion.treesPlanted}</span>
                </div>
              </div>

              <div className="p-4 bg-[#330066]/30 border border-[#d4af37]/20 text-xs font-sans">
                <span className="text-[9px] font-sans uppercase tracking-[0.25em] text-[#d4af37] block mb-1">Key Focus Initiative</span>
                <p className="text-[#f5f2ed]/90">{selectedRegion.keyInitiative}</p>
              </div>
            </div>

            <div className="mt-8 pt-6 border-t border-[#d4af37]/20 flex items-center justify-between">
              <span className="text-[10px] font-sans uppercase tracking-[0.2em] text-[#f5f2ed]/60">Download Full 2025 Sustainability Report (PDF)</span>
              <a
                href="#report"
                onClick={(e) => {
                  e.preventDefault();
                  audioEngine.playHover();
                }}
                className="text-[10px] font-sans uppercase tracking-[0.2em] text-[#d4af37] hover:underline flex items-center gap-1"
              >
                <span>Read ESG Audit</span>
                <ArrowUpRight className="w-3.5 h-3.5" />
              </a>
            </div>

          </div>

        </div>

      </div>
    </section>
  );
};
