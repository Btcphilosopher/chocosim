import { Product, TimelineEra, FactoryStep, SustainabilityRegion } from '../types';

export const CADBURY_PRODUCTS: Product[] = [
  {
    id: 'cadbury-dairy-milk-classic',
    name: 'Cadbury Dairy Milk Original',
    tagline: 'The British Icon — A Glass & a Half of Fresh Milk',
    category: 'bars',
    price: 3.50,
    weight: '200g',
    cocoaPercentage: 38,
    description: 'The golden standard of British chocolate. Created with fresh British and Irish milk for an unmistakable silky melt, balanced sweetness, and delicate floral vanilla notes.',
    tastingNotes: ['Creamy Fresh Milk', 'Floral Cocoa', 'Madagascan Vanilla', 'Silky Caramel finish'],
    ingredients: ['Milk', 'Sugar', 'Cocoa Butter', 'Cocoa Mass', 'Vegetable Fats', 'Emulsifiers (E442, E476)', 'Flavourings'],
    image: 'https://images.unsplash.com/photo-1549007994-cb92caebd54b?auto=format&fit=crop&w=800&q=80',
    accentColor: '#23085a',
    isBestseller: true,
    origin: 'Bournville, England'
  },
  {
    id: 'cadbury-signature-collection',
    name: 'Cadbury Signature Grand Cru Box',
    tagline: 'Hand-Finished Master Chocolates with 24k Gold Flakes',
    category: 'signature',
    price: 28.00,
    weight: '340g (24 pieces)',
    cocoaPercentage: 58,
    description: 'An architectural tasting journey curated by master chocolatiers. Featuring single-origin Ghanaian cocoa ganache, sea-salted Bournville honeycomb, roasted Piedmont gianduja, and Cornish clotted cream truffles.',
    tastingNotes: ['Velvet Ganache', 'Smoked Honeycomb', 'Roasted Hazelnut Gianduja', 'Clotted Cream Truffle'],
    ingredients: ['Single Origin Cocoa Mass', 'Organic Cocoa Butter', 'Whole Milk', 'Piedmont Hazelnuts', 'Cornish Sea Salt', 'Edible 24k Gold Leaf'],
    image: 'https://images.unsplash.com/photo-1548907040-4baa42d10919?auto=format&fit=crop&w=800&q=80',
    accentColor: '#c9a050',
    isNew: true,
    origin: 'Private Confectionery Atelier, Birmingham'
  },
  {
    id: 'cadbury-1824-heritage-dark',
    name: 'Cadbury 1824 Heritage Reserve 70%',
    tagline: 'Honouring John Cadbury’s Bull Street Recipe',
    category: 'heritage',
    price: 4.80,
    weight: '180g',
    cocoaPercentage: 70,
    description: 'A tribute to the original 1824 apothecary blends. Deep roasted Trinitario cocoa beans, tempered slowly on marble slabs to produce a resonant snap with notes of dried fig, warm spice, and dark molasses.',
    tastingNotes: ['Sun-dried Black Fig', 'Roasted Espresso', 'Nutmeg & Clove', 'Subtle Oak Tannins'],
    ingredients: ['Cocoa Mass', 'Raw Cane Sugar', 'Cocoa Butter', 'Vanilla Pod Extract'],
    image: 'https://images.unsplash.com/photo-1606312619070-d48b4c652a52?auto=format&fit=crop&w=800&q=80',
    accentColor: '#1a0802',
    isBestseller: true,
    origin: 'Selected West African Co-operatives'
  },
  {
    id: 'cadbury-roses-luxe-tin',
    name: 'Cadbury Roses Heritage Velvet Tin',
    tagline: 'Say Thank You with Timeless British Elegance',
    category: 'boxes',
    price: 16.50,
    weight: '450g',
    cocoaPercentage: 42,
    description: 'Encased in a collectible embossed purple and antique gold keepsake tin. A celebratory medley including Hazel Whirl, Golden Barrel, Tangy Orange Crème, Strawberry Dream, and Signature Caramel.',
    tastingNotes: ['Salted Butter Caramel', 'Valencia Orange Fondant', 'Whole Hazelnut Praline', 'Strawberry Nectar'],
    ingredients: ['Milk Chocolate', 'Glucose Syrup', 'Sweetened Condensed Milk', 'Roasted Hazelnuts', 'Natural Fruit Extracts'],
    image: 'https://images.unsplash.com/photo-1587314168485-3236d6710814?auto=format&fit=crop&w=800&q=80',
    accentColor: '#7b1158',
    isBestseller: true,
    origin: 'Bournville, England'
  },
  {
    id: 'cadbury-bournville-old-jamaica',
    name: 'Cadbury Bournville Old Jamaica Rum & Raisin',
    tagline: 'Rich Dark Chocolate with Sun-Soaked Raisins',
    category: 'bars',
    price: 3.90,
    weight: '180g',
    cocoaPercentage: 54,
    description: 'The legendary dark chocolate recipe infused with rum-steeped sultanas. Full-bodied cocoa paired with rich sweet fruit and warm molasses warmth.',
    tastingNotes: ['Soaked Sultanas', 'Dark Rum Essence', 'Robust Roasted Cocoa', 'Brown Sugar Warmth'],
    ingredients: ['Sugar', 'Cocoa Mass', 'Raisins (13%)', 'Cocoa Butter', 'Rum Flavouring', 'Emulsifier'],
    image: 'https://images.unsplash.com/photo-1511381939415-e44015466834?auto=format&fit=crop&w=800&q=80',
    accentColor: '#2b1007',
    origin: 'Bournville, England'
  },
  {
    id: 'cadbury-marvellous-creations',
    name: 'Marvellous Creations Popping Candy & Jelly',
    tagline: 'Explosive Joy & Playful Confectionery Magic',
    category: 'bars',
    price: 3.50,
    weight: '180g',
    cocoaPercentage: 35,
    description: 'Silky Cadbury Dairy Milk studded with raspberry jellies, crisp sugar coated chocolate drops, and fizzy crackling popping candy.',
    tastingNotes: ['Popping Fizz', 'Fruity Raspberry Jellies', 'Crisp Sugar Shells', 'Creamy Milk Chocolate'],
    ingredients: ['Milk', 'Sugar', 'Jelly Beans', 'Popping Candy (Carbon Dioxide)', 'Cocoa Butter', 'Cocoa Mass'],
    image: 'https://images.unsplash.com/photo-1575372587186-5012f99558ef?auto=format&fit=crop&w=800&q=80',
    accentColor: '#8a1f6a',
    origin: 'Bournville, England'
  },
  {
    id: 'cadbury-flake-royale',
    name: 'Cadbury Flake Royale Crisp & Delicate',
    tagline: 'The Crumbliest, Flakiest Chocolate in the World',
    category: 'bars',
    price: 4.20,
    weight: '160g (4 Luxury Folded Bars)',
    cocoaPercentage: 40,
    description: 'Thinly folded sheets of delicate milk chocolate layered precisely to create an extraordinary melt-in-the-mouth texture that cannot be melted like normal bars.',
    tastingNotes: ['Airy Layered Texture', 'Warm Roasted Milk', 'Instant Velvet Dissolution', 'Subtle Malt'],
    ingredients: ['Milk', 'Sugar', 'Cocoa Butter', 'Cocoa Mass', 'Vegetable Fats', 'Emulsifier (E442)'],
    image: 'https://images.unsplash.com/photo-1541781774459-bb2af2f05b55?auto=format&fit=crop&w=800&q=80',
    accentColor: '#d4af37',
    isNew: true,
    origin: 'Bournville, England'
  },
  {
    id: 'cadbury-bespoke-gifting-box',
    name: 'Custom Bespoke Presentation Box',
    tagline: 'Personalised with Hand-Tied Satin & Monogram',
    category: 'gifting',
    price: 34.00,
    weight: '400g Custom Assortment',
    cocoaPercentage: 50,
    description: 'Design your own Cadbury luxury box with custom choice of 16 artisan pralines, satin ribbon, hot-foil personalized message, and commemorative certificate of craft.',
    tastingNotes: ['Customised to your individual palate selection'],
    ingredients: ['Hand-selected premium ingredients tailored to your recipe'],
    image: 'https://images.unsplash.com/photo-1513519245088-0e12902e5a38?auto=format&fit=crop&w=800&q=80',
    accentColor: '#23085a',
    isNew: true,
    origin: 'Crafted to Order, Bournville Atelier'
  }
];

export const TIMELINE_ERAS: TimelineEra[] = [
  {
    year: '1824',
    title: 'The Bull Street Apothecary',
    subtitle: 'John Cadbury Opens in Birmingham',
    description: 'Quaker entrepreneur John Cadbury opens a shop at 93 Bull Street, Birmingham. Using a mortar and pestle, he grinds raw cocoa nibs and drinking chocolate, promoting it as a wholesome alternative to alcohol.',
    image: 'https://images.unsplash.com/photo-1514432324607-a09d9b4aefdd?auto=format&fit=crop&w=800&q=80',
    milestone: 'First commercial cocoa grinding in Birmingham',
    quote: '“We must make chocolate that elevates the soul and provides pure nourishment.”',
    stat: '1 shop, 1 pestle, 1 visionary idea'
  },
  {
    year: '1879',
    title: 'The Factory in a Garden',
    subtitle: 'Foundation of Bournville Village',
    description: 'George and Richard Cadbury relocate the enterprise from smoggy Birmingham to countryside estate named Bournville. They build model cottages with fruit trees, gardens, swimming pools, and cricket grounds for employees.',
    image: 'https://images.unsplash.com/photo-1513836279014-a89f7a76ae86?auto=format&fit=crop&w=800&q=80',
    milestone: 'Pioneering ethical workplace welfare and village architecture',
    quote: '“No man ought to be condemned to live in a place where a rose cannot grow.”',
    stat: '313 Arts & Crafts homes built with private gardens'
  },
  {
    year: '1905',
    title: 'A Glass and a Half',
    subtitle: 'Birth of Cadbury Dairy Milk',
    description: 'Challenging the dominant Swiss milk chocolate, George Cadbury Jr. develops an unprecedented recipe with far higher liquid milk content. Packaged in distinctive purple wrap with red script, it becomes the UK’s favourite.',
    image: 'https://images.unsplash.com/photo-1549007994-cb92caebd54b?auto=format&fit=crop&w=800&q=80',
    milestone: 'Launch of Dairy Milk & Royal Warrant appointment',
    quote: '“Rich, creamy, and undeniably British.”',
    stat: '1.5 pints of British milk in every half pound'
  },
  {
    year: '1920',
    title: 'The Golden Age of Confectionery',
    subtitle: 'Flake, Fruit & Nut, and Royal Purple',
    description: 'Cadbury adopts Pantone 2685C purple as its official corporate colour in tribute to Queen Victoria. The accidental invention of Flake and the introduction of Fruit & Nut establish an iconic British repertoire.',
    image: 'https://images.unsplash.com/photo-1548907040-4baa42d10919?auto=format&fit=crop&w=800&q=80',
    milestone: 'Official registration of the iconic Cadbury Purple',
    quote: '“An indelible mark of luxury and generosity.”',
    stat: 'Distributed across 4 continents by steamship'
  },
  {
    year: '1969',
    title: 'The Bournville Innovation Era',
    subtitle: 'Precision Engineering & Worldwide Scale',
    description: 'State-of-the-art automated conching and continuous tempering towers are erected in Bournville. Production scales to millions of bars daily while maintaining the artisanal tempering curve.',
    image: 'https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?auto=format&fit=crop&w=800&q=80',
    milestone: 'Modern continuous chocolate pipelines',
    quote: '“Science in service of pure indulgence.”',
    stat: '100 tonnes of chocolate tempered daily'
  },
  {
    year: '2008',
    title: 'Cocoa Life & Sustainable Stewardship',
    subtitle: 'Direct Farmer Partnerships & Fair Sourcing',
    description: 'Cadbury launches Cocoa Life, a groundbreaking $1 Billion sustainability programme transforming cocoa-growing communities across Ghana, Côte d’Ivoire, and Indonesia through forest protection and education.',
    image: 'https://images.unsplash.com/photo-1615485290382-441e4d049cb5?auto=format&fit=crop&w=800&q=80',
    milestone: '100% sustainably sourced cocoa commitment',
    quote: '“Nurturing the land and communities that make joy possible.”',
    stat: '250,000+ cocoa farmers supported'
  },
  {
    year: '2024',
    title: 'The Bicentenary (200 Years)',
    subtitle: 'Generations of Joy Across 200 Years',
    description: 'Celebrating two centuries of chocolate mastery. Reimagining historic archives, introducing 100% recyclable paper wrappers, and unveiling the digital Bournville experience.',
    image: 'https://images.unsplash.com/photo-1526045612212-70caf35c14df?auto=format&fit=crop&w=800&q=80',
    milestone: '200 Years of British Heritage',
    quote: '“From Bull Street to the world: Two centuries of creating moments that matter.”',
    stat: 'Over 350 Million bars enjoyed annually'
  },
  {
    year: '2124',
    title: 'The Future of Chocolate',
    subtitle: 'The Next Century of Sensory Craft',
    description: 'Zero-carbon solar-powered precision crystallisation, quantum bio-conching, personalized micro-nutrient chocolate profiles, and self-restoring circular packaging grown from cocoa pod husks.',
    image: 'https://images.unsplash.com/photo-1507668077129-56e32842fceb?auto=format&fit=crop&w=800&q=80',
    milestone: 'Circular closed-loop confectionery architecture',
    quote: '“The future tastes even more extraordinary than the past.”',
    stat: '100% Circular, Zero Net Carbon'
  }
];

export const FACTORY_STEPS: FactoryStep[] = [
  {
    id: 'step-cocoa',
    number: '01',
    name: 'Cocoa Harvesting & Fermentation',
    tagline: 'Sun-dried Trinitario & Forastero pods',
    temperature: '48°C (Ferment)',
    duration: '6 Days',
    description: 'Ripe golden pods are harvested by hand across sustainable co-operatives. Cocoa beans ferment beneath banana leaves to develop deep floral and fruity precursor esters.',
    flowState: 'Raw Organic Nibs',
    icon: 'Leaf'
  },
  {
    id: 'step-roasting',
    number: '02',
    name: 'Precision Drum Roasting',
    tagline: 'Gentle warmth unlocking aroma',
    temperature: '128°C',
    duration: '45 Mins',
    description: 'Rotating thermal drums gently roast the shelled cocoa nibs. The Maillard reaction unlocks rich notes of roasted malt, warm spice, and nutty caramel.',
    flowState: 'Warm Roasted Nibs',
    icon: 'Flame'
  },
  {
    id: 'step-grinding',
    number: '03',
    name: 'Granite Millstone Grinding',
    tagline: 'Friction turning solid into silk',
    temperature: '55°C',
    duration: '2 Hours',
    description: 'Heavy rotating granite stones crush the nibs until cellular walls release pure cocoa butter, transforming dry granules into glossy, viscous chocolate liquor.',
    flowState: 'Pure Cocoa Liquor',
    icon: 'Layers'
  },
  {
    id: 'step-milk',
    number: '04',
    name: 'Glass & a Half Milk Blending',
    tagline: 'Fresh British & Irish dairy infusion',
    temperature: '65°C',
    duration: '3 Hours',
    description: 'Liquid chocolate liquor is blended with fresh condensed milk and raw cane sugar, creating Cadbury’s proprietary chocolate crumb with unique caramelised notes.',
    flowState: 'Golden Milk Crumb',
    icon: 'Droplets'
  },
  {
    id: 'step-conching',
    number: '05',
    name: 'Acoustic & Mechanical Conching',
    tagline: 'Aerating and refining to 18 microns',
    temperature: '72°C',
    duration: '24 Hours',
    description: 'Heavy granite rollers agitate the liquid chocolate for 24 continuous hours, evaporating bitter volatiles and coating every cocoa particle in smooth cocoa butter.',
    flowState: 'Silken Liquid Chocolate',
    icon: 'RotateCw'
  },
  {
    id: 'step-tempering',
    number: '06',
    name: 'Form V Crystal Tempering',
    tagline: 'The thermal dance for the perfect snap',
    temperature: '28°C → 31.5°C',
    duration: '15 Mins',
    description: 'The molten chocolate is precisely cooled and gently rewarmed through continuous scraped-surface heat exchangers to seed stable Beta-V cocoa butter crystals.',
    flowState: 'Tempered Glossy Flow',
    icon: 'Sparkles'
  },
  {
    id: 'step-moulding',
    number: '07',
    name: 'Precision Vibrational Moulding',
    tagline: 'De-aerating and forming iconic bevelled squares',
    temperature: '29°C',
    duration: '8 Mins',
    description: 'Molten chocolate is deposited into engraved Cadbury moulds. High-frequency acoustic vibration expels micro air bubbles before entering multi-stage cooling tunnels.',
    flowState: 'Solidifying Bar Form',
    icon: 'Grid'
  },
  {
    id: 'step-wrapping',
    number: '08',
    name: 'Gold Foil & Royal Purple Fold',
    tagline: 'Hermetic seal preserving peak aroma',
    temperature: '18°C',
    duration: 'Instantaneous',
    description: 'Solidified bars are enclosed in airtight golden foil and sealed within Royal Cadbury Purple sleeves, ready to bring moments of joy across the globe.',
    flowState: 'Finished Cadbury Bar',
    icon: 'PackageCheck'
  }
];

export const SUSTAINABILITY_REGIONS: SustainabilityRegion[] = [
  {
    id: 'ghana',
    name: 'Ashanti & Western Region',
    country: 'Ghana',
    coordinates: [6.6666, -1.6163],
    farmersCount: '140,000+',
    treesPlanted: '2.8 Million Shade Trees',
    keyInitiative: 'Agroforestry, Women’s Village Savings & Clean Water Boreholes',
    impactStory: 'Over 850 rural school buildings constructed and full digital mapping of 100% farm boundaries ensuring zero deforestation.'
  },
  {
    id: 'ivory-coast',
    name: 'San-Pédro & Soubré',
    country: 'Côte d’Ivoire',
    coordinates: [5.3600, -6.6500],
    farmersCount: '85,000+',
    treesPlanted: '1.2 Million Native Seedlings',
    keyInitiative: 'Child Labour Monitoring & Soil Moisture Conservation',
    impactStory: 'Implemented climate-resilient organic compost systems and solar-powered micro-grid community centers.'
  },
  {
    id: 'indonesia',
    name: 'Sulawesi Cocoa Belt',
    country: 'Indonesia',
    coordinates: [-2.5489, 121.0149],
    farmersCount: '22,000+',
    treesPlanted: '450,000 Canopy Trees',
    keyInitiative: 'Grafting Mastery & High-Yield Disease Resistance',
    impactStory: 'Farmer training academies tripled bean yields per hectare while rejuvenating coastal rainforest buffers.'
  }
];
