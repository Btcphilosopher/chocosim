export interface Product {
  id: string;
  name: string;
  tagline: string;
  category: 'bars' | 'boxes' | 'signature' | 'gifting' | 'heritage';
  price: number;
  weight: string;
  cocoaPercentage: number;
  description: string;
  tastingNotes: string[];
  ingredients: string[];
  image: string;
  accentColor: string;
  isNew?: boolean;
  isBestseller?: boolean;
  origin: string;
}

export interface CartItem {
  product: Product;
  quantity: number;
  customMessage?: string;
  giftBoxStyle?: string;
}

export interface TimelineEra {
  year: string;
  title: string;
  subtitle: string;
  description: string;
  image: string;
  milestone: string;
  quote?: string;
  stat?: string;
}

export interface FactoryStep {
  id: string;
  number: string;
  name: string;
  tagline: string;
  temperature: string;
  duration: string;
  description: string;
  flowState: string;
  icon: string;
}

export interface SustainabilityRegion {
  id: string;
  name: string;
  country: string;
  coordinates: [number, number]; // lat, lng
  farmersCount: string;
  treesPlanted: string;
  keyInitiative: string;
  impactStory: string;
}

export type FidelityMode = 'ultra' | 'high' | 'mobile' | 'reduced-motion';
