-- ChocoSim Schema: 25 Tables for Chocolate Factory Simulation & Production Control
-- For PostgreSQL - Production Ready Schema with UUIDs, constraints, and audit logs.

-- Enable UUID extension if available
-- CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- 1. FACTORIES
CREATE TABLE factories (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name VARCHAR(255) NOT NULL,
    location VARCHAR(255),
    status VARCHAR(50) DEFAULT 'ACTIVE',
    version INT DEFAULT 1,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- 2. PRODUCTION LINES
CREATE TABLE production_lines (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    factory_id UUID REFERENCES factories(id) ON DELETE CASCADE,
    name VARCHAR(255) NOT NULL,
    capacity_kg_per_hr DECIMAL(10, 2) NOT NULL,
    status VARCHAR(50) DEFAULT 'ACTIVE',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- 3. MACHINES
CREATE TABLE machines (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    production_line_id UUID REFERENCES production_lines(id) ON DELETE CASCADE,
    name VARCHAR(255) NOT NULL,
    type VARCHAR(100) NOT NULL, -- 'MIXER', 'CONCHE', 'TEMPERER', 'DEPOSITOR', 'WRAPPER'
    model VARCHAR(100),
    power_rating_kw DECIMAL(10, 2),
    status VARCHAR(50) DEFAULT 'IDLE',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- 4. MACHINE EVENTS
CREATE TABLE machine_events (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    machine_id UUID REFERENCES machines(id) ON DELETE CASCADE,
    event_type VARCHAR(100) NOT NULL, -- 'MACHINE_STARTED', 'MACHINE_STOPPED', 'MACHINE_FAULT', 'MAINTENANCE_REQUIRED'
    severity VARCHAR(50) DEFAULT 'INFO', -- 'INFO', 'WARNING', 'CRITICAL'
    description TEXT,
    is_resolved BOOLEAN DEFAULT FALSE,
    timestamp TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- 5. INGREDIENTS
CREATE TABLE ingredients (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name VARCHAR(255) NOT NULL UNIQUE,
    sku VARCHAR(100) UNIQUE,
    allergen_info TEXT,
    unit_cost_per_kg DECIMAL(10, 4) NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- 6. SUPPLIERS
CREATE TABLE suppliers (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name VARCHAR(255) NOT NULL,
    contact_info TEXT,
    reliability_rating DECIMAL(3, 2),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- 7. INGREDIENT BATCHES
CREATE TABLE ingredient_batches (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    ingredient_id UUID REFERENCES ingredients(id),
    supplier_id UUID REFERENCES suppliers(id),
    lot_number VARCHAR(100) NOT NULL UNIQUE,
    quantity_received_kg DECIMAL(12, 4) NOT NULL,
    quantity_remaining_kg DECIMAL(12, 4) NOT NULL,
    cost_per_kg DECIMAL(10, 4) NOT NULL,
    received_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    expiry_date TIMESTAMP WITH TIME ZONE
);

-- 8. RECIPES
CREATE TABLE recipes (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name VARCHAR(255) NOT NULL UNIQUE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- 9. RECIPE VERSIONS
CREATE TABLE recipe_versions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    recipe_id UUID REFERENCES recipes(id) ON DELETE CASCADE,
    version INT NOT NULL,
    cocoa_percentage DECIMAL(5, 2) NOT NULL,
    cocoa_butter_percentage DECIMAL(5, 2) NOT NULL,
    sugar_percentage DECIMAL(5, 2) NOT NULL,
    milk_percentage DECIMAL(5, 2) NOT NULL,
    lecithin_percentage DECIMAL(5, 2) NOT NULL,
    flavour_percentage DECIMAL(5, 2) NOT NULL,
    target_viscosity_pa_s DECIMAL(8, 4) NOT NULL, -- Target viscosity in Pascal-seconds
    target_particle_size_um DECIMAL(6, 2) NOT NULL, -- Target particle size in micrometers
    is_active BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT unique_recipe_version UNIQUE (recipe_id, version)
);

-- 10. PRODUCTION BATCHES
CREATE TABLE production_batches (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    recipe_version_id UUID REFERENCES recipe_versions(id),
    batch_number VARCHAR(100) NOT NULL UNIQUE,
    status VARCHAR(50) DEFAULT 'PLANNED', -- 'PLANNED', 'QUEUED', 'RUNNING', 'PAUSED', 'COMPLETED', 'FAILED', 'CANCELLED'
    target_quantity_kg DECIMAL(12, 2) NOT NULL,
    actual_yield_kg DECIMAL(12, 2),
    process_loss_kg DECIMAL(12, 2) DEFAULT 0,
    waste_kg DECIMAL(12, 2) DEFAULT 0,
    started_at TIMESTAMP WITH TIME ZONE,
    completed_at TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- 11. PROCESS STAGES
CREATE TABLE process_stages (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    production_batch_id UUID REFERENCES production_batches(id) ON DELETE CASCADE,
    stage_name VARCHAR(100) NOT NULL, -- 'MIXING', 'CONCHING', 'TEMPERING', 'DEPOSITING', 'PACKAGING'
    sequence_order INT NOT NULL,
    status VARCHAR(50) DEFAULT 'PENDING',
    started_at TIMESTAMP WITH TIME ZONE,
    completed_at TIMESTAMP WITH TIME ZONE,
    CONSTRAINT unique_batch_stage UNIQUE (production_batch_id, sequence_order)
);

-- 12. PROCESS MEASUREMENTS
CREATE TABLE process_measurements (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    process_stage_id UUID REFERENCES process_stages(id) ON DELETE CASCADE,
    machine_id UUID REFERENCES machines(id),
    parameter_name VARCHAR(100) NOT NULL, -- 'TEMPERATURE', 'SHEAR_RATE', 'CONCHE_SPEED'
    measured_value DECIMAL(12, 4) NOT NULL,
    unit VARCHAR(50) NOT NULL,
    timestamp TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- 13. QUALITY MEASUREMENTS
CREATE TABLE quality_measurements (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    production_batch_id UUID REFERENCES production_batches(id) ON DELETE CASCADE,
    particle_size_um DECIMAL(6, 2) NOT NULL,
    viscosity_pa_s DECIMAL(8, 4) NOT NULL,
    moisture_percentage DECIMAL(5, 2) NOT NULL,
    temper_index DECIMAL(4, 2) NOT NULL,
    defect_rate_pct DECIMAL(5, 2) DEFAULT 0.0,
    is_within_spec BOOLEAN DEFAULT TRUE,
    tested_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- 14. INVENTORY
CREATE TABLE inventory (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    ingredient_id UUID REFERENCES ingredients(id),
    total_quantity_kg DECIMAL(12, 4) NOT NULL DEFAULT 0.0,
    reorder_level_kg DECIMAL(12, 4) NOT NULL DEFAULT 1000.0,
    last_updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- 15. INVENTORY TRANSACTIONS
CREATE TABLE inventory_transactions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    ingredient_id UUID REFERENCES ingredients(id),
    transaction_type VARCHAR(50) NOT NULL, -- 'RECEIPT', 'CONSUMPTION', 'ADJUSTMENT'
    quantity_kg DECIMAL(12, 4) NOT NULL,
    batch_id UUID, -- References production_batch_id if type is 'CONSUMPTION'
    timestamp TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- 16. PACKAGING
CREATE TABLE packaging (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name VARCHAR(255) NOT NULL,
    type VARCHAR(100) NOT NULL, -- 'FOIL', 'BOX', 'PALLET'
    unit_cost DECIMAL(10, 4) NOT NULL,
    quantity_in_stock INT NOT NULL DEFAULT 0,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- 17. FINISHED PRODUCTS
CREATE TABLE finished_products (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    production_batch_id UUID REFERENCES production_batches(id),
    sku VARCHAR(100) NOT NULL UNIQUE,
    units_produced INT NOT NULL,
    unit_weight_g DECIMAL(8, 2) NOT NULL,
    quality_grade VARCHAR(50) DEFAULT 'GRADE_A',
    packaged_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- 18. ENERGY MEASUREMENTS
CREATE TABLE energy_measurements (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    machine_id UUID REFERENCES machines(id) ON DELETE CASCADE,
    energy_kwh DECIMAL(12, 4) NOT NULL,
    cost_per_kwh DECIMAL(8, 4) NOT NULL,
    timestamp TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- 19. MAINTENANCE
CREATE TABLE maintenance (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    machine_id UUID REFERENCES machines(id) ON DELETE CASCADE,
    type VARCHAR(100) NOT NULL, -- 'PREVENTATIVE', 'REACTIVE', 'CALIBRATION'
    description TEXT,
    cost DECIMAL(10, 2) NOT NULL,
    scheduled_at TIMESTAMP WITH TIME ZONE,
    completed_at TIMESTAMP WITH TIME ZONE
);

-- 20. TELEMETRY
CREATE TABLE telemetry (
    id BIGSERIAL, -- BigSerial for high frequency telemetry
    machine_id UUID REFERENCES machines(id) ON DELETE CASCADE,
    timestamp TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    parameter VARCHAR(100) NOT NULL, -- 'TEMPERATURE', 'PRESSURE', 'RPM', 'MOTOR_LOAD', 'VIBRATION', 'FLOW'
    value DECIMAL(12, 4) NOT NULL,
    unit VARCHAR(50) NOT NULL,
    quality VARCHAR(50) DEFAULT 'GOOD', -- 'GOOD', 'POOR', 'FAULTY'
    PRIMARY KEY (id, timestamp)
) PARTITION BY RANGE (timestamp); -- partitioned by range in production

-- 21. SIMULATION_RUNS
CREATE TABLE simulation_runs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    scenario VARCHAR(100) NOT NULL, -- 'COCOA_PRICE_SPIKE', 'ENERGY_HIKE', 'CONCHE_FAILURE', 'BASE_CASE'
    parameters JSONB NOT NULL,
    random_seed INT NOT NULL,
    software_version VARCHAR(50) NOT NULL,
    status VARCHAR(50) DEFAULT 'RUNNING', -- 'RUNNING', 'COMPLETED', 'FAILED'
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- 22. SIMULATION_RESULTS
CREATE TABLE simulation_results (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    simulation_run_id UUID REFERENCES simulation_runs(id) ON DELETE CASCADE,
    total_yield_kg DECIMAL(12, 2) NOT NULL,
    total_loss_kg DECIMAL(12, 2) NOT NULL,
    total_energy_kwh DECIMAL(12, 2) NOT NULL,
    total_cost DECIMAL(12, 2) NOT NULL,
    simulated_duration_hrs DECIMAL(8, 2) NOT NULL,
    aggregated_metrics JSONB NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- 23. OPTIMISATION_RUNS
CREATE TABLE optimisation_runs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    objective VARCHAR(100) NOT NULL, -- 'MINIMIZE_COST', 'MAXIMIZE_YIELD', 'MINIMIZE_ENERGY'
    constraints JSONB NOT NULL,
    input_parameters JSONB NOT NULL,
    status VARCHAR(50) DEFAULT 'PENDING', -- 'PENDING', 'RUNNING', 'COMPLETED', 'FAILED'
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- 24. OPTIMISATION_RESULTS
CREATE TABLE optimisation_results (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    optimisation_run_id UUID REFERENCES optimisation_runs(id) ON DELETE CASCADE,
    solution JSONB NOT NULL, -- Optimal recipe proportions or production speeds
    expected_yield_kg DECIMAL(12, 2) NOT NULL,
    expected_cost_saving DECIMAL(12, 2) NOT NULL,
    solver_metadata JSONB,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- 25. ECONOMIC_RESULTS
CREATE TABLE economic_results (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    production_batch_id UUID REFERENCES production_batches(id) ON DELETE CASCADE,
    ingredient_cost DECIMAL(12, 2) NOT NULL,
    energy_cost DECIMAL(12, 2) NOT NULL,
    labour_cost DECIMAL(12, 2) NOT NULL,
    packaging_cost DECIMAL(12, 2) NOT NULL,
    maintenance_cost DECIMAL(12, 2) NOT NULL,
    waste_cost DECIMAL(12, 2) NOT NULL,
    total_production_cost DECIMAL(12, 2) NOT NULL,
    cost_per_kg DECIMAL(10, 4) NOT NULL,
    gross_margin_pct DECIMAL(5, 2) NOT NULL,
    calculated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Performance Indexes
CREATE INDEX idx_telemetry_machine_time ON telemetry (machine_id, timestamp DESC);
CREATE INDEX idx_machine_events_severity ON machine_events (severity, timestamp DESC);
CREATE INDEX idx_production_batches_status ON production_batches (status);
CREATE INDEX idx_quality_measurements_spec ON quality_measurements (is_within_spec);
CREATE INDEX idx_inventory_transactions_sku ON inventory_transactions (ingredient_id, timestamp DESC);
