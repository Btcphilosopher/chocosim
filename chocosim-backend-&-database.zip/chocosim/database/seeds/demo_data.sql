-- ChocoSim Demo Data Seeding File
-- Seeds a realistic industrial context including factories, suppliers, active machines,
-- version-controlled recipes, batch logs, and historical process/quality statistics.

-- 1. Insert Factory
INSERT INTO factories (id, name, location, status) VALUES 
('f0000000-0000-0000-0000-000000000001', 'Zurich Craft Confectionery', 'Zurich, Switzerland', 'ACTIVE');

-- 2. Insert Production Lines
INSERT INTO production_lines (id, factory_id, name, capacity_kg_per_hr, status) VALUES 
('l0000000-0000-0000-0000-000000000001', 'f0000000-0000-0000-0000-000000000001', 'Premium Dark & Milk Line A', 500.00, 'ACTIVE');

-- 3. Insert Machines for Line A
INSERT INTO machines (id, production_line_id, name, type, model, power_rating_kw, status) VALUES 
('m0000000-0000-0000-0000-000000000001', 'l0000000-0000-0000-0000-000000000001', 'High-Shear Blender Mix-101', 'MIXER', 'BlendMaster 5000', 45.00, 'RUNNING'),
('m0000000-0000-0000-0000-000000000002', 'l0000000-0000-0000-0000-000000000001', 'Intensive Conche Con-202', 'CONCHE', 'ConcheElite 2T', 90.00, 'RUNNING'),
('m0000000-0000-0000-0000-000000000003', 'l0000000-0000-0000-0000-000000000001', 'Precision Tempering Column Temp-303', 'TEMPERER', 'TempFlow Pro', 30.00, 'RUNNING'),
('m0000000-0000-0000-0000-000000000004', 'l0000000-0000-0000-0000-000000000001', 'Multi-Nozzle Depositor Dep-404', 'DEPOSITOR', 'PistonDep 600', 15.00, 'RUNNING'),
('m0000000-0000-0000-0000-000000000005', 'l0000000-0000-0000-0000-000000000001', 'High-Speed Flow Wrapper Wrap-505', 'WRAPPER', 'PackSpeed 100', 12.00, 'RUNNING');

-- 4. Insert Suppliers
INSERT INTO suppliers (id, name, contact_info, reliability_rating) VALUES 
('s0000000-0000-0000-0000-000000000001', 'Andes Cocoa Bean Co.', 'Andes Region Logistics, Ecuador. email: shipping@andes.co', 0.96),
('s0000000-0000-0000-0000-000000000002', 'Swiss Pure Sugars Ltd', 'Bern Sugar Refinery. contact@swisssugars.ch', 0.99),
('s0000000-0000-0000-0000-000000000003', 'Alpina Dairy Fats', 'Interlaken Dairy Cooperative. fats@alpina.com', 0.94);

-- 5. Insert Ingredients
INSERT INTO ingredients (id, name, sku, allergen_info, unit_cost_per_kg) VALUES 
('i0000000-0000-0000-0000-000000000001', 'Cocoa Mass (Ecuador Single Origin)', 'ING-COCOA-MASS', 'None', 4.5000),
('i0000000-0000-0000-0000-000000000002', 'Cocoa Butter (Deodorized Premium)', 'ING-COCOA-BUTTER', 'None', 6.2000),
('i0000000-0000-0000-0000-000000000003', 'Refined Beet Sugar', 'ING-BEET-SUGAR', 'None', 1.1000),
('i0000000-0000-0000-0000-000000000004', 'Whole Milk Powder', 'ING-MILK-POWDER', 'Dairy (Lactose)', 3.8000),
('i0000000-0000-0000-0000-000000000005', 'Soy Lecithin Emulsifier', 'ING-LECITHIN', 'Soy', 1.9000),
('i0000000-0000-0000-0000-000000000006', 'Natural Bourbon Vanilla Extract', 'ING-VANILLA-EXT', 'None', 45.0000);

-- 6. Insert Inventory Baseline
INSERT INTO inventory (id, ingredient_id, total_quantity_kg, reorder_level_kg) VALUES 
(gen_random_uuid(), 'i0000000-0000-0000-0000-000000000001', 25000.00, 5000.00),
(gen_random_uuid(), 'i0000000-0000-0000-0000-000000000002', 12000.00, 3000.00),
(gen_random_uuid(), 'i0000000-0000-0000-0000-000000000003', 45000.00, 10000.00),
(gen_random_uuid(), 'i0000000-0000-0000-0000-000000000004', 18000.00, 4000.00),
(gen_random_uuid(), 'i0000000-0000-0000-0000-000000000005', 2500.00, 500.00),
(gen_random_uuid(), 'i0000000-0000-0000-0000-000000000006', 450.00, 100.00);

-- 7. Insert Recipes
INSERT INTO recipes (id, name) VALUES 
('r0000000-0000-0000-0000-000000000001', '72% Single Origin Artisan Dark'),
('r0000000-0000-0000-0000-000000000002', 'Alpine Creamy Milk Chocolate');

-- 8. Insert Recipe Versions (Version-controlled)
INSERT INTO recipe_versions (id, recipe_id, version, cocoa_percentage, cocoa_butter_percentage, sugar_percentage, milk_percentage, lecithin_percentage, flavour_percentage, target_viscosity_pa_s, target_particle_size_um, is_active) VALUES 
('v0000000-0000-0000-0000-000000000011', 'r0000000-0000-0000-0000-000000000001', 1, 72.00, 8.00, 19.50, 0.00, 0.40, 0.10, 3.2000, 18.50, FALSE),
('v0000000-0000-0000-0000-000000000012', 'r0000000-0000-0000-0000-000000000001', 2, 72.00, 9.00, 18.50, 0.00, 0.40, 0.10, 2.9000, 16.20, TRUE), -- Active
('v0000000-0000-0000-0000-000000000021', 'r0000000-0000-0000-0000-000000000002', 1, 35.00, 15.00, 31.20, 18.00, 0.50, 0.30, 1.8500, 21.00, TRUE); -- Active

-- 9. Insert Historical Production Batches (Traceable Mass-Balance Demo Data)
INSERT INTO production_batches (id, recipe_version_id, batch_number, status, target_quantity_kg, actual_yield_kg, process_loss_kg, waste_kg, started_at, completed_at) VALUES 
('b0000000-0000-0000-0000-000000000001', 'v0000000-0000-0000-0000-000000000012', 'B-DARK-20260810-01', 'COMPLETED', 1000.00, 982.50, 12.30, 5.20, '2026-08-10 08:00:00+00', '2026-08-10 14:30:00+00'),
('b0000000-0000-0000-0000-000000000002', 'v0000000-0000-0000-0000-000000000012', 'B-DARK-20260811-01', 'COMPLETED', 1000.00, 984.10, 11.20, 4.70, '2026-08-11 08:00:00+00', '2026-08-11 14:15:00+00'),
('b0000000-0000-0000-0000-000000000003', 'v0000000-0000-0000-0000-000000000021', 'B-MILK-20260812-01', 'COMPLETED', 1500.00, 1475.00, 18.50, 6.50, '2026-08-12 07:30:00+00', '2026-08-12 15:00:00+00');

-- 10. Insert Economic Calculations for Historical Batches
INSERT INTO economic_results (id, production_batch_id, ingredient_cost, energy_cost, labour_cost, packaging_cost, maintenance_cost, waste_cost, total_production_cost, cost_per_kg, gross_margin_pct) VALUES 
(gen_random_uuid(), 'b0000000-0000-0000-0000-000000000001', 3720.50, 180.00, 450.00, 120.00, 75.00, 23.40, 4568.90, 4.65, 38.50),
(gen_random_uuid(), 'b0000000-0000-0000-0000-000000000002', 3720.50, 175.40, 450.00, 120.00, 75.00, 21.15, 4562.05, 4.63, 38.75),
(gen_random_uuid(), 'b0000000-0000-0000-0000-000000000003', 5110.20, 245.00, 525.00, 180.00, 95.00, 24.70, 6179.90, 4.19, 44.10);

-- 11. Insert Quality Measurements (SPC baseline)
INSERT INTO quality_measurements (id, production_batch_id, particle_size_um, viscosity_pa_s, moisture_percentage, temper_index, defect_rate_pct, is_within_spec, tested_at) VALUES 
(gen_random_uuid(), 'b0000000-0000-0000-0000-000000000001', 16.45, 2.9500, 1.25, 4.25, 0.12, TRUE, '2026-08-10 14:45:00+00'),
(gen_random_uuid(), 'b0000000-0000-0000-0000-000000000002', 16.12, 2.8800, 1.18, 4.30, 0.08, TRUE, '2026-08-11 14:30:00+00'),
(gen_random_uuid(), 'b0000000-0000-0000-0000-000000000003', 21.25, 1.8800, 1.45, 4.15, 0.15, TRUE, '2026-08-12 15:15:00+00');
