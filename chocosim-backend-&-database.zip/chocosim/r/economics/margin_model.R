# ChocoSim R Economics - Costing and Production Margin Model
# Estimates per-kilogram chocolate production costs, energy rates, and gross margins.

#' Calculate full production cost and gross margin for a finished batch
#' @param raw_material_cost Total cost of ingredients consumed (cocoa mass, butter, sugar, vanilla, etc.)
#' @param yield_kg Actual packaged output weight in kilograms
#' @param power_kwh Total energy consumed by machines on the production line
#' @param electricity_rate_per_kwh Utility rate in CHF/kWh (Swiss Francs)
#' @param labor_hours Total technician and operator effort
#' @param hourly_labor_rate Standard operator labor rate
#' @param packaging_units Number of wrapped consumer boxes
#' @param packaging_unit_cost Material cost per package unit
#' @param waste_kg Scrap chocolate or spillage weight
#' @return A detailed cost breakdown structure
calculate_batch_economics <- function(raw_material_cost, yield_kg, power_kwh, 
                                      electricity_rate_per_kwh = 0.22,
                                      labor_hours = 6.0,
                                      hourly_labor_rate = 35.0,
                                      packaging_units = 1000,
                                      packaging_unit_cost = 0.12,
                                      waste_kg = 5.0) {
  
  # Calculate operational overheads
  energy_cost <- power_kwh * electricity_rate_per_kwh
  labor_cost <- labor_hours * hourly_labor_rate
  packaging_cost <- packaging_units * packaging_unit_cost
  
  # Allocate maintenance depreciation based on running duration
  # Standard machine wear depreciation estimate (CHF 15.00 per active hour)
  maintenance_cost <- labor_hours * 15.00
  
  # Value the waste loss (waste is chocolate we paid for but cannot sell)
  # Standard ingredient material loss value: we multiply waste_kg by the estimated average cost
  estimated_cost_per_kg_ingredients <- raw_material_cost / (yield_kg + waste_kg)
  waste_cost <- waste_kg * estimated_cost_per_kg_ingredients
  
  # Combine to find the total production expenditure
  total_production_cost <- raw_material_cost + energy_cost + labor_cost + packaging_cost + maintenance_cost + waste_cost
  
  # Cost per useful kilogram produced
  cost_per_kg <- total_production_cost / yield_kg
  
  # Market wholesale value per premium kg (e.g. standard premium craft price of CHF 12.50 / kg)
  market_value_per_kg <- 12.50
  total_batch_revenue <- yield_kg * market_value_per_kg
  
  gross_profit <- total_batch_revenue - total_production_cost
  gross_margin_pct <- (gross_profit / total_batch_revenue) * 100.0
  
  # Compile detailed economic report
  economics_report <- list(
    yield_kg = yield_kg,
    ingredient_cost = raw_material_cost,
    energy_cost = energy_cost,
    labor_cost = labor_cost,
    packaging_cost = packaging_cost,
    maintenance_cost = maintenance_cost,
    waste_cost = waste_cost,
    total_production_cost = total_production_cost,
    cost_per_kg = cost_per_kg,
    wholesale_value = market_value_per_kg,
    total_revenue = total_batch_revenue,
    gross_profit = gross_profit,
    gross_margin_pct = gross_margin_pct
  )
  
  return(economics_report)
}

#' Run sensitivity analysis for fluctuating cocoa market rates
#' Shows the financial impact on margin as cocoa bean rates rise.
cocoa_price_sensitivity_analysis <- function(baseline_report, cocoa_increase_percentages) {
  sensitivities <- data.frame(
    Price_Increase_Pct = cocoa_increase_percentages,
    New_Ingredient_Cost = numeric(length(cocoa_increase_percentages)),
    New_Total_Cost = numeric(length(cocoa_increase_percentages)),
    New_Cost_Per_Kg = numeric(length(cocoa_increase_percentages)),
    New_Margin_Pct = numeric(length(cocoa_increase_percentages))
  )
  
  for (i in 1:length(cocoa_increase_percentages)) {
    inc <- cocoa_increase_percentages[i] / 100
    # Assume 72% of ingredient cost is sensitive to cocoa mass price shifts
    cocoa_portion <- baseline_report$ingredient_cost * 0.72
    other_portion <- baseline_report$ingredient_cost * 0.28
    
    new_ingredients <- cocoa_portion * (1 + inc) + other_portion
    new_total_cost <- baseline_report$total_production_cost - baseline_report$ingredient_cost + new_ingredients
    new_cost_per_kg <- new_total_cost / baseline_report$yield_kg
    
    new_profit <- baseline_report$total_revenue - new_total_cost
    new_margin <- (new_profit / baseline_report$total_revenue) * 100.0
    
    sensitivities$New_Ingredient_Cost[i] <- new_ingredients
    sensitivities$New_Total_Cost[i] <- new_total_cost
    sensitivities$New_Cost_Per_Kg[i] <- new_cost_per_kg
    sensitivities$New_Margin_Pct[i] <- new_margin
  }
  
  return(sensitivities)
}
