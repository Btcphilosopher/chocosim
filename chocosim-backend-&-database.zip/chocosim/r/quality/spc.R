# ChocoSim R Analytics - Statistical Process Control (SPC) Engine
# Computes process mean, variance, control limits (UCL, LCL), and capability indices (Cp, Cpk).

library(stats)

#' Calculate SPC metrics for chocolate quality parameters (e.g. Particle Size, Viscosity)
#' @param measurements_df A data frame containing 'batch_id' and 'value' (the parameter measured)
#' @param target_nominal The targeted value specified by the food technologists
#' @param usl Upper Specification Limit
#' @param lsl Lower Specification Limit
#' @return A list of process capability indices and control boundary coordinates
calculate_process_capability <- function(measurements_df, target_nominal, usl, lsl) {
  values <- measurements_df$value
  n <- length(values)
  
  if (n < 5) {
    stop("Insufficient data points. Minimum 5 batches required for statistical stability.")
  }
  
  # Calculate baseline statistics
  process_mean <- mean(values, na.rm = TRUE)
  process_sd <- sd(values, na.rm = TRUE)
  process_median <- median(values, na.rm = TRUE)
  
  # 3-Sigma Control Limits (Shewhart charts)
  ucl <- process_mean + 3 * process_sd
  lcl <- max(0, process_mean - 3 * process_sd) # cannot be negative for physical attributes
  
  # Process Capability Indices (Cp, Cpk)
  # Cp = (USL - LSL) / (6 * sd)
  # Cpk = Min( (USL - Mean)/(3 * sd), (Mean - LSL)/(3 * sd) )
  cp <- (usl - lsl) / (6 * process_sd)
  
  cpu <- (usl - process_mean) / (3 * process_sd)
  cpl <- (process_mean - lsl) / (3 * process_sd)
  cpk <- min(cpu, cpl)
  
  # Flag Outliers (outside 3-Sigma bounds)
  outliers <- measurements_df[values > ucl | values < lcl, ]
  
  # Return complete statistical context
  spc_report <- list(
    data_points = n,
    mean = process_mean,
    median = process_median,
    sd = process_sd,
    ucl = ucl,
    lcl = lcl,
    target = target_nominal,
    cp = cp,
    cpk = cpk,
    is_capable_process = (cpk >= 1.33), # Industrial standard: 1.33 means highly capable
    outlier_count = nrow(outliers),
    outlier_batches = outliers$batch_id
  )
  
  return(spc_report)
}

#' Generate process warning flags based on Western Electric rules (Runs rules)
#' Detects drift or shifts in tempering viscosity before failure occurs.
detect_process_drift <- function(values) {
  n <- length(values)
  if (n < 8) return("STABLE")
  
  mu <- mean(values)
  sigma <- sd(values)
  
  # Rule 1: Single point beyond 3-sigma
  if (any(abs(values - mu) > 3 * sigma)) {
    return("RULE_1_VIOLATION: Point Out of Control Limits")
  }
  
  # Rule 2: 9 consecutive points on one side of the mean (shift in process average)
  for (i in 1:(n - 8)) {
    sub <- values[i:(i + 8)] - mu
    if (all(sub > 0) || all(sub < 0)) {
      return("RULE_2_VIOLATION: Shift in Process Mean detected (9 consecutive points)")
    }
  }
  
  return("IN_CONTROL")
}
