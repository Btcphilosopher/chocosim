//! ChocoSim - Production Mass Balance & Material Traceability Engine
//! High-performance material verification and mass-conservation checker for chocolate batches.

use std::collections::HashMap;
use uuid::Uuid;
use chrono::{DateTime, Utc};
use serde::{Serialize, Deserialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct IngredientUsage {
    pub ingredient_id: Uuid,
    pub quantity_input_kg: f64,
    pub lot_number: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct MassBalanceRecord {
    pub batch_id: Uuid,
    pub recipe_version_id: Uuid,
    pub total_input_mass_kg: f64,
    pub raw_materials_used: Vec<IngredientUsage>,
    
    // Outputs & losses
    pub actual_yield_kg: f64,
    pub process_loss_kg: f64, // e.g. stuck to scraper walls, evaporation
    pub scrap_waste_kg: f64,   // e.g. off-spec discard, line flushing
    
    pub timestamp: DateTime<Utc>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct MassReconciliationReport {
    pub batch_id: Uuid,
    pub mass_input: f64,
    pub mass_output_total: f64,
    pub mass_discrepancy_kg: f64,
    pub process_loss_pct: f64,
    pub waste_pct: f64,
    pub yield_pct: f64,
    pub is_balanced: bool,
    pub validation_message: String,
}

pub struct MassBalanceEngine {
    tolerance_kg: f64, // Allowed numerical/sensor accuracy discrepancy (e.g. 0.1 kg)
}

impl MassBalanceEngine {
    pub fn new(tolerance_kg: f64) -> Self {
        Self { tolerance_kg }
    }

    /// Reconciles input mass against outputs (yield + loss + waste) to satisfy:
    /// Sum(Inputs) = Yield + Loss + Waste ± Tolerance
    pub fn reconcile(&self, record: &MassBalanceRecord) -> MassReconciliationReport {
        let total_input = record.total_input_mass_kg;
        let total_output = record.actual_yield_kg + record.process_loss_kg + record.scrap_waste_kg;
        
        let discrepancy = (total_input - total_output).abs();
        let is_balanced = discrepancy <= self.tolerance_kg;
        
        let yield_pct = (record.actual_yield_kg / total_input) * 100.0;
        let process_loss_pct = (record.process_loss_kg / total_input) * 100.0;
        let waste_pct = (record.scrap_waste_kg / total_input) * 100.0;
        
        let validation_message = if is_balanced {
            format!("Mass balance verified successfully. Discrepancy of {:.4} kg is within safe threshold of {:.4} kg.", discrepancy, self.tolerance_kg)
        } else {
            format!("CRITICAL: Mass balance violation! Unaccounted mass of {:.4} kg detected. Inputs ({:.2} kg) do not equal outputs ({:.2} kg). Please audit load cells and scraper logs.", discrepancy, total_input, total_output)
        };

        MassReconciliationReport {
            batch_id: record.batch_id,
            mass_input: total_input,
            mass_output_total: total_output,
            mass_discrepancy_kg: discrepancy,
            process_loss_pct,
            waste_pct,
            yield_pct,
            is_balanced,
            validation_message,
        }
    }
}
