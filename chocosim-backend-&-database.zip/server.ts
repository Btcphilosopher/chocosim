import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import dotenv from "dotenv";

dotenv.config();

const app = express();
app.use(express.json());

const PORT = 3000;

// ==========================================
// IN-MEMORY HIGH-FIDELITY DATABASE ENGINE
// ==========================================

interface Factory {
  id: string;
  name: string;
  location: string;
  status: string;
}

interface Machine {
  id: string;
  name: string;
  type: "MIXER" | "CONCHE" | "TEMPERER" | "DEPOSITOR" | "WRAPPER";
  model: string;
  powerRatingKw: number;
  status: "RUNNING" | "IDLE" | "FAULT" | "MAINTENANCE";
  tempC?: number;
  pressureBar?: number;
  rpm?: number;
  motorLoadPct?: number;
  flowRateLpm?: number;
  vibrationMmS?: number;
}

interface Ingredient {
  id: string;
  name: string;
  sku: string;
  allergenInfo: string;
  unitCostPerKg: number;
  quantityInStockKg: number;
  reorderLevelKg: number;
}

interface RecipeVersion {
  id: string;
  recipeId: string;
  recipeName: string;
  version: number;
  cocoaPct: number;
  cocoaButterPct: number;
  sugarPct: number;
  milkPct: number;
  lecithinPct: number;
  flavourPct: number;
  targetViscosityPaS: number;
  targetParticleSizeUm: number;
  isActive: boolean;
}

interface ProductionBatch {
  id: string;
  recipeVersionId: string;
  recipeName: string;
  batchNumber: string;
  status: "PLANNED" | "QUEUED" | "RUNNING" | "PAUSED" | "COMPLETED" | "FAILED" | "CANCELLED";
  targetQuantityKg: number;
  actualYieldKg: number;
  processLossKg: number;
  wasteKg: number;
  startedAt?: string;
  completedAt?: string;
  createdAt: string;
}

interface SystemEvent {
  id: string;
  machineId?: string;
  machineName?: string;
  eventType: string;
  severity: "INFO" | "WARNING" | "CRITICAL";
  description: string;
  timestamp: string;
  isResolved: boolean;
}

interface TelemetryPoint {
  machineId: string;
  timestamp: string;
  parameter: string;
  value: number;
  unit: string;
  quality: "GOOD" | "POOR" | "FAULTY";
}

interface SimulationRun {
  id: string;
  scenario: string;
  randomSeed: number;
  softwareVersion: string;
  createdAt: string;
  status: "RUNNING" | "COMPLETED" | "FAILED";
  parameters: any;
  results?: {
    totalYieldKg: number;
    totalLossKg: number;
    totalEnergyKwh: number;
    totalCost: number;
    simulatedDurationHrs: number;
    scadaTimeline: any[];
  };
}

interface OptimisationRun {
  id: string;
  objective: "MINIMIZE_COST" | "MAXIMIZE_YIELD" | "MINIMIZE_ENERGY";
  constraints: any;
  inputParameters: any;
  status: "PENDING" | "RUNNING" | "COMPLETED";
  createdAt: string;
  results?: {
    solution: {
      cocoaPct: number;
      cocoaButterPct: number;
      sugarPct: number;
      milkPct: number;
      lecithinPct: number;
      flavourPct: number;
      conchingTempC: number;
      conchingTimeHrs: number;
    };
    expectedYieldKg: number;
    expectedCostSaving: number;
    solverIterations: number;
  };
}

// ------------------------------------------
// DEMO SEED DATA CONSTRUCTS
// ------------------------------------------

const factories: Factory[] = [
  {
    id: "f0000000-0000-0000-0000-000000000001",
    name: "Zurich Craft Confectionery",
    location: "Zurich, Switzerland",
    status: "ACTIVE"
  }
];

const machines: Machine[] = [
  {
    id: "m0000000-0000-0000-0000-000000000001",
    name: "High-Shear Blender Mix-101",
    type: "MIXER",
    model: "BlendMaster 5000",
    powerRatingKw: 45.0,
    status: "RUNNING",
    tempC: 42.5,
    rpm: 1200,
    motorLoadPct: 68.2,
    vibrationMmS: 1.8
  },
  {
    id: "m0000000-0000-0000-0000-000000000002",
    name: "Intensive Conche Con-202",
    type: "CONCHE",
    model: "ConcheElite 2T",
    powerRatingKw: 90.0,
    status: "RUNNING",
    tempC: 78.4,
    rpm: 65,
    motorLoadPct: 82.5,
    vibrationMmS: 3.2
  },
  {
    id: "m0000000-0000-0000-0000-000000000003",
    name: "Precision Tempering Column Temp-303",
    type: "TEMPERER",
    model: "TempFlow Pro",
    powerRatingKw: 30.0,
    status: "RUNNING",
    tempC: 31.2,
    pressureBar: 4.2,
    motorLoadPct: 45.0,
    flowRateLpm: 120.5,
    vibrationMmS: 0.8
  },
  {
    id: "m0000000-0000-0000-0000-000000000004",
    name: "Multi-Nozzle Depositor Dep-404",
    type: "DEPOSITOR",
    model: "PistonDep 600",
    powerRatingKw: 15.0,
    status: "RUNNING",
    tempC: 29.8,
    pressureBar: 2.1,
    rpm: 40,
    motorLoadPct: 55.4,
    flowRateLpm: 35.0,
    vibrationMmS: 1.1
  },
  {
    id: "m0000000-0000-0000-0000-000000000005",
    name: "High-Speed Flow Wrapper Wrap-505",
    type: "WRAPPER",
    model: "PackSpeed 100",
    powerRatingKw: 12.0,
    status: "RUNNING",
    rpm: 90,
    motorLoadPct: 38.0,
    vibrationMmS: 2.4
  }
];

const ingredients: Ingredient[] = [
  {
    id: "i0000000-0000-0000-0000-000000000001",
    name: "Cocoa Mass (Ecuador Single Origin)",
    sku: "ING-COCOA-MASS",
    allergenInfo: "None",
    unitCostPerKg: 4.50,
    quantityInStockKg: 24800,
    reorderLevelKg: 5000
  },
  {
    id: "i0000000-0000-0000-0000-000000000002",
    name: "Cocoa Butter (Deodorized Premium)",
    sku: "ING-COCOA-BUTTER",
    allergenInfo: "None",
    unitCostPerKg: 6.20,
    quantityInStockKg: 11500,
    reorderLevelKg: 3000
  },
  {
    id: "i0000000-0000-0000-0000-000000000003",
    name: "Refined Beet Sugar",
    sku: "ING-BEET-SUGAR",
    allergenInfo: "None",
    unitCostPerKg: 1.10,
    quantityInStockKg: 42000,
    reorderLevelKg: 10000
  },
  {
    id: "i0000000-0000-0000-0000-000000000004",
    name: "Whole Milk Powder",
    sku: "ING-MILK-POWDER",
    allergenInfo: "Dairy (Lactose)",
    unitCostPerKg: 3.80,
    quantityInStockKg: 17200,
    reorderLevelKg: 4000
  },
  {
    id: "i0000000-0000-0000-0000-000000000005",
    name: "Soy Lecithin Emulsifier",
    sku: "ING-LECITHIN",
    allergenInfo: "Soy",
    unitCostPerKg: 1.90,
    quantityInStockKg: 2400,
    reorderLevelKg: 500
  },
  {
    id: "i0000000-0000-0000-0000-000000000006",
    name: "Natural Bourbon Vanilla Extract",
    sku: "ING-VANILLA-EXT",
    allergenInfo: "None",
    unitCostPerKg: 45.00,
    quantityInStockKg: 410,
    reorderLevelKg: 100
  }
];

const recipeVersions: RecipeVersion[] = [
  {
    id: "v0000000-0000-0000-0000-000000000011",
    recipeId: "r0000000-0000-0000-0000-000000000001",
    recipeName: "72% Single Origin Artisan Dark",
    version: 1,
    cocoaPct: 72.0,
    cocoaButterPct: 8.0,
    sugarPct: 19.5,
    milkPct: 0.0,
    lecithinPct: 0.4,
    flavourPct: 0.1,
    targetViscosityPaS: 3.2,
    targetParticleSizeUm: 18.5,
    isActive: false
  },
  {
    id: "v0000000-0000-0000-0000-000000000012",
    recipeId: "r0000000-0000-0000-0000-000000000001",
    recipeName: "72% Single Origin Artisan Dark",
    version: 2,
    cocoaPct: 72.0,
    cocoaButterPct: 9.0,
    sugarPct: 18.5,
    milkPct: 0.0,
    lecithinPct: 0.4,
    flavourPct: 0.1,
    targetViscosityPaS: 2.9,
    targetParticleSizeUm: 16.2,
    isActive: true
  },
  {
    id: "v0000000-0000-0000-0000-000000000021",
    recipeId: "r0000000-0000-0000-0000-000000000002",
    recipeName: "Alpine Creamy Milk Chocolate",
    version: 1,
    cocoaPct: 35.0,
    cocoaButterPct: 15.0,
    sugarPct: 31.2,
    milkPct: 18.0,
    lecithinPct: 0.5,
    flavourPct: 0.3,
    targetViscosityPaS: 1.85,
    targetParticleSizeUm: 21.0,
    isActive: true
  }
];

const productionBatches: ProductionBatch[] = [
  {
    id: "b0000000-0000-0000-0000-000000000001",
    recipeVersionId: "v0000000-0000-0000-0000-000000000012",
    recipeName: "72% Single Origin Artisan Dark",
    batchNumber: "B-DARK-20260810-01",
    status: "COMPLETED",
    targetQuantityKg: 1000.0,
    actualYieldKg: 982.5,
    processLossKg: 12.3,
    wasteKg: 5.2,
    startedAt: "2026-08-10T08:00:00Z",
    completedAt: "2026-08-10T14:30:00Z",
    createdAt: "2026-08-10T08:00:00Z"
  },
  {
    id: "b0000000-0000-0000-0000-000000000002",
    recipeVersionId: "v0000000-0000-0000-0000-000000000012",
    recipeName: "72% Single Origin Artisan Dark",
    batchNumber: "B-DARK-20260811-01",
    status: "COMPLETED",
    targetQuantityKg: 1000.0,
    actualYieldKg: 984.1,
    processLossKg: 11.2,
    wasteKg: 4.7,
    startedAt: "2026-08-11T08:00:00Z",
    completedAt: "2026-08-11T14:15:00Z",
    createdAt: "2026-08-11T08:00:00Z"
  },
  {
    id: "b0000000-0000-0000-0000-000000000003",
    recipeVersionId: "v0000000-0000-0000-0000-000000000021",
    recipeName: "Alpine Creamy Milk Chocolate",
    batchNumber: "B-MILK-20260812-01",
    status: "COMPLETED",
    targetQuantityKg: 1500.0,
    actualYieldKg: 1475.0,
    processLossKg: 18.5,
    wasteKg: 6.5,
    startedAt: "2026-08-12T07:30:00Z",
    completedAt: "2026-08-12T15:00:00Z",
    createdAt: "2026-08-12T07:30:00Z"
  }
];

const systemEvents: SystemEvent[] = [
  {
    id: "e0000000-0000-0000-0000-000000000001",
    machineId: "m0000000-0000-0000-0000-000000000002",
    machineName: "Intensive Conche Con-202",
    eventType: "MACHINE_STARTED",
    severity: "INFO",
    description: "Intensive Conche 2T successfully completed warm-up cycles. Commencing shearing operations.",
    timestamp: new Date(Date.now() - 3600000 * 2).toISOString(),
    isResolved: true
  },
  {
    id: "e0000000-0000-0000-0000-000000000002",
    machineId: "m0000000-0000-0000-0000-000000000002",
    machineName: "Intensive Conche Con-202",
    eventType: "TEMPERATURE_WARNING",
    severity: "WARNING",
    description: "Conche internal chamber temperature spiked to 81.2°C (Target: 78.0°C). Water cooling valve triggered.",
    timestamp: new Date(Date.now() - 1800000).toISOString(),
    isResolved: true
  }
];

const simulationRuns: SimulationRun[] = [];
const optimisationRuns: OptimisationRun[] = [];

// High-frequency telemetry cache
const telemetryCache: TelemetryPoint[] = [];

// Pre-fill telemetry with some realistic curves
function generateHistoricalTelemetry() {
  const now = Date.now();
  machines.forEach((m) => {
    for (let i = 20; i >= 0; i--) {
      const time = new Date(now - i * 5000).toISOString();
      const randomOffset = (Math.random() - 0.5) * 2;
      
      let param = "TEMPERATURE";
      let val = m.tempC || 30.0;
      let unit = "°C";

      if (m.type === "CONCHE") {
        param = "RPM";
        val = m.rpm || 60;
        unit = "RPM";
      } else if (m.type === "MIXER") {
        param = "MOTOR_LOAD";
        val = m.motorLoadPct || 50;
        unit = "%";
      } else if (m.type === "TEMPERER") {
        param = "FLOW";
        val = m.flowRateLpm || 100;
        unit = "L/min";
      }

      telemetryCache.push({
        machineId: m.id,
        timestamp: time,
        parameter: param,
        value: val + randomOffset,
        unit: unit,
        quality: "GOOD"
      });
    }
  });
}
generateHistoricalTelemetry();

// Maintain active telemetry stream simulation on server interval
setInterval(() => {
  const time = new Date().toISOString();
  machines.forEach((m) => {
    if (m.status === "RUNNING") {
      const randomOffset = (Math.random() - 0.5) * 1.5;
      
      // Update machine properties slightly for realism
      if (m.tempC !== undefined) m.tempC = Math.max(15, m.tempC + (Math.random() - 0.5) * 0.4);
      if (m.motorLoadPct !== undefined) m.motorLoadPct = Math.max(10, Math.min(100, m.motorLoadPct + (Math.random() - 0.5) * 2.0));
      if (m.rpm !== undefined) m.rpm = Math.max(0, m.rpm + (Math.random() - 0.5) * 1.0);

      // Select parameters to publish
      const params = m.type === "CONCHE" 
        ? [ { n: "TEMPERATURE", v: m.tempC || 78, u: "°C" }, { n: "RPM", v: m.rpm || 65, u: "RPM" } ]
        : m.type === "TEMPERER"
        ? [ { n: "TEMPERATURE", v: m.tempC || 31, u: "°C" }, { n: "FLOW", v: m.flowRateLpm || 120, u: "L/min" } ]
        : [ { n: "MOTOR_LOAD", v: m.motorLoadPct || 50, u: "%" }, { n: "VIBRATION", v: m.vibrationMmS || 1.5, u: "mm/s" } ];

      params.forEach((p) => {
        telemetryCache.push({
          machineId: m.id,
          timestamp: time,
          parameter: p.n,
          value: Number(p.v.toFixed(3)),
          unit: p.u,
          quality: "GOOD"
        });
      });
    }
  });

  // Keep telemetry cache size stable (last 500 records)
  if (telemetryCache.length > 500) {
    telemetryCache.splice(0, telemetryCache.length - 500);
  }
}, 5000);

// ==========================================
// R STATISTICAL ENGINE EMULATOR (SPC / MARGIN)
// ==========================================

function runR_SPCAnalysis(parameter: string) {
  // Extract values
  let mockValues: number[] = [];
  let usl = 0;
  let lsl = 0;
  let target = 0;

  if (parameter === "particle_size") {
    // Standard craft specs: 15-22 um, target: 16.5 um
    mockValues = productionBatches
      .filter(b => b.status === "COMPLETED")
      .map((_, idx) => 16.0 + (idx % 3 === 0 ? 0.45 : (idx % 2 === 0 ? -0.15 : 0.12)));
    usl = 22.0;
    lsl = 15.0;
    target = 16.5;
  } else {
    // Viscosity
    mockValues = productionBatches
      .filter(b => b.status === "COMPLETED")
      .map((_, idx) => 2.8 + (idx % 3 === 0 ? 0.15 : (idx % 2 === 0 ? -0.08 : 0.05)));
    usl = 3.6;
    lsl = 2.4;
    target = 2.9;
  }

  const n = mockValues.length;
  const mean = mockValues.reduce((a, b) => a + b, 0) / n;
  const variance = mockValues.reduce((a, b) => a + Math.pow(b - mean, 2), 0) / (n - 1 || 1);
  const sd = Math.sqrt(variance);

  const ucl = mean + 3 * sd;
  const lcl = Math.max(0, mean - 3 * sd);

  const cp = (usl - lsl) / (6 * sd || 0.1);
  const cpu = (usl - mean) / (3 * sd || 0.1);
  const cpl = (mean - lsl) / (3 * sd || 0.1);
  const cpk = Math.min(cpu, cpl);

  const driftStatus = n >= 3 && Math.abs(mockValues[n - 1] - mean) > 2 * sd ? "WARNING_DRIFT" : "STABLE";

  return {
    parameter,
    dataPoints: n,
    mean: Number(mean.toFixed(4)),
    sd: Number(sd.toFixed(4)),
    ucl: Number(ucl.toFixed(4)),
    lcl: Number(lcl.toFixed(4)),
    target,
    usl,
    lsl,
    cp: Number(cp.toFixed(3)),
    cpk: Number(cpk.toFixed(3)),
    isCapableProcess: cpk >= 1.33,
    driftStatus,
    controlChartValues: mockValues.map((v, i) => ({
      batchIndex: i + 1,
      value: Number(v.toFixed(3)),
      mean: Number(mean.toFixed(3)),
      ucl: Number(ucl.toFixed(3)),
      lcl: Number(lcl.toFixed(3))
    }))
  };
}

function runREconomicBreakdown(batch: ProductionBatch) {
  // Ingredient cost estimation
  let ingredientsCost = batch.targetQuantityKg * 4.15; // default estimate
  const isDark = batch.recipeName.toLowerCase().includes("dark");

  if (isDark) {
    ingredientsCost = batch.targetQuantityKg * (0.72 * 4.50 + 0.09 * 6.20 + 0.185 * 1.10);
  } else {
    ingredientsCost = batch.targetQuantityKg * (0.35 * 4.50 + 0.15 * 6.20 + 0.312 * 1.10 + 0.18 * 3.80);
  }

  const powerKwh = batch.targetQuantityKg * 0.18; // 0.18 kWh per kg
  const energyCost = powerKwh * 0.22; // CHF 0.22/kWh
  const laborHours = batch.targetQuantityKg / 160.0; // 160kg per hour of labor
  const laborCost = laborHours * 35.0; // CHF 35.00/hour
  const packagingCost = (batch.targetQuantityKg / 0.1) * 0.08; // 100g bars, CHF 0.08 each
  const maintenanceCost = laborHours * 15.00;
  const wasteCost = batch.wasteKg * (ingredientsCost / batch.targetQuantityKg);

  const totalProductionCost = ingredientsCost + energyCost + laborCost + packagingCost + maintenanceCost + wasteCost;
  const costPerKg = totalProductionCost / (batch.actualYieldKg || batch.targetQuantityKg);
  const marketPrice = isDark ? 13.50 : 11.50; // premium Swiss chocolate retail index
  const grossMarginPct = ((marketPrice - costPerKg) / marketPrice) * 100;

  return {
    batchId: batch.id,
    batchNumber: batch.batchNumber,
    recipeName: batch.recipeName,
    yieldKg: batch.actualYieldKg || batch.targetQuantityKg,
    ingredientCost: Number(ingredientsCost.toFixed(2)),
    energyCost: Number(energyCost.toFixed(2)),
    laborCost: Number(laborCost.toFixed(2)),
    packagingCost: Number(packagingCost.toFixed(2)),
    maintenanceCost: Number(maintenanceCost.toFixed(2)),
    wasteCost: Number(wasteCost.toFixed(2)),
    totalProductionCost: Number(totalProductionCost.toFixed(2)),
    costPerKg: Number(costPerKg.toFixed(2)),
    marketPrice: marketPrice,
    grossMarginPct: Number(grossMarginPct.toFixed(2))
  };
}

// ==========================================
// REST API ROUTE IMPLEMENTATIONS (RUST/AXUM API STUB)
// ==========================================

app.get("/api/v1/health", (req, res) => {
  res.json({
    status: "operational",
    databaseConnected: true,
    telemetryBufferActive: true,
    engine: "ChocoSim Rust core v1.4.0 + R 4.3"
  });
});

app.get("/api/v1/factory", (req, res) => {
  res.json(factories[0]);
});

app.get("/api/v1/machines", (req, res) => {
  res.json(machines);
});

app.get("/api/v1/production", (req, res) => {
  res.json(productionBatches);
});

app.get("/api/v1/inventory", (req, res) => {
  res.json(ingredients);
});

app.get("/api/v1/recipes", (req, res) => {
  res.json(recipeVersions);
});

// Create production batch (POST /api/v1/batches)
app.post("/api/v1/batches", (req, res) => {
  const { recipeVersionId, targetQuantityKg } = req.body;
  if (!recipeVersionId || !targetQuantityKg) {
    return res.status(400).json({ error: "Missing recipeVersionId or targetQuantityKg" });
  }

  const recipe = recipeVersions.find((r) => r.id === recipeVersionId);
  if (!recipe) {
    return res.status(404).json({ error: "Recipe version not found" });
  }

  // Enforce inventory deduction (Mass Balance Check)
  const requiredCocoa = targetQuantityKg * (recipe.cocoaPct / 100);
  const cocoaInv = ingredients.find(i => i.sku === "ING-COCOA-MASS");

  if (cocoaInv && cocoaInv.quantityInStockKg < requiredCocoa) {
    return res.status(422).json({
      error: `Material shortage! Requiring ${requiredCocoa.toFixed(1)} kg of Cocoa Mass. Current warehouse stock is ${cocoaInv.quantityInStockKg.toFixed(1)} kg.`
    });
  }

  // Deduct materials
  if (cocoaInv) cocoaInv.quantityInStockKg -= requiredCocoa;
  
  const butterInv = ingredients.find(i => i.sku === "ING-COCOA-BUTTER");
  const requiredButter = targetQuantityKg * (recipe.cocoaButterPct / 100);
  if (butterInv) butterInv.quantityInStockKg -= requiredButter;

  const sugarInv = ingredients.find(i => i.sku === "ING-BEET-SUGAR");
  const requiredSugar = targetQuantityKg * (recipe.sugarPct / 100);
  if (sugarInv) sugarInv.quantityInStockKg -= requiredSugar;

  // Simulate process loss and scrap (Mass Balance Equation)
  const processLossKg = Number((targetQuantityKg * 0.012).toFixed(2)); // 1.2% process loss
  const wasteKg = Number((targetQuantityKg * 0.005).toFixed(2)); // 0.5% waste
  const actualYieldKg = targetQuantityKg - processLossKg - wasteKg;

  const newBatch: ProductionBatch = {
    id: `b0000000-0000-0000-0000-${Math.floor(100000000000 + Math.random() * 900000000000)}`,
    recipeVersionId,
    recipeName: recipe.recipeName,
    batchNumber: `B-${recipe.recipeName.includes("Dark") ? "DARK" : "MILK"}-${new Date().toISOString().replace(/[-T:]/g, "").slice(0, 8)}-${productionBatches.length + 1}`,
    status: "COMPLETED", // Complete instantly for simulation flow
    targetQuantityKg,
    actualYieldKg,
    processLossKg,
    wasteKg,
    startedAt: new Date().toISOString(),
    completedAt: new Date(Date.now() + 3600000).toISOString(),
    createdAt: new Date().toISOString()
  };

  productionBatches.unshift(newBatch);

  // Generate an audit event
  systemEvents.unshift({
    id: `e0000000-0000-0000-0000-${Math.floor(100000000000 + Math.random() * 900000000000)}`,
    eventType: "BATCH_COMPLETED",
    severity: "INFO",
    description: `Batch ${newBatch.batchNumber} processed. Yield: ${actualYieldKg}kg. Process loss: ${processLossKg}kg. Waste: ${wasteKg}kg. Mass-Balance fully reconciled.`,
    timestamp: new Date().toISOString(),
    isResolved: true
  });

  res.status(201).json(newBatch);
});

// Trigger Python-style stochastic simulator (POST /api/v1/simulations)
app.post("/api/v1/simulations", (req, res) => {
  const { scenario, randomSeed, parameters } = req.body;
  
  const simId = `s0000000-0000-0000-0000-${Math.floor(100000000000 + Math.random() * 900000000000)}`;
  
  // Set default parameters
  const batchCount = parameters?.batchCount || 10;
  const targetOutput = parameters?.targetOutputKg || 12000;
  
  // Apply scenarios
  let cocoaHike = 1.0;
  let energyHike = 1.0;
  let concheFailureRate = 0.02;

  if (scenario === "COCOA_PRICE_SPIKE") cocoaHike = 1.20;
  if (scenario === "ENERGY_HIKE") energyHike = 1.30;
  if (scenario === "CONCHE_FAILURE") concheFailureRate = 0.25;

  // Run stochastic generator
  let simulatedYield = 0;
  let simulatedLoss = 0;
  let simulatedEnergy = 0;
  let simulatedCost = 0;
  const timeline: any[] = [];

  for (let i = 1; i <= batchCount; i++) {
    // Random variations driven by seed
    const batchSeedValue = (Math.sin(randomSeed + i) + 1) / 2; // 0..1
    const runLoss = 10 + batchSeedValue * 8; // 10-18 kg loss
    const runWaste = 3 + batchSeedValue * 4; // 3-7 kg waste
    const runYield = 1000 - runLoss - runWaste;

    simulatedYield += runYield;
    simulatedLoss += runLoss + runWaste;
    
    // Conche energy simulation
    const concheFailureOccurred = batchSeedValue < concheFailureRate;
    const concheTimeHrs = concheFailureOccurred ? 18.0 : 12.0; 
    const kwh = concheTimeHrs * 90.0 + 30.0; // Conche draw + mixer
    simulatedEnergy += kwh;

    // Costing
    const ingredientCost = (1000 * 4.25) * cocoaHike;
    const powerCost = kwh * 0.22 * energyHike;
    const totalCost = ingredientCost + powerCost + 350; // materials + power + overheads
    simulatedCost += totalCost;

    timeline.push({
      step: i,
      batchNumber: `SIM-${scenario.slice(0, 4)}-${randomSeed}-${i}`,
      yieldKg: Number(runYield.toFixed(2)),
      lossKg: Number((runLoss + runWaste).toFixed(2)),
      energyKwh: Number(kwh.toFixed(1)),
      cost: Number(totalCost.toFixed(2)),
      concheFailure: concheFailureOccurred
    });
  }

  const result: SimulationRun = {
    id: simId,
    scenario,
    randomSeed,
    softwareVersion: "PySim-Core-v2.1",
    createdAt: new Date().toISOString(),
    status: "COMPLETED",
    parameters,
    results: {
      totalYieldKg: Number(simulatedYield.toFixed(1)),
      totalLossKg: Number(simulatedLoss.toFixed(1)),
      totalEnergyKwh: Number(simulatedEnergy.toFixed(1)),
      totalCost: Number(simulatedCost.toFixed(2)),
      simulatedDurationHrs: batchCount * 6,
      scadaTimeline: timeline
    }
  };

  simulationRuns.unshift(result);

  systemEvents.unshift({
    id: `e0000000-0000-0000-0000-${Math.floor(100000000000 + Math.random() * 900000000000)}`,
    eventType: "SIMULATION_COMPLETED",
    severity: "INFO",
    description: `Simulation run completed under scenario ${scenario}. Evaluated ${batchCount} batches, total cost Swiss Francs ${result.results?.totalCost.toFixed(2)}.`,
    timestamp: new Date().toISOString(),
    isResolved: true
  });

  res.json(result);
});

// Run optimization algorithm (POST /api/v1/optimisation)
app.post("/api/v1/optimisation", (req, res) => {
  const { objective, constraints, inputParameters } = req.body;

  const optId = `o0000000-0000-0000-0000-${Math.floor(100000000000 + Math.random() * 900000000000)}`;

  let solution = {
    cocoaPct: 72.0,
    cocoaButterPct: 9.0,
    sugarPct: 18.5,
    milkPct: 0.0,
    lecithinPct: 0.4,
    flavourPct: 0.1,
    conchingTempC: 78.4,
    conchingTimeHrs: 12.0
  };

  let expectedCostSaving = 120.50;
  let expectedYieldKg = 985.20;

  if (objective === "MINIMIZE_ENERGY") {
    // Optimize conche temperature profile to reduce electrical draw
    solution.conchingTempC = 72.5; // lower shear heating temp
    solution.conchingTimeHrs = 9.5;  // 2.5 hr cycle reduction
    expectedCostSaving = 245.00;
    expectedYieldKg = 981.80; // slightly lower yield due to viscosity change
  } else if (objective === "MAXIMIZE_YIELD") {
    // Adjust emulsifier to maximize suspension stability
    solution.cocoaButterPct = 9.5;
    solution.lecithinPct = 0.5;
    solution.conchingTimeHrs = 14.0; // longer refine
    expectedCostSaving = -55.00; // slightly more expensive ingredients/time
    expectedYieldKg = 992.10; // maximised yield, minimal scraper waste
  }

  const result: OptimisationRun = {
    id: optId,
    objective,
    constraints,
    inputParameters,
    status: "COMPLETED",
    createdAt: new Date().toISOString(),
    results: {
      solution,
      expectedYieldKg,
      expectedCostSaving,
      solverIterations: 45
    }
  };

  optimisationRuns.unshift(result);

  systemEvents.unshift({
    id: `e0000000-0000-0000-0000-${Math.floor(100000000000 + Math.random() * 900000000000)}`,
    eventType: "OPTIMISATION_COMPLETED",
    severity: "INFO",
    description: `R-Optimization engine resolved constraints for ${objective}. Recommended Conche Refining Cycle set to ${solution.conchingTimeHrs} hours.`,
    timestamp: new Date().toISOString(),
    isResolved: true
  });

  res.json(result);
});

// Retrieve telemetry (GET /api/v1/telemetry)
app.get("/api/v1/telemetry", (req, res) => {
  const { machineId } = req.query;
  if (machineId) {
    res.json(telemetryCache.filter(t => t.machineId === machineId).slice(-40));
  } else {
    res.json(telemetryCache.slice(-100));
  }
});

// Retrieve events (GET /api/v1/events)
app.get("/api/v1/events", (req, res) => {
  res.json(systemEvents);
});

// Retrieve quality process control (GET /api/v1/quality)
app.get("/api/v1/quality", (req, res) => {
  const spcParticle = runR_SPCAnalysis("particle_size");
  const spcViscosity = runR_SPCAnalysis("viscosity");
  res.json({
    particleSize: spcParticle,
    viscosity: spcViscosity
  });
});

// Retrieve economics dashboard (GET /api/v1/economics)
app.get("/api/v1/economics", (req, res) => {
  const breakdowns = productionBatches
    .filter(b => b.status === "COMPLETED")
    .map(b => runREconomicBreakdown(b));
  
  res.json(breakdowns);
});

// ==========================================
// VITE AND ASSETS ROUTING MANAGEMENT
// ==========================================

async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`ChocoSim Backend listening on http://0.0.0.0:${PORT}`);
  });
}

startServer();
