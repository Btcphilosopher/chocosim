import React, { useState, useEffect } from "react";
import { 
  Factory, Machine, Ingredient, RecipeVersion, ProductionBatch, 
  SystemEvent, TelemetryPoint, SimulationRun, OptimisationRun, 
  SpcParameterAnalysis, EconomicBreakdown 
} from "./types";
import PlantScada from "./components/PlantScada";
import RAnalytics from "./components/RAnalytics";
import PySimGateway from "./components/PySimGateway";
import DbInspector from "./components/DbInspector";
import CodeRepository from "./components/CodeRepository";
import { 
  Database, LayoutDashboard, LineChart, Cpu, 
  Terminal, ShieldCheck, Factory as FactoryIcon 
} from "lucide-react";

export default function App() {
  const [activeTab, setActiveTab] = useState<"scada" | "analytics" | "pysim" | "db" | "repo">("scada");

  // State caches
  const [factory, setFactory] = useState<Factory | null>(null);
  const [machines, setMachines] = useState<Machine[]>([]);
  const [inventory, setInventory] = useState<Ingredient[]>([]);
  const [recipes, setRecipes] = useState<RecipeVersion[]>([]);
  const [batches, setBatches] = useState<ProductionBatch[]>([]);
  const [events, setEvents] = useState<SystemEvent[]>([]);
  const [telemetry, setTelemetry] = useState<TelemetryPoint[]>([]);
  const [simulations, setSimulations] = useState<SimulationRun[]>([]);
  const [optimisations, setOptimisations] = useState<OptimisationRun[]>([]);
  const [quality, setQuality] = useState<{ particleSize: SpcParameterAnalysis; viscosity: SpcParameterAnalysis } | null>(null);
  const [economics, setEconomics] = useState<EconomicBreakdown[]>([]);

  // Fetch all state from full-stack Express API
  const refreshAllData = async () => {
    try {
      const [
        resFactory, resMachines, resInventory, resRecipes, resBatches, 
        resEvents, resTelemetry, resQuality, resEconomics
      ] = await Promise.all([
        fetch("/api/v1/factory").then(r => r.json()),
        fetch("/api/v1/machines").then(r => r.json()),
        fetch("/api/v1/inventory").then(r => r.json()),
        fetch("/api/v1/recipes").then(r => r.json()),
        fetch("/api/v1/production").then(r => r.json()),
        fetch("/api/v1/events").then(r => r.json()),
        fetch("/api/v1/telemetry").then(r => r.json()),
        fetch("/api/v1/quality").then(r => r.json()),
        fetch("/api/v1/economics").then(r => r.json())
      ]);

      setFactory(resFactory);
      setMachines(resMachines);
      setInventory(resInventory);
      setRecipes(resRecipes);
      setBatches(resBatches);
      setEvents(resEvents);
      setTelemetry(resTelemetry);
      setQuality(resQuality);
      setEconomics(resEconomics);
    } catch (err) {
      console.error("Error connecting to ChocoSim fullstack server: ", err);
    }
  };

  useEffect(() => {
    refreshAllData();

    // High frequency synoptic refresh loop
    const syncInterval = setInterval(() => {
      // Fetch dynamic metrics only to keep loading overhead low
      Promise.all([
        fetch("/api/v1/machines").then(r => r.json()),
        fetch("/api/v1/telemetry").then(r => r.json()),
        fetch("/api/v1/events").then(r => r.json())
      ]).then(([updatedMachines, updatedTelem, updatedEvents]) => {
        setMachines(updatedMachines);
        setTelemetry(updatedTelem);
        setEvents(updatedEvents);
      }).catch(err => console.error("Telemetry synch failure: ", err));
    }, 5000);

    return () => clearInterval(syncInterval);
  }, []);

  // Dispatch custom production batch (POST /api/v1/batches)
  const handleDispatchBatch = async (recipeVersionId: string, quantityKg: number): Promise<boolean> => {
    const res = await fetch("/api/v1/batches", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ recipeVersionId, targetQuantityKg: quantityKg })
    });
    if (res.ok) {
      await refreshAllData();
      return true;
    }
    const errData = await res.json();
    throw new Error(errData.error || "Material shortage in silos");
  };

  // Run stochastic Python simulation (POST /api/v1/simulations)
  const handleRunSimulation = async (scenario: string, seed: number, batchCount: number): Promise<SimulationRun | null> => {
    const res = await fetch("/api/v1/simulations", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        scenario,
        randomSeed: seed,
        parameters: { batchCount, targetOutputKg: batchCount * 1000 }
      })
    });
    if (res.ok) {
      const data: SimulationRun = await res.json();
      setSimulations(prev => [data, ...prev]);
      await refreshAllData();
      return data;
    }
    return null;
  };

  // Run solver optimization model (POST /api/v1/optimisation)
  const handleRunOptimisation = async (objective: "MINIMIZE_COST" | "MAXIMIZE_YIELD" | "MINIMIZE_ENERGY"): Promise<OptimisationRun | null> => {
    const res = await fetch("/api/v1/optimisation", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ objective, constraints: {}, inputParameters: {} })
    });
    if (res.ok) {
      const data: OptimisationRun = await res.json();
      setOptimisations(prev => [data, ...prev]);
      await refreshAllData();
      return data;
    }
    return null;
  };

  return (
    <div className="flex flex-col md:flex-row min-h-screen bg-[#E4E3E0] text-[#141414] font-sans antialiased selection:bg-[#141414] selection:text-[#E4E3E0]">
      {/* SIDEBAR ASIDE */}
      <aside className="w-full md:w-64 border-b md:border-b-0 md:border-r border-[#141414] flex flex-col shrink-0">
        {/* SIDEBAR BRANDING */}
        <div className="p-6 border-b border-[#141414]">
          <h1 className="font-serif italic text-2xl tracking-tight leading-none text-[#141414]">
            ChocoSim<br />Control
          </h1>
          <p className="text-[10px] uppercase tracking-widest mt-2 opacity-60 font-mono">
            Industrial Backend v3.5
          </p>
        </div>

        {/* SIDEBAR NAVIGATION */}
        <nav className="flex-1 py-4 flex flex-row md:flex-col overflow-x-auto md:overflow-x-visible">
          {[
            { id: "scada", label: "SCADA & Telemetry", desc: "Telemetric Hub" },
            { id: "analytics", label: "R SPC & Analytics", desc: "R-Engine SPC" },
            { id: "pysim", label: "Python Sim Gateway", desc: "Simulation Solver" },
            { id: "db", label: "Postgres Inspector", desc: "SQL DB Catalog" },
            { id: "repo", label: "Source Repository", desc: "Git Repository" }
          ].map((tab) => {
            const isActive = activeTab === tab.id;
            if (isActive) {
              return (
                <div
                  key={tab.id}
                  className="px-6 py-3 bg-[#141414] text-[#E4E3E0] flex items-center justify-between cursor-default border-b border-[#141414] shrink-0 md:shrink flex-1 md:flex-none"
                >
                  <span className="text-xs font-bold uppercase tracking-wider">{tab.label}</span>
                  <div className="w-2 h-2 rounded-full bg-green-500 shadow-[0_0_8px_rgba(34,197,94,0.6)] hidden md:block"></div>
                </div>
              );
            } else {
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id as any)}
                  className="px-6 py-3 border-b border-[#141414] hover:bg-[#D4D3D0] text-[#141414] cursor-pointer group flex items-center justify-between transition-colors shrink-0 md:shrink flex-1 md:flex-none text-left w-full"
                >
                  <span className="text-xs uppercase font-medium group-hover:italic tracking-wide">
                    {tab.label}
                  </span>
                  <span className="text-[10px] opacity-0 group-hover:opacity-60 font-mono transition-opacity hidden md:inline">
                    // VIEW
                  </span>
                </button>
              );
            }
          })}
        </nav>

        {/* SIDEBAR DB MONITOR */}
        <div className="p-6 border-t border-[#141414] space-y-4 hidden md:block">
          <div className="flex justify-between items-end">
            <span className="text-[10px] uppercase opacity-50 font-mono">PostgreSQL</span>
            <span className="font-mono text-xs font-bold text-emerald-700">ACTIVE</span>
          </div>
          <div className="w-full bg-[#D4D3D0] h-1">
            <div className="bg-[#141414] h-full w-[100%]"></div>
          </div>
        </div>
      </aside>

      {/* MAIN CONTAINER */}
      <main className="flex-1 flex flex-col md:h-screen md:overflow-y-auto">
        {/* MAIN HEADER */}
        <header className="h-auto md:h-20 border-b border-[#141414] flex flex-col md:flex-row items-start md:items-center justify-between px-6 py-4 md:py-0 gap-4 shrink-0">
          <div className="flex flex-wrap gap-6 md:gap-12">
            <div>
              <p className="font-serif italic text-[11px] opacity-50 uppercase">Active Instances</p>
              <p className="font-mono text-base font-bold">3 / 3 (RUST/R/PY)</p>
            </div>
            <div>
              <p className="font-serif italic text-[11px] opacity-50 uppercase">System Stream</p>
              <p className="font-mono text-base font-bold">
                {telemetry.length > 0 ? `${telemetry.length} Points Ingested` : "Active / 120Hz"}
              </p>
            </div>
            <div>
              <p className="font-serif italic text-[11px] opacity-50 uppercase">Network Latency</p>
              <p className="font-mono text-base font-bold">1.08ms</p>
            </div>
          </div>

          <div className="flex items-center gap-4 self-end md:self-auto">
            <div className="text-right">
              <p className="text-[10px] font-bold uppercase tracking-wider font-mono">Session Code</p>
              <p className="font-mono text-[10px] opacity-60">CS_RU_4920X-881</p>
            </div>
            <div className="w-10 h-10 border border-[#141414] flex items-center justify-center font-bold font-mono">
              {batches.length.toString().padStart(2, "0")}
            </div>
          </div>
        </header>

        {/* WORKSPACE VIEWPORT */}
        <div className="flex-1 p-6 overflow-y-auto space-y-6">
          {activeTab === "scada" && (
            <PlantScada
              machines={machines}
              inventory={inventory}
              recipes={recipes}
              batches={batches}
              events={events}
              telemetry={telemetry}
              onDispatchBatch={handleDispatchBatch}
              onRefreshData={refreshAllData}
            />
          )}

          {activeTab === "analytics" && (
            <RAnalytics
              qualityData={quality}
              economicsData={economics}
            />
          )}

          {activeTab === "pysim" && (
            <PySimGateway
              simulationHistory={simulations}
              optimisationHistory={optimisations}
              onRunSimulation={handleRunSimulation}
              onRunOptimisation={handleRunOptimisation}
            />
          )}

          {activeTab === "db" && (
            <DbInspector
              factories={factory ? [factory] : []}
              machines={machines}
              inventory={inventory}
              recipes={recipes}
              batches={batches}
              events={events}
              telemetry={telemetry}
              simulations={simulations}
              optimisations={optimisations}
              economics={economics}
            />
          )}

          {activeTab === "repo" && <CodeRepository />}
        </div>

        {/* SYSTEM STATUS FOOTER */}
        <footer className="h-auto md:h-12 border-t border-[#141414] flex flex-col md:flex-row items-center px-6 py-3 md:py-0 bg-[#141414] text-[#E4E3E0] justify-between shrink-0 text-[10px] font-mono tracking-widest gap-2">
          <div className="flex flex-wrap gap-4 md:gap-8 justify-center">
            <span>ID: {batches[0]?.id ? `BATCH_${batches[0].id.substring(0,6).toUpperCase()}` : "ID: CHOCO_B_4922"}</span>
            <span>RECIPE: {recipes.find(r => r.id === batches[0]?.recipeVersionId)?.recipeName.toUpperCase() || "RECIPE: DARK_70_V2.1"}</span>
            <span>STATUS: {batches[0]?.status || "PROCESSING_ACTIVE"}</span>
          </div>
          <div className="flex gap-4 items-center">
            <div className="flex gap-1">
              <div className="w-1.5 h-3 bg-white"></div>
              <div className="w-1.5 h-3 bg-white opacity-40"></div>
              <div className="w-1.5 h-3 bg-white opacity-40"></div>
            </div>
            <span className="font-bold uppercase text-[9px]">SYSTEM SAFE</span>
          </div>
        </footer>
      </main>
    </div>
  );
}
