import React, { useState } from "react";
import { Folder, File, Code, Terminal, Database, BookOpen, Layers } from "lucide-react";

// Raw code contents we already created inside our chocosim directory.
// We load them statically in the React component so they load instantly without separate filesystem calls!

const RUST_MASS_BALANCE = `//! ChocoSim - Production Mass Balance & Material Traceability Engine
//! High-performance material verification and mass-conservation checker for chocolate batches.

use std::collections::HashMap;
use uuid::Uuid;
use chrono::{DateTime, Utc};
use serde::{Serialize, Deserialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct IngredientUsage {
    pub ingredient_id: Uuid,
    pub quantity_input_kg: f64,
    pub lot_number: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct MassBalanceRecord {
    pub batch_id: Uuid,
    pub recipe_version_id: Uuid,
    pub total_input_mass_kg: f64,
    pub raw_materials_used: Vec<IngredientUsage>,
    
    // Outputs & losses
    pub actual_yield_kg: f64,
    pub process_loss_kg: f64, // e.g. stuck to scraper walls, evaporation
    pub scrap_waste_kg: f64,   // e.g. off-spec discard, line flushing
    
    pub timestamp: DateTime<Utc>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct MassReconciliationReport {
    pub batch_id: Uuid,
    pub mass_input: f64,
    pub mass_output_total: f64,
    pub mass_discrepancy_kg: f64,
    pub process_loss_pct: f64,
    pub waste_pct: f64,
    pub yield_pct: f64,
    pub is_balanced: bool,
    pub validation_message: String,
}

pub struct MassBalanceEngine {
    tolerance_kg: f64, // Allowed numerical/sensor accuracy discrepancy (e.g. 0.1 kg)
}

impl MassBalanceEngine {
    pub fn new(tolerance_kg: f64) -> Self {
        Self { tolerance_kg }
    }

    /// Reconciles input mass against outputs (yield + loss + waste) to satisfy:
    /// Sum(Inputs) = Yield + Loss + Waste ± Tolerance
    pub fn reconcile(&self, record: &MassBalanceRecord) -> MassReconciliationReport {
        let total_input = record.total_input_mass_kg;
        let total_output = record.actual_yield_kg + record.process_loss_kg + record.scrap_waste_kg;
        
        let discrepancy = (total_input - total_output).abs();
        let is_balanced = discrepancy <= self.tolerance_kg;
        
        let yield_pct = (record.actual_yield_kg / total_input) * 100.0;
        let process_loss_pct = (record.process_loss_kg / total_input) * 100.0;
        let waste_pct = (record.scrap_waste_kg / total_input) * 100.0;
        
        let validation_message = if is_balanced {
            format!("Mass balance verified successfully. Discrepancy of {:.4} kg is within safe threshold of {:.4} kg.", discrepancy, self.tolerance_kg)
        } else {
            format!("CRITICAL: Mass balance violation! Unaccounted mass of {:.4} kg detected.", discrepancy)
        };

        MassReconciliationReport {
            batch_id: record.batch_id,
            mass_input: total_input,
            mass_output_total: total_output,
            mass_discrepancy_kg: discrepancy,
            process_loss_pct,
            waste_pct,
            yield_pct,
            is_balanced,
            validation_message,
        }
    }
}`;

const RUST_TELEMETRY = `//! ChocoSim - Asynchronous Telemetry Ingestion Service
//! Designed for high-frequency time-series logging from industrial sensors (temperature, pressure, RPM, load).

use std::sync::Arc;
use tokio::sync::mpsc;
use tokio::time::{sleep, Duration};
use uuid::Uuid;
use chrono::{DateTime, Utc};
use serde::{Serialize, Deserialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TelemetryObservation {
    pub machine_id: Uuid,
    pub timestamp: DateTime<Utc>,
    pub parameter: String, // "TEMPERATURE", "PRESSURE", "RPM", "MOTOR_LOAD"
    pub value: f64,
    pub unit: String,
    pub quality: String, // "GOOD", "POOR"
}

pub struct TelemetryStreamer {
    tx: mpsc::Sender<TelemetryObservation>,
}

impl TelemetryStreamer {
    pub fn new(buffer_size: usize, db_pool: Arc<sqlx::PgPool>) -> Self {
        let (tx, mut rx) = mpsc::channel::<TelemetryObservation>(buffer_size);

        tokio::spawn(async move {
            let mut batch_buffer: Vec<TelemetryObservation> = Vec::with_capacity(100);
            let mut interval = tokio::time::interval(Duration::from_millis(500));

            loop {
                tokio::select! {
                    Some(obs) = rx.recv() => {
                        batch_buffer.push(obs);
                        if batch_buffer.len() >= 100 {
                            Self::flush_batch(&batch_buffer, &db_pool).await;
                            batch_buffer.clear();
                        }
                    }
                    _ = interval.tick() => {
                        if !batch_buffer.is_empty() {
                            Self::flush_batch(&batch_buffer, &db_pool).await;
                            batch_buffer.clear();
                        }
                    }
                }
            }
        });

        Self { tx }
    }

    async fn flush_batch(batch: &[TelemetryObservation], db_pool: &sqlx::PgPool) {
        log::info!("Ingesting batch of {} industrial sensor records...", batch.len());
        // Bulk INSERT SQL shown in system files
    }
}`;

const RUST_ROUTER = `//! ChocoSim - Axum REST API Routes & Router Design
//! Satisfies high-concurrency requirements and typed JSON payloads for industrial operations.

use axum::{
    routing::{get, post},
    Router,
    Json,
    extract::{Path, Query, State},
};
use std::sync::Arc;
use uuid::Uuid;
use serde::{Serialize, Deserialize};

pub fn create_router(state: Arc<AppState>) -> Router {
    Router::new()
        .route("/api/v1/health", get(health_check))
        .route("/api/v1/factory", get(get_factory_status))
        .route("/api/v1/machines", get(list_machines))
        .route("/api/v1/production", get(get_production_summary))
        .route("/api/v1/inventory", get(get_inventory_levels))
        .route("/api/v1/recipes", get(list_recipes))
        .route("/api/v1/batches", post(create_production_batch))
        .route("/api/v1/simulations", post(trigger_simulation_run))
        .route("/api/v1/optimisation", post(run_optimisation_model))
        .route("/api/v1/telemetry", get(get_recent_telemetry))
        .with_state(state)
}`;

const R_QUALITY_SPC = `# ChocoSim R Analytics - Statistical Process Control (SPC) Engine
# Computes process mean, variance, control limits (UCL, LCL), and capability indices (Cp, Cpk).

library(stats)

calculate_process_capability <- function(measurements_df, target_nominal, usl, lsl) {
  values <- measurements_df$value
  n <- length(values)
  
  if (n < 5) {
    stop("Insufficient data points. Minimum 5 batches required.")
  }
  
  process_mean <- mean(values, na.rm = TRUE)
  process_sd <- sd(values, na.rm = TRUE)
  
  # 3-Sigma Control Limits
  ucl <- process_mean + 3 * process_sd
  lcl <- max(0, process_mean - 3 * process_sd)
  
  # Process Capability Indices (Cp, Cpk)
  cp <- (usl - lsl) / (6 * process_sd)
  cpu <- (usl - process_mean) / (3 * process_sd)
  cpl <- (process_mean - lsl) / (3 * process_sd)
  cpk <- min(cpu, cpl)
  
  return(list(
    mean = process_mean,
    sd = process_sd,
    ucl = ucl,
    lcl = lcl,
    cp = cp,
    cpk = cpk
  ))
}`;

const R_ECONOMICS = `# ChocoSim R Economics - Costing and Production Margin Model
# Estimates per-kilogram chocolate production costs, energy rates, and gross margins.

calculate_batch_economics <- function(raw_material_cost, yield_kg, power_kwh, 
                                      electricity_rate_per_kwh = 0.22,
                                      labor_hours = 6.0,
                                      hourly_labor_rate = 35.0) {
  
  energy_cost <- power_kwh * electricity_rate_per_kwh
  labor_cost <- labor_hours * hourly_labor_rate
  packaging_cost <- 1000 * 0.12 # target CHF 0.12/box
  
  total_production_cost <- raw_material_cost + energy_cost + labor_cost + packaging_cost
  cost_per_kg <- total_production_cost / yield_kg
  
  market_value_per_kg = 12.50 # craft reference index
  total_revenue <- yield_kg * market_value_per_kg
  gross_profit <- total_revenue - total_production_cost
  gross_margin_pct <- (gross_profit / total_revenue) * 100.0
  
  return(list(
    total_cost = total_production_cost,
    cost_per_kg = cost_per_kg,
    gross_margin_pct = gross_margin_pct
  ))
}`;

const DB_SCHEMA = `-- 25 Relational Tables for Chocolate Factory Simulation & Production Control
-- For PostgreSQL - Production Ready Schema with UUIDs, constraints, and audit logs.

CREATE TABLE factories (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name VARCHAR(255) NOT NULL,
    location VARCHAR(255),
    status VARCHAR(50) DEFAULT 'ACTIVE'
);

CREATE TABLE machines (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    production_line_id UUID REFERENCES production_lines(id),
    name VARCHAR(255) NOT NULL,
    type VARCHAR(100) NOT NULL,
    power_rating_kw DECIMAL(10,2),
    status VARCHAR(50) DEFAULT 'IDLE'
);

-- Full list of tables: factories, production_lines, machines, machine_events, ingredients, 
-- suppliers, ingredient_batches, recipes, recipe_versions, production_batches, process_stages, 
-- process_measurements, quality_measurements, inventory, inventory_transactions, packaging, 
-- finished_products, energy_measurements, maintenance, telemetry, simulation_runs...`;

export default function CodeRepository() {
  const [selectedFile, setSelectedFile] = useState("rust/core/mass_balance.rs");

  const repoFiles: Record<string, { lang: "rust" | "r" | "sql"; content: string; path: string }> = {
    "rust/core/mass_balance.rs": { lang: "rust", content: RUST_MASS_BALANCE, path: "/chocosim/rust/core/mass_balance.rs" },
    "rust/telemetry/streamer.rs": { lang: "rust", content: RUST_TELEMETRY, path: "/chocosim/rust/telemetry/streamer.rs" },
    "rust/api/router.rs": { lang: "rust", content: RUST_ROUTER, path: "/chocosim/rust/api/router.rs" },
    "r/quality/spc.R": { lang: "r", content: R_QUALITY_SPC, path: "/chocosim/r/quality/spc.R" },
    "r/economics/margin_model.R": { lang: "r", content: R_ECONOMICS, path: "/chocosim/r/economics/margin_model.R" },
    "database/schema/up.sql": { lang: "sql", content: DB_SCHEMA, path: "/chocosim/database/schema/up.sql" }
  };

  const activeFile = repoFiles[selectedFile];

  return (
    <div className="space-y-6 text-[#141414]">
      {/* SECTION HEADER */}
      <div className="bg-[#DCDAD7] p-4 border border-[#141414]">
        <h2 className="text-lg font-serif italic text-[#141414]">Zurich Industrial Code Repository</h2>
        <p className="text-[10px] font-mono uppercase tracking-wider opacity-60">
          Inspect production-ready Rust and R source files deployed inside the digital factory workspace
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* REPO FILE TREE */}
        <div className="lg:col-span-1 bg-[#f0efed] border border-[#141414] p-4 space-y-4">
          <div>
            <h3 className="text-[10px] font-bold text-[#141414]/60 uppercase tracking-widest mb-3 pb-2 border-b border-[#141414]/20 flex items-center gap-1.5 font-mono">
              <Folder className="h-3.5 w-3.5 text-[#141414]" />
              chocosim/
            </h3>

            {/* RUST TREE */}
            <div className="space-y-1 pl-2">
              <h4 className="text-[10px] font-bold opacity-60 uppercase flex items-center gap-1 font-mono">
                <Folder className="h-3 w-3" /> rust/
              </h4>
              <div className="pl-3 space-y-1 font-mono text-xs">
                {[
                  { id: "rust/core/mass_balance.rs", label: "core/mass_balance.rs" },
                  { id: "rust/telemetry/streamer.rs", label: "telemetry/streamer.rs" },
                  { id: "rust/api/router.rs", label: "api/router.rs" }
                ].map(file => (
                  <button
                    key={file.id}
                    onClick={() => setSelectedFile(file.id)}
                    className={`w-full text-left px-2 py-1.5 transition-all block border cursor-pointer ${
                      selectedFile === file.id 
                        ? "bg-[#141414] text-[#E4E3E0] border-[#141414]" 
                        : "text-[#141414]/80 hover:bg-[#DCDAD7] border-transparent"
                    }`}
                  >
                    📄 {file.label}
                  </button>
                ))}
              </div>
            </div>

            {/* R TREE */}
            <div className="space-y-1 pl-2 mt-4">
              <h4 className="text-[10px] font-bold opacity-60 uppercase flex items-center gap-1 font-mono">
                <Folder className="h-3 w-3" /> r/
              </h4>
              <div className="pl-3 space-y-1 font-mono text-xs">
                {[
                  { id: "r/quality/spc.R", label: "quality/spc.R" },
                  { id: "r/economics/margin_model.R", label: "economics/margin_model.R" }
                ].map(file => (
                  <button
                    key={file.id}
                    onClick={() => setSelectedFile(file.id)}
                    className={`w-full text-left px-2 py-1.5 transition-all block border cursor-pointer ${
                      selectedFile === file.id 
                        ? "bg-[#141414] text-[#E4E3E0] border-[#141414]" 
                        : "text-[#141414]/80 hover:bg-[#DCDAD7] border-transparent"
                    }`}
                  >
                    📄 {file.label}
                  </button>
                ))}
              </div>
            </div>

            {/* DATABASE TREE */}
            <div className="space-y-1 pl-2 mt-4">
              <h4 className="text-[10px] font-bold opacity-60 uppercase flex items-center gap-1 font-mono">
                <Folder className="h-3 w-3" /> database/
              </h4>
              <div className="pl-3 space-y-1 font-mono text-xs">
                <button
                  onClick={() => setSelectedFile("database/schema/up.sql")}
                  className={`w-full text-left px-2 py-1.5 transition-all block border cursor-pointer ${
                    selectedFile === "database/schema/up.sql" 
                      ? "bg-[#141414] text-[#E4E3E0] border-[#141414]" 
                      : "text-[#141414]/80 hover:bg-[#DCDAD7] border-transparent"
                  }`}
                >
                  📄 schema/up.sql
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* CODE VIEW AREA (COLSPAN 3) */}
        <div className="lg:col-span-3 space-y-3">
          <div className="bg-[#141414] text-[#E4E3E0] border border-[#141414] overflow-hidden">
            <div className="p-3 bg-[#1c1c1c] border-b border-[#141414] flex justify-between items-center px-4 font-mono text-xs">
              <div className="flex items-center gap-2">
                <div className="w-2.5 h-2.5 rounded-full bg-[#E4E3E0]/20"></div>
                <div className="w-2.5 h-2.5 rounded-full bg-[#E4E3E0]/20"></div>
                <div className="w-2.5 h-2.5 rounded-full bg-[#E4E3E0]/20"></div>
                <span className="opacity-60 ml-2">{activeFile.path}</span>
              </div>
              <span className="text-[9px] bg-[#E4E3E0] text-[#141414] font-bold px-1.5 py-0.5 uppercase">
                {activeFile.lang}
              </span>
            </div>

            <pre className="p-5 overflow-auto text-[11px] leading-relaxed font-mono max-h-[500px]">
              <code>{activeFile.content}</code>
            </pre>
          </div>
        </div>
      </div>
    </div>
  );
}
