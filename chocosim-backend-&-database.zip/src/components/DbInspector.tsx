import React, { useState } from "react";
import { 
  Database, Table, FileSpreadsheet, Eye, HelpCircle, 
  ArrowRight, Key, ShieldCheck 
} from "lucide-react";

interface DbInspectorProps {
  factories: any[];
  machines: any[];
  inventory: any[];
  recipes: any[];
  batches: any[];
  events: any[];
  telemetry: any[];
  simulations: any[];
  optimisations: any[];
  economics: any[];
}

export default function DbInspector({
  factories,
  machines,
  inventory,
  recipes,
  batches,
  events,
  telemetry,
  simulations,
  optimisations,
  economics
}: DbInspectorProps) {
  const [selectedTable, setSelectedTable] = useState("production_batches");

  // Relational definitions of the 25 tables specified in Section 3 of the prompt
  const schemaDefinitions: Record<string, {
    description: string;
    primaryKey: string;
    foreignKeys: string[];
    columns: { name: string; type: string; constraints?: string }[];
    getData: () => any[];
  }> = {
    factories: {
      description: "Authoritative list of manufacturing plants and facilities.",
      primaryKey: "id (UUID)",
      foreignKeys: [],
      columns: [
        { name: "id", type: "UUID", constraints: "PRIMARY KEY" },
        { name: "name", type: "VARCHAR(255)", constraints: "NOT NULL" },
        { name: "location", type: "VARCHAR(255)" },
        { name: "status", type: "VARCHAR(50)", constraints: "DEFAULT 'ACTIVE'" }
      ],
      getData: () => factories
    },
    production_lines: {
      description: "Subdivisions within a factory housing distinct assembly equipment.",
      primaryKey: "id (UUID)",
      foreignKeys: ["factory_id -> factories.id"],
      columns: [
        { name: "id", type: "UUID", constraints: "PRIMARY KEY" },
        { name: "factory_id", type: "UUID", constraints: "REFERENCES factories" },
        { name: "name", type: "VARCHAR(255)", constraints: "NOT NULL" },
        { name: "capacity_kg_per_hr", type: "DECIMAL(10,2)", constraints: "NOT NULL" }
      ],
      getData: () => [{ id: "l001", factory_id: "f001", name: "Premium Dark & Milk Line A", capacity_kg_per_hr: 500.00 }]
    },
    machines: {
      description: "Industrial hardware assets performing active blending, conching, tempering, etc.",
      primaryKey: "id (UUID)",
      foreignKeys: ["production_line_id -> production_lines.id"],
      columns: [
        { name: "id", type: "UUID", constraints: "PRIMARY KEY" },
        { name: "production_line_id", type: "UUID" },
        { name: "name", type: "VARCHAR(255)", constraints: "NOT NULL" },
        { name: "type", type: "VARCHAR(100)", constraints: "NOT NULL" },
        { name: "power_rating_kw", type: "DECIMAL(10,2)" },
        { name: "status", type: "VARCHAR(50)" }
      ],
      getData: () => machines
    },
    machine_events: {
      description: "Auditable telemetry warnings, errors, and motor activations.",
      primaryKey: "id (UUID)",
      foreignKeys: ["machine_id -> machines.id"],
      columns: [
        { name: "id", type: "UUID", constraints: "PRIMARY KEY" },
        { name: "machine_id", type: "UUID" },
        { name: "event_type", type: "VARCHAR(100)", constraints: "NOT NULL" },
        { name: "severity", type: "VARCHAR(50)" },
        { name: "description", type: "TEXT" }
      ],
      getData: () => events
    },
    ingredients: {
      description: "Raw commodity ingredients available in inventory warehouses.",
      primaryKey: "id (UUID)",
      foreignKeys: [],
      columns: [
        { name: "id", type: "UUID", constraints: "PRIMARY KEY" },
        { name: "name", type: "VARCHAR(255)", constraints: "NOT NULL" },
        { name: "sku", type: "VARCHAR(100)", constraints: "UNIQUE" },
        { name: "unit_cost_per_kg", type: "DECIMAL(10,4)", constraints: "NOT NULL" }
      ],
      getData: () => inventory
    },
    suppliers: {
      description: "Wholesale merchants supplying certified beans and dairy inputs.",
      primaryKey: "id (UUID)",
      foreignKeys: [],
      columns: [
        { name: "id", type: "UUID", constraints: "PRIMARY KEY" },
        { name: "name", type: "VARCHAR(255)", constraints: "NOT NULL" },
        { name: "reliability_rating", type: "DECIMAL(3,2)" }
      ],
      getData: () => [
        { id: "s001", name: "Andes Cocoa Bean Co.", reliability_rating: 0.96 },
        { id: "s002", name: "Swiss Pure Sugars Ltd", reliability_rating: 0.99 }
      ]
    },
    ingredient_batches: {
      description: "Individual traceable deliveries (lots) linked to quality specs.",
      primaryKey: "id (UUID)",
      foreignKeys: ["ingredient_id -> ingredients.id", "supplier_id -> suppliers.id"],
      columns: [
        { name: "id", type: "UUID" },
        { name: "ingredient_id", type: "UUID" },
        { name: "lot_number", type: "VARCHAR(100)" },
        { name: "quantity_received_kg", type: "DECIMAL(12,4)" }
      ],
      getData: () => [
        { id: "b01", ingredient_id: "i01", lot_number: "LOT-EC-9092", quantity_received_kg: 25000 },
        { id: "b02", ingredient_id: "i02", lot_number: "LOT-CH-1182", quantity_received_kg: 12000 }
      ]
    },
    recipes: {
      description: "High-level catalog of artisan and commercial chocolate types.",
      primaryKey: "id (UUID)",
      foreignKeys: [],
      columns: [
        { name: "id", type: "UUID", constraints: "PRIMARY KEY" },
        { name: "name", type: "VARCHAR(255)", constraints: "UNIQUE" }
      ],
      getData: () => [
        { id: "r001", name: "72% Single Origin Artisan Dark" },
        { id: "r002", name: "Alpine Creamy Milk Chocolate" }
      ]
    },
    recipe_versions: {
      description: "Strictly version-controlled, immutable cocoa-butter proportion recipes.",
      primaryKey: "id (UUID)",
      foreignKeys: ["recipe_id -> recipes.id"],
      columns: [
        { name: "id", type: "UUID", constraints: "PRIMARY KEY" },
        { name: "recipe_id", type: "UUID" },
        { name: "version", type: "INT" },
        { name: "cocoa_percentage", type: "DECIMAL(5,2)" },
        { name: "cocoa_butter_percentage", type: "DECIMAL(5,2)" },
        { name: "target_viscosity_pa_s", type: "DECIMAL(8,4)" }
      ],
      getData: () => recipes
    },
    production_batches: {
      description: "Historical log of actual chocolate processing batches with completed yields.",
      primaryKey: "id (UUID)",
      foreignKeys: ["recipe_version_id -> recipe_versions.id"],
      columns: [
        { name: "id", type: "UUID", constraints: "PRIMARY KEY" },
        { name: "recipe_version_id", type: "UUID" },
        { name: "batch_number", type: "VARCHAR(100)", constraints: "UNIQUE" },
        { name: "status", type: "VARCHAR(50)" },
        { name: "target_quantity_kg", type: "DECIMAL(12,2)" },
        { name: "actual_yield_kg", type: "DECIMAL(12,2)" },
        { name: "process_loss_kg", type: "DECIMAL(12,2)" },
        { name: "waste_kg", type: "DECIMAL(12,2)" }
      ],
      getData: () => batches
    },
    process_stages: {
      description: "Steps representing the batch progress (MIXING, CONCHING, TEMPERING, etc.)",
      primaryKey: "id (UUID)",
      foreignKeys: ["production_batch_id -> production_batches.id"],
      columns: [
        { name: "id", type: "UUID" },
        { name: "production_batch_id", type: "UUID" },
        { name: "stage_name", type: "VARCHAR(100)" },
        { name: "sequence_order", type: "INT" }
      ],
      getData: () => [
        { id: "s01", production_batch_id: "b01", stage_name: "MIXING", sequence_order: 1 },
        { id: "s02", production_batch_id: "b01", stage_name: "CONCHING", sequence_order: 2 }
      ]
    },
    process_measurements: {
      description: "Active measurements recorded during active batch processing.",
      primaryKey: "id (UUID)",
      foreignKeys: ["process_stage_id -> process_stages.id", "machine_id -> machines.id"],
      columns: [
        { name: "id", type: "UUID" },
        { name: "process_stage_id", type: "UUID" },
        { name: "parameter_name", type: "VARCHAR(100)" },
        { name: "measured_value", type: "DECIMAL(12,4)" }
      ],
      getData: () => [
        { id: "m01", process_stage_id: "s01", parameter_name: "SHEAR_SPEED", measured_value: 1250 },
        { id: "m02", process_stage_id: "s02", parameter_name: "CONCH_TEMP", measured_value: 78.4 }
      ]
    },
    packaging_runs: {
      description: "Boxing and wrapping metrics for finished mass outputs.",
      primaryKey: "id (UUID)",
      foreignKeys: ["production_batch_id -> production_batches.id"],
      columns: [
        { name: "id", type: "UUID" },
        { name: "production_batch_id", type: "UUID" },
        { name: "package_type", type: "VARCHAR(100)" },
        { name: "cartons_sealed", type: "INT" }
      ],
      getData: () => [
        { id: "p01", production_batch_id: "b01", package_type: "Artisan Box 100g", cartons_sealed: 9500 }
      ]
    },
    quality_checks: {
      description: "Finished-goods compliance test logs (micron limits & viscosity).",
      primaryKey: "id (UUID)",
      foreignKeys: ["production_batch_id -> production_batches.id"],
      columns: [
        { name: "id", type: "UUID" },
        { name: "production_batch_id", type: "UUID" },
        { name: "particle_size_mean_um", type: "DECIMAL(6,3)" },
        { name: "status", type: "VARCHAR(50)" }
      ],
      getData: () => [
        { id: "q01", production_batch_id: "b01", particle_size_mean_um: 18.25, status: "APPROVED" }
      ]
    },
    scrap_records: {
      description: "Unsalvageable chocolate waste and floor loss audits.",
      primaryKey: "id (UUID)",
      foreignKeys: ["production_batch_id -> production_batches.id"],
      columns: [
        { name: "id", type: "UUID" },
        { name: "production_batch_id", type: "UUID" },
        { name: "loss_reason", type: "VARCHAR(255)" },
        { name: "quantity_kg", type: "DECIMAL(10,2)" }
      ],
      getData: () => [
        { id: "sc01", production_batch_id: "b01", loss_reason: "Filter screen purge", quantity_kg: 8.50 }
      ]
    },
    shift_schedules: {
      description: "Human resource scheduling records on assembly lines.",
      primaryKey: "id (UUID)",
      foreignKeys: ["production_line_id -> production_lines.id"],
      columns: [
        { name: "id", type: "UUID" },
        { name: "production_line_id", type: "UUID" },
        { name: "shift_name", type: "VARCHAR(100)" },
        { name: "operator_count", type: "INT" }
      ],
      getData: () => [
        { id: "sh01", production_line_id: "l001", shift_name: "Morning Shift A", operator_count: 5 }
      ]
    },
    maintenance_logs: {
      description: "Preventative and emergency repair schedules on processing hardware.",
      primaryKey: "id (UUID)",
      foreignKeys: ["machine_id -> machines.id"],
      columns: [
        { name: "id", type: "UUID" },
        { name: "machine_id", type: "UUID" },
        { name: "maintenance_type", type: "VARCHAR(100)" },
        { name: "cost_chf", type: "DECIMAL(10,2)" }
      ],
      getData: () => [
        { id: "maint01", machine_id: "mac01", maintenance_type: "BLADE_ALIGNMENT", cost_chf: 120.00 }
      ]
    },
    utility_rates: {
      description: "Live commercial power and water rate tables (CHF per kWh).",
      primaryKey: "id (UUID)",
      foreignKeys: ["factory_id -> factories.id"],
      columns: [
        { name: "id", type: "UUID" },
        { name: "factory_id", type: "UUID" },
        { name: "utility_type", type: "VARCHAR(100)" },
        { name: "rate_per_unit", type: "DECIMAL(8,4)" }
      ],
      getData: () => [
        { id: "ut01", factory_id: "f001", utility_type: "ELECTRICITY", rate_per_unit: 0.185 }
      ]
    },
    conching_profiles: {
      description: "Stochastic shear rate and heating parameters for conching runs.",
      primaryKey: "id (UUID)",
      foreignKeys: ["recipe_version_id -> recipe_versions.id"],
      columns: [
        { name: "id", type: "UUID" },
        { name: "recipe_version_id", type: "UUID" },
        { name: "target_temp_c", type: "DECIMAL(5,2)" },
        { name: "duration_hours", type: "DECIMAL(5,2)" }
      ],
      getData: () => [
        { id: "cp01", recipe_version_id: "r01_v1", target_temp_c: 78.00, duration_hours: 12.0 }
      ]
    },
    tempering_profiles: {
      description: "Strict cooling-heating-cooling boundaries for crystalline fat formation.",
      primaryKey: "id (UUID)",
      foreignKeys: ["recipe_version_id -> recipe_versions.id"],
      columns: [
        { name: "id", type: "UUID" },
        { name: "recipe_version_id", type: "UUID" },
        { name: "t1_melt_temp_c", type: "DECIMAL(5,2)" },
        { name: "t2_cool_temp_c", type: "DECIMAL(5,2)" },
        { name: "t3_crystallize_temp_c", type: "DECIMAL(5,2)" }
      ],
      getData: () => [
        { id: "tp01", recipe_version_id: "r01_v1", t1_melt_temp_c: 45.0, t2_cool_temp_c: 27.0, t3_crystallize_temp_c: 31.5 }
      ]
    },
    raw_telemetry: {
      description: "High-frequency streaming parameters stored from physical PLCs.",
      primaryKey: "id (UUID)",
      foreignKeys: ["machine_id -> machines.id"],
      columns: [
        { name: "id", type: "UUID" },
        { name: "machine_id", type: "UUID" },
        { name: "parameter", type: "VARCHAR(100)" },
        { name: "value", type: "DECIMAL(12,4)" }
      ],
      getData: () => telemetry
    },
    simulation_runs: {
      description: "Stochastic Monte Carlo runs created via Python Sim Gateway.",
      primaryKey: "id (UUID)",
      foreignKeys: [],
      columns: [
        { name: "id", type: "UUID" },
        { name: "scenario", type: "VARCHAR(100)" },
        { name: "seed", type: "INT" },
        { name: "total_batches", type: "INT" }
      ],
      getData: () => simulations
    },
    optimisation_runs: {
      description: "R solver coordinate sets for overhead cost elimination.",
      primaryKey: "id (UUID)",
      foreignKeys: [],
      columns: [
        { name: "id", type: "UUID" },
        { name: "objective", type: "VARCHAR(100)" },
        { name: "solver_iterations", type: "INT" },
        { name: "expected_saving_chf", type: "DECIMAL(10,2)" }
      ],
      getData: () => optimisations
    },
    economic_breakdowns: {
      description: "Consolidated factory financial overhead records.",
      primaryKey: "id (UUID)",
      foreignKeys: ["production_batch_id -> production_batches.id"],
      columns: [
        { name: "id", type: "UUID" },
        { name: "production_batch_id", type: "UUID" },
        { name: "ingredient_cost_chf", type: "DECIMAL(10,2)" },
        { name: "margin_percentage", type: "DECIMAL(5,2)" }
      ],
      getData: () => economics
    },
    audit_events: {
      description: "Immutable mass balance reconciliation logs.",
      primaryKey: "id (UUID)",
      foreignKeys: [],
      columns: [
        { name: "id", type: "UUID" },
        { name: "reconciliation_type", type: "VARCHAR(100)" },
        { name: "discrepancy_kg", type: "DECIMAL(10,4)" },
        { name: "authorized_signature", type: "VARCHAR(255)" }
      ],
      getData: () => [
        { id: "a01", reconciliation_type: "END_OF_SHIFT_MASS_BALANCE", discrepancy_kg: 0.0042, authorized_signature: "ZURICH_AUDIT_BOT_01" }
      ]
    }
  };

  const activeDef = schemaDefinitions[selectedTable] || schemaDefinitions.production_batches;
  const tableData = activeDef.getData();

  return (
    <div className="space-y-6 text-[#141414]">
      {/* SECTION HEADER */}
      <div className="bg-[#DCDAD7] p-4 border border-[#141414]">
        <h2 className="text-lg font-serif italic text-[#141414]">PostgreSQL Relational Schema Inspector</h2>
        <p className="text-[10px] font-mono uppercase tracking-wider opacity-60">
          Relational state monitoring representing all 25 tables specified in Core Systems Architecture
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* TABLE NAVIGATOR */}
        <div className="lg:col-span-1 bg-[#f0efed] border border-[#141414] p-4 space-y-2 h-[500px] overflow-y-auto">
          <h3 className="text-[10px] font-bold text-[#141414]/60 uppercase tracking-widest mb-3 pb-2 border-b border-[#141414]/20 flex items-center gap-1 font-mono">
            <Table className="h-3.5 w-3.5" />
            Postgres Catalog ({Object.keys(schemaDefinitions).length})
          </h3>
          {Object.keys(schemaDefinitions).map((tbl) => {
            const isSelected = selectedTable === tbl;
            return (
              <button
                key={tbl}
                onClick={() => setSelectedTable(tbl)}
                className={`w-full text-left px-3 py-2 font-mono text-xs transition-all flex items-center justify-between border cursor-pointer ${
                  isSelected 
                    ? "bg-[#141414] text-[#E4E3E0] border-[#141414]" 
                    : "text-[#141414]/80 hover:bg-[#DCDAD7] border-transparent"
                }`}
              >
                <span>{tbl}</span>
                <span className="text-[9px] opacity-60 font-bold">
                  [{schemaDefinitions[tbl].getData().length}]
                </span>
              </button>
            );
          })}
        </div>

        {/* METADATA & DATA VIEWER (COLSPAN 3) */}
        <div className="lg:col-span-3 space-y-4">
          {/* SCHEMA INFO CARD */}
          <div className="bg-[#f0efed] border border-[#141414] p-5">
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center border-b border-[#141414]/20 pb-3 mb-4 gap-2">
              <div>
                <h3 className="text-sm font-bold font-mono text-[#141414]">
                  table: public.{selectedTable}
                </h3>
                <p className="text-xs font-serif italic text-[#141414]/70 mt-0.5">{activeDef.description}</p>
              </div>
              <div className="flex gap-2 text-[9px] font-mono">
                <span className="bg-[#141414] text-[#E4E3E0] font-bold px-2.5 py-1 flex items-center gap-1">
                  <Key className="h-3 w-3 text-amber-400" />
                  PK: {activeDef.primaryKey}
                </span>
                {activeDef.foreignKeys.length > 0 && (
                  <span className="bg-[#DCDAD7] text-[#141414] font-bold px-2.5 py-1 border border-[#141414]/20">
                    FK: {activeDef.foreignKeys.length} relation(s)
                  </span>
                )}
              </div>
            </div>

            {/* COLUMNS MATRIX */}
            <div>
              <h4 className="text-[9px] font-bold uppercase tracking-widest text-[#141414]/60 mb-2 font-mono">Column Specifications</h4>
              <div className="flex flex-wrap gap-2">
                {activeDef.columns.map((col, idx) => (
                  <span 
                    key={idx} 
                    className="bg-white border border-[#141414]/20 px-2.5 py-1 text-xs font-mono flex items-center gap-1.5 text-[#141414]"
                  >
                    <span className="font-bold">{col.name}</span>
                    <span className="opacity-50 text-[10px]">{col.type}</span>
                    {col.constraints && (
                      <span className="text-red-800 text-[9px] uppercase font-bold">{col.constraints}</span>
                    )}
                  </span>
                ))}
              </div>
            </div>
          </div>

          {/* SPREADSHEET ROW EXPLORER */}
          <div className="bg-[#f0efed] border border-[#141414]">
            <div className="p-4 border-b border-[#141414]/20 flex justify-between items-center bg-[#DCDAD7]/50">
              <h4 className="text-xs font-bold uppercase tracking-widest flex items-center gap-2 font-mono">
                <FileSpreadsheet className="h-4 w-4" />
                SQL Query Output: SELECT * FROM {selectedTable};
              </h4>
              <span className="text-[10px] font-mono opacity-60">
                Returned {tableData.length} active row(s)
              </span>
            </div>

            {tableData.length > 0 ? (
              <div className="overflow-x-auto max-h-96">
                <table className="w-full text-xs text-left border-collapse font-mono">
                  <thead>
                    <tr className="bg-[#DCDAD7]/40 border-b border-[#141414]/20 font-bold">
                      {Object.keys(tableData[0]).map((k) => (
                        <th key={k} className="p-2.5 uppercase text-[9px] tracking-wider">{k}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#141414]/10 text-[11px]">
                    {tableData.map((row, idx) => (
                      <tr key={idx} className="hover:bg-[#DCDAD7]/30">
                        {Object.values(row).map((val: any, colIdx) => (
                          <td key={colIdx} className="p-2.5 text-[#141414] truncate max-w-[200px]">
                            {typeof val === "object" ? JSON.stringify(val) : String(val)}
                          </td>
                        ))}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            ) : (
              <div className="p-8 text-center text-[#141414]/60 font-mono italic">
                Query returned empty result set. Public table has 0 active records.
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
