import React, { useState, useEffect } from "react";
import { Machine, Ingredient, RecipeVersion, ProductionBatch, SystemEvent, TelemetryPoint } from "../types";
import { 
  Cpu, Zap, RefreshCw, AlertTriangle, Play, Package, 
  Layers, CheckCircle, Flame, Activity, ArrowRight, Gauge
} from "lucide-react";

interface PlantScadaProps {
  machines: Machine[];
  inventory: Ingredient[];
  recipes: RecipeVersion[];
  batches: ProductionBatch[];
  events: SystemEvent[];
  telemetry: TelemetryPoint[];
  onDispatchBatch: (recipeId: string, quantityKg: number) => Promise<boolean>;
  onRefreshData: () => void;
}

export default function PlantScada({
  machines,
  inventory,
  recipes,
  batches,
  events,
  telemetry,
  onDispatchBatch,
  onRefreshData
}: PlantScadaProps) {
  const [selectedRecipe, setSelectedRecipe] = useState("");
  const [dispatchQty, setDispatchQty] = useState(1000);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [selectedMachine, setSelectedMachine] = useState<string | null>(null);
  const [submissionFeedback, setSubmissionFeedback] = useState<{ type: "success" | "error"; msg: string } | null>(null);

  useEffect(() => {
    if (recipes.length > 0 && !selectedRecipe) {
      const activeRecipe = recipes.find(r => r.isActive);
      if (activeRecipe) setSelectedRecipe(activeRecipe.id);
    }
  }, [recipes, selectedRecipe]);

  const handleDispatch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedRecipe || dispatchQty <= 0) return;
    setIsSubmitting(true);
    setSubmissionFeedback(null);
    try {
      const ok = await onDispatchBatch(selectedRecipe, dispatchQty);
      if (ok) {
        setSubmissionFeedback({
          type: "success",
          msg: `Batch dispatched successfully. Mass balance verified. Material stock subtracted from storage silos.`
        });
      } else {
        setSubmissionFeedback({
          type: "error",
          msg: "Failed to dispatch batch. Check warehouse stock levels."
        });
      }
    } catch (err: any) {
      setSubmissionFeedback({
        type: "error",
        msg: err.message || "Material shortage in silos. Cannot verify mass-reconciliation."
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const getMachineTelem = (machineId: string) => {
    return telemetry.filter(t => t.machineId === machineId).slice(-20);
  };

  const activeBatch = batches[0];

  return (
    <div className="space-y-6">
      {/* HEADER CONTROLS */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center bg-[#DCDAD7] p-4 border border-[#141414] gap-4">
        <div>
          <h2 className="text-lg font-serif italic text-[#141414]">Zurich Factory Control Room</h2>
          <p className="text-[10px] font-mono uppercase tracking-wider opacity-60">Live SCADA Mimic & Material Ingestion Gateways</p>
        </div>
        <button
          onClick={onRefreshData}
          className="flex items-center gap-2 px-4 py-2 bg-[#141414] hover:bg-[#D4D3D0] hover:text-[#141414] text-[#E4E3E0] text-xs font-mono font-bold border border-[#141414] transition-colors uppercase tracking-wider"
        >
          <RefreshCw className="h-3.5 w-3.5" />
          Synchronize Server State
        </button>
      </div>

      {/* PLANT EFFICIENCY SUMMARY GRID */}
      <div className="grid grid-cols-1 md:grid-cols-4 border-l border-t border-[#141414] bg-transparent">
        <div className="bg-[#f0efed] border-r border-b border-[#141414] p-4">
          <div className="flex items-center gap-1.5 text-[#141414]/60 text-[10px] font-bold uppercase tracking-wider mb-2 font-mono">
            <Cpu className="h-3.5 w-3.5 text-[#141414]" />
            Active Line Capacity
          </div>
          <div className="text-xl font-bold font-mono text-[#141414]">500.00 kg/hr</div>
          <div className="text-[10px] text-[#141414]/60 mt-1 font-serif italic">Premium Line A - Active</div>
        </div>

        <div className="bg-[#f0efed] border-r border-b border-[#141414] p-4">
          <div className="flex items-center gap-1.5 text-[#141414]/60 text-[10px] font-bold uppercase tracking-wider mb-2 font-mono">
            <Zap className="h-3.5 w-3.5 text-amber-600" />
            Power Ingestion Rate
          </div>
          <div className="text-xl font-bold font-mono text-[#141414]">
            {machines.reduce((acc, m) => acc + (m.status === "RUNNING" ? m.powerRatingKw : 0), 0).toFixed(1)} kW
          </div>
          <div className="text-[10px] text-[#141414]/60 mt-1 font-serif italic">Active induction motor load</div>
        </div>

        <div className="bg-[#f0efed] border-r border-b border-[#141414] p-4">
          <div className="flex items-center gap-1.5 text-[#141414]/60 text-[10px] font-bold uppercase tracking-wider mb-2 font-mono">
            <Layers className="h-3.5 w-3.5 text-blue-700" />
            Completed Batches
          </div>
          <div className="text-xl font-bold font-mono text-[#141414]">
            {batches.filter(b => b.status === "COMPLETED").length}
          </div>
          <div className="text-[10px] text-[#141414]/60 mt-1 font-serif italic">Reconciled this session</div>
        </div>

        <div className="bg-[#f0efed] border-r border-b border-[#141414] p-4">
          <div className="flex items-center gap-1.5 text-[#141414]/60 text-[10px] font-bold uppercase tracking-wider mb-2 font-mono">
            <CheckCircle className="h-3.5 w-3.5 text-emerald-700" />
            Average Process Loss
          </div>
          <div className="text-xl font-bold font-mono text-[#141414]">1.22 %</div>
          <div className="text-[10px] text-[#141414]/60 mt-1 font-serif italic">Evaporative & wall losses</div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* SCADA MIMIC PANEL (COLSPAN 2) */}
        <div className="lg:col-span-2 space-y-6">
          <div className="bg-[#f0efed] border border-[#141414] p-5">
            <div className="flex justify-between items-center mb-4 pb-3 border-b border-[#141414]/20">
              <h3 className="text-xs font-bold uppercase tracking-widest text-[#141414] flex items-center gap-2 font-mono">
                <span className="h-2 w-2 rounded-full bg-emerald-600 animate-pulse"></span>
                Live Synoptic Machine Matrix
              </h3>
              <span className="text-[9px] font-mono uppercase opacity-50">STATIONARY FLOW</span>
            </div>

            {/* FLOW SCHEMATIC */}
            <div className="grid grid-cols-1 md:grid-cols-5 gap-3 relative">
              {machines.map((m, idx) => {
                const isSelected = selectedMachine === m.id;
                const statusColors = {
                  RUNNING: isSelected 
                    ? "bg-[#141414] text-[#E4E3E0] border-[#141414]" 
                    : "border-[#141414] bg-emerald-50 text-emerald-950 hover:bg-emerald-100/80",
                  IDLE: isSelected 
                    ? "bg-[#141414] text-[#E4E3E0] border-[#141414]" 
                    : "border-[#141414] bg-[#DCDAD7] text-slate-700 hover:bg-[#D4D3D0]",
                  FAULT: isSelected 
                    ? "bg-[#141414] text-[#E4E3E0] border-[#141414]" 
                    : "border-rose-600 bg-rose-50 text-rose-950 animate-pulse hover:bg-rose-100",
                  MAINTENANCE: isSelected 
                    ? "bg-[#141414] text-[#E4E3E0] border-[#141414]" 
                    : "border-amber-600 bg-amber-50 text-amber-950 hover:bg-amber-100"
                };

                return (
                  <div key={m.id} className="relative flex flex-col justify-between">
                    <button
                      onClick={() => setSelectedMachine(m.id)}
                      className={`w-full text-left p-3 border font-mono transition-all cursor-pointer ${
                        isSelected ? "ring-2 ring-[#141414] ring-offset-2" : ""
                      } ${statusColors[m.status]}`}
                    >
                      <div className="flex justify-between items-start mb-2">
                        <span className="text-[8px] font-bold uppercase tracking-wider opacity-60 bg-white/40 px-1 font-mono">
                          M-00{idx + 1}
                        </span>
                        <span className="text-[8px] font-bold uppercase px-1 bg-white/50 text-[#141414]">
                          {m.status}
                        </span>
                      </div>
                      <h4 className="text-xs font-bold leading-tight mb-2 h-8 font-serif italic truncate-2-lines">{m.name}</h4>
                      <p className="text-[9px] opacity-60 truncate">{m.model}</p>
                      
                      {/* Active Params */}
                      <div className="space-y-1 pt-2 mt-2 border-t border-[#141414]/10 text-[9px]">
                        {m.tempC !== undefined && (
                          <div className="flex justify-between">
                            <span>Temp:</span>
                            <span className="font-bold">{m.tempC.toFixed(1)}°C</span>
                          </div>
                        )}
                        {m.rpm !== undefined && (
                          <div className="flex justify-between">
                            <span>Speed:</span>
                            <span className="font-bold">{Math.round(m.rpm)} RPM</span>
                          </div>
                        )}
                        {m.motorLoadPct !== undefined && (
                          <div className="flex justify-between">
                            <span>Load:</span>
                            <span className="font-bold">{Math.round(m.motorLoadPct)}%</span>
                          </div>
                        )}
                        {m.flowRateLpm !== undefined && (
                          <div className="flex justify-between">
                            <span>Flow:</span>
                            <span className="font-bold">{m.flowRateLpm.toFixed(1)} L/m</span>
                          </div>
                        )}
                      </div>
                    </button>

                    {/* FLOW ARROW */}
                    {idx < machines.length - 1 && (
                      <div className="hidden md:flex absolute top-1/2 -right-2.5 transform -translate-y-1/2 z-10 text-[#141414]">
                        <ArrowRight className="h-4 w-4" />
                      </div>
                    )}
                  </div>
                );
              })}
            </div>

            {/* EXPANDED TELEMETRY SPARKLINE */}
            {selectedMachine && (
              <div className="mt-5 pt-4 border-t border-[#141414]/20 bg-[#DCDAD7]/50 p-4">
                {(() => {
                  const m = machines.find(mac => mac.id === selectedMachine);
                  if (!m) return null;
                  const pts = getMachineTelem(selectedMachine);
                  const param = pts[0]?.parameter || "MOTOR_LOAD";
                  const unit = pts[0]?.unit || "%";
                  const latestVal = pts[pts.length - 1]?.value || 0;

                  return (
                    <div className="space-y-3 font-mono">
                      <div className="flex justify-between items-center">
                        <div>
                          <h4 className="text-xs font-bold uppercase tracking-wider text-[#141414]">
                            Sensor Stream: {m.name}
                          </h4>
                          <p className="text-[10px] opacity-60">
                            Time-series telemetry of <span className="font-bold">{param}</span> ({unit})
                          </p>
                        </div>
                        <div className="text-right">
                          <span className="text-[10px] opacity-60 mr-2">VALUE:</span>
                          <span className="text-base font-bold text-[#141414]">{latestVal.toFixed(2)} {unit}</span>
                        </div>
                      </div>

                      {/* SVG PLOT */}
                      {pts.length > 1 ? (
                        <div className="h-28 bg-[#f0efed] border border-[#141414] p-2 relative">
                          <svg className="w-full h-full" viewBox="0 0 400 100" preserveAspectRatio="none">
                            {/* Grid Lines */}
                            <line x1="0" y1="25" x2="400" y2="25" stroke="#141414" strokeWidth="1" strokeOpacity="0.1" />
                            <line x1="0" y1="50" x2="400" y2="50" stroke="#141414" strokeWidth="1" strokeOpacity="0.1" />
                            <line x1="0" y1="75" x2="400" y2="75" stroke="#141414" strokeWidth="1" strokeOpacity="0.1" />
                            
                            {/* Path */}
                            {(() => {
                              const min = Math.min(...pts.map(p => p.value)) * 0.95;
                              const max = Math.max(...pts.map(p => p.value)) * 1.05;
                              const range = max - min || 1;
                              const pointsStr = pts.map((p, i) => {
                                const x = (i / (pts.length - 1)) * 400;
                                const y = 100 - ((p.value - min) / range) * 90 - 5;
                                return `${x},${y}`;
                              }).join(" ");

                              return (
                                <>
                                  <polyline
                                    fill="none"
                                    stroke="#141414"
                                    strokeWidth="1.5"
                                    points={pointsStr}
                                  />
                                  <polygon
                                    fill="#141414"
                                    opacity="0.05"
                                    points={`0,100 ${pointsStr} 400,100`}
                                  />
                                </>
                              );
                            })()}
                          </svg>
                          <div className="absolute bottom-1 right-2 text-[8px] opacity-40">
                            Telemetry interval: 5.00s
                          </div>
                        </div>
                      ) : (
                        <div className="h-28 flex items-center justify-center border border-[#141414] bg-[#f0efed] text-xs opacity-50 italic">
                          Awaiting telemetry transmission bursts...
                        </div>
                      )}
                    </div>
                  );
                })()}
              </div>
            )}
          </div>

          {/* FORM CONSERVATION PANEL */}
          <div className="bg-[#f0efed] border border-[#141414] p-5">
            <h3 className="text-xs font-bold uppercase tracking-widest text-[#141414] mb-4 pb-3 border-b border-[#141414]/20 font-mono flex items-center gap-2">
              <Play className="h-4 w-4" />
              Formula & Ingredient Dispatch Gateway
            </h3>

            <form onSubmit={handleDispatch} className="grid grid-cols-1 md:grid-cols-3 gap-4 items-end font-mono">
              <div>
                <label className="block text-[10px] uppercase font-bold text-[#141414]/60 mb-1">
                  Target Recipe
                </label>
                <select
                  value={selectedRecipe}
                  onChange={(e) => setSelectedRecipe(e.target.value)}
                  className="w-full bg-[#DCDAD7] border border-[#141414] px-3 py-2 text-xs focus:outline-none focus:bg-white text-[#141414]"
                >
                  {recipes.map(r => (
                    <option key={r.id} value={r.id}>
                      {r.recipeName} (v{r.version})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-[10px] uppercase font-bold text-[#141414]/60 mb-1">
                  Batch target mass (kg)
                </label>
                <input
                  type="number"
                  min="100"
                  max="10000"
                  step="50"
                  value={dispatchQty}
                  onChange={(e) => setDispatchQty(Number(e.target.value))}
                  className="w-full bg-[#DCDAD7] border border-[#141414] px-3 py-2 text-xs focus:outline-none focus:bg-white font-mono text-[#141414]"
                />
              </div>

              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full flex items-center justify-center gap-2 px-4 py-2 bg-[#141414] hover:bg-[#D4D3D0] hover:text-[#141414] text-[#E4E3E0] text-xs font-bold border border-[#141414] transition-colors h-[34px] cursor-pointer uppercase tracking-wider"
              >
                {isSubmitting ? (
                  <>
                    <RefreshCw className="h-3.5 w-3.5 animate-spin" />
                    Calculating...
                  </>
                ) : (
                  <>
                    <Activity className="h-3.5 w-3.5" />
                    Dispatch Recipe
                  </>
                )}
              </button>
            </form>

            {submissionFeedback && (
              <div className={`mt-4 p-3 border text-xs leading-relaxed flex items-start gap-2 font-mono ${
                submissionFeedback.type === "success" 
                  ? "bg-emerald-50 text-emerald-900 border-emerald-500" 
                  : "bg-rose-50 text-rose-900 border-rose-500"
              }`}>
                {submissionFeedback.type === "success" ? (
                  <CheckCircle className="h-4 w-4 text-emerald-700 shrink-0 mt-0.5" />
                ) : (
                  <AlertTriangle className="h-4 w-4 text-rose-700 shrink-0 mt-0.5" />
                )}
                <span>{submissionFeedback.msg}</span>
              </div>
            )}
          </div>
        </div>

        {/* SIDEBAR CONTAINER */}
        <div className="space-y-6">
          {/* WAREHOUSE MATERIAL INVENTORY STATUS */}
          <div className="bg-[#f0efed] border border-[#141414] p-5">
            <h3 className="text-xs font-bold uppercase tracking-widest text-[#141414] mb-4 pb-3 border-b border-[#141414]/20 font-mono flex items-center gap-2">
              <Package className="h-4 w-4" />
              Warehouse Silos Stock
            </h3>

            <div className="space-y-4 font-mono">
              {inventory.map(ing => {
                const pct = (ing.quantityInStockKg / 50000) * 100;
                const isLow = ing.quantityInStockKg < ing.reorderLevelKg;

                return (
                  <div key={ing.id} className="text-xs">
                    <div className="flex justify-between text-[#141414]/80 mb-1">
                      <span className="truncate max-w-[150px] uppercase text-[11px] font-bold">{ing.name}</span>
                      <span className="font-bold">
                        {Math.round(ing.quantityInStockKg).toLocaleString()} kg
                      </span>
                    </div>
                    {/* Visual Silo Bar */}
                    <div className="w-full bg-[#D4D3D0] h-2 border border-[#141414]">
                      <div
                        className={`h-full transition-all duration-500 ${
                          isLow ? "bg-amber-600" : "bg-[#141414]"
                        }`}
                        style={{ width: `${Math.min(100, pct)}%` }}
                      ></div>
                    </div>
                    {isLow && (
                      <div className="flex items-center gap-1 text-[9px] text-amber-700 mt-1 font-bold uppercase">
                        <AlertTriangle className="h-3 w-3" />
                        Reorder needed (&lt; {ing.reorderLevelKg} kg)
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>

          {/* ACTIVE SYSTEM EVENT LOGGER */}
          <div className="bg-[#f0efed] border border-[#141414] p-5">
            <h3 className="text-xs font-bold uppercase tracking-widest text-[#141414] mb-4 pb-3 border-b border-[#141414]/20 font-mono flex items-center gap-2">
              <Gauge className="h-4 w-4" />
              Real-time Event Ingestion
            </h3>

            <div className="space-y-2 max-h-[300px] overflow-y-auto pr-1">
              {events.slice(0, 5).map(evt => (
                <div key={evt.id} className="p-3 border-b border-[#141414]/10 text-[10px] font-mono leading-relaxed space-y-1">
                  <div className="flex justify-between items-center opacity-60">
                    <span className="font-bold uppercase tracking-wider text-[#141414]">
                      {evt.eventType}
                    </span>
                    <span>{new Date(evt.timestamp).toLocaleTimeString()}</span>
                  </div>
                  <p className="text-[#141414] font-serif italic">{evt.description}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
