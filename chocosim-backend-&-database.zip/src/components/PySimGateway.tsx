import React, { useState } from "react";
import { SimulationRun, OptimisationRun } from "../types";
import { 
  Play, Cpu, Settings, RefreshCw, Layers, CheckCircle2, 
  HelpCircle, Sparkles, Sliders, ShieldAlert, Award
} from "lucide-react";

interface PySimGatewayProps {
  simulationHistory: SimulationRun[];
  optimisationHistory: OptimisationRun[];
  onRunSimulation: (scenario: string, seed: number, batchCount: number) => Promise<SimulationRun | null>;
  onRunOptimisation: (objective: "MINIMIZE_COST" | "MAXIMIZE_YIELD" | "MINIMIZE_ENERGY") => Promise<OptimisationRun | null>;
}

export default function PySimGateway({
  simulationHistory,
  optimisationHistory,
  onRunSimulation,
  onRunOptimisation
}: PySimGatewayProps) {
  // Sim parameters
  const [selectedScenario, setSelectedScenario] = useState("BASE_CASE");
  const [simSeed, setSimSeed] = useState(42);
  const [simBatchCount, setSimBatchCount] = useState(10);
  const [isSimulating, setIsSimulating] = useState(false);

  // Optimiser parameters
  const [selectedObjective, setSelectedObjective] = useState<"MINIMIZE_COST" | "MAXIMIZE_YIELD" | "MINIMIZE_ENERGY">("MINIMIZE_COST");
  const [isOptimising, setIsOptimising] = useState(false);

  const handleSimSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSimulating(true);
    try {
      await onRunSimulation(selectedScenario, simSeed, simBatchCount);
    } catch (err) {
      console.error(err);
    } finally {
      setIsSimulating(false);
    }
  };

  const handleOptSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsOptimising(true);
    try {
      await onRunOptimisation(selectedObjective);
    } catch (err) {
      console.error(err);
    } finally {
      setIsOptimising(false);
    }
  };

  const activeSim = simulationHistory[0];
  const activeOpt = optimisationHistory[0];

  return (
    <div className="space-y-6 text-[#141414]">
      {/* SECTION HEADER */}
      <div className="bg-[#DCDAD7] p-4 border border-[#141414]">
        <h2 className="text-lg font-serif italic text-[#141414]">Python Simulation & Solver Engine Gateway</h2>
        <p className="text-[10px] font-mono uppercase tracking-wider opacity-60">Stochastic Process Simulator, Sensitivity Forecasters & Recipe Solver Modules</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* PYTHONSIM STOCHASTIC PROCESS SIMULATOR */}
        <div className="bg-[#f0efed] border border-[#141414] p-5 space-y-4">
          <div className="border-b border-[#141414]/20 pb-3">
            <h3 className="text-xs font-bold uppercase tracking-widest text-[#141414] font-mono flex items-center gap-2">
              <Sliders className="h-4 w-4" />
              Python Stochastic Simulator
            </h3>
            <p className="text-[10px] opacity-60 mt-0.5 font-mono">
              Evaluates thermodynamic, mechanical, and price scenarios via random seed generation
            </p>
          </div>

          <form onSubmit={handleSimSubmit} className="space-y-4 font-mono">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-[10px] uppercase font-bold text-[#141414]/60 mb-1">Scenario Preset</label>
                <select
                  value={selectedScenario}
                  onChange={(e) => setSelectedScenario(e.target.value)}
                  className="w-full bg-[#DCDAD7] border border-[#141414] px-3 py-2 text-xs focus:outline-none focus:bg-white text-[#141414]"
                >
                  <option value="BASE_CASE">Base Case (Standard Run)</option>
                  <option value="COCOA_PRICE_SPIKE">Cocoa Price Spike (+20%)</option>
                  <option value="ENERGY_HIKE">Energy Utility Hike (+30%)</option>
                  <option value="CONCHE_FAILURE">Conche Mechanical Failure</option>
                </select>
              </div>

              <div>
                <label className="block text-[10px] uppercase font-bold text-[#141414]/60 mb-1">Random Seed</label>
                <input
                  type="number"
                  value={simSeed}
                  onChange={(e) => setSimSeed(Number(e.target.value))}
                  className="w-full bg-[#DCDAD7] border border-[#141414] px-3 py-2 text-xs focus:outline-none focus:bg-white font-mono text-[#141414]"
                />
              </div>

              <div className="sm:col-span-2">
                <label className="block text-[10px] uppercase font-bold text-[#141414]/60 mb-1">
                  Simulation Batch Count: <span className="font-bold text-blue-700">{simBatchCount}</span>
                </label>
                <input
                  type="range"
                  min="2"
                  max="30"
                  step="1"
                  value={simBatchCount}
                  onChange={(e) => setSimBatchCount(Number(e.target.value))}
                  className="w-full h-1.5 bg-[#D4D3D0] appearance-none cursor-pointer accent-[#141414]"
                />
              </div>
            </div>

            <button
              type="submit"
              disabled={isSimulating}
              className="w-full flex items-center justify-center gap-2 px-4 py-2 bg-[#141414] hover:bg-[#D4D3D0] hover:text-[#141414] text-[#E4E3E0] text-xs font-bold border border-[#141414] transition-colors h-9 uppercase tracking-wider cursor-pointer"
            >
              {isSimulating ? (
                <>
                  <RefreshCw className="h-3.5 w-3.5 animate-spin" />
                  Spinning Monte Carlo Chains...
                </>
              ) : (
                <>
                  <Play className="h-3.5 w-3.5" />
                  Trigger Simulation Run
                </>
              )}
            </button>
          </form>

          {/* ACTIVE SIMULATION RESULT */}
          {activeSim && activeSim.results && (
            <div className="pt-4 border-t border-[#141414]/20 space-y-4">
              <div className="bg-[#DCDAD7]/30 p-3 border border-[#141414]">
                <div className="flex justify-between text-[10px] opacity-60 font-mono mb-2">
                  <span>RUN ID: {activeSim.id.slice(0, 8).toUpperCase()}...</span>
                  <span className="font-bold text-emerald-800">SUCCESS</span>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-center font-mono">
                  <div className="bg-[#f0efed] p-2 border border-[#141414]/10">
                    <div className="text-[8px] opacity-60 uppercase">Yield</div>
                    <div className="text-sm font-bold text-[#141414] mt-1">
                      {activeSim.results.totalYieldKg.toLocaleString()} kg
                    </div>
                  </div>
                  <div className="bg-[#f0efed] p-2 border border-[#141414]/10">
                    <div className="text-[8px] opacity-60 uppercase">Losses</div>
                    <div className="text-sm font-bold text-[#141414] mt-1">
                      {activeSim.results.totalLossKg.toLocaleString()} kg
                    </div>
                  </div>
                  <div className="bg-[#f0efed] p-2 border border-[#141414]/10">
                    <div className="text-[8px] opacity-60 uppercase">Power</div>
                    <div className="text-sm font-bold text-[#141414] mt-1">
                      {activeSim.results.totalEnergyKwh.toLocaleString()} kWh
                    </div>
                  </div>
                  <div className="bg-[#f0efed] p-2 border border-[#141414]/10">
                    <div className="text-[8px] opacity-60 uppercase">Operating Cost</div>
                    <div className="text-sm font-bold text-[#141414] mt-1">
                      CHF {activeSim.results.totalCost.toLocaleString()}
                    </div>
                  </div>
                </div>
              </div>

              {/* SIMULATION TIMELINE */}
              <div>
                <h4 className="text-[10px] font-bold opacity-60 uppercase mb-2 font-mono">
                  Stochastic Batch Timeline
                </h4>
                <div className="max-h-48 overflow-y-auto border border-[#141414] text-[10px] divide-y divide-[#141414]/10 font-mono">
                  {activeSim.results.scadaTimeline.map((step) => (
                    <div key={step.step} className="p-2 flex justify-between items-center hover:bg-[#DCDAD7]/30">
                      <div className="flex items-center gap-2">
                        <span className="font-bold opacity-40">#{step.step}</span>
                        <span className="font-bold text-[#141414]">{step.batchNumber}</span>
                      </div>
                      <div className="flex items-center gap-4 opacity-75 text-right">
                        <span>Yield: {step.yieldKg}kg</span>
                        <span>Loss: {step.lossKg}kg</span>
                        {step.concheFailure ? (
                          <span className="px-1 bg-red-100 text-red-950 font-bold text-[9px] border border-red-400">
                            Conche Down
                          </span>
                        ) : (
                          <span className="text-emerald-800 font-bold">Stable</span>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>

        {/* R-STYLE RECIPE OPTIMISER */}
        <div className="bg-[#f0efed] border border-[#141414] p-5 space-y-4">
          <div className="border-b border-[#141414]/20 pb-3">
            <h3 className="text-xs font-bold uppercase tracking-widest text-[#141414] font-mono flex items-center gap-2">
              <Award className="h-4 w-4" />
              R Recipe Solver & Optimizer
            </h3>
            <p className="text-[10px] opacity-60 mt-0.5 font-mono">
              Iterates cocoa fat suspension matrices to identify minimal overhead coordinates
            </p>
          </div>

          <form onSubmit={handleOptSubmit} className="space-y-4 font-mono">
            <div>
              <label className="block text-[10px] uppercase font-bold text-[#141414]/60 mb-1">Target Objective Function</label>
              <select
                value={selectedObjective}
                onChange={(e) => setSelectedObjective(e.target.value as any)}
                className="w-full bg-[#DCDAD7] border border-[#141414] px-3 py-2 text-xs focus:outline-none focus:bg-white text-[#141414]"
              >
                <option value="MINIMIZE_COST">Minimize Ingredient & Raw Material Cost</option>
                <option value="MAXIMIZE_YIELD">Maximize Production Yield (Stabilize Scrapers)</option>
                <option value="MINIMIZE_ENERGY">Minimize Electrical Utility Draw</option>
              </select>
            </div>

            <button
              type="submit"
              disabled={isOptimising}
              className="w-full flex items-center justify-center gap-2 px-4 py-2 bg-[#141414] hover:bg-[#D4D3D0] hover:text-[#141414] text-[#E4E3E0] text-xs font-bold border border-[#141414] transition-colors h-9 uppercase tracking-wider cursor-pointer"
            >
              {isOptimising ? (
                <>
                  <RefreshCw className="h-3.5 w-3.5 animate-spin" />
                  Running Solver Iterations...
                </>
              ) : (
                <>
                  <Award className="h-3.5 w-3.5" />
                  Execute Optimization Model
                </>
              )}
            </button>
          </form>

          {/* ACTIVE OPTIMIZATION RESULT */}
          {activeOpt && activeOpt.results && (
            <div className="pt-4 border-t border-[#141414]/20 space-y-4">
              <div className="bg-[#DCDAD7]/30 p-4 border border-[#141414] space-y-3 font-mono">
                <div className="flex justify-between items-center">
                  <span className="text-xs font-bold uppercase tracking-wider">Optimal Recipe Solution</span>
                  <span className="text-[9px] bg-[#141414] text-[#E4E3E0] font-bold px-1.5 py-0.5">
                    SOLVER ITERATIONS: {activeOpt.results.solverIterations}
                  </span>
                </div>

                {/* SOLUTION PROPORTIONS */}
                <div className="grid grid-cols-2 gap-2 text-xs">
                  <div className="p-2 bg-[#f0efed] border border-[#141414]/10 flex justify-between">
                    <span className="opacity-60">Cocoa Mass:</span>
                    <span className="font-bold">{activeOpt.results.solution.cocoaPct}%</span>
                  </div>
                  <div className="p-2 bg-[#f0efed] border border-[#141414]/10 flex justify-between">
                    <span className="opacity-60">Cocoa Butter:</span>
                    <span className="font-bold">{activeOpt.results.solution.cocoaButterPct}%</span>
                  </div>
                  <div className="p-2 bg-[#f0efed] border border-[#141414]/10 flex justify-between">
                    <span className="opacity-60">Sugar Content:</span>
                    <span className="font-bold">{activeOpt.results.solution.sugarPct}%</span>
                  </div>
                  <div className="p-2 bg-[#f0efed] border border-[#141414]/10 flex justify-between">
                    <span className="opacity-60">Conche Cycle:</span>
                    <span className="font-bold">{activeOpt.results.solution.conchingTimeHrs} hrs</span>
                  </div>
                </div>

                <div className="text-xs leading-relaxed space-y-1.5 pt-2 border-t border-[#141414]/10 font-mono">
                  <div className="flex justify-between">
                    <span className="opacity-60">Expected Yield (per 1k kg):</span>
                    <span className="font-bold">{activeOpt.results.expectedYieldKg.toFixed(1)} kg</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="opacity-60">Predicted Overhead Savings:</span>
                    <span className="font-bold text-emerald-800">CHF {activeOpt.results.expectedCostSaving.toFixed(2)}</span>
                  </div>
                </div>
              </div>

              <div className="text-[10px] leading-relaxed bg-[#DCDAD7]/40 p-3 border border-[#141414] flex items-start gap-2 font-mono">
                <CheckCircle2 className="h-4 w-4 text-emerald-800 shrink-0 mt-0.5" />
                <span>
                  <strong>Audit Record Persisted:</strong> This calculation is registered as run key{" "}
                  <code className="font-bold text-[#141414] bg-[#DCDAD7] px-1 border border-[#141414]/20">{activeOpt.id.slice(0, 8).toUpperCase()}</code>. 
                  Committed securely to the SQL database tables.
                </span>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
