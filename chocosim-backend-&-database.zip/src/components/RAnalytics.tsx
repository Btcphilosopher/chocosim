import React, { useState } from "react";
import { SpcParameterAnalysis, EconomicBreakdown } from "../types";
import { 
  TrendingUp, BarChart4, Compass, ShieldCheck, 
  HelpCircle, Sparkles, DollarSign, ArrowUpRight
} from "lucide-react";

interface RAnalyticsProps {
  qualityData: {
    particleSize: SpcParameterAnalysis;
    viscosity: SpcParameterAnalysis;
  } | null;
  economicsData: EconomicBreakdown[];
}

export default function RAnalytics({ qualityData, economicsData }: RAnalyticsProps) {
  const [selectedParam, setSelectedParam] = useState<"particleSize" | "viscosity">("particleSize");
  const [cocoaSensitivity, setCocoaSensitivity] = useState(20);

  if (!qualityData) {
    return (
      <div className="p-8 text-center text-[#141414] font-mono italic">
        Awaiting response buffer from R process engine...
      </div>
    );
  }

  const activeSpc = qualityData[selectedParam];

  // Calculate cocoa price sensitivity matrices (R Economics Emulator)
  const averageBatch = economicsData[0] || {
    ingredientCost: 3720.50,
    energyCost: 177.50,
    laborCost: 450.00,
    packagingCost: 120.00,
    maintenanceCost: 75.00,
    wasteCost: 22.00,
    totalProductionCost: 4565.00,
    yieldKg: 983.3,
    marketPrice: 13.50
  };

  const calculateSensitiveMargin = (increasePct: number) => {
    // 72% of chocolate cost is sensitive to global raw cocoa rates
    const cocoaPortion = averageBatch.ingredientCost * 0.72;
    const stablePortion = averageBatch.ingredientCost * 0.28;
    
    const newIngredients = cocoaPortion * (1 + increasePct / 100) + stablePortion;
    const newTotalCost = averageBatch.totalProductionCost - averageBatch.ingredientCost + newIngredients;
    const newCostPerKg = newTotalCost / averageBatch.yieldKg;
    const revenuePerKg = averageBatch.marketPrice;
    
    const marginPct = ((revenuePerKg - newCostPerKg) / revenuePerKg) * 100;
    return {
      ingredientCost: newIngredients,
      totalCost: newTotalCost,
      costPerKg: newCostPerKg,
      marginPct: marginPct
    };
  };

  const sens_base = calculateSensitiveMargin(0);
  const sens_custom = calculateSensitiveMargin(cocoaSensitivity);
  const sens_hike50 = calculateSensitiveMargin(50);

  return (
    <div className="space-y-6 text-[#141414]">
      {/* SECTION HEADER */}
      <div className="bg-[#DCDAD7] p-4 border border-[#141414]">
        <h2 className="text-lg font-serif italic text-[#141414]">R Statistical Process Control & Economic Modeller</h2>
        <p className="text-[10px] font-mono uppercase tracking-wider opacity-60">Quality Capability Indices, Shewhart UCL/LCL Bounds & Ingredient Sensitivity Matrices</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* SPC QUALITY ASSURANCE ENGINE (COLSPAN 2) */}
        <div className="lg:col-span-2 space-y-6">
          <div className="bg-[#f0efed] border border-[#141414] p-5">
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center border-b border-[#141414]/20 pb-4 mb-4 gap-4">
              <div>
                <h3 className="text-xs font-bold uppercase tracking-widest font-mono">SPC Shewhart Quality Charts</h3>
                <p className="text-[10px] opacity-60 mt-0.5">3-Sigma boundaries calculated over completed production batches</p>
              </div>
              <div className="flex gap-2 font-mono">
                <button
                  onClick={() => setSelectedParam("particleSize")}
                  className={`px-3 py-1 text-xs border border-[#141414] transition-colors cursor-pointer uppercase ${
                    selectedParam === "particleSize" 
                      ? "bg-[#141414] text-[#E4E3E0] font-bold" 
                      : "bg-[#DCDAD7] text-[#141414] hover:bg-[#D4D3D0]"
                  }`}
                >
                  Particle Size (μm)
                </button>
                <button
                  onClick={() => setSelectedParam("viscosity")}
                  className={`px-3 py-1 text-xs border border-[#141414] transition-colors cursor-pointer uppercase ${
                    selectedParam === "viscosity" 
                      ? "bg-[#141414] text-[#E4E3E0] font-bold" 
                      : "bg-[#DCDAD7] text-[#141414] hover:bg-[#D4D3D0]"
                  }`}
                >
                  Viscosity (Pa·s)
                </button>
              </div>
            </div>

            {/* SPC METRICS BOX */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-5 text-center font-mono">
              <div className="bg-[#DCDAD7]/30 p-3 border border-[#141414]">
                <div className="text-[9px] uppercase font-bold opacity-60">Process Mean</div>
                <div className="text-lg font-bold text-[#141414] font-mono mt-1">{activeSpc.mean}</div>
                <div className="text-[8px] opacity-50 mt-1">Target: {activeSpc.target}</div>
              </div>

              <div className="bg-[#DCDAD7]/30 p-3 border border-[#141414]">
                <div className="text-[9px] uppercase font-bold opacity-60">Std Deviation (σ)</div>
                <div className="text-lg font-bold text-[#141414] font-mono mt-1">{activeSpc.sd}</div>
                <div className="text-[8px] opacity-50 mt-1">Dispersion check</div>
              </div>

              <div className="bg-[#DCDAD7]/30 p-3 border border-[#141414]">
                <div className="text-[9px] uppercase font-bold opacity-60">Capability (C_pk)</div>
                <div className={`text-lg font-bold font-mono mt-1 ${
                  activeSpc.cpk >= 1.33 ? "text-emerald-700" : "text-amber-700"
                }`}>
                  {activeSpc.cpk}
                </div>
                <div className="text-[8px] opacity-50 mt-1">Ideal &gt;= 1.33</div>
              </div>

              <div className="bg-[#DCDAD7]/30 p-3 border border-[#141414]">
                <div className="text-[9px] uppercase font-bold opacity-60">Process Status</div>
                <div className={`text-[10px] font-bold uppercase mt-1.5 px-1 py-0.5 border ${
                  activeSpc.cpk >= 1.33 
                    ? "bg-emerald-50 text-emerald-950 border-emerald-400" 
                    : "bg-amber-50 text-amber-950 border-amber-400"
                }`}>
                  {activeSpc.cpk >= 1.33 ? "Stable Line" : "Process Shift"}
                </div>
                <div className="text-[8px] opacity-50 mt-1">Western Electric OK</div>
              </div>
            </div>

            {/* CHART VIEWPORT */}
            <div className="bg-[#DCDAD7]/50 border border-[#141414] p-4 relative mb-4">
              <div className="flex justify-between items-center text-[9px] font-mono opacity-60 mb-2">
                <span>Shewhart Control Log (UCL: {activeSpc.ucl} / LCL: {activeSpc.lcl})</span>
                <span className="font-bold uppercase">PARAMETER: {activeSpc.parameter}</span>
              </div>

              <div className="h-48 bg-[#f0efed] border border-[#141414] p-2 relative">
                <svg className="w-full h-full" viewBox="0 0 500 120" preserveAspectRatio="none">
                  {/* Shewhart boundaries */}
                  {/* UCL Line */}
                  <line x1="0" y1="20" x2="500" y2="20" stroke="#b91c1c" strokeWidth="1.5" strokeDasharray="3" />
                  {/* Mean Line */}
                  <line x1="0" y1="60" x2="500" y2="60" stroke="#15803d" strokeWidth="1.5" />
                  {/* LCL Line */}
                  <line x1="0" y1="100" x2="500" y2="100" stroke="#b91c1c" strokeWidth="1.5" strokeDasharray="3" />

                  {/* Labels on SVG */}
                  <text x="5" y="15" fill="#b91c1c" className="text-[8px] font-bold font-mono">UCL ({activeSpc.ucl})</text>
                  <text x="5" y="55" fill="#15803d" className="text-[8px] font-bold font-mono">MEAN ({activeSpc.mean})</text>
                  <text x="5" y="95" fill="#b91c1c" className="text-[8px] font-bold font-mono">LCL ({activeSpc.lcl})</text>

                  {/* Draw values */}
                  {(() => {
                    const values = activeSpc.controlChartValues;
                    const minBound = activeSpc.lcl * 0.95;
                    const maxBound = activeSpc.ucl * 1.05;
                    const range = maxBound - minBound || 1;

                    const ptsStr = values.map((val, i) => {
                      const x = (i / (values.length - 1 || 1)) * 480 + 10;
                      const y = 120 - ((val.value - minBound) / range) * 100 - 10;
                      return `${x},${y}`;
                    }).join(" ");

                    return (
                      <>
                        <polyline
                          fill="none"
                          stroke="#141414"
                          strokeWidth="2"
                          points={ptsStr}
                        />
                        {/* Dots */}
                        {values.map((val, i) => {
                          const x = (i / (values.length - 1 || 1)) * 480 + 10;
                          const y = 120 - ((val.value - minBound) / range) * 100 - 10;
                          const isOut = val.value > activeSpc.ucl || val.value < activeSpc.lcl;
                          return (
                            <circle
                              key={i}
                              cx={x}
                              cy={y}
                              r={isOut ? 4.5 : 3}
                              fill={isOut ? "#b91c1c" : "#141414"}
                              className={isOut ? "animate-ping" : ""}
                            />
                          );
                        })}
                      </>
                    );
                  })()}
                </svg>
              </div>
            </div>

            <div className="flex items-center gap-2 text-xs bg-[#DCDAD7]/40 p-3 border border-[#141414] font-mono">
              <ShieldCheck className="h-4 w-4 shrink-0 text-emerald-800" />
              <span>
                <strong>Process Capability Index (C_pk) Analysis:</strong>{" "}
                With a calculated C_pk of <strong className="font-bold">{activeSpc.cpk}</strong>, this production line is classified as{" "}
                {activeSpc.cpk >= 1.33 ? (
                  <strong className="text-emerald-800">highly capable and stable</strong>
                ) : (
                  <strong className="text-amber-800 font-bold">borderline (minor recipe shear rate tuning recommended)</strong>
                )}.
              </span>
            </div>
          </div>
        </div>

        {/* ECONOMIC MARGINS & COCOA PRICE SENSITIVITY (COLSPAN 1) */}
        <div className="space-y-6">
          <div className="bg-[#f0efed] border border-[#141414] p-5">
            <h3 className="text-xs font-bold uppercase tracking-widest text-[#141414] mb-3 pb-2 border-b border-[#141414]/20 font-mono flex items-center gap-2">
              <DollarSign className="h-4 w-4" />
              R Recipe Costing Breakdown
            </h3>
            <p className="text-[10px] opacity-60 mb-4 font-mono">Baseline cost estimates derived from Zurich Line A batch averages (1,000 kg targets)</p>

            <div className="space-y-2 text-xs border-b border-[#141414]/10 pb-4 mb-4 font-mono">
              <div className="flex justify-between">
                <span className="opacity-60">Raw Material Ingredients</span>
                <span className="font-bold">CHF {averageBatch.ingredientCost.toFixed(2)}</span>
              </div>
              <div className="flex justify-between">
                <span className="opacity-60">Power Utilities Draw</span>
                <span className="font-bold">CHF {averageBatch.energyCost.toFixed(2)}</span>
              </div>
              <div className="flex justify-between">
                <span className="opacity-60">Direct Factory Labor Cost</span>
                <span className="font-bold">CHF {averageBatch.laborCost.toFixed(2)}</span>
              </div>
              <div className="flex justify-between">
                <span className="opacity-60">Packaging Materials</span>
                <span className="font-bold">CHF {averageBatch.packagingCost.toFixed(2)}</span>
              </div>
              <div className="flex justify-between">
                <span className="opacity-60">Machinery Wear / Maint</span>
                <span className="font-bold">CHF {averageBatch.maintenanceCost.toFixed(2)}</span>
              </div>
              <div className="flex justify-between">
                <span className="opacity-60">Scrap waste Allocation</span>
                <span className="font-bold">CHF {averageBatch.wasteCost.toFixed(2)}</span>
              </div>
              <div className="flex justify-between border-t border-[#141414]/30 pt-2 font-bold">
                <span>Total Production Cost</span>
                <span>CHF {averageBatch.totalProductionCost.toFixed(2)}</span>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-2 text-center font-mono text-xs">
              <div className="bg-[#DCDAD7]/30 p-2.5 border border-[#141414]">
                <div className="opacity-60 text-[9px] uppercase font-bold">Cost per kg</div>
                <div className="text-base font-bold text-[#141414] mt-1">
                  CHF {(averageBatch.totalProductionCost / averageBatch.yieldKg).toFixed(2)}
                </div>
              </div>
              <div className="bg-[#141414] text-[#E4E3E0] p-2.5 border border-[#141414]">
                <div className="opacity-60 text-[9px] uppercase font-bold text-slate-300">Gross Margin</div>
                <div className="text-base font-bold text-emerald-400 mt-1">
                  {(((averageBatch.marketPrice - (averageBatch.totalProductionCost / averageBatch.yieldKg)) / averageBatch.marketPrice) * 100).toFixed(1)}%
                </div>
              </div>
            </div>
          </div>

          {/* SENSITIVITY PANEL */}
          <div className="bg-[#f0efed] border border-[#141414] p-5">
            <h3 className="text-xs font-bold uppercase tracking-widest text-[#141414] mb-1 pb-2 border-b border-[#141414]/20 font-mono flex items-center gap-2">
              <TrendingUp className="h-4 w-4" />
              Cocoa Rate Price Sensitivity
            </h3>
            <p className="text-[10px] opacity-60 mb-4 font-mono">Simulate effect of global commodity cocoa bean price spikes on Swiss manufacturing margins</p>

            <div className="space-y-4">
              <div className="font-mono">
                <div className="flex justify-between text-xs font-bold mb-1">
                  <span className="opacity-60 uppercase">Cocoa Inflation Rate:</span>
                  <span className="text-red-700">+{cocoaSensitivity}%</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="100"
                  step="5"
                  value={cocoaSensitivity}
                  onChange={(e) => setCocoaSensitivity(Number(e.target.value))}
                  className="w-full h-1.5 bg-[#D4D3D0] appearance-none cursor-pointer accent-[#141414]"
                />
              </div>

              {/* COMPARATIVE GRID */}
              <div className="text-xs space-y-2 font-mono">
                <div className="flex justify-between p-2 border border-[#141414]/10 bg-[#f0efed]">
                  <span className="opacity-60">Baseline Rate (+0%)</span>
                  <span className="text-emerald-800 font-bold">{sens_base.marginPct.toFixed(1)}% Margin</span>
                </div>
                <div className="flex justify-between p-2 bg-[#141414] text-[#E4E3E0] border border-[#141414]">
                  <span className="opacity-80">Spike (+{cocoaSensitivity}%)</span>
                  <span className="text-amber-400 font-bold">{sens_custom.marginPct.toFixed(1)}% Margin</span>
                </div>
                <div className="flex justify-between p-2 border border-[#141414]/10 bg-red-50 text-red-950">
                  <span className="opacity-60">Severe Hike (+50%)</span>
                  <span className="text-red-700 font-bold">{sens_hike50.marginPct.toFixed(1)}% Margin</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
