// ChocoSim Frontend TypeScript Type Declarations

export interface Factory {
  id: string;
  name: string;
  location: string;
  status: string;
}

export interface Machine {
  id: string;
  name: string;
  type: "MIXER" | "CONCHE" | "TEMPERER" | "DEPOSITOR" | "WRAPPER";
  model: string;
  powerRatingKw: number;
  status: "RUNNING" | "IDLE" | "FAULT" | "MAINTENANCE";
  tempC?: number;
  pressureBar?: number;
  rpm?: number;
  motorLoadPct?: number;
  flowRateLpm?: number;
  vibrationMmS?: number;
}

export interface Ingredient {
  id: string;
  name: string;
  sku: string;
  allergenInfo: string;
  unitCostPerKg: number;
  quantityInStockKg: number;
  reorderLevelKg: number;
}

export interface RecipeVersion {
  id: string;
  recipeId: string;
  recipeName: string;
  version: number;
  cocoaPct: number;
  cocoaButterPct: number;
  sugarPct: number;
  milkPct: number;
  lecithinPct: number;
  flavourPct: number;
  targetViscosityPaS: number;
  targetParticleSizeUm: number;
  isActive: boolean;
}

export interface ProductionBatch {
  id: string;
  recipeVersionId: string;
  recipeName: string;
  batchNumber: string;
  status: "PLANNED" | "QUEUED" | "RUNNING" | "PAUSED" | "COMPLETED" | "FAILED" | "CANCELLED";
  targetQuantityKg: number;
  actualYieldKg: number;
  processLossKg: number;
  wasteKg: number;
  startedAt?: string;
  completedAt?: string;
  createdAt: string;
}

export interface SystemEvent {
  id: string;
  machineId?: string;
  machineName?: string;
  eventType: string;
  severity: "INFO" | "WARNING" | "CRITICAL";
  description: string;
  timestamp: string;
  isResolved: boolean;
}

export interface TelemetryPoint {
  machineId: string;
  timestamp: string;
  parameter: string;
  value: number;
  unit: string;
  quality: "GOOD" | "POOR" | "FAULTY";
}

export interface SimulationRun {
  id: string;
  scenario: string;
  randomSeed: number;
  softwareVersion: string;
  createdAt: string;
  status: "RUNNING" | "COMPLETED" | "FAILED";
  parameters: {
    batchCount: number;
    targetOutputKg: number;
  };
  results?: {
    totalYieldKg: number;
    totalLossKg: number;
    totalEnergyKwh: number;
    totalCost: number;
    simulatedDurationHrs: number;
    scadaTimeline: {
      step: number;
      batchNumber: string;
      yieldKg: number;
      lossKg: number;
      energyKwh: number;
      cost: number;
      concheFailure: boolean;
    }[];
  };
}

export interface OptimisationRun {
  id: string;
  objective: "MINIMIZE_COST" | "MAXIMIZE_YIELD" | "MINIMIZE_ENERGY";
  constraints: any;
  inputParameters: any;
  status: "PENDING" | "RUNNING" | "COMPLETED";
  createdAt: string;
  results?: {
    solution: {
      cocoaPct: number;
      cocoaButterPct: number;
      sugarPct: number;
      milkPct: number;
      lecithinPct: number;
      flavourPct: number;
      conchingTempC: number;
      conchingTimeHrs: number;
    };
    expectedYieldKg: number;
    expectedCostSaving: number;
    solverIterations: number;
  };
}

export interface SpcChartValue {
  batchIndex: number;
  value: number;
  mean: number;
  ucl: number;
  lcl: number;
}

export interface SpcParameterAnalysis {
  parameter: string;
  dataPoints: number;
  mean: number;
  sd: number;
  ucl: number;
  lcl: number;
  target: number;
  usl: number;
  lsl: number;
  cp: number;
  cpk: number;
  isCapableProcess: boolean;
  driftStatus: "STABLE" | "WARNING_DRIFT" | "OUT_OF_CONTROL";
  controlChartValues: SpcChartValue[];
}

export interface EconomicBreakdown {
  batchId: string;
  batchNumber: string;
  recipeName: string;
  yieldKg: number;
  ingredientCost: number;
  energyCost: number;
  laborCost: number;
  packagingCost: number;
  maintenanceCost: number;
  wasteCost: number;
  totalProductionCost: number;
  costPerKg: number;
  marketPrice: number;
  grossMarginPct: number;
}
