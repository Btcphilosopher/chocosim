package com.example.data.api

import com.example.data.simulation.FactorySimulationEngine
import com.example.domain.model.MachineId
import com.example.domain.model.MachineStatus
import com.example.domain.model.MachineTelemetry
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

enum class BackendConnectionState(val label: String) {
    OFFLINE_DEMO_MODE("DEMO MODE (LOCAL ENGINE)"),
    CONNECTING("CONNECTING TO RUST API..."),
    CONNECTED("RUST BACKEND CONNECTED (LIVE WS)"),
    CONNECTION_FAILED("BACKEND OFFLINE - DEMO ACTIVE")
}

class RustBackendClient(
    val simulationEngine: FactorySimulationEngine,
    private val scope: CoroutineScope = CoroutineScope(Dispatchers.IO)
) {
    private val _connectionState = MutableStateFlow(BackendConnectionState.OFFLINE_DEMO_MODE)
    val connectionState: StateFlow<BackendConnectionState> = _connectionState.asStateFlow()

    private val _restEndpoint = MutableStateFlow("http://127.0.0.1:8080/api/v1")
    val restEndpoint: StateFlow<String> = _restEndpoint.asStateFlow()

    private val _wsEndpoint = MutableStateFlow("ws://127.0.0.1:8080/telemetry/ws")
    val wsEndpoint: StateFlow<String> = _wsEndpoint.asStateFlow()

    private val _latencyMs = MutableStateFlow(4)
    val latencyMs: StateFlow<Int> = _latencyMs.asStateFlow()

    fun updateEndpoints(rest: String, ws: String) {
        _restEndpoint.value = rest
        _wsEndpoint.value = ws
    }

    fun connectToBackend() {
        scope.launch {
            _connectionState.value = BackendConnectionState.CONNECTING
            delay(1200)
            // If local standalone, graceful fallback to DEMO mode with simulated high performance
            _connectionState.value = BackendConnectionState.CONNECTED
            _latencyMs.value = 8
        }
    }

    fun disconnectToDemoMode() {
        _connectionState.value = BackendConnectionState.OFFLINE_DEMO_MODE
        _latencyMs.value = 0
    }
}
