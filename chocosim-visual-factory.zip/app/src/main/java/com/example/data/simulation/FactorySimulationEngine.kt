package com.example.data.simulation

import com.example.domain.model.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.math.*
import kotlin.random.Random

class FactorySimulationEngine(
    private val scope: CoroutineScope = CoroutineScope(Dispatchers.Default)
) {
    private var simulationJob: Job? = null

    // Simulation Clock & Speed
    private var simSpeedMultiplier = 1.0
    private var simTickCount = 0L

    // Machine states
    private val _machineMap = MutableStateFlow<Map<MachineId, MachineTelemetry>>(emptyMap())
    val machineMap: StateFlow<Map<MachineId, MachineTelemetry>> = _machineMap.asStateFlow()

    // Factory Overview
    private val _overview = MutableStateFlow(FactoryOverview())
    val overview: StateFlow<FactoryOverview> = _overview.asStateFlow()

    // Quality metrics
    private val _quality = MutableStateFlow(QualityMetrics())
    val quality: StateFlow<QualityMetrics> = _quality.asStateFlow()

    // Tempering Profile
    private val _temperingProfile = MutableStateFlow(TemperingProfile())
    val temperingProfile: StateFlow<TemperingProfile> = _temperingProfile.asStateFlow()

    // Batches
    private val _batches = MutableStateFlow<List<BatchInfo>>(emptyList())
    val batches: StateFlow<List<BatchInfo>> = _batches.asStateFlow()

    private val _selectedBatchId = MutableStateFlow("BATCH #1842")
    val selectedBatchId: StateFlow<String> = _selectedBatchId.asStateFlow()

    // Alerts
    private val _alerts = MutableStateFlow<List<AlertItem>>(emptyList())
    val alerts: StateFlow<List<AlertItem>> = _alerts.asStateFlow()

    // Material Flow Particle States
    data class FlowStreamState(
        val fromMachine: MachineId,
        val toMachine: MachineId,
        val flowRateKgH: Double,
        val density: Float, // 0.0 to 1.0
        val isFlowing: Boolean,
        val materialColor: Long // Hex color representation
    )

    private val _flowStreams = MutableStateFlow<List<FlowStreamState>>(emptyList())
    val flowStreams: StateFlow<List<FlowStreamState>> = _flowStreams.asStateFlow()

    // Simulation Parameters & What-If
    private val _simulationScenario = MutableStateFlow(SimulationScenario())
    val simulationScenario: StateFlow<SimulationScenario> = _simulationScenario.asStateFlow()

    private val _whatIfResult = MutableStateFlow<WhatIfResult?>(null)
    val whatIfResult: StateFlow<WhatIfResult?> = _whatIfResult.asStateFlow()

    private val _isSimulatingFast = MutableStateFlow(false)
    val isSimulatingFast: StateFlow<Boolean> = _isSimulatingFast.asStateFlow()

    private val _simulationProgress = MutableStateFlow(0f)
    val simulationProgress: StateFlow<Float> = _simulationProgress.asStateFlow()

    init {
        initializeFactoryState()
        startSimulationLoop()
    }

    private fun initializeFactoryState() {
        val initialMachines = mutableMapOf<MachineId, MachineTelemetry>()

        val initialHistory = List(18) { idx -> (50f + sin(idx * 0.4f) * 15f + Random.nextFloat() * 5f) }

        initialMachines[MachineId.COCOA_SILO] = MachineTelemetry(
            machineId = MachineId.COCOA_SILO,
            status = MachineStatus.RUNNING,
            temperature = 22.4,
            targetTemperature = 22.0,
            rpm = 12.0,
            targetRpm = 12.0,
            loadPercent = 84.0,
            energyKw = 4.5,
            pressureBar = 1.0,
            vibrationMmS = 0.4,
            throughputKgH = 3450.0,
            progressPercent = 84.0,
            historySamples = initialHistory
        )

        initialMachines[MachineId.ROASTER] = MachineTelemetry(
            machineId = MachineId.ROASTER,
            status = MachineStatus.RUNNING,
            temperature = 138.8,
            targetTemperature = 138.5,
            rpm = 45.2,
            targetRpm = 45.0,
            loadPercent = 78.0,
            energyKw = 18.5,
            pressureBar = 2.4,
            vibrationMmS = 1.8,
            throughputKgH = 3420.0,
            progressPercent = 76.5,
            historySamples = initialHistory
        )

        initialMachines[MachineId.GRINDER] = MachineTelemetry(
            machineId = MachineId.GRINDER,
            status = MachineStatus.RUNNING,
            temperature = 65.4,
            targetTemperature = 65.0,
            rpm = 1205.0,
            targetRpm = 1200.0,
            loadPercent = 82.5,
            energyKw = 24.2,
            pressureBar = 4.8,
            vibrationMmS = 2.6,
            throughputKgH = 3410.0,
            progressPercent = 74.0,
            historySamples = initialHistory
        )

        initialMachines[MachineId.MIXER] = MachineTelemetry(
            machineId = MachineId.MIXER,
            status = MachineStatus.RUNNING,
            temperature = 45.8,
            targetTemperature = 45.0,
            rpm = 84.0,
            targetRpm = 85.0,
            loadPercent = 71.0,
            energyKw = 15.0,
            pressureBar = 1.2,
            vibrationMmS = 1.2,
            throughputKgH = 3400.0,
            progressPercent = 73.0,
            historySamples = initialHistory
        )

        initialMachines[MachineId.REFINER] = MachineTelemetry(
            machineId = MachineId.REFINER,
            status = MachineStatus.RUNNING,
            temperature = 38.4,
            targetTemperature = 38.0,
            rpm = 322.0,
            targetRpm = 320.0,
            loadPercent = 86.0,
            energyKw = 32.1,
            pressureBar = 6.2,
            vibrationMmS = 3.1,
            throughputKgH = 3380.0,
            progressPercent = 72.8,
            historySamples = initialHistory
        )

        initialMachines[MachineId.CONCHE] = MachineTelemetry(
            machineId = MachineId.CONCHE,
            status = MachineStatus.RUNNING,
            temperature = 48.2,
            targetTemperature = 47.5,
            rpm = 31.0,
            targetRpm = 31.0,
            loadPercent = 67.0,
            energyKw = 48.6,
            pressureBar = 1.8,
            vibrationMmS = 1.9,
            throughputKgH = 3390.0,
            progressPercent = 72.4,
            historySamples = initialHistory
        )

        initialMachines[MachineId.TEMPERER] = MachineTelemetry(
            machineId = MachineId.TEMPERER,
            status = MachineStatus.RUNNING,
            temperature = 31.5,
            targetTemperature = 31.5,
            rpm = 180.0,
            targetRpm = 180.0,
            loadPercent = 74.0,
            energyKw = 12.8,
            pressureBar = 3.2,
            vibrationMmS = 1.1,
            throughputKgH = 3420.0,
            progressPercent = 71.2,
            historySamples = initialHistory
        )

        initialMachines[MachineId.MOULDER] = MachineTelemetry(
            machineId = MachineId.MOULDER,
            status = MachineStatus.RUNNING,
            temperature = 30.5,
            targetTemperature = 30.5,
            rpm = 60.0,
            targetRpm = 60.0,
            loadPercent = 69.0,
            energyKw = 8.4,
            pressureBar = 1.5,
            vibrationMmS = 2.4,
            throughputKgH = 3400.0,
            progressPercent = 70.5,
            historySamples = initialHistory
        )

        initialMachines[MachineId.COOLER] = MachineTelemetry(
            machineId = MachineId.COOLER,
            status = MachineStatus.RUNNING,
            temperature = 12.2,
            targetTemperature = 12.0,
            rpm = 15.0,
            targetRpm = 15.0,
            loadPercent = 64.0,
            energyKw = 28.5,
            pressureBar = 1.0,
            vibrationMmS = 0.8,
            throughputKgH = 3380.0,
            progressPercent = 69.0,
            historySamples = initialHistory
        )

        initialMachines[MachineId.PACKAGING] = MachineTelemetry(
            machineId = MachineId.PACKAGING,
            status = MachineStatus.RUNNING,
            temperature = 21.0,
            targetTemperature = 21.0,
            rpm = 422.0,
            targetRpm = 420.0,
            loadPercent = 76.0,
            energyKw = 9.3,
            pressureBar = 2.0,
            vibrationMmS = 1.6,
            throughputKgH = 3360.0,
            progressPercent = 68.0,
            historySamples = initialHistory
        )

        _machineMap.value = initialMachines

        _batches.value = listOf(
            BatchInfo(
                batchId = "BATCH #1842",
                recipeName = "Grand Cru Single Origin 70% Dark",
                cocoaPercentage = 70,
                targetKg = 10000.0,
                currentKg = 7240.0,
                progressPercent = 72.4,
                startTime = "06:30",
                estCompletion = "14:42",
                activeStage = MachineId.CONCHE,
                targetViscosity = 2.41,
                targetParticleSize = 18.0
            ),
            BatchInfo(
                batchId = "BATCH #1843",
                recipeName = "Alpine Velvet 38% Milk",
                cocoaPercentage = 38,
                targetKg = 15000.0,
                currentKg = 4120.0,
                progressPercent = 27.5,
                startTime = "09:15",
                estCompletion = "17:30",
                activeStage = MachineId.MIXER,
                targetViscosity = 2.85,
                targetParticleSize = 19.5
            ),
            BatchInfo(
                batchId = "BATCH #1844",
                recipeName = "Ecuadorian Raw Gold 85%",
                cocoaPercentage = 85,
                targetKg = 8000.0,
                currentKg = 790.0,
                progressPercent = 9.8,
                startTime = "11:00",
                estCompletion = "19:45",
                activeStage = MachineId.ROASTER,
                targetViscosity = 2.15,
                targetParticleSize = 16.5
            )
        )

        _alerts.value = listOf(
            AlertItem(
                id = "ALT-001",
                severity = AlertSeverity.WARNING,
                machineId = MachineId.CONCHE,
                title = "Conche 02 Thermal Shift",
                message = "Vessel temperature slightly above target setpoint",
                valueStr = "48.2°C",
                thresholdStr = "Target: 47.5°C",
                timestamp = "11:24:08"
            ),
            AlertItem(
                id = "ALT-002",
                severity = AlertSeverity.INFO,
                machineId = MachineId.REFINER,
                title = "Roll Gap Calibration",
                message = "Hydraulic pressure stable at 6.2 bar (18.2 μm gap)",
                valueStr = "18.2 μm",
                thresholdStr = "< 20.0 μm",
                timestamp = "11:15:32"
            )
        )

        updateFlowStreams()
    }

    private fun updateFlowStreams() {
        val currentMachines = _machineMap.value
        val stageList = MachineId.entries

        val streams = mutableListOf<FlowStreamState>()
        for (i in 0 until stageList.size - 1) {
            val from = stageList[i]
            val to = stageList[i + 1]
            val fromTelemetry = currentMachines[from]
            val toTelemetry = currentMachines[to]

            val isFlowing = (fromTelemetry?.status?.isOperating == true) &&
                    (toTelemetry?.status?.isOperating == true)

            val flowRate = if (isFlowing) (fromTelemetry?.throughputKgH ?: 3400.0) else 0.0

            // Color gradates as material processes from raw bean to dark tempered liquid
            val color = when (from) {
                MachineId.COCOA_SILO -> 0xFF381E11 // Raw cocoa
                MachineId.ROASTER -> 0xFF5A311A    // Roasted
                MachineId.GRINDER -> 0xFF7C4223    // Liquor
                MachineId.MIXER -> 0xFF8A4926      // Mixed
                MachineId.REFINER -> 0xFF9E562E    // Refined
                MachineId.CONCHE -> 0xFFB36234     // Conched liquid
                MachineId.TEMPERER -> 0xFFC46E3A   // Tempered gloss
                MachineId.MOULDER -> 0xFFD27D48    // Deposited
                MachineId.COOLER -> 0xFF7C4223     // Solidifying
                MachineId.PACKAGING -> 0xFF381E11  // Bars
            }

            streams.add(
                FlowStreamState(
                    fromMachine = from,
                    toMachine = to,
                    flowRateKgH = flowRate,
                    density = if (isFlowing) 0.85f else 0.05f,
                    isFlowing = isFlowing,
                    materialColor = color
                )
            )
        }
        _flowStreams.value = streams
    }

    private fun startSimulationLoop() {
        simulationJob?.cancel()
        simulationJob = scope.launch {
            while (isActive) {
                val delayMs = (100L / simSpeedMultiplier).toLong().coerceAtLeast(20L)
                delay(delayMs)
                simTickCount++
                tickSimulation()
            }
        }
    }

    private fun tickSimulation() {
        val currentMachines = _machineMap.value.toMutableMap()
        val tickPhase = (simTickCount % 360) * (PI / 180.0)

        var totalPower = 0.0
        var totalThroughput = 0.0

        for (id in MachineId.entries) {
            val telemetry = currentMachines[id] ?: continue

            if (telemetry.status.isOperating) {
                // Realistic minor fluctuation around setpoints
                val noiseTemp = (sin(tickPhase * 2.0 + id.ordinal) * 0.25) + ((Random.nextDouble() - 0.5) * 0.1)
                val newTemp = (telemetry.targetTemperature + noiseTemp).coerceAtLeast(0.0)

                val noiseRpm = (cos(tickPhase * 3.0 + id.ordinal) * (telemetry.targetRpm * 0.015))
                val newRpm = (telemetry.targetRpm + noiseRpm).coerceAtLeast(0.0)

                val noiseLoad = sin(tickPhase + id.ordinal) * 2.5
                val newLoad = (telemetry.loadPercent + noiseLoad).coerceIn(10.0, 99.0)

                val powerFactor = (newLoad / 100.0) * (newRpm / (telemetry.targetRpm.coerceAtLeast(1.0)))
                val newEnergyKw = (id.nominalPowerKw * powerFactor).coerceAtLeast(0.5)

                val newThroughput = if (telemetry.status == MachineStatus.RUNNING) {
                    (3400.0 + sin(tickPhase * 1.5 + id.ordinal) * 80.0)
                } else 0.0

                val newVibration = (telemetry.vibrationMmS + (Random.nextDouble() - 0.5) * 0.08).coerceIn(0.2, 5.0)

                // Update rolling history samples
                val updatedHistory = (telemetry.historySamples + newTemp.toFloat()).takeLast(24)

                currentMachines[id] = telemetry.copy(
                    temperature = (round(newTemp * 10.0) / 10.0),
                    rpm = (round(newRpm * 10.0) / 10.0),
                    loadPercent = (round(newLoad * 10.0) / 10.0),
                    energyKw = (round(newEnergyKw * 10.0) / 10.0),
                    throughputKgH = (round(newThroughput * 10.0) / 10.0),
                    vibrationMmS = (round(newVibration * 100.0) / 100.0),
                    historySamples = updatedHistory
                )

                totalPower += newEnergyKw
                if (id == MachineId.PACKAGING) {
                    totalThroughput = newThroughput
                }
            } else {
                // Paused or idle machine
                currentMachines[id] = telemetry.copy(
                    rpm = 0.0,
                    energyKw = 0.8,
                    throughputKgH = 0.0,
                    vibrationMmS = 0.1
                )
                totalPower += 0.8
            }
        }

        _machineMap.value = currentMachines

        // Update Factory Overview smoothly
        val prevOverview = _overview.value
        val prodDeltaKg = (totalThroughput / 3600.0) * (0.1 * simSpeedMultiplier)
        val newProdTotal = prevOverview.totalProductionKg + prodDeltaKg
        val newSpecificEnergy = (totalPower / (totalThroughput.coerceAtLeast(1.0) / 1000.0))
            .coerceIn(1.2, 2.5)

        _overview.value = prevOverview.copy(
            totalProductionKg = round(newProdTotal * 10.0) / 10.0,
            throughputKgH = round(totalThroughput * 10.0) / 10.0,
            totalPowerKw = round(totalPower * 10.0) / 10.0,
            specificEnergyKwhKg = round(newSpecificEnergy * 100.0) / 100.0
        )

        // Update Quality telemetry
        val currentQuality = _quality.value
        val newVisc = (2.41 + sin(tickPhase * 0.8) * 0.03)
        val newParticle = (18.2 + cos(tickPhase * 0.5) * 0.15)
        _quality.value = currentQuality.copy(
            viscosityPaS = round(newVisc * 100.0) / 100.0,
            particleSizeUm = round(newParticle * 10.0) / 10.0,
            temperIndexPercent = (94.4 + sin(tickPhase) * 0.6).coerceIn(80.0, 99.0)
        )

        // Update Tempering state
        val currentTemperer = currentMachines[MachineId.TEMPERER]
        if (currentTemperer != null) {
            val tVal = currentTemperer.temperature
            _temperingProfile.value = _temperingProfile.value.copy(
                currentTemp = tVal,
                betaVCrystalIndex = round((94.2 + (31.5 - tVal).absoluteValue * -2.0).coerceIn(85.0, 99.5) * 10.0) / 10.0
            )
        }

        // Update batch progress
        val updatedBatches = _batches.value.map { batch ->
            if (batch.batchId == _selectedBatchId.value) {
                val newCur = (batch.currentKg + prodDeltaKg).coerceAtMost(batch.targetKg)
                val newProg = (newCur / batch.targetKg) * 100.0
                batch.copy(
                    currentKg = round(newCur * 10.0) / 10.0,
                    progressPercent = round(newProg * 10.0) / 10.0
                )
            } else batch
        }
        _batches.value = updatedBatches

        updateFlowStreams()
    }

    fun setMachineStatus(id: MachineId, status: MachineStatus) {
        val current = _machineMap.value.toMutableMap()
        val tel = current[id] ?: return
        current[id] = tel.copy(status = status)
        _machineMap.value = current
        updateFlowStreams()
    }

    fun setMachineTargetTemp(id: MachineId, targetTemp: Double) {
        val current = _machineMap.value.toMutableMap()
        val tel = current[id] ?: return
        current[id] = tel.copy(targetTemperature = targetTemp)
        _machineMap.value = current
    }

    fun setMachineTargetRpm(id: MachineId, targetRpm: Double) {
        val current = _machineMap.value.toMutableMap()
        val tel = current[id] ?: return
        current[id] = tel.copy(targetRpm = targetRpm)
        _machineMap.value = current
    }

    fun selectBatch(batchId: String) {
        _selectedBatchId.value = batchId
    }

    fun acknowledgeAlert(alertId: String) {
        _alerts.value = _alerts.value.map { alert ->
            if (alert.id == alertId) alert.copy(acknowledged = true) else alert
        }
    }

    fun dismissAlert(alertId: String) {
        _alerts.value = _alerts.value.filter { it.id != alertId }
    }

    fun injectScenario(scenarioType: ScenarioType) {
        when (scenarioType) {
            ScenarioType.TEMPERING_ANOMALY -> {
                setMachineTargetTemp(MachineId.TEMPERER, 34.2)
                _alerts.value = listOf(
                    AlertItem(
                        id = "ALT-${System.currentTimeMillis() % 10000}",
                        severity = AlertSeverity.CRITICAL,
                        machineId = MachineId.TEMPERER,
                        title = "Tempering Crystal De-stabilisation",
                        message = "Zone 4 heating exceeded 34°C - Beta-V seed melting risk!",
                        valueStr = "34.2°C",
                        thresholdStr = "Target: 31.5°C",
                        timestamp = "JUST NOW"
                    )
                ) + _alerts.value
            }
            ScenarioType.REFINER_SHEAR_SPIKE -> {
                val current = _machineMap.value.toMutableMap()
                val ref = current[MachineId.REFINER]
                if (ref != null) {
                    current[MachineId.REFINER] = ref.copy(
                        status = MachineStatus.WARNING,
                        pressureBar = 7.8,
                        vibrationMmS = 4.2
                    )
                    _machineMap.value = current
                }
                _alerts.value = listOf(
                    AlertItem(
                        id = "ALT-${System.currentTimeMillis() % 10000}",
                        severity = AlertSeverity.WARNING,
                        machineId = MachineId.REFINER,
                        title = "Refiner Roll Gap Overpressure",
                        message = "Hydraulic pressure rose to 7.8 bar on roll #4",
                        valueStr = "7.8 bar",
                        thresholdStr = "< 6.5 bar",
                        timestamp = "JUST NOW"
                    )
                ) + _alerts.value
            }
            ScenarioType.NORMAL_OPTIMAL -> {
                for (id in MachineId.entries) {
                    setMachineStatus(id, MachineStatus.RUNNING)
                    setMachineTargetTemp(id, id.defaultTargetTemp)
                    setMachineTargetRpm(id, id.defaultRpm)
                }
            }
            ScenarioType.ENERGY_SAVER -> {
                for (id in MachineId.entries) {
                    setMachineTargetRpm(id, id.defaultRpm * 0.85)
                }
            }
        }
    }

    enum class ScenarioType {
        NORMAL_OPTIMAL,
        TEMPERING_ANOMALY,
        REFINER_SHEAR_SPIKE,
        ENERGY_SAVER
    }

    fun updateSimulationScenario(params: SimulationScenario) {
        _simulationScenario.value = params
    }

    fun runWhatIfSimulation() {
        scope.launch {
            _isSimulatingFast.value = true
            _simulationProgress.value = 0f

            for (step in 1..20) {
                delay(40)
                _simulationProgress.value = step / 20f
            }

            val p = _simulationScenario.value
            val simulatedOutput = (84200.0 * p.machineSpeedMultiplier * (p.demandKgDay / 85000.0)).coerceIn(50000.0, 120000.0)
            val simulatedEnergy = (1.62 / p.machineSpeedMultiplier.coerceAtLeast(0.8) * (p.conchingDurationHours / 12.0).pow(0.2)).coerceIn(1.2, 2.2)
            val simulatedWaste = (2.7 * (1.0 / p.machineSpeedMultiplier.coerceAtLeast(0.5)) * 0.8).coerceIn(1.2, 4.5)
            val simulatedUtilisation = (82.0 * p.machineSpeedMultiplier).coerceIn(60.0, 96.0)

            val baseCost = (p.cocoaPricePerTon / 1000.0 * 0.7) + (1.62 * p.energyPricePerKwh) + 0.8
            val simCost = (p.cocoaPricePerTon / 1000.0 * 0.7) + (simulatedEnergy * p.energyPricePerKwh) + 0.72

            _whatIfResult.value = WhatIfResult(
                baselineProductionKg = 84200.0,
                simulatedProductionKg = round(simulatedOutput * 10.0) / 10.0,
                baselineEnergyKwhKg = 1.62,
                simulatedEnergyKwhKg = round(simulatedEnergy * 100.0) / 100.0,
                baselineWastePercent = 2.7,
                simulatedWastePercent = round(simulatedWaste * 10.0) / 10.0,
                baselineUtilisationPercent = 82.0,
                simulatedUtilisationPercent = round(simulatedUtilisation * 10.0) / 10.0,
                baselineCostPerKg = round(baseCost * 100.0) / 100.0,
                simulatedCostPerKg = round(simCost * 100.0) / 100.0
            )

            _isSimulatingFast.value = false
            _simulationProgress.value = 1f
        }
    }
}
