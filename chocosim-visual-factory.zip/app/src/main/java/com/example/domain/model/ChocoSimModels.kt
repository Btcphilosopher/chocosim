package com.example.domain.model

enum class MachineId(
    val code: String,
    val displayName: String,
    val stageIndex: Int,
    val defaultTargetTemp: Double,
    val defaultRpm: Double,
    val nominalPowerKw: Double
) {
    COCOA_SILO("SILO-01", "Cocoa Intake Silo", 0, 22.0, 0.0, 4.5),
    ROASTER("ROAST-01", "Continuous Drum Roaster", 1, 138.5, 45.0, 18.5),
    GRINDER("GRIND-02", "Cocoa Liquor Grinder", 2, 65.0, 1200.0, 24.2),
    MIXER("MIX-01", "Batch Ingredient Mixer", 3, 45.0, 85.0, 15.0),
    REFINER("REF-03", "5-Roll Steel Refiner", 4, 38.0, 320.0, 32.0),
    CONCHE("CONCHE-02", "Rotary Conching Vessel", 5, 48.2, 31.0, 48.6),
    TEMPERER("TEMP-01", "Multi-Zone Temperer", 6, 31.5, 180.0, 12.8),
    MOULDER("MOULD-02", "Piston Bar Depositor", 7, 30.5, 60.0, 8.4),
    COOLER("COOL-01", "Tunnel Cooling System", 8, 12.0, 15.0, 28.5),
    PACKAGING("PACK-04", "High-Speed Flow Wrapper", 9, 21.0, 420.0, 9.3)
}

enum class MachineStatus(val label: String, val isOperating: Boolean) {
    OFFLINE("OFFLINE", false),
    IDLE("IDLE", false),
    STARTING("STARTING", true),
    RUNNING("RUNNING", true),
    PAUSED("PAUSED", false),
    WARNING("WARNING", true),
    FAULT("FAULT", false),
    MAINTENANCE("MAINTENANCE", false),
    COMPLETED("COMPLETED", false)
}

enum class AlertSeverity {
    CRITICAL,
    WARNING,
    INFO
}

data class MachineTelemetry(
    val machineId: MachineId,
    val status: MachineStatus = MachineStatus.RUNNING,
    val temperature: Double,
    val targetTemperature: Double,
    val rpm: Double,
    val targetRpm: Double,
    val loadPercent: Double,
    val energyKw: Double,
    val pressureBar: Double,
    val vibrationMmS: Double,
    val throughputKgH: Double,
    val batchId: String = "BATCH #1842",
    val progressPercent: Double = 72.0,
    val runtimeHours: Double = 1420.5,
    val maintenanceHealth: Double = 94.2,
    val historySamples: List<Float> = emptyList()
)

data class BatchInfo(
    val batchId: String,
    val recipeName: String,
    val cocoaPercentage: Int,
    val targetKg: Double,
    val currentKg: Double,
    val progressPercent: Double,
    val startTime: String,
    val estCompletion: String,
    val activeStage: MachineId,
    val targetViscosity: Double = 2.40,
    val targetParticleSize: Double = 18.0
)

data class FactoryOverview(
    val factoryId: String = "FACTORY 01 - ZÜRICH",
    val systemStatus: String = "RUNNING (OPTIMAL)",
    val totalProductionKg: Double = 84200.0,
    val targetProductionKg: Double = 100000.0,
    val throughputKgH: Double = 3420.0,
    val specificEnergyKwhKg: Double = 1.62,
    val totalPowerKw: Double = 201.7,
    val dailyEnergyKwh: Double = 4280.0,
    val yieldPercent: Double = 97.8,
    val wastePercent: Double = 1.9,
    val utilisationPercent: Double = 88.0,
    val qualityScore: Double = 94.7,
    val activeBatches: Int = 3,
    val activeAlerts: Int = 1
)

data class QualityMetrics(
    val particleSizeUm: Double = 18.2,
    val particleSizeTarget: Double = 18.0,
    val viscosityPaS: Double = 2.41,
    val viscosityTarget: Double = 2.40,
    val moisturePercent: Double = 0.72,
    val moistureTarget: Double = 0.70,
    val temperIndexPercent: Double = 94.2,
    val temperIndexTarget: Double = 95.0,
    val defectRatePercent: Double = 1.1,
    val processCapabilityCpk: Double = 1.68,
    val particleDistribution: List<Float> = listOf(5f, 12f, 28f, 54f, 88f, 96f, 99f, 100f),
    val viscosityHistory: List<Float> = listOf(2.65f, 2.58f, 2.50f, 2.44f, 2.42f, 2.41f)
)

data class TemperingZoneState(
    val zoneName: String,
    val tempC: Double,
    val targetTempC: Double,
    val isCrystallising: Boolean = false
)

data class TemperingProfile(
    val currentTemp: Double = 31.5,
    val zone1Melting: Double = 49.8,       // ~50°C
    val zone2PreCooling: Double = 32.2,     // ~32°C
    val zone3Crystallisation: Double = 27.6,// ~27.5°C Beta V crystal seeding
    val zone4Reheating: Double = 31.5,      // ~31.5°C Form V working temp
    val betaVCrystalIndex: Double = 94.2,
    val temperSlopeCti: Double = 1.42,
    val status: String = "WELL TEMPERED (FORM V)"
)

data class AlertItem(
    val id: String,
    val severity: AlertSeverity,
    val machineId: MachineId,
    val title: String,
    val message: String,
    val valueStr: String,
    val thresholdStr: String,
    val timestamp: String,
    val acknowledged: Boolean = false
)

data class SimulationScenario(
    val cocoaPricePerTon: Double = 8450.0,
    val energyPricePerKwh: Double = 0.24,
    val demandKgDay: Double = 85000.0,
    val machineSpeedMultiplier: Double = 1.0,
    val batchSizeKg: Double = 10000.0,
    val temperingDurationMin: Double = 24.0,
    val conchingDurationHours: Double = 12.0
)

data class WhatIfResult(
    val baselineProductionKg: Double = 84200.0,
    val simulatedProductionKg: Double = 91400.0,
    val baselineEnergyKwhKg: Double = 1.62,
    val simulatedEnergyKwhKg: Double = 1.48,
    val baselineWastePercent: Double = 2.7,
    val simulatedWastePercent: Double = 1.9,
    val baselineUtilisationPercent: Double = 82.0,
    val simulatedUtilisationPercent: Double = 91.0,
    val baselineCostPerKg: Double = 4.12,
    val simulatedCostPerKg: Double = 3.84
)
