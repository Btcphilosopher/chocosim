package com.example.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.api.BackendConnectionState
import com.example.data.api.RustBackendClient
import com.example.data.simulation.FactorySimulationEngine
import com.example.domain.model.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class FactoryViewMode(val title: String, val badge: String) {
    FACTORY_TWIN("Factory Twin", "LIVE SCHEMATIC"),
    TELEMETRY_MATRIX("Telemetry", "10 MACHINES"),
    TEMPERING_LAB("Tempering", "BETA-V CURVE"),
    ENERGY_FLOW("Energy & Grid", "POWER FLOW"),
    QUALITY_CONTROL("Quality & SPC", "PARTICLE / RHEO"),
    SIMULATION_WHAT_IF("Simulation", "WHAT-IF OPTIMIZER"),
    BATCH_TRACKER("Batches & Gantt", "SCHEDULE"),
    SCADA_ALARMS("Alarm Monitor", "SCADA ALERTS")
}

enum class FactoryZoomLevel(val label: String, val scale: Float, val description: String) {
    LEVEL_1_ENTERPRISE("L1 Enterprise", 0.75f, "Entire Factory Overview & Mass Balance"),
    LEVEL_2_PRODUCTION_LINE("L2 Line", 1.0f, "Continuous Processing Line & Material Conveyors"),
    LEVEL_3_MACHINE("L3 Machine", 1.4f, "Machine Cutaways & Detailed Telemetry"),
    LEVEL_4_PROCESS("L4 Process", 2.0f, "Machine Internals & Thermodynamics")
}

class ChocoSimViewModel(
    val engine: FactorySimulationEngine = FactorySimulationEngine(),
    val backendClient: RustBackendClient = RustBackendClient(engine)
) : ViewModel() {

    // Active Navigation
    private val _currentViewMode = MutableStateFlow(FactoryViewMode.FACTORY_TWIN)
    val currentViewMode: StateFlow<FactoryViewMode> = _currentViewMode.asStateFlow()

    // Zoom Level
    private val _zoomLevel = MutableStateFlow(FactoryZoomLevel.LEVEL_2_PRODUCTION_LINE)
    val zoomLevel: StateFlow<FactoryZoomLevel> = _zoomLevel.asStateFlow()

    // Selected Machine for Detail Inspector
    private val _selectedMachine = MutableStateFlow<MachineTelemetry?>(null)
    val selectedMachine: StateFlow<MachineTelemetry?> = _selectedMachine.asStateFlow()

    // Pan / Zoom Canvas states
    private val _canvasPanX = MutableStateFlow(0f)
    val canvasPanX: StateFlow<Float> = _canvasPanX.asStateFlow()

    private val _canvasPanY = MutableStateFlow(0f)
    val canvasPanY: StateFlow<Float> = _canvasPanY.asStateFlow()

    private val _canvasScale = MutableStateFlow(1.0f)
    val canvasScale: StateFlow<Float> = _canvasScale.asStateFlow()

    // Connection Dialog
    private val _showConnectionDialog = MutableStateFlow(false)
    val showConnectionDialog: StateFlow<Boolean> = _showConnectionDialog.asStateFlow()

    // Scenario Preset Dialog
    private val _showScenarioDialog = MutableStateFlow(false)
    val showScenarioDialog: StateFlow<Boolean> = _showScenarioDialog.asStateFlow()

    // Flows from Engine
    val machineMap: StateFlow<Map<MachineId, MachineTelemetry>> = engine.machineMap
    val overview: StateFlow<FactoryOverview> = engine.overview
    val quality: StateFlow<QualityMetrics> = engine.quality
    val temperingProfile: StateFlow<TemperingProfile> = engine.temperingProfile
    val batches: StateFlow<List<BatchInfo>> = engine.batches
    val selectedBatchId: StateFlow<String> = engine.selectedBatchId
    val alerts: StateFlow<List<AlertItem>> = engine.alerts
    val flowStreams: StateFlow<List<FactorySimulationEngine.FlowStreamState>> = engine.flowStreams
    val simulationScenario: StateFlow<SimulationScenario> = engine.simulationScenario
    val whatIfResult: StateFlow<WhatIfResult?> = engine.whatIfResult
    val isSimulatingFast: StateFlow<Boolean> = engine.isSimulatingFast
    val simulationProgress: StateFlow<Float> = engine.simulationProgress
    val backendState: StateFlow<BackendConnectionState> = backendClient.connectionState
    val backendLatency: StateFlow<Int> = backendClient.latencyMs

    fun setViewMode(mode: FactoryViewMode) {
        _currentViewMode.value = mode
    }

    fun setZoomLevel(level: FactoryZoomLevel) {
        _zoomLevel.value = level
        _canvasScale.value = level.scale
    }

    fun selectMachine(telemetry: MachineTelemetry?) {
        _selectedMachine.value = telemetry
    }

    fun selectMachineById(id: MachineId) {
        _selectedMachine.value = machineMap.value[id]
    }

    fun updatePan(deltaX: Float, deltaY: Float) {
        _canvasPanX.value = (_canvasPanX.value + deltaX).coerceIn(-1200f, 1200f)
        _canvasPanY.value = (_canvasPanY.value + deltaY).coerceIn(-800f, 800f)
    }

    fun resetCanvasView() {
        _canvasPanX.value = 0f
        _canvasPanY.value = 0f
        _canvasScale.value = _zoomLevel.value.scale
    }

    fun toggleMachinePower(id: MachineId) {
        val cur = machineMap.value[id] ?: return
        val newStatus = if (cur.status.isOperating) MachineStatus.PAUSED else MachineStatus.RUNNING
        engine.setMachineStatus(id, newStatus)
        // Refresh selected machine if open
        if (_selectedMachine.value?.machineId == id) {
            _selectedMachine.value = machineMap.value[id]
        }
    }

    fun setMachineStatus(id: MachineId, status: MachineStatus) {
        engine.setMachineStatus(id, status)
        if (_selectedMachine.value?.machineId == id) {
            _selectedMachine.value = machineMap.value[id]
        }
    }

    fun setMachineTargetTemp(id: MachineId, temp: Double) {
        engine.setMachineTargetTemp(id, temp)
        if (_selectedMachine.value?.machineId == id) {
            _selectedMachine.value = machineMap.value[id]
        }
    }

    fun setMachineTargetRpm(id: MachineId, rpm: Double) {
        engine.setMachineTargetRpm(id, rpm)
        if (_selectedMachine.value?.machineId == id) {
            _selectedMachine.value = machineMap.value[id]
        }
    }

    fun selectBatch(batchId: String) {
        engine.selectBatch(batchId)
    }

    fun acknowledgeAlert(alertId: String) {
        engine.acknowledgeAlert(alertId)
    }

    fun dismissAlert(alertId: String) {
        engine.dismissAlert(alertId)
    }

    fun injectScenario(scenario: FactorySimulationEngine.ScenarioType) {
        engine.injectScenario(scenario)
    }

    fun updateSimulationScenario(params: SimulationScenario) {
        engine.updateSimulationScenario(params)
    }

    fun runWhatIfSimulation() {
        engine.runWhatIfSimulation()
    }

    fun openConnectionDialog(show: Boolean) {
        _showConnectionDialog.value = show
    }

    fun openScenarioDialog(show: Boolean) {
        _showScenarioDialog.value = show
    }

    fun connectToBackend() {
        backendClient.connectToBackend()
    }

    fun disconnectToDemoMode() {
        backendClient.disconnectToDemoMode()
    }
}
