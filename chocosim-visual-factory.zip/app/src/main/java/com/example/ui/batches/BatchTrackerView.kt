package com.example.ui.batches

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.model.BatchInfo
import com.example.domain.model.MachineId
import com.example.ui.theme.*

@Composable
fun BatchTrackerView(
    batches: List<BatchInfo>,
    selectedBatchId: String,
    onSelectBatch: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val activeBatch = batches.find { it.batchId == selectedBatchId } ?: batches.firstOrNull()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Graphite950)
            .padding(12.dp)
    ) {
        // Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "PRODUCTION BATCHES & GANTT TIMELINE",
                    style = MaterialTheme.typography.titleMedium,
                    color = ChocolateGold,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Recipe formulations // Mass balance tracking // Active schedule",
                    style = MaterialTheme.typography.bodySmall,
                    color = Graphite400
                )
            }

            Surface(
                shape = RoundedCornerShape(4.dp),
                color = Graphite850,
                border = androidx.compose.foundation.BorderStroke(1.dp, TechnicalBorder)
            ) {
                Text(
                    text = "${batches.size} ACTIVE BATCHES",
                    style = MaterialTheme.typography.bodySmall,
                    color = TechAmber,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Horizontal Gantt Production Timeline
        Surface(
            shape = RoundedCornerShape(6.dp),
            color = TechnicalSurfaceCard,
            border = androidx.compose.foundation.BorderStroke(1.dp, TechnicalBorder),
            modifier = Modifier
                .fillMaxWidth()
                .testTag("gantt_timeline_panel")
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "LIVE PRODUCTION TIMELINE (06:00 → 18:00)",
                        style = MaterialTheme.typography.labelSmall,
                        color = Graphite200,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "ACTIVE STAGE: ${activeBatch?.activeStage?.displayName?.uppercase() ?: "N/A"}",
                        style = MaterialTheme.typography.labelSmall,
                        color = TechAmber,
                        fontWeight = FontWeight.Bold
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Timeline stages
                val timelineStages = listOf(
                    "ROAST" to 0.15f,
                    "GRIND" to 0.28f,
                    "MIX" to 0.42f,
                    "REFINE" to 0.58f,
                    "CONCHE" to 0.74f,
                    "TEMPER" to 0.85f,
                    "MOULD" to 0.92f,
                    "PACK" to 1.0f
                )

                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    timelineStages.forEachIndexed { idx, stage ->
                        val isPastOrCurrent = (activeBatch?.progressPercent ?: 0.0) >= (stage.second * 100f - 15f)
                        val isCurrent = idx == 4 // Conche is active

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = stage.first,
                                style = MaterialTheme.typography.bodySmall,
                                color = if (isCurrent) TechAmber else if (isPastOrCurrent) Graphite200 else Graphite600,
                                modifier = Modifier.width(60.dp),
                                fontSize = 8.5.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = if (isCurrent) FontWeight.Bold else FontWeight.Normal
                            )

                            // Gantt Bar
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .height(10.dp)
                                    .clip(RoundedCornerShape(2.dp))
                                    .background(Graphite950)
                            ) {
                                val barStart = (idx * 0.11f).coerceIn(0f, 1f)
                                val barWidth = 0.22f

                                Box(
                                    modifier = Modifier
                                        .fillMaxHeight()
                                        .fillMaxWidth(fraction = (barStart + barWidth).coerceAtMost(1f))
                                        .padding(start = (barStart * 200).dp)
                                        .clip(RoundedCornerShape(2.dp))
                                        .background(
                                            if (isCurrent) TechAmber
                                            else if (isPastOrCurrent) ChocolateRoasted
                                            else Graphite750
                                        )
                                )
                            }
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Batches List
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(batches) { batch ->
                val isSelected = batch.batchId == selectedBatchId

                Surface(
                    onClick = { onSelectBatch(batch.batchId) },
                    shape = RoundedCornerShape(6.dp),
                    color = if (isSelected) TechnicalSurfaceElevated else TechnicalSurfaceCard,
                    border = androidx.compose.foundation.BorderStroke(
                        1.dp,
                        if (isSelected) TechAmber else TechnicalBorder
                    ),
                    modifier = Modifier.fillMaxWidth().testTag("batch_card_${batch.batchId.filter { it.isLetterOrDigit() }}")
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text(
                                    text = batch.batchId,
                                    style = MaterialTheme.typography.labelMedium,
                                    color = if (isSelected) TechAmber else Graphite100,
                                    fontWeight = FontWeight.Bold
                                )
                                Surface(
                                    shape = RoundedCornerShape(3.dp),
                                    color = ChocolateRoasted
                                ) {
                                    Text(
                                        text = "${batch.cocoaPercentage}% COCOA",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = ChocolateGold,
                                        fontSize = 8.sp,
                                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                                    )
                                }
                            }

                            Text(
                                text = "EST. COMPLETION: ${batch.estCompletion}",
                                style = MaterialTheme.typography.bodySmall,
                                color = Graphite400,
                                fontSize = 8.5.sp
                            )
                        }

                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = batch.recipeName,
                            style = MaterialTheme.typography.titleMedium,
                            color = Graphite50,
                            fontWeight = FontWeight.SemiBold
                        )

                        Spacer(modifier = Modifier.height(6.dp))

                        // Progress Bar
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "CURRENT: ${String.format("%,.0f", batch.currentKg)} / ${String.format("%,.0f", batch.targetKg)} kg",
                                style = MaterialTheme.typography.bodySmall,
                                color = Graphite200,
                                fontSize = 8.5.sp
                            )
                            Text(
                                text = "${String.format("%.1f", batch.progressPercent)}%",
                                style = MaterialTheme.typography.labelMedium,
                                color = TechAmber,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Spacer(modifier = Modifier.height(3.dp))
                        LinearProgressIndicator(
                            progress = { (batch.progressPercent / 100.0).toFloat() },
                            modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)),
                            color = TechAmber,
                            trackColor = Graphite800
                        )
                    }
                }
            }
        }
    }
}
