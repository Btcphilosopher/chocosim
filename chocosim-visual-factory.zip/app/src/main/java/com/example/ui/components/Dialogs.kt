package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.api.BackendConnectionState
import com.example.data.simulation.FactorySimulationEngine
import com.example.ui.theme.*

@Composable
fun BackendConnectionDialog(
    connectionState: BackendConnectionState,
    restUrl: String,
    wsUrl: String,
    onDismiss: () -> Unit,
    onConnect: () -> Unit,
    onSwitchDemo: () -> Unit
) {
    var editRest by remember { mutableStateOf(restUrl) }
    var editWs by remember { mutableStateOf(wsUrl) }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(8.dp),
            color = Graphite900,
            border = androidx.compose.foundation.BorderStroke(1.dp, TechCyan),
            modifier = Modifier
                .fillMaxWidth()
                .padding(4.dp)
                .testTag("backend_connection_dialog")
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                // Title
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "RUST BACKEND & WEBSOCKET GATEWAY",
                        style = MaterialTheme.typography.titleMedium,
                        color = TechCyan,
                        fontWeight = FontWeight.Bold
                    )
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = Graphite200)
                    }
                }

                Text(
                    text = "Configure connectivity to the Rust + Actix/Axum SCADA API and Python simulation server.",
                    style = MaterialTheme.typography.bodySmall,
                    color = Graphite400
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Current State
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(4.dp))
                        .background(Graphite950)
                        .padding(10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "CURRENT STATUS:",
                        style = MaterialTheme.typography.labelSmall,
                        color = Graphite400
                    )
                    Text(
                        text = connectionState.label,
                        style = MaterialTheme.typography.labelSmall,
                        color = if (connectionState == BackendConnectionState.CONNECTED) TechGreen else TechCyan,
                        fontWeight = FontWeight.Bold
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = editRest,
                    onValueChange = { editRest = it },
                    label = { Text("REST Endpoint", style = MaterialTheme.typography.bodySmall) },
                    modifier = Modifier.fillMaxWidth(),
                    textStyle = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = TechCyan,
                        unfocusedBorderColor = TechnicalBorder,
                        focusedTextColor = Graphite50,
                        unfocusedTextColor = Graphite100
                    )
                )

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = editWs,
                    onValueChange = { editWs = it },
                    label = { Text("WebSocket Telemetry URL", style = MaterialTheme.typography.bodySmall) },
                    modifier = Modifier.fillMaxWidth(),
                    textStyle = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = TechCyan,
                        unfocusedBorderColor = TechnicalBorder,
                        focusedTextColor = Graphite50,
                        unfocusedTextColor = Graphite100
                    )
                )

                Spacer(modifier = Modifier.height(14.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = onConnect,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = TechCyan,
                            contentColor = Graphite950
                        ),
                        shape = RoundedCornerShape(4.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("CONNECT LIVE", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                    }

                    Button(
                        onClick = onSwitchDemo,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Graphite800,
                            contentColor = TechAmber
                        ),
                        shape = RoundedCornerShape(4.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("OFFLINE DEMO", style = MaterialTheme.typography.labelSmall)
                    }
                }
            }
        }
    }
}

@Composable
fun ScenarioPresetDialog(
    onDismiss: () -> Unit,
    onInject: (FactorySimulationEngine.ScenarioType) -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(8.dp),
            color = Graphite900,
            border = androidx.compose.foundation.BorderStroke(1.dp, TechAmber),
            modifier = Modifier
                .fillMaxWidth()
                .padding(4.dp)
                .testTag("scenario_preset_dialog")
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "INJECT SIMULATION SCENARIOS",
                        style = MaterialTheme.typography.titleMedium,
                        color = TechAmber,
                        fontWeight = FontWeight.Bold
                    )
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = Graphite200)
                    }
                }

                Text(
                    text = "Select a pre-engineered industrial operating condition to evaluate real-time twin response.",
                    style = MaterialTheme.typography.bodySmall,
                    color = Graphite400
                )

                Spacer(modifier = Modifier.height(12.dp))

                ScenarioItem(
                    title = "1. Normal High-Yield Production",
                    desc = "All 10 machines balanced at 3,420 kg/h with optimal 1.62 kWh/kg efficiency.",
                    badge = "OPTIMAL",
                    color = TechGreen,
                    onClick = {
                        onInject(FactorySimulationEngine.ScenarioType.NORMAL_OPTIMAL)
                        onDismiss()
                    }
                )

                Spacer(modifier = Modifier.height(6.dp))

                ScenarioItem(
                    title = "2. Tempering Thermal Spike Anomaly",
                    desc = "Zone 4 heater surges to 34.2°C; triggers Beta-V de-crystallisation alarm.",
                    badge = "FAULT ALARM",
                    color = TechRed,
                    onClick = {
                        onInject(FactorySimulationEngine.ScenarioType.TEMPERING_ANOMALY)
                        onDismiss()
                    }
                )

                Spacer(modifier = Modifier.height(6.dp))

                ScenarioItem(
                    title = "3. 5-Roll Refiner Roll Overpressure",
                    desc = "Hydraulic cylinder pressure spike to 7.8 bar on roll #4.",
                    badge = "WARNING",
                    color = TechAmber,
                    onClick = {
                        onInject(FactorySimulationEngine.ScenarioType.REFINER_SHEAR_SPIKE)
                        onDismiss()
                    }
                )

                Spacer(modifier = Modifier.height(6.dp))

                ScenarioItem(
                    title = "4. Night Shift Eco Energy-Saver",
                    desc = "Line speed throttled by 15% to leverage off-peak power tariffs.",
                    badge = "ECO SAVER",
                    color = TechCyan,
                    onClick = {
                        onInject(FactorySimulationEngine.ScenarioType.ENERGY_SAVER)
                        onDismiss()
                    }
                )
            }
        }
    }
}

@Composable
private fun ScenarioItem(
    title: String,
    desc: String,
    badge: String,
    color: Color,
    onClick: () -> Unit
) {
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(4.dp),
        color = TechnicalSurfaceCard,
        border = androidx.compose.foundation.BorderStroke(1.dp, TechnicalBorder),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(10.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.labelMedium,
                    color = Graphite50,
                    fontWeight = FontWeight.Bold
                )
                Surface(
                    shape = RoundedCornerShape(3.dp),
                    color = color.copy(alpha = 0.2f),
                    border = androidx.compose.foundation.BorderStroke(1.dp, color)
                ) {
                    Text(
                        text = badge,
                        style = MaterialTheme.typography.labelSmall,
                        color = color,
                        fontSize = 8.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                    )
                }
            }
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = desc,
                style = MaterialTheme.typography.bodySmall,
                color = Graphite400,
                fontSize = 8.5.sp
            )
        }
    }
}
