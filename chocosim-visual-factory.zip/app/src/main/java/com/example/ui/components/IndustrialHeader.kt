package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.api.BackendConnectionState
import com.example.domain.model.AlertSeverity
import com.example.domain.model.FactoryOverview
import com.example.ui.ChocoSimViewModel
import com.example.ui.FactoryViewMode
import com.example.ui.theme.*

@Composable
fun IndustrialHeader(
    overview: FactoryOverview,
    backendState: BackendConnectionState,
    backendLatency: Int,
    activeAlertCount: Int,
    onOpenConnection: () -> Unit,
    onOpenScenarios: () -> Unit,
    onOpenAlarms: () -> Unit,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val alertPulseAlpha by infiniteTransition.animateFloat(
        initialValue = 0.4f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(800, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "alertAlpha"
    )

    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(Graphite900)
            .border(width = 1.dp, color = TechnicalBorder)
            .padding(horizontal = 14.dp, vertical = 8.dp)
    ) {
        // Top Row: Brand, Node, Connection State, Action Controls
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Brand and Location
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Technical Brand Badge
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(
                            Brush.horizontalGradient(
                                listOf(ChocolateRoasted, ChocolateLiquor)
                            )
                        )
                        .border(1.dp, TechAmber.copy(alpha = 0.6f), RoundedCornerShape(4.dp))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = "CHOCOSIM",
                        style = MaterialTheme.typography.labelLarge,
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.2.sp
                    )
                }

                Column {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(
                            text = "PLANT 01 // ZÜRICH",
                            style = MaterialTheme.typography.labelMedium,
                            color = Graphite100,
                            fontWeight = FontWeight.SemiBold
                        )
                        Box(
                            modifier = Modifier
                                .size(6.dp)
                                .clip(CircleShape)
                                .background(TechGreen)
                        )
                        Text(
                            text = overview.systemStatus,
                            style = MaterialTheme.typography.bodySmall,
                            color = TechGreen
                        )
                    }
                    Text(
                        text = "DIGITAL TWIN TW-2026.08",
                        style = MaterialTheme.typography.bodySmall,
                        color = Graphite400
                    )
                }
            }

            // Status & Quick Actions
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Connection Pill (Clickable to open dialog)
                val connColor = when (backendState) {
                    BackendConnectionState.CONNECTED -> TechGreen
                    BackendConnectionState.CONNECTING -> TechAmber
                    BackendConnectionState.OFFLINE_DEMO_MODE -> TechCyan
                    BackendConnectionState.CONNECTION_FAILED -> TechRed
                }

                Surface(
                    onClick = onOpenConnection,
                    shape = RoundedCornerShape(4.dp),
                    color = Graphite800,
                    border = androidx.compose.foundation.BorderStroke(1.dp, connColor.copy(alpha = 0.5f)),
                    modifier = Modifier.testTag("backend_connection_pill")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(7.dp)
                                .clip(CircleShape)
                                .background(connColor)
                        )
                        Text(
                            text = if (backendState == BackendConnectionState.CONNECTED) "RUST API (${backendLatency}ms)" else backendState.label,
                            style = MaterialTheme.typography.bodySmall,
                            color = connColor,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }

                // Scenario Injection Button
                Button(
                    onClick = onOpenScenarios,
                    shape = RoundedCornerShape(4.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Graphite750,
                        contentColor = Graphite100
                    ),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                    modifier = Modifier
                        .height(28.dp)
                        .testTag("scenarios_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Science,
                        contentDescription = "Scenarios",
                        modifier = Modifier.size(14.dp),
                        tint = TechAmber
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "SCENARIOS",
                        style = MaterialTheme.typography.labelSmall
                    )
                }

                // Alarms Indicator (Pulsing if active)
                if (activeAlertCount > 0) {
                    Surface(
                        onClick = onOpenAlarms,
                        shape = RoundedCornerShape(4.dp),
                        color = TechRed.copy(alpha = 0.2f * alertPulseAlpha),
                        border = androidx.compose.foundation.BorderStroke(
                            1.dp,
                            TechRed.copy(alpha = alertPulseAlpha)
                        ),
                        modifier = Modifier.testTag("alarm_indicator_pill")
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Warning,
                                contentDescription = "Active Alarms",
                                tint = TechRed,
                                modifier = Modifier.size(14.dp)
                            )
                            Text(
                                text = "$activeAlertCount ALARM${if (activeAlertCount > 1) "S" else ""}",
                                style = MaterialTheme.typography.labelSmall,
                                color = TechRed,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        // Bottom Telemetry Ribbon: 6 Core Performance Metrics
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(4.dp))
                .background(Graphite950)
                .border(1.dp, TechnicalBorder.copy(alpha = 0.6f), RoundedCornerShape(4.dp))
                .padding(horizontal = 10.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            KpiMetricItem(
                label = "PRODUCTION",
                value = "${String.format("%,.0f", overview.totalProductionKg)} kg",
                subtext = "Target: 100t",
                color = TechAmber
            )
            DividerVertical()
            KpiMetricItem(
                label = "THROUGHPUT",
                value = "${String.format("%,.0f", overview.throughputKgH)} kg/h",
                subtext = "Nominal: 3,400",
                color = Graphite50
            )
            DividerVertical()
            KpiMetricItem(
                label = "SPEC. ENERGY",
                value = "${String.format("%.2f", overview.specificEnergyKwhKg)} kWh/kg",
                subtext = "Total: ${String.format("%.0f", overview.totalPowerKw)} kW",
                color = TechCyan
            )
            DividerVertical()
            KpiMetricItem(
                label = "YIELD",
                value = "${overview.yieldPercent}%",
                subtext = "Waste: ${overview.wastePercent}%",
                color = TechGreen
            )
            DividerVertical()
            KpiMetricItem(
                label = "UTILISATION",
                value = "${overview.utilisationPercent.toInt()}%",
                subtext = "Line OEE: 86.4%",
                color = TechBlue
            )
            DividerVertical()
            KpiMetricItem(
                label = "QUALITY SCORE",
                value = "${overview.qualityScore}",
                subtext = "Grade A+",
                color = ChocolateGold
            )
        }
    }
}

@Composable
private fun KpiMetricItem(
    label: String,
    value: String,
    subtext: String,
    color: Color
) {
    Column(
        horizontalAlignment = Alignment.Start
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = Graphite400,
            fontSize = 8.5.sp
        )
        Text(
            text = value,
            style = MaterialTheme.typography.labelLarge,
            color = color,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace,
            fontSize = 12.sp
        )
        Text(
            text = subtext,
            style = MaterialTheme.typography.bodySmall,
            color = Graphite400,
            fontSize = 8.5.sp
        )
    }
}

@Composable
private fun DividerVertical() {
    Box(
        modifier = Modifier
            .width(1.dp)
            .height(26.dp)
            .background(TechnicalBorder.copy(alpha = 0.5f))
    )
}
