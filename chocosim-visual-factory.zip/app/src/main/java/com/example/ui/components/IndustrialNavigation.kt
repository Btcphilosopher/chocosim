package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.FactoryViewMode
import com.example.ui.theme.*

@Composable
fun IndustrialNavigation(
    currentMode: FactoryViewMode,
    onSelectMode: (FactoryViewMode) -> Unit,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()

    Row(
        modifier = modifier
            .fillMaxWidth()
            .background(Graphite950)
            .border(width = 1.dp, color = TechnicalBorder)
            .horizontalScroll(scrollState)
            .padding(horizontal = 8.dp, vertical = 6.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        FactoryViewMode.entries.forEach { mode ->
            val isSelected = mode == currentMode
            val icon = getModeIcon(mode)

            val backgroundColor = if (isSelected) Graphite750 else Graphite900
            val borderColor = if (isSelected) TechAmber else TechnicalBorder.copy(alpha = 0.6f)
            val textColor = if (isSelected) TechAmber else Graphite200

            Surface(
                onClick = { onSelectMode(mode) },
                shape = RoundedCornerShape(4.dp),
                color = backgroundColor,
                border = androidx.compose.foundation.BorderStroke(1.dp, borderColor),
                modifier = Modifier.testTag("nav_tab_${mode.name.lowercase()}")
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = mode.title,
                        modifier = Modifier.size(14.dp),
                        tint = if (isSelected) TechAmber else Graphite400
                    )

                    Text(
                        text = mode.title.uppercase(),
                        style = MaterialTheme.typography.labelSmall,
                        color = textColor,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                        letterSpacing = 0.5.sp
                    )

                    // Small Technical Badge
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(2.dp))
                            .background(if (isSelected) TechAmber.copy(alpha = 0.2f) else Graphite800)
                            .padding(horizontal = 4.dp, vertical = 1.dp)
                    ) {
                        Text(
                            text = mode.badge,
                            style = MaterialTheme.typography.bodySmall,
                            fontSize = 8.sp,
                            color = if (isSelected) TechAmber else Graphite400
                        )
                    }
                }
            }
        }
    }
}

private fun getModeIcon(mode: FactoryViewMode): ImageVector {
    return when (mode) {
        FactoryViewMode.FACTORY_TWIN -> Icons.Default.PrecisionManufacturing
        FactoryViewMode.TELEMETRY_MATRIX -> Icons.Default.Speed
        FactoryViewMode.TEMPERING_LAB -> Icons.Default.Thermostat
        FactoryViewMode.ENERGY_FLOW -> Icons.Default.ElectricBolt
        FactoryViewMode.QUALITY_CONTROL -> Icons.Default.Biotech
        FactoryViewMode.SIMULATION_WHAT_IF -> Icons.Default.QueryStats
        FactoryViewMode.BATCH_TRACKER -> Icons.Default.Inventory2
        FactoryViewMode.SCADA_ALARMS -> Icons.Default.NotificationsActive
    }
}
