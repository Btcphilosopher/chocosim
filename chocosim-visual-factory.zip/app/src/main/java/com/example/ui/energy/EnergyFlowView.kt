package com.example.ui.energy

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.*
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.model.FactoryOverview
import com.example.domain.model.MachineId
import com.example.domain.model.MachineTelemetry
import com.example.ui.theme.*
import kotlin.math.sin

@OptIn(ExperimentalTextApi::class)
@Composable
fun EnergyFlowView(
    overview: FactoryOverview,
    machines: Map<MachineId, MachineTelemetry>,
    modifier: Modifier = Modifier
) {
    val textMeasurer = rememberTextMeasurer()

    val infiniteTransition = rememberInfiniteTransition(label = "energyMotion")
    val pulseTick by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 100f,
        animationSpec = infiniteRepeatable(
            animation = tween(4000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "pulseTick"
    )

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Graphite950)
            .padding(12.dp)
            .verticalScroll(rememberScrollState())
    ) {
        // Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "FACTORY ELECTRICAL ENERGY FLOW & SANKEY",
                    style = MaterialTheme.typography.titleMedium,
                    color = TechCyan,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Grid Substation 24kV // 400V Distribution Bus // Active Load kW",
                    style = MaterialTheme.typography.bodySmall,
                    color = Graphite400
                )
            }

            Surface(
                shape = RoundedCornerShape(4.dp),
                color = TechCyan.copy(alpha = 0.15f),
                border = androidx.compose.foundation.BorderStroke(1.dp, TechCyan)
            ) {
                Text(
                    text = "${overview.dailyEnergyKwh.toInt()} kWh DAILY",
                    style = MaterialTheme.typography.labelSmall,
                    color = TechCyan,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Dynamic Energy Flow Diagram Canvas (Grid -> Factory -> Machines)
        Surface(
            shape = RoundedCornerShape(6.dp),
            color = TechnicalSurfaceCard,
            border = androidx.compose.foundation.BorderStroke(1.dp, TechnicalBorder),
            modifier = Modifier
                .fillMaxWidth()
                .testTag("energy_flow_canvas_panel")
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Text(
                    text = "LIVE POWER DISTRIBUTION TREE (GRID -> BUS -> PROCESSORS)",
                    style = MaterialTheme.typography.labelSmall,
                    color = Graphite200,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(8.dp))

                Canvas(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(220.dp)
                        .clip(RoundedCornerShape(4.dp))
                        .background(Graphite950)
                        .border(1.dp, TechnicalBorder, RoundedCornerShape(4.dp))
                ) {
                    val w = size.width
                    val h = size.height

                    // 1. Grid Node on Left
                    val gridX = 50f
                    val gridY = h / 2f
                    drawRoundRect(
                        color = Graphite850,
                        topLeft = Offset(gridX - 40f, gridY - 30f),
                        size = Size(80f, 60f),
                        cornerRadius = CornerRadius(4f, 4f)
                    )
                    drawRoundRect(
                        color = TechCyan,
                        topLeft = Offset(gridX - 40f, gridY - 30f),
                        size = Size(80f, 60f),
                        cornerRadius = CornerRadius(4f, 4f),
                        style = Stroke(1.5f)
                    )

                    val gridLayout = textMeasurer.measure(
                        text = AnnotatedString("GRID 24kV\n${overview.totalPowerKw.toInt()} kW"),
                        style = TextStyle(color = TechCyan, fontSize = 9.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                    )
                    drawText(gridLayout, topLeft = Offset(gridX - 32f, gridY - 18f))

                    // 2. Central Transformer Bus
                    val busX = 170f
                    val busY = h / 2f
                    drawLine(
                        color = TechnicalBorder,
                        start = Offset(gridX + 40f, gridY),
                        end = Offset(busX - 25f, busY),
                        strokeWidth = 4f
                    )
                    // Animated Energy Packet
                    val epX = (gridX + 40f) + ((pulseTick * 0.01f) % 1f) * ((busX - 25f) - (gridX + 40f))
                    drawCircle(color = TechCyan, radius = 3.5f, center = Offset(epX, gridY))

                    drawRoundRect(
                        color = Graphite800,
                        topLeft = Offset(busX - 25f, 20f),
                        size = Size(50f, h - 40f),
                        cornerRadius = CornerRadius(4f, 4f)
                    )
                    drawRoundRect(
                        color = TechAmber,
                        topLeft = Offset(busX - 25f, 20f),
                        size = Size(50f, h - 40f),
                        cornerRadius = CornerRadius(4f, 4f),
                        style = Stroke(1.5f)
                    )

                    val busLayout = textMeasurer.measure(
                        text = AnnotatedString("MAIN\nBUS\n400V"),
                        style = TextStyle(color = TechAmber, fontSize = 9.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                    )
                    drawText(busLayout, topLeft = Offset(busX - 16f, busY - 20f))

                    // 3. Machine Branch Lines on Right
                    val branchMachineList = listOf(
                        MachineId.ROASTER,
                        MachineId.GRINDER,
                        MachineId.REFINER,
                        MachineId.CONCHE,
                        MachineId.COOLER,
                        MachineId.PACKAGING
                    )

                    val rightX = w - 100f
                    val spacingY = (h - 40f) / branchMachineList.size

                    branchMachineList.forEachIndexed { index, mId ->
                        val my = 28f + index * spacingY + spacingY / 2
                        val tel = machines[mId]
                        val kw = tel?.energyKw ?: 10.0

                        // Connecting Feeder Line
                        drawLine(
                            color = TechnicalBorder,
                            start = Offset(busX + 25f, busY),
                            end = Offset(busX + 50f, my),
                            strokeWidth = 2f
                        )
                        drawLine(
                            color = TechnicalBorder,
                            start = Offset(busX + 50f, my),
                            end = Offset(rightX - 35f, my),
                            strokeWidth = 2f
                        )

                        // Branch Pulse Particle
                        val branchProg = ((pulseTick * 0.012f + index * 0.15f) % 1f)
                        val bx = (busX + 50f) + branchProg * ((rightX - 35f) - (busX + 50f))
                        drawCircle(color = TechCyan, radius = 2.5f, center = Offset(bx, my))

                        // Machine Power Box
                        drawRoundRect(
                            color = Graphite850,
                            topLeft = Offset(rightX - 35f, my - 12f),
                            size = Size(110f, 24f),
                            cornerRadius = CornerRadius(3f, 3f)
                        )
                        drawRoundRect(
                            color = TechnicalBorder,
                            topLeft = Offset(rightX - 35f, my - 12f),
                            size = Size(110f, 24f),
                            cornerRadius = CornerRadius(3f, 3f),
                            style = Stroke(1f)
                        )

                        val mLayout = textMeasurer.measure(
                            text = AnnotatedString("${mId.displayName.take(8)}.. ${String.format("%.1f", kw)}kW"),
                            style = TextStyle(color = Graphite100, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
                        )
                        drawText(mLayout, topLeft = Offset(rightX - 30f, my - 6f))
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Machine Energy Breakdown Matrix
        Surface(
            shape = RoundedCornerShape(6.dp),
            color = TechnicalSurfaceCard,
            border = androidx.compose.foundation.BorderStroke(1.dp, TechnicalBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Text(
                    text = "MACHINE ACTIVE LOAD BREAKDOWN (kW)",
                    style = MaterialTheme.typography.labelSmall,
                    color = Graphite400
                )
                Spacer(modifier = Modifier.height(8.dp))

                MachineId.entries.forEach { id ->
                    val tel = machines[id]
                    val kw = tel?.energyKw ?: 0.0
                    val maxKw = 60.0

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 3.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = id.displayName,
                            style = MaterialTheme.typography.bodySmall,
                            color = Graphite200,
                            modifier = Modifier.width(130.dp),
                            fontSize = 9.sp
                        )

                        LinearProgressIndicator(
                            progress = { (kw / maxKw).toFloat().coerceIn(0f, 1f) },
                            modifier = Modifier
                                .weight(1f)
                                .height(6.dp)
                                .clip(RoundedCornerShape(3.dp)),
                            color = TechCyan,
                            trackColor = Graphite800
                        )

                        Text(
                            text = "${String.format("%.1f", kw)} kW",
                            style = MaterialTheme.typography.bodySmall,
                            color = TechCyan,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace,
                            modifier = Modifier.width(55.dp),
                            fontSize = 9.5.sp
                        )
                    }
                }
            }
        }
    }
}
