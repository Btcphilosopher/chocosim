package com.example.ui.factory

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.*
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.*
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.simulation.FactorySimulationEngine
import com.example.domain.model.MachineId
import com.example.domain.model.MachineStatus
import com.example.domain.model.MachineTelemetry
import com.example.ui.FactoryZoomLevel
import com.example.ui.theme.*
import kotlin.math.*

@OptIn(ExperimentalTextApi::class)
@Composable
fun FactoryMapCanvas(
    machines: Map<MachineId, MachineTelemetry>,
    flowStreams: List<FactorySimulationEngine.FlowStreamState>,
    selectedMachine: MachineTelemetry?,
    zoomLevel: FactoryZoomLevel,
    panX: Float,
    panY: Float,
    onPanChange: (Float, Float) -> Unit,
    onZoomChange: (FactoryZoomLevel) -> Unit,
    onSelectMachine: (MachineTelemetry) -> Unit,
    onResetView: () -> Unit,
    modifier: Modifier = Modifier
) {
    val textMeasurer = rememberTextMeasurer()

    // Continuous smooth animation clock for machine components and flow particles
    val infiniteTransition = rememberInfiniteTransition(label = "machineMotion")
    val animationTick by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1000f,
        animationSpec = infiniteRepeatable(
            animation = tween(20000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "animTick"
    )

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Graphite950)
            .pointerInput(Unit) {
                detectDragGestures { change, dragAmount ->
                    change.consume()
                    onPanChange(dragAmount.x, dragAmount.y)
                }
            }
            .pointerInput(Unit) {
                detectTapGestures { tapOffset ->
                    // Convert screen tap coordinate to world space
                    // We check if tap hit any machine bounding box
                }
            }
    ) {
        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .testTag("factory_canvas")
                .pointerInput(machines, zoomLevel, panX, panY) {
                    detectTapGestures { tapOffset ->
                        val centerX = size.width / 2f + panX
                        val centerY = size.height / 2f + panY
                        val scale = zoomLevel.scale

                        // Compute which machine was clicked
                        val machinePositions = getMachineLayoutPositions()
                        for ((id, pos) in machinePositions) {
                            val screenX = centerX + (pos.x * scale)
                            val screenY = centerY + (pos.y * scale)
                            val boxW = 160f * scale
                            val boxH = 130f * scale

                            if (tapOffset.x in (screenX - boxW / 2)..(screenX + boxW / 2) &&
                                tapOffset.y in (screenY - boxH / 2)..(screenY + boxH / 2)
                            ) {
                                val tel = machines[id]
                                if (tel != null) {
                                    onSelectMachine(tel)
                                    break
                                }
                            }
                        }
                    }
                }
        ) {
            val canvasW = size.width
            val canvasH = size.height
            val centerX = canvasW / 2f + panX
            val centerY = canvasH / 2f + panY
            val scale = zoomLevel.scale

            // 1. Draw Technical Background Grid with mm coordinates
            drawTechnicalGrid(canvasW, canvasH, panX, panY, scale)

            // 2. Draw Factory Structural Foundation Lines & Facility Perimeter
            drawFactoryFlooring(centerX, centerY, scale)

            // 3. Draw Inter-Machine Connecting Pipes, Conveyors & Animated Material Particles
            val machinePositions = getMachineLayoutPositions()
            drawConnectingPipesAndFlow(
                centerX = centerX,
                centerY = centerY,
                scale = scale,
                positions = machinePositions,
                flowStreams = flowStreams,
                animationTick = animationTick
            )

            // 4. Draw Each Machine with Physical Visual Representation & Animated Mechanisms
            for ((id, pos) in machinePositions) {
                val tel = machines[id] ?: continue
                val machineCenterX = centerX + (pos.x * scale)
                val machineCenterY = centerY + (pos.y * scale)
                val isSelected = selectedMachine?.machineId == id

                drawMachineNode(
                    id = id,
                    telemetry = tel,
                    centerX = machineCenterX,
                    centerY = machineCenterY,
                    scale = scale,
                    isSelected = isSelected,
                    animationTick = animationTick,
                    textMeasurer = textMeasurer
                )
            }
        }

        // Overlay: Factory Zoom Controls & Control Room HUD
        FactoryMapOverlayControls(
            currentZoom = zoomLevel,
            onZoomChange = onZoomChange,
            onResetView = onResetView,
            modifier = Modifier
                .align(Alignment.BottomStart)
                .padding(12.dp)
        )

        // Overlay: Selected Machine Quick Telemetry Badge
        if (selectedMachine != null) {
            SelectedMachineQuickBadge(
                telemetry = selectedMachine,
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(12.dp)
            )
        }
    }
}

// 10-Machine 2D Spatial Layout (arranged in logical dual-row industrial production flow)
// Row 1: COCOA -> ROASTER -> GRINDER -> MIXER -> REFINER
// Row 2: PACKAGING <- COOLER <- MOULDER <- TEMPERER <- CONCHE
private fun getMachineLayoutPositions(): Map<MachineId, Offset> {
    val spacingX = 220f
    val row1Y = -120f
    val row2Y = 120f

    return mapOf(
        MachineId.COCOA_SILO to Offset(-2f * spacingX, row1Y),
        MachineId.ROASTER to Offset(-1f * spacingX, row1Y),
        MachineId.GRINDER to Offset(0f * spacingX, row1Y),
        MachineId.MIXER to Offset(1f * spacingX, row1Y),
        MachineId.REFINER to Offset(2f * spacingX, row1Y),

        MachineId.CONCHE to Offset(2f * spacingX, row2Y),
        MachineId.TEMPERER to Offset(1f * spacingX, row2Y),
        MachineId.MOULDER to Offset(0f * spacingX, row2Y),
        MachineId.COOLER to Offset(-1f * spacingX, row2Y),
        MachineId.PACKAGING to Offset(-2f * spacingX, row2Y)
    )
}

private fun DrawScope.drawTechnicalGrid(
    w: Float,
    h: Float,
    panX: Float,
    panY: Float,
    scale: Float
) {
    val gridSize = 40f * scale
    val offsetX = (panX % gridSize + gridSize) % gridSize
    val offsetY = (panY % gridSize + gridSize) % gridSize

    // Minor Grid Lines
    var x = offsetX
    while (x < w) {
        drawLine(
            color = TechnicalGridLine.copy(alpha = 0.35f),
            start = Offset(x, 0f),
            end = Offset(x, h),
            strokeWidth = 1f
        )
        x += gridSize
    }

    var y = offsetY
    while (y < h) {
        drawLine(
            color = TechnicalGridLine.copy(alpha = 0.35f),
            start = Offset(0f, y),
            end = Offset(w, y),
            strokeWidth = 1f
        )
        y += gridSize
    }

    // Major Grid Lines (every 5 grid cells)
    val majorGridSize = gridSize * 5f
    val majorOffsetX = (panX % majorGridSize + majorGridSize) % majorGridSize
    val majorOffsetY = (panY % majorGridSize + majorGridSize) % majorGridSize

    var mx = majorOffsetX
    while (mx < w) {
        drawLine(
            color = TechnicalBorder.copy(alpha = 0.4f),
            start = Offset(mx, 0f),
            end = Offset(mx, h),
            strokeWidth = 1.2f
        )
        mx += majorGridSize
    }

    var my = majorOffsetY
    while (my < h) {
        drawLine(
            color = TechnicalBorder.copy(alpha = 0.4f),
            start = Offset(0f, my),
            end = Offset(w, my),
            strokeWidth = 1.2f
        )
        my += majorGridSize
    }
}

private fun DrawScope.drawFactoryFlooring(
    centerX: Float,
    centerY: Float,
    scale: Float
) {
    val floorW = 1100f * scale
    val floorH = 440f * scale

    // Factory Hall Floor Boundary
    drawRoundRect(
        color = Graphite900.copy(alpha = 0.85f),
        topLeft = Offset(centerX - floorW / 2, centerY - floorH / 2),
        size = Size(floorW, floorH),
        cornerRadius = CornerRadius(12f * scale, 12f * scale),
        style = Fill
    )

    drawRoundRect(
        color = TechnicalBorder.copy(alpha = 0.7f),
        topLeft = Offset(centerX - floorW / 2, centerY - floorH / 2),
        size = Size(floorW, floorH),
        cornerRadius = CornerRadius(12f * scale, 12f * scale),
        style = Stroke(width = 1.5f * scale)
    )

    // Safety Walkway Marking lines
    drawRoundRect(
        color = TechAmber.copy(alpha = 0.15f),
        topLeft = Offset(centerX - floorW / 2 + 15f * scale, centerY - floorH / 2 + 15f * scale),
        size = Size(floorW - 30f * scale, floorH - 30f * scale),
        cornerRadius = CornerRadius(8f * scale, 8f * scale),
        style = Stroke(
            width = 1f * scale,
            pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f * scale, 10f * scale), 0f)
        )
    )
}

private fun DrawScope.drawConnectingPipesAndFlow(
    centerX: Float,
    centerY: Float,
    scale: Float,
    positions: Map<MachineId, Offset>,
    flowStreams: List<FactorySimulationEngine.FlowStreamState>,
    animationTick: Float
) {
    val stageList = MachineId.entries

    for (i in 0 until stageList.size - 1) {
        val fromId = stageList[i]
        val toId = stageList[i + 1]
        val fromPos = positions[fromId] ?: continue
        val toPos = positions[toId] ?: continue

        val stream = flowStreams.find { it.fromMachine == fromId && it.toMachine == toId }
        val isFlowing = stream?.isFlowing == true
        val streamColor = Color(stream?.materialColor ?: 0xFF8A5233)

        val p1 = Offset(centerX + fromPos.x * scale, centerY + fromPos.y * scale)
        val p2 = Offset(centerX + toPos.x * scale, centerY + toPos.y * scale)

        // Draw Pipe / Conveyor Base Track
        if (fromId == MachineId.REFINER && toId == MachineId.CONCHE) {
            // U-Turn Connecting Pipe between Row 1 and Row 2
            val midX = p1.x + 40f * scale
            val path = Path().apply {
                moveTo(p1.x, p1.y)
                cubicTo(midX, p1.y, midX, p2.y, p2.x, p2.y)
            }
            drawPath(
                path = path,
                color = TechnicalBorder,
                style = Stroke(width = 8f * scale, cap = StrokeCap.Round)
            )
            drawPath(
                path = path,
                color = Graphite950,
                style = Stroke(width = 4f * scale, cap = StrokeCap.Round)
            )

            // Flow Particles on U-turn
            if (isFlowing) {
                val particleCount = 8
                for (p in 0 until particleCount) {
                    val t = ((animationTick * 0.08f + (p.toFloat() / particleCount)) % 1f)
                    val px = (1 - t).pow(3) * p1.x + 3 * (1 - t).pow(2) * t * midX + 3 * (1 - t) * t.pow(2) * midX + t.pow(3) * p2.x
                    val py = (1 - t).pow(3) * p1.y + 3 * (1 - t).pow(2) * t * p1.y + 3 * (1 - t) * t.pow(2) * p2.y + t.pow(3) * p2.y

                    drawCircle(
                        color = streamColor,
                        radius = 3.5f * scale,
                        center = Offset(px, py)
                    )
                }
            }
        } else {
            // Straight Pipe / Conveyor
            drawLine(
                color = TechnicalBorder,
                start = p1,
                end = p2,
                strokeWidth = 8f * scale,
                cap = StrokeCap.Round
            )
            drawLine(
                color = Graphite950,
                start = p1,
                end = p2,
                strokeWidth = 4f * scale,
                cap = StrokeCap.Round
            )

            // Material Particles traveling between machines
            if (isFlowing) {
                val particleCount = 6
                val dx = p2.x - p1.x
                val dy = p2.y - p1.y
                val dist = sqrt(dx * dx + dy * dy)

                for (p in 0 until particleCount) {
                    val progress = ((animationTick * 0.12f + (p.toFloat() / particleCount)) % 1f)
                    val px = p1.x + dx * progress
                    val py = p1.y + dy * progress

                    // Pulse particle size slightly
                    val rad = 3.5f * scale

                    drawCircle(
                        color = streamColor,
                        radius = rad,
                        center = Offset(px, py)
                    )

                    // Small flow trail
                    drawLine(
                        color = streamColor.copy(alpha = 0.4f),
                        start = Offset(px, py),
                        end = Offset(px - (dx / dist) * 8f * scale, py - (dy / dist) * 8f * scale),
                        strokeWidth = 2f * scale,
                        cap = StrokeCap.Round
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalTextApi::class)
private fun DrawScope.drawMachineNode(
    id: MachineId,
    telemetry: MachineTelemetry,
    centerX: Float,
    centerY: Float,
    scale: Float,
    isSelected: Boolean,
    animationTick: Float,
    textMeasurer: TextMeasurer
) {
    val boxW = 170f * scale
    val boxH = 120f * scale
    val left = centerX - boxW / 2
    val top = centerY - boxH / 2

    val statusColor = when (telemetry.status) {
        MachineStatus.RUNNING -> TechGreen
        MachineStatus.WARNING -> TechAmber
        MachineStatus.FAULT -> TechRed
        MachineStatus.MAINTENANCE -> TechPurple
        MachineStatus.IDLE, MachineStatus.PAUSED -> Graphite400
        MachineStatus.STARTING -> TechCyan
        MachineStatus.OFFLINE, MachineStatus.COMPLETED -> Graphite600
    }

    // Machine Outer Chassis Box
    drawRoundRect(
        color = if (isSelected) TechnicalSurfaceElevated else TechnicalSurfaceCard,
        topLeft = Offset(left, top),
        size = Size(boxW, boxH),
        cornerRadius = CornerRadius(6f * scale, 6f * scale),
        style = Fill
    )

    // Border Glow / Highlight
    val borderWidth = if (isSelected) 2f * scale else 1f * scale
    val borderColor = if (isSelected) TechAmber else TechnicalBorder
    drawRoundRect(
        color = borderColor,
        topLeft = Offset(left, top),
        size = Size(boxW, boxH),
        cornerRadius = CornerRadius(6f * scale, 6f * scale),
        style = Stroke(width = borderWidth)
    )

    // Machine Header Bar
    val headerH = 24f * scale
    drawRoundRect(
        color = Graphite900,
        topLeft = Offset(left, top),
        size = Size(boxW, headerH),
        cornerRadius = CornerRadius(6f * scale, 6f * scale),
        style = Fill
    )
    drawLine(
        color = TechnicalBorder.copy(alpha = 0.6f),
        start = Offset(left, top + headerH),
        end = Offset(left + boxW, top + headerH),
        strokeWidth = 1f * scale
    )

    // Status Indicator LED Pill
    val ledRadius = 3.5f * scale
    drawCircle(
        color = statusColor,
        radius = ledRadius,
        center = Offset(left + 12f * scale, top + headerH / 2)
    )

    // Text: Machine Name & Code
    val headerLayout = textMeasurer.measure(
        text = AnnotatedString("${id.displayName.uppercase()} // ${id.code}"),
        style = TextStyle(
            color = if (isSelected) TechAmber else Graphite100,
            fontSize = (8.5f * scale).sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace
        )
    )
    drawText(
        textLayoutResult = headerLayout,
        topLeft = Offset(left + 22f * scale, top + (headerH - headerLayout.size.height) / 2)
    )

    // Draw Machine Mechanical Visual Internal Graphics
    val internalTop = top + headerH + 6f * scale
    val internalH = 50f * scale
    val internalW = boxW - 16f * scale
    val internalLeft = left + 8f * scale

    drawMachineMechanicalIllustration(
        id = id,
        telemetry = telemetry,
        left = internalLeft,
        top = internalTop,
        width = internalW,
        height = internalH,
        scale = scale,
        animationTick = animationTick
    )

    // Machine Bottom Telemetry Footer Readouts
    val footerTop = top + headerH + internalH + 8f * scale

    // Temperature Badge
    val tempText = "${String.format("%.1f", telemetry.temperature)}°C"
    val tempLayout = textMeasurer.measure(
        text = AnnotatedString("T: $tempText"),
        style = TextStyle(
            color = if (telemetry.temperature > 100) TechOrange else if (telemetry.temperature < 20) TechCyan else TechAmber,
            fontSize = (8f * scale).sp,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.SemiBold
        )
    )
    drawText(textLayoutResult = tempLayout, topLeft = Offset(left + 10f * scale, footerTop))

    // RPM / Speed
    val rpmText = "${telemetry.rpm.toInt()} RPM"
    val rpmLayout = textMeasurer.measure(
        text = AnnotatedString(rpmText),
        style = TextStyle(
            color = Graphite200,
            fontSize = (8f * scale).sp,
            fontFamily = FontFamily.Monospace
        )
    )
    drawText(textLayoutResult = rpmLayout, topLeft = Offset(left + 75f * scale, footerTop))

    // Power kW
    val kwText = "${String.format("%.1f", telemetry.energyKw)} kW"
    val kwLayout = textMeasurer.measure(
        text = AnnotatedString(kwText),
        style = TextStyle(
            color = TechCyan,
            fontSize = (8f * scale).sp,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Medium
        )
    )
    drawText(textLayoutResult = kwLayout, topLeft = Offset(left + 125f * scale, footerTop))

    // Load Progress Line at very bottom
    val loadW = (boxW - 16f * scale) * (telemetry.loadPercent.toFloat() / 100f)
    drawLine(
        color = TechnicalBorder,
        start = Offset(left + 8f * scale, top + boxH - 4f * scale),
        end = Offset(left + boxW - 8f * scale, top + boxH - 4f * scale),
        strokeWidth = 2f * scale
    )
    drawLine(
        color = statusColor,
        start = Offset(left + 8f * scale, top + boxH - 4f * scale),
        end = Offset(left + 8f * scale + loadW, top + boxH - 4f * scale),
        strokeWidth = 2f * scale
    )
}

// Custom Mechanical Internal Canvas Illustrators for each machine
private fun DrawScope.drawMachineMechanicalIllustration(
    id: MachineId,
    telemetry: MachineTelemetry,
    left: Float,
    top: Float,
    width: Float,
    height: Float,
    scale: Float,
    animationTick: Float
) {
    val isRunning = telemetry.status.isOperating
    val centerX = left + width / 2
    val centerY = top + height / 2

    // Mechanical background chamber
    drawRoundRect(
        color = Graphite950,
        topLeft = Offset(left, top),
        size = Size(width, height),
        cornerRadius = CornerRadius(4f * scale, 4f * scale),
        style = Fill
    )
    drawRoundRect(
        color = TechnicalBorder.copy(alpha = 0.5f),
        topLeft = Offset(left, top),
        size = Size(width, height),
        cornerRadius = CornerRadius(4f * scale, 4f * scale),
        style = Stroke(width = 1f * scale)
    )

    when (id) {
        MachineId.COCOA_SILO -> {
            // Conical Hopper with level and falling beans
            val hopperPath = Path().apply {
                moveTo(centerX - 35f * scale, top + 4f * scale)
                lineTo(centerX + 35f * scale, top + 4f * scale)
                lineTo(centerX + 12f * scale, top + height - 8f * scale)
                lineTo(centerX - 12f * scale, top + height - 8f * scale)
                close()
            }
            drawPath(hopperPath, color = ChocolateRaw.copy(alpha = 0.7f), style = Fill)
            drawPath(hopperPath, color = TechnicalBorder, style = Stroke(1f * scale))

            if (isRunning) {
                // Falling cocoa bean particles
                for (b in 0..4) {
                    val by = top + height - 8f * scale + ((animationTick * 0.2f + b * 6f) % (12f * scale))
                    drawCircle(
                        color = ChocolateRoasted,
                        radius = 2.5f * scale,
                        center = Offset(centerX + (b % 3 - 1) * 4f * scale, by)
                    )
                }
            }
        }

        MachineId.ROASTER -> {
            // Rotating Roaster Drum with Burner Fire Glow
            val rotAngle = if (isRunning) (animationTick * 4f) % 360f else 0f
            val rad = 18f * scale

            // Burner flame glow beneath
            if (isRunning) {
                drawRect(
                    brush = Brush.verticalGradient(
                        listOf(TechOrange.copy(alpha = 0.6f), Color.Transparent)
                    ),
                    topLeft = Offset(centerX - 24f * scale, centerY + 8f * scale),
                    size = Size(48f * scale, 14f * scale)
                )
            }

            drawCircle(color = Graphite800, radius = rad, center = Offset(centerX, centerY))
            drawCircle(color = TechAmber, radius = rad, center = Offset(centerX, centerY), style = Stroke(1.5f * scale))

            // Rotating Agitator Fins
            for (i in 0..3) {
                val angleRad = (rotAngle + i * 90f) * (PI / 180f)
                val ex = centerX + cos(angleRad).toFloat() * (rad - 3f * scale)
                val ey = centerY + sin(angleRad).toFloat() * (rad - 3f * scale)
                drawLine(
                    color = ChocolateRoasted,
                    start = Offset(centerX, centerY),
                    end = Offset(ex, ey),
                    strokeWidth = 2f * scale
                )
            }
        }

        MachineId.GRINDER -> {
            // Dual High-Speed Grinding Burrs
            val rot = if (isRunning) (animationTick * 12f) % 360f else 0f
            val r1 = 12f * scale

            // Burr 1
            drawCircle(color = Graphite750, radius = r1, center = Offset(centerX - 14f * scale, centerY))
            drawCircle(color = TechnicalBorderHighlight, radius = r1, center = Offset(centerX - 14f * scale, centerY), style = Stroke(1.5f * scale))

            // Burr 2
            drawCircle(color = Graphite750, radius = r1, center = Offset(centerX + 14f * scale, centerY))
            drawCircle(color = TechnicalBorderHighlight, radius = r1, center = Offset(centerX + 14f * scale, centerY), style = Stroke(1.5f * scale))

            // Shear teeth
            for (t in 0..5) {
                val a1 = (rot + t * 60f) * (PI / 180f)
                val a2 = (-rot + t * 60f) * (PI / 180f)
                drawLine(
                    color = ChocolateLiquor,
                    start = Offset(centerX - 14f * scale, centerY),
                    end = Offset(centerX - 14f * scale + cos(a1).toFloat() * r1, centerY + sin(a1).toFloat() * r1),
                    strokeWidth = 1.5f * scale
                )
                drawLine(
                    color = ChocolateLiquor,
                    start = Offset(centerX + 14f * scale, centerY),
                    end = Offset(centerX + 14f * scale + cos(a2).toFloat() * r1, centerY + sin(a2).toFloat() * r1),
                    strokeWidth = 1.5f * scale
                )
            }
        }

        MachineId.MIXER -> {
            // Planetary Mixing Blades with Chocolate Churn
            val rot = if (isRunning) (animationTick * 5f) % 360f else 0f
            val vesselW = 50f * scale
            val vesselH = 30f * scale

            drawRoundRect(
                color = ChocolateLiquor.copy(alpha = 0.5f),
                topLeft = Offset(centerX - vesselW / 2, centerY - vesselH / 2),
                size = Size(vesselW, vesselH),
                cornerRadius = CornerRadius(4f * scale, 4f * scale)
            )

            // Dual Spiral Mixing Arms
            val armOffset1 = sin(rot * (PI / 180f)).toFloat() * 12f * scale
            val armOffset2 = -sin(rot * (PI / 180f)).toFloat() * 12f * scale

            drawLine(
                color = Graphite100,
                start = Offset(centerX - 12f * scale, centerY - 14f * scale),
                end = Offset(centerX - 12f * scale + armOffset1, centerY + 12f * scale),
                strokeWidth = 2.5f * scale,
                cap = StrokeCap.Round
            )
            drawLine(
                color = Graphite100,
                start = Offset(centerX + 12f * scale, centerY - 14f * scale),
                end = Offset(centerX + 12f * scale + armOffset2, centerY + 12f * scale),
                strokeWidth = 2.5f * scale,
                cap = StrokeCap.Round
            )
        }

        MachineId.REFINER -> {
            // 5 Stacked Precision Steel Refiner Rolls
            val rollCount = 5
            val rollRad = 5f * scale
            val rollSpan = width - 30f * scale
            val spacing = rollSpan / (rollCount - 1)

            for (r in 0 until rollCount) {
                val rx = (left + 15f * scale) + r * spacing
                val ry = centerY + ((r % 2) * 4f - 2f) * scale
                val rollRot = if (isRunning) ((animationTick * (if (r % 2 == 0) 8f else -8f)) % 360f) else 0f

                drawCircle(color = Graphite600, radius = rollRad, center = Offset(rx, ry))
                drawCircle(color = Graphite100, radius = rollRad, center = Offset(rx, ry), style = Stroke(1.2f * scale))

                // Chocolate film layer thinning from roll 1 to roll 5
                val filmThick = (5 - r).coerceAtLeast(1) * 0.8f * scale
                drawLine(
                    color = ChocolateRefined,
                    start = Offset(rx - rollRad, ry - rollRad - filmThick),
                    end = Offset(rx + rollRad, ry - rollRad - filmThick),
                    strokeWidth = filmThick
                )
            }
        }

        MachineId.CONCHE -> {
            // Conching Vessel with Kneading Agitator & Heated Jacket
            val vesselW = 56f * scale
            val vesselH = 32f * scale
            val rot = if (isRunning) (animationTick * 3f) % 360f else 0f

            // Heated Jacket Boundary
            drawRoundRect(
                color = TechAmber.copy(alpha = 0.15f),
                topLeft = Offset(centerX - vesselW / 2 - 2f * scale, centerY - vesselH / 2 - 2f * scale),
                size = Size(vesselW + 4f * scale, vesselH + 4f * scale),
                cornerRadius = CornerRadius(6f * scale, 6f * scale)
            )

            // Conche Body
            drawRoundRect(
                color = ChocolateRefined,
                topLeft = Offset(centerX - vesselW / 2, centerY - vesselH / 2),
                size = Size(vesselW, vesselH),
                cornerRadius = CornerRadius(4f * scale, 4f * scale)
            )

            // Heavy Kneading Rotor
            val rX = sin(rot * (PI / 180f)).toFloat() * 16f * scale
            drawCircle(
                color = Graphite100,
                radius = 6f * scale,
                center = Offset(centerX + rX, centerY)
            )
            drawLine(
                color = Graphite200,
                start = Offset(centerX, centerY - 10f * scale),
                end = Offset(centerX + rX, centerY),
                strokeWidth = 2.5f * scale,
                cap = StrokeCap.Round
            )
        }

        MachineId.TEMPERER -> {
            // Multi-Zone Tempering Column (4-zone thermal coils)
            val colW = 48f * scale
            val colH = 34f * scale

            drawRoundRect(
                color = Graphite850,
                topLeft = Offset(centerX - colW / 2, centerY - colH / 2),
                size = Size(colW, colH),
                cornerRadius = CornerRadius(4f * scale, 4f * scale)
            )

            // 4 Thermal Zone indicators
            val zW = colW / 4f
            val colors = listOf(TechOrange, TechCyan, TechBlue, TechAmber)
            for (z in 0..3) {
                drawRect(
                    color = colors[z].copy(alpha = 0.4f),
                    topLeft = Offset(centerX - colW / 2 + z * zW, centerY - colH / 2),
                    size = Size(zW, colH)
                )
                drawLine(
                    color = colors[z],
                    start = Offset(centerX - colW / 2 + z * zW, centerY - colH / 2),
                    end = Offset(centerX - colW / 2 + z * zW, centerY + colH / 2),
                    strokeWidth = 1f * scale
                )
            }

            // Beta V Seed Nuclei
            if (isRunning) {
                for (s in 0..5) {
                    val sx = centerX - colW / 4 + ((animationTick * 0.3f + s * 8f) % (colW / 2))
                    val sy = centerY + sin((animationTick + s * 30f) * 0.1f).toFloat() * 8f * scale
                    drawCircle(
                        color = ChocolateTempered,
                        radius = 2.2f * scale,
                        center = Offset(sx, sy)
                    )
                }
            }
        }

        MachineId.MOULDER -> {
            // Piston Depositor & Mould Plate Vibrator
            val depositorW = 44f * scale
            val depositorH = 14f * scale

            // Piston block
            drawRoundRect(
                color = Graphite700,
                topLeft = Offset(centerX - depositorW / 2, top + 4f * scale),
                size = Size(depositorW, depositorH),
                cornerRadius = CornerRadius(2f * scale, 2f * scale)
            )

            // 3 Nozzles dropping liquid chocolate into moulds
            for (n in -1..1) {
                val nx = centerX + n * 14f * scale
                drawLine(
                    color = Graphite200,
                    start = Offset(nx, top + 4f * scale + depositorH),
                    end = Offset(nx, top + 4f * scale + depositorH + 6f * scale),
                    strokeWidth = 2f * scale
                )

                if (isRunning) {
                    // Chocolate drops
                    val dropY = top + 4f * scale + depositorH + 6f * scale + ((animationTick * 0.3f) % (12f * scale))
                    drawCircle(
                        color = ChocolateTempered,
                        radius = 2.2f * scale,
                        center = Offset(nx, dropY)
                    )
                }
            }

            // Mould Tray
            val mouldW = 54f * scale
            val vibOffset = if (isRunning) sin(animationTick * 0.8f).toFloat() * 1.5f * scale else 0f
            drawRoundRect(
                color = Graphite800,
                topLeft = Offset(centerX - mouldW / 2 + vibOffset, top + height - 10f * scale),
                size = Size(mouldW, 8f * scale),
                cornerRadius = CornerRadius(2f * scale, 2f * scale)
            )
        }

        MachineId.COOLER -> {
            // Cooling Tunnel with Multi-Zone Chill & Airflow
            val tunnelW = 56f * scale
            val tunnelH = 30f * scale

            drawRoundRect(
                color = Graphite850,
                topLeft = Offset(centerX - tunnelW / 2, centerY - tunnelH / 2),
                size = Size(tunnelW, tunnelH),
                cornerRadius = CornerRadius(4f * scale, 4f * scale)
            )

            // Frost Cyan Air Stream Waves
            if (isRunning) {
                for (w in 0..2) {
                    val wx = centerX - tunnelW / 2 + ((animationTick * 0.4f + w * 18f) % tunnelW)
                    drawLine(
                        color = TechCyan.copy(alpha = 0.5f),
                        start = Offset(wx, centerY - 8f * scale),
                        end = Offset(wx + 8f * scale, centerY + 8f * scale),
                        strokeWidth = 1.2f * scale
                    )
                }
            }

            // Conveyor Bars
            for (b in 0..3) {
                val bx = centerX - tunnelW / 2 + 6f * scale + b * 12f * scale
                drawRoundRect(
                    color = ChocolateRoasted,
                    topLeft = Offset(bx, centerY + 2f * scale),
                    size = Size(8f * scale, 5f * scale),
                    cornerRadius = CornerRadius(1f * scale, 1f * scale)
                )
            }
        }

        MachineId.PACKAGING -> {
            // Flow Wrapper Rotating Cutter Wheel & Finished Bar Output
            val wrapW = 54f * scale
            val wrapH = 30f * scale
            val rot = if (isRunning) (animationTick * 10f) % 360f else 0f

            drawRoundRect(
                color = Graphite850,
                topLeft = Offset(centerX - wrapW / 2, centerY - wrapH / 2),
                size = Size(wrapW, wrapH),
                cornerRadius = CornerRadius(4f * scale, 4f * scale)
            )

            // Rotating Wrapper Head
            drawCircle(color = Graphite700, radius = 9f * scale, center = Offset(centerX - 10f * scale, centerY))
            val hx = (centerX - 10f * scale) + cos(rot * (PI / 180f)).toFloat() * 9f * scale
            val hy = centerY + sin(rot * (PI / 180f)).toFloat() * 9f * scale
            drawLine(
                color = TechAmber,
                start = Offset(centerX - 10f * scale, centerY),
                end = Offset(hx, hy),
                strokeWidth = 2f * scale
            )

            // Packaged Chocolate Bars exiting right
            val barX = centerX + 12f * scale + (if (isRunning) ((animationTick * 0.2f) % (14f * scale)) else 0f)
            drawRoundRect(
                color = ChocolateMilk,
                topLeft = Offset(barX, centerY - 4f * scale),
                size = Size(10f * scale, 8f * scale),
                cornerRadius = CornerRadius(1.5f * scale, 1.5f * scale)
            )
            drawRoundRect(
                color = Color.White.copy(alpha = 0.8f),
                topLeft = Offset(barX + 2f * scale, centerY - 3f * scale),
                size = Size(6f * scale, 6f * scale),
                cornerRadius = CornerRadius(1f * scale, 1f * scale),
                style = Stroke(0.8f * scale)
            )
        }
    }
}

@Composable
private fun FactoryMapOverlayControls(
    currentZoom: FactoryZoomLevel,
    onZoomChange: (FactoryZoomLevel) -> Unit,
    onResetView: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier.clip(RoundedCornerShape(6.dp)),
        color = Graphite900.copy(alpha = 0.92f),
        border = androidx.compose.foundation.BorderStroke(1.dp, TechnicalBorder),
        shape = RoundedCornerShape(6.dp)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Text(
                text = "ZOOM:",
                style = MaterialTheme.typography.labelSmall,
                color = Graphite400
            )

            FactoryZoomLevel.entries.forEach { level ->
                val isSelected = level == currentZoom
                Surface(
                    onClick = { onZoomChange(level) },
                    shape = RoundedCornerShape(3.dp),
                    color = if (isSelected) TechAmber else Graphite800,
                    modifier = Modifier.testTag("zoom_btn_${level.name.lowercase()}")
                ) {
                    Text(
                        text = level.label,
                        style = MaterialTheme.typography.labelSmall,
                        color = if (isSelected) Graphite950 else Graphite200,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                    )
                }
            }

            Box(
                modifier = Modifier
                    .width(1.dp)
                    .height(16.dp)
                    .background(TechnicalBorder)
            )

            IconButton(
                onClick = onResetView,
                modifier = Modifier.size(24.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.CenterFocusStrong,
                    contentDescription = "Center View",
                    tint = Graphite200,
                    modifier = Modifier.size(16.dp)
                )
            }
        }
    }
}

@Composable
private fun SelectedMachineQuickBadge(
    telemetry: MachineTelemetry,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier
            .clip(RoundedCornerShape(6.dp))
            .border(1.dp, TechAmber, RoundedCornerShape(6.dp)),
        color = Graphite900.copy(alpha = 0.94f),
        shape = RoundedCornerShape(6.dp)
    ) {
        Column(
            modifier = Modifier.padding(10.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .clip(RoundedCornerShape(2.dp))
                        .background(TechAmber)
                )
                Text(
                    text = telemetry.machineId.displayName.uppercase(),
                    style = MaterialTheme.typography.labelMedium,
                    color = TechAmber,
                    fontWeight = FontWeight.Bold
                )
            }
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "STATUS: ${telemetry.status.label} | LOAD: ${telemetry.loadPercent.toInt()}%",
                style = MaterialTheme.typography.bodySmall,
                color = Graphite100
            )
            Text(
                text = "TEMP: ${telemetry.temperature}°C | SPEED: ${telemetry.rpm.toInt()} RPM",
                style = MaterialTheme.typography.bodySmall,
                color = Graphite200
            )
            Text(
                text = "POWER: ${telemetry.energyKw} kW | FLOW: ${telemetry.throughputKgH.toInt()} kg/h",
                style = MaterialTheme.typography.bodySmall,
                color = TechCyan
            )
        }
    }
}
