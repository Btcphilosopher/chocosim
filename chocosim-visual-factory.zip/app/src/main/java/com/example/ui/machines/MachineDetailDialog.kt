package com.example.ui.machines

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.domain.model.MachineId
import com.example.domain.model.MachineStatus
import com.example.domain.model.MachineTelemetry
import com.example.ui.theme.*

@Composable
fun MachineDetailDialog(
    telemetry: MachineTelemetry,
    onDismiss: () -> Unit,
    onSetStatus: (MachineId, MachineStatus) -> Unit,
    onSetTargetTemp: (MachineId, Double) -> Unit,
    onSetTargetRpm: (MachineId, Double) -> Unit
) {
    var editTargetTemp by remember(telemetry) { mutableDoubleStateOf(telemetry.targetTemperature) }
    var editTargetRpm by remember(telemetry) { mutableDoubleStateOf(telemetry.targetRpm) }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(8.dp),
            color = Graphite900,
            border = androidx.compose.foundation.BorderStroke(1.dp, TechAmber),
            modifier = Modifier
                .fillMaxWidth()
                .padding(4.dp)
                .testTag("machine_detail_dialog")
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text(
                                text = telemetry.machineId.displayName.uppercase(),
                                style = MaterialTheme.typography.titleMedium,
                                color = TechAmber,
                                fontWeight = FontWeight.Bold
                            )
                            Surface(
                                shape = RoundedCornerShape(3.dp),
                                color = Graphite800
                            ) {
                                Text(
                                    text = telemetry.machineId.code,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = Graphite200,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }
                        Text(
                            text = "STAGE 0${telemetry.machineId.stageIndex + 1} // SCADA DETAILED INSPECTION",
                            style = MaterialTheme.typography.bodySmall,
                            color = Graphite400
                        )
                    }

                    IconButton(onClick = onDismiss) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Close",
                            tint = Graphite200
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Time-Series Oscilloscope History Chart (Canvas)
                Text(
                    text = "TIME-SERIES OSCILLOSCOPE (TEMP °C / DYNAMICS)",
                    style = MaterialTheme.typography.labelSmall,
                    color = Graphite400
                )
                Spacer(modifier = Modifier.height(4.dp))
                OscilloscopeHistoryGraph(
                    history = telemetry.historySamples,
                    currentValue = telemetry.temperature.toFloat(),
                    targetValue = telemetry.targetTemperature.toFloat(),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(110.dp)
                        .clip(RoundedCornerShape(4.dp))
                        .background(Graphite950)
                        .border(1.dp, TechnicalBorder, RoundedCornerShape(4.dp))
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Real-time 6 Gauge Readouts
                Text(
                    text = "LIVE TELEMETRY GAUGES",
                    style = MaterialTheme.typography.labelSmall,
                    color = Graphite400
                )
                Spacer(modifier = Modifier.height(6.dp))

                Column(
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        GaugeBox(
                            label = "PROCESS TEMP",
                            value = "${telemetry.temperature} °C",
                            subtext = "Target: ${telemetry.targetTemperature} °C",
                            color = TechAmber,
                            modifier = Modifier.weight(1f)
                        )
                        GaugeBox(
                            label = "MOTOR SPEED",
                            value = "${telemetry.rpm.toInt()} RPM",
                            subtext = "Target: ${telemetry.targetRpm.toInt()} RPM",
                            color = Graphite50,
                            modifier = Modifier.weight(1f)
                        )
                        GaugeBox(
                            label = "MOTOR LOAD",
                            value = "${telemetry.loadPercent.toInt()} %",
                            subtext = "Nominal < 85%",
                            color = if (telemetry.loadPercent > 85) TechOrange else TechGreen,
                            modifier = Modifier.weight(1f)
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        GaugeBox(
                            label = "ACTIVE POWER",
                            value = "${telemetry.energyKw} kW",
                            subtext = "Nominal ${telemetry.machineId.nominalPowerKw} kW",
                            color = TechCyan,
                            modifier = Modifier.weight(1f)
                        )
                        GaugeBox(
                            label = "PRESSURE",
                            value = "${telemetry.pressureBar} bar",
                            subtext = "Hydraulic Circuit",
                            color = TechBlue,
                            modifier = Modifier.weight(1f)
                        )
                        GaugeBox(
                            label = "VIBRATION",
                            value = "${telemetry.vibrationMmS} mm/s",
                            subtext = "ISO Standard OK",
                            color = if (telemetry.vibrationMmS > 3.0) TechAmber else TechGreen,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Industrial Process Physics & Thermodynamics
                Text(
                    text = "PROCESS PHYSICS & THERMODYNAMIC MODEL",
                    style = MaterialTheme.typography.labelSmall,
                    color = TechCyan
                )
                Spacer(modifier = Modifier.height(6.dp))

                Surface(
                    shape = RoundedCornerShape(4.dp),
                    color = Graphite950,
                    border = androidx.compose.foundation.BorderStroke(1.dp, TechnicalBorder.copy(alpha = 0.8f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        val physicsData = getMachinePhysicsData(telemetry.machineId, telemetry.temperature)

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "GOVERNING EQUATION: ${physicsData.equationName}",
                                style = MaterialTheme.typography.labelSmall,
                                color = TechAmber,
                                fontWeight = FontWeight.Bold,
                                fontSize = 8.5.sp
                            )
                            Text(
                                text = "RUST SOLVER: RUNGE-KUTTA 4",
                                style = MaterialTheme.typography.bodySmall,
                                color = Graphite400,
                                fontSize = 7.5.sp
                            )
                        }

                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = physicsData.formula,
                            style = MaterialTheme.typography.bodySmall,
                            color = TechCyan,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp
                        )

                        Spacer(modifier = Modifier.height(6.dp))
                        physicsData.parameters.forEach { param ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 2.dp),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(param.first, style = MaterialTheme.typography.bodySmall, color = Graphite200, fontSize = 8.5.sp)
                                Text(param.second, style = MaterialTheme.typography.bodySmall, color = Graphite100, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.SemiBold, fontSize = 8.5.sp)
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Setpoint Adjusters
                Text(
                    text = "SETPOINT OVERRIDES",
                    style = MaterialTheme.typography.labelSmall,
                    color = TechAmber
                )
                Spacer(modifier = Modifier.height(6.dp))

                // Target Temp Slider
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Target Temperature:",
                            style = MaterialTheme.typography.bodySmall,
                            color = Graphite200
                        )
                        Text(
                            text = "${String.format("%.1f", editTargetTemp)} °C",
                            style = MaterialTheme.typography.labelMedium,
                            color = TechAmber,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Slider(
                        value = editTargetTemp.toFloat(),
                        onValueChange = {
                            editTargetTemp = it.toDouble()
                            onSetTargetTemp(telemetry.machineId, editTargetTemp)
                        },
                        valueRange = (telemetry.machineId.defaultTargetTemp * 0.5f).toFloat()..(telemetry.machineId.defaultTargetTemp * 1.5f).toFloat().coerceAtLeast(40f),
                        colors = SliderDefaults.colors(
                            thumbColor = TechAmber,
                            activeTrackColor = TechAmber,
                            inactiveTrackColor = Graphite800
                        )
                    )
                }

                // Target RPM Slider
                if (telemetry.machineId.defaultRpm > 0) {
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "Target Motor Speed:",
                                style = MaterialTheme.typography.bodySmall,
                                color = Graphite200
                            )
                            Text(
                                text = "${editTargetRpm.toInt()} RPM",
                                style = MaterialTheme.typography.labelMedium,
                                color = Graphite50,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Slider(
                            value = editTargetRpm.toFloat(),
                            onValueChange = {
                                editTargetRpm = it.toDouble()
                                onSetTargetRpm(telemetry.machineId, editTargetRpm)
                            },
                            valueRange = 0f..(telemetry.machineId.defaultRpm * 1.5f).toFloat(),
                            colors = SliderDefaults.colors(
                                thumbColor = Graphite100,
                                activeTrackColor = TechCyan,
                                inactiveTrackColor = Graphite800
                            )
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Maintenance & Operating State Buttons
                Text(
                    text = "MACHINE OPERATING STATE CONTROL",
                    style = MaterialTheme.typography.labelSmall,
                    color = Graphite400
                )
                Spacer(modifier = Modifier.height(6.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Button(
                        onClick = { onSetStatus(telemetry.machineId, MachineStatus.RUNNING) },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = TechGreen.copy(alpha = 0.25f),
                            contentColor = TechGreen
                        ),
                        shape = RoundedCornerShape(4.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("START", style = MaterialTheme.typography.labelSmall)
                    }

                    Button(
                        onClick = { onSetStatus(telemetry.machineId, MachineStatus.PAUSED) },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = TechAmber.copy(alpha = 0.25f),
                            contentColor = TechAmber
                        ),
                        shape = RoundedCornerShape(4.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("PAUSE", style = MaterialTheme.typography.labelSmall)
                    }

                    Button(
                        onClick = { onSetStatus(telemetry.machineId, MachineStatus.MAINTENANCE) },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = TechPurple.copy(alpha = 0.25f),
                            contentColor = TechPurple
                        ),
                        shape = RoundedCornerShape(4.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("SERVICE", style = MaterialTheme.typography.labelSmall)
                    }

                    Button(
                        onClick = { onSetStatus(telemetry.machineId, MachineStatus.FAULT) },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = TechRed.copy(alpha = 0.25f),
                            contentColor = TechRed
                        ),
                        shape = RoundedCornerShape(4.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("FAULT", style = MaterialTheme.typography.labelSmall)
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Maintenance Info Footer
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(4.dp))
                        .background(Graphite950)
                        .padding(8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "TOTAL RUNTIME: ${telemetry.runtimeHours.toInt()} h",
                        style = MaterialTheme.typography.bodySmall,
                        color = Graphite400
                    )
                    Text(
                        text = "HEALTH SCORE: ${telemetry.maintenanceHealth}%",
                        style = MaterialTheme.typography.bodySmall,
                        color = TechGreen,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

@Composable
private fun GaugeBox(
    label: String,
    value: String,
    subtext: String,
    color: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        shape = RoundedCornerShape(4.dp),
        color = Graphite950,
        border = androidx.compose.foundation.BorderStroke(1.dp, TechnicalBorder),
        modifier = modifier
    ) {
        Column(
            modifier = Modifier.padding(6.dp)
        ) {
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall,
                color = Graphite400,
                fontSize = 7.5.sp
            )
            Text(
                text = value,
                style = MaterialTheme.typography.labelMedium,
                color = color,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                fontSize = 11.sp
            )
            Text(
                text = subtext,
                style = MaterialTheme.typography.bodySmall,
                color = Graphite400,
                fontSize = 7.5.sp
            )
        }
    }
}

@Composable
private fun OscilloscopeHistoryGraph(
    history: List<Float>,
    currentValue: Float,
    targetValue: Float,
    modifier: Modifier = Modifier
) {
    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height

        // Draw Oscilloscope Reticle Grid
        val gridRows = 4
        val gridCols = 8
        for (r in 0..gridRows) {
            val y = (h / gridRows) * r
            drawLine(
                color = TechnicalGridLine,
                start = Offset(0f, y),
                end = Offset(w, y),
                strokeWidth = 1f
            )
        }
        for (c in 0..gridCols) {
            val x = (w / gridCols) * c
            drawLine(
                color = TechnicalGridLine,
                start = Offset(x, 0f),
                end = Offset(x, h),
                strokeWidth = 1f
            )
        }

        if (history.size < 2) return@Canvas

        val minVal = (history.minOrNull() ?: 0f).coerceAtMost(targetValue - 5f)
        val maxVal = (history.maxOrNull() ?: 100f).coerceAtLeast(targetValue + 5f)
        val valRange = (maxVal - minVal).coerceAtLeast(1f)

        // Draw Target Line (Dashed)
        val targetY = h - ((targetValue - minVal) / valRange) * h
        drawLine(
            color = TechAmber.copy(alpha = 0.5f),
            start = Offset(0f, targetY),
            end = Offset(w, targetY),
            strokeWidth = 1.2f
        )

        // Plot Signal Curve
        val path = Path()
        val stepX = w / (history.size - 1)

        history.forEachIndexed { index, value ->
            val x = index * stepX
            val y = h - ((value - minVal) / valRange) * (h - 16f) - 8f

            if (index == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }

        drawPath(
            path = path,
            color = TechCyan,
            style = Stroke(width = 2f)
        )

        // Pulse dot on latest value
        val lastY = h - ((currentValue - minVal) / valRange) * (h - 16f) - 8f
        drawCircle(
            color = TechCyan,
            radius = 4f,
            center = Offset(w, lastY)
        )
    }
}

private data class MachinePhysicsInfo(
    val equationName: String,
    val formula: String,
    val parameters: List<Pair<String, String>>
)

private fun getMachinePhysicsData(machineId: MachineId, currentTemp: Double): MachinePhysicsInfo {
    return when (machineId) {
        MachineId.COCOA_SILO -> MachinePhysicsInfo(
            equationName = "Janssen Hydrostatic Granular Pressure",
            formula = "σ_v(z) = (ρ·g·R / 2μ·k) · [1 - exp(-2μ·k·z / R)]",
            parameters = listOf(
                "Bulk Density (ρ)" to "580 kg/m³",
                "Friction Coeff (μ)" to "0.42 (Internal shear)",
                "Hopper Angle (θ)" to "60° Mass Flow",
                "Discharge Rate" to "3,420 kg/h active"
            )
        )
        MachineId.ROASTER -> MachinePhysicsInfo(
            equationName = "Convective-Conductive Heat & Moisture Transfer",
            formula = "q = h·A·(T_gas - T_bean) - m_dot_evap·ΔH_vap",
            parameters = listOf(
                "Heat Transfer Coeff (h)" to "85 W/(m²·K)",
                "Moisture Ratio (X/X0)" to "${String.format("%.2f", (140.0 - currentTemp).coerceAtLeast(10.0) / 100.0 * 0.075)} db",
                "Maillard Reaction Rate" to "k_m = 3.2e-3 s⁻¹",
                "Thermal Efficiency" to "87.4% heat recovery"
            )
        )
        MachineId.GRINDER -> MachinePhysicsInfo(
            equationName = "Rittinger Milling Specific Shear Energy",
            formula = "E_m = K_R · (1/D_p_out - 1/D_p_in)",
            parameters = listOf(
                "Burr Clearance Gap" to "42 μm precision",
                "Shear Rate (γ_dot)" to "14,200 s⁻¹",
                "Cell Rupture Yield" to "98.8% free cocoa butter",
                "Rittinger Constant (K_R)" to "18.4 kWh·μm/t"
            )
        )
        MachineId.MIXER -> MachinePhysicsInfo(
            equationName = "Planetary Agitation Power Number (Np)",
            formula = "P = N_p · ρ · N³ · D⁵ (Turbulent / Transition Regime)",
            parameters = listOf(
                "Power Number (N_p)" to "2.85",
                "Froude Number (Fr)" to "0.42 (Vortex prevention)",
                "Blend Uniformity (Cv)" to "0.994 (Homogeneous)",
                "Enthalpy Balance" to "+14.2 kW mechanical heat"
            )
        )
        MachineId.REFINER -> MachinePhysicsInfo(
            equationName = "Hydrodynamic Lubrication & Roll Nip Squeeze",
            formula = "h_min = 2.65 · R' · (G*)^0.54 · (U*)^0.70 · (W*)^-0.13",
            parameters = listOf(
                "5-Roll Clearance (h)" to "120 → 70 → 40 → 25 → 18.2 μm",
                "Hydraulic Roll Nip" to "4.8 bar clamping",
                "Surface Velocity Ratio" to "1.0 : 1.6 : 2.5 : 4.0 : 6.4",
                "D90 Output Target" to "< 20.0 μm pass"
            )
        )
        MachineId.CONCHE -> MachinePhysicsInfo(
            equationName = "Casson De-Acidification & Lecithin Kinetics",
            formula = "τ^(1/2) = τ_0^(1/2) + η_ca^(1/2) · γ_dot^(1/2)",
            parameters = listOf(
                "Volatile Acid Evap" to "-45.2% acetic acid removed",
                "Free Fat Coating" to "34.5% total lipid phase",
                "Moisture Removal" to "0.72% final mass balance",
                "Conche Operating Phase" to "Liquid Shear Phase"
            )
        )
        MachineId.TEMPERER -> MachinePhysicsInfo(
            equationName = "Classical Crystal Nucleation & Polymorphic Rate",
            formula = "J = A · exp(-ΔG* / k_B·T) · exp(-E_a / k_B·T)",
            parameters = listOf(
                "Active Polymorph" to "Beta-V (Form V) 94.2%",
                "Nucleation Density" to "1.85 × 10⁷ nuclei/ml",
                "Tempering Index (CTI)" to "1.42 °C/min optimal",
                "Contraction Coeff (ΔV)" to "2.2% mould release"
            )
        )
        MachineId.MOULDER -> MachinePhysicsInfo(
            equationName = "Piston Flow Volumetric Displacement",
            formula = "V_deposit = A_piston · s_stroke = m_bar / ρ_liquid",
            parameters = listOf(
                "Deposit Accuracy" to "100.0g ± 0.2g",
                "Vibration Frequency" to "50 Hz de-aeration",
                "Nozzle Temperature" to "31.2 °C (Anti-solidify)",
                "Cycle Rate" to "48 moulds/min"
            )
        )
        MachineId.COOLER -> MachinePhysicsInfo(
            equationName = "Forced Convection Cooling & Latent Solidification",
            formula = "q = h_air · A · (T_bar - T_air) + m_dot · ΔH_fusion",
            parameters = listOf(
                "Heat of Fusion (ΔH)" to "45.0 kJ/kg crystallized",
                "Air Tunnel Velocity" to "3.2 m/s counter-current",
                "Zone 1 / 2 / 3 Temp" to "14°C / 10°C / 15°C",
                "Solid Fat Index (SFI)" to "78.4% at tunnel exit"
            )
        )
        MachineId.PACKAGING -> MachinePhysicsInfo(
            equationName = "Rotary Flow-Wrap Sealing Thermal Kinetics",
            formula = "Q_seal = k_film / d · (T_jaw - T_melt) · t_dwell",
            parameters = listOf(
                "Jaw Seal Temp" to "135.0 °C",
                "Dwell Time (t_dwell)" to "45 ms",
                "Bar Flow Rate" to "240 bars/min",
                "O2 Barrier Integrity" to "99.98% hermetic"
            )
        )
    }
}
