package com.example.ui.machines

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.model.MachineId
import com.example.domain.model.MachineStatus
import com.example.domain.model.MachineTelemetry
import com.example.ui.theme.*

@Composable
fun MachineTelemetryView(
    machines: Map<MachineId, MachineTelemetry>,
    onSelectMachine: (MachineTelemetry) -> Unit,
    onTogglePower: (MachineId) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Graphite950)
            .padding(12.dp)
    ) {
        // Section Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "MACHINE TELEMETRY MATRIX",
                    style = MaterialTheme.typography.titleMedium,
                    color = TechAmber,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Live SCADA monitoring // 10 Processing Units // Continuous Flow",
                    style = MaterialTheme.typography.bodySmall,
                    color = Graphite400
                )
            }

            Surface(
                shape = RoundedCornerShape(4.dp),
                color = Graphite850,
                border = androidx.compose.foundation.BorderStroke(1.dp, TechnicalBorder)
            ) {
                Text(
                    text = "SAMPLING RATE: 100ms",
                    style = MaterialTheme.typography.bodySmall,
                    color = TechCyan,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Grid of 10 Machines
        LazyVerticalGrid(
            columns = GridCells.Adaptive(minSize = 290.dp),
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(MachineId.entries) { id ->
                val telemetry = machines[id]
                if (telemetry != null) {
                    MachineTelemetryCard(
                        telemetry = telemetry,
                        onClick = { onSelectMachine(telemetry) },
                        onTogglePower = { onTogglePower(id) }
                    )
                }
            }
        }
    }
}

@Composable
fun MachineTelemetryCard(
    telemetry: MachineTelemetry,
    onClick: () -> Unit,
    onTogglePower: () -> Unit,
    modifier: Modifier = Modifier
) {
    val statusColor = when (telemetry.status) {
        MachineStatus.RUNNING -> TechGreen
        MachineStatus.WARNING -> TechAmber
        MachineStatus.FAULT -> TechRed
        MachineStatus.MAINTENANCE -> TechPurple
        MachineStatus.IDLE, MachineStatus.PAUSED -> Graphite400
        MachineStatus.STARTING -> TechCyan
        MachineStatus.OFFLINE, MachineStatus.COMPLETED -> Graphite600
    }

    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(6.dp),
        color = TechnicalSurfaceCard,
        border = androidx.compose.foundation.BorderStroke(1.dp, TechnicalBorder),
        modifier = modifier
            .fillMaxWidth()
            .testTag("machine_card_${telemetry.machineId.name.lowercase()}")
    ) {
        Column(
            modifier = Modifier.padding(10.dp)
        ) {
            // Top Card Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .clip(RoundedCornerShape(2.dp))
                            .background(statusColor)
                    )
                    Text(
                        text = telemetry.machineId.displayName.uppercase(),
                        style = MaterialTheme.typography.labelLarge,
                        color = Graphite50,
                        fontWeight = FontWeight.Bold
                    )
                }

                Surface(
                    shape = RoundedCornerShape(3.dp),
                    color = statusColor.copy(alpha = 0.15f),
                    border = androidx.compose.foundation.BorderStroke(1.dp, statusColor.copy(alpha = 0.5f))
                ) {
                    Text(
                        text = telemetry.status.label,
                        style = MaterialTheme.typography.labelSmall,
                        color = statusColor,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                        fontSize = 9.sp
                    )
                }
            }

            Text(
                text = "${telemetry.machineId.code} // STAGE 0${telemetry.machineId.stageIndex + 1}",
                style = MaterialTheme.typography.bodySmall,
                color = Graphite400
            )

            Spacer(modifier = Modifier.height(8.dp))

            // 4-Column Key Metrics
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(4.dp))
                    .background(Graphite950)
                    .border(1.dp, TechnicalBorder.copy(alpha = 0.5f), RoundedCornerShape(4.dp))
                    .padding(8.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                TelemetryMetricMini(
                    label = "TEMP",
                    value = "${telemetry.temperature}°C",
                    target = "Set: ${telemetry.targetTemperature}°C",
                    valueColor = if (telemetry.temperature > 100) TechOrange else TechAmber
                )
                TelemetryMetricMini(
                    label = "SPEED",
                    value = "${telemetry.rpm.toInt()}",
                    target = "RPM",
                    valueColor = Graphite100
                )
                TelemetryMetricMini(
                    label = "LOAD",
                    value = "${telemetry.loadPercent.toInt()}%",
                    target = "P: ${telemetry.pressureBar} bar",
                    valueColor = if (telemetry.loadPercent > 85) TechAmber else TechGreen
                )
                TelemetryMetricMini(
                    label = "ENERGY",
                    value = "${telemetry.energyKw} kW",
                    target = "${telemetry.throughputKgH.toInt()} kg/h",
                    valueColor = TechCyan
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Load Bar & Quick Control Action
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "BATCH: ${telemetry.batchId}",
                            style = MaterialTheme.typography.bodySmall,
                            color = Graphite400,
                            fontSize = 8.5.sp
                        )
                        Text(
                            text = "${telemetry.progressPercent.toInt()}%",
                            style = MaterialTheme.typography.bodySmall,
                            color = TechAmber,
                            fontSize = 8.5.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Spacer(modifier = Modifier.height(2.dp))
                    LinearProgressIndicator(
                        progress = { (telemetry.progressPercent / 100.0).toFloat() },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(4.dp)
                            .clip(RoundedCornerShape(2.dp)),
                        color = TechAmber,
                        trackColor = Graphite800,
                    )
                }

                // Quick Power Toggle
                IconButton(
                    onClick = onTogglePower,
                    modifier = Modifier.size(28.dp)
                ) {
                    Icon(
                        imageVector = if (telemetry.status.isOperating) Icons.Default.PauseCircle else Icons.Default.PlayCircle,
                        contentDescription = "Toggle Power",
                        tint = if (telemetry.status.isOperating) TechAmber else TechGreen,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun TelemetryMetricMini(
    label: String,
    value: String,
    target: String,
    valueColor: Color
) {
    Column(horizontalAlignment = Alignment.Start) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = Graphite400,
            fontSize = 8.sp
        )
        Text(
            text = value,
            style = MaterialTheme.typography.labelMedium,
            color = valueColor,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace,
            fontSize = 11.sp
        )
        Text(
            text = target,
            style = MaterialTheme.typography.bodySmall,
            color = Graphite400,
            fontSize = 7.5.sp
        )
    }
}
