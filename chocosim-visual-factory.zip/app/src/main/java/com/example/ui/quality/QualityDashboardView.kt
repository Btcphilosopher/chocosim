package com.example.ui.quality

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.model.QualityMetrics
import com.example.ui.theme.*

@Composable
fun QualityDashboardView(
    quality: QualityMetrics,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Graphite950)
            .padding(12.dp)
            .verticalScroll(rememberScrollState())
    ) {
        // Section Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "LAB QUALITY & RHEOLOGY LABORATORY",
                    style = MaterialTheme.typography.titleMedium,
                    color = ChocolateGold,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Micro-particle distribution // Casson yield stress // Statistical Process Control (SPC)",
                    style = MaterialTheme.typography.bodySmall,
                    color = Graphite400
                )
            }

            Surface(
                shape = RoundedCornerShape(4.dp),
                color = TechGreen.copy(alpha = 0.2f),
                border = androidx.compose.foundation.BorderStroke(1.dp, TechGreen)
            ) {
                Text(
                    text = "CPK: ${quality.processCapabilityCpk} (SIX SIGMA)",
                    style = MaterialTheme.typography.labelSmall,
                    color = TechGreen,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // 6 Quality Telemetry Indicator Cards
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            QualityCard(
                title = "PARTICLE SIZE",
                value = "${quality.particleSizeUm} μm",
                target = "Target: < 20.0 μm",
                status = "PASS (D90 = 18.2)",
                color = TechGreen,
                modifier = Modifier.weight(1f)
            )
            QualityCard(
                title = "CASSON VISCOSITY",
                value = "${quality.viscosityPaS} Pa·s",
                target = "Target: 2.40 Pa·s",
                status = "OPTIMAL SHEAR",
                color = TechCyan,
                modifier = Modifier.weight(1f)
            )
            QualityCard(
                title = "MOISTURE CONTENT",
                value = "${quality.moisturePercent} %",
                target = "Target: < 0.80 %",
                status = "DRY MASS STABLE",
                color = TechAmber,
                modifier = Modifier.weight(1f)
            )
        }

        Spacer(modifier = Modifier.height(8.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            QualityCard(
                title = "TEMPER INDEX",
                value = "${quality.temperIndexPercent} %",
                target = "Target: > 90.0 %",
                status = "FORM V DOMINANT",
                color = TechGreen,
                modifier = Modifier.weight(1f)
            )
            QualityCard(
                title = "DEFECT RATE",
                value = "${quality.defectRatePercent} %",
                target = "Tolerance: < 2.0 %",
                status = "LOW REJECTION",
                color = TechGreen,
                modifier = Modifier.weight(1f)
            )
            QualityCard(
                title = "CAPABILITY CPK",
                value = "${quality.processCapabilityCpk}",
                target = "Threshold: > 1.33",
                status = "EXCELLENT",
                color = ChocolateGold,
                modifier = Modifier.weight(1f)
            )
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Particle Size Micron Distribution Curve (Canvas)
        Surface(
            shape = RoundedCornerShape(6.dp),
            color = TechnicalSurfaceCard,
            border = androidx.compose.foundation.BorderStroke(1.dp, TechnicalBorder),
            modifier = Modifier
                .fillMaxWidth()
                .testTag("particle_distribution_panel")
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Text(
                    text = "PARTICLE SIZE DISTRIBUTION (LASER DIFFRACTION SPECTROMETRY)",
                    style = MaterialTheme.typography.labelSmall,
                    color = Graphite200,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(8.dp))

                Canvas(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(130.dp)
                        .clip(RoundedCornerShape(4.dp))
                        .background(Graphite950)
                        .border(1.dp, TechnicalBorder, RoundedCornerShape(4.dp))
                ) {
                    val w = size.width
                    val h = size.height

                    // Reticle
                    for (i in 1..3) {
                        val y = (h / 4f) * i
                        drawLine(TechnicalGridLine, Offset(0f, y), Offset(w, y), 1f)
                    }

                    val dist = quality.particleDistribution
                    val stepX = w / (dist.size - 1)

                    val curve = Path()
                    dist.forEachIndexed { i, valPct ->
                        val x = i * stepX
                        val y = h - (valPct / 100f) * (h - 20f) - 10f
                        if (i == 0) curve.moveTo(x, y) else curve.lineTo(x, y)
                    }

                    drawPath(curve, color = TechGreen, style = Stroke(2.5f))

                    // Upper Spec Limit at 20 μm (D90)
                    val limitX = w * 0.72f
                    drawLine(
                        color = TechRed,
                        start = Offset(limitX, 0f),
                        end = Offset(limitX, h),
                        strokeWidth = 1.2f
                    )
                }

                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("0.5 μm (Fines)", style = MaterialTheme.typography.bodySmall, color = Graphite400, fontSize = 8.sp)
                    Text("18.2 μm (Mean D50)", style = MaterialTheme.typography.bodySmall, color = TechGreen, fontSize = 8.sp, fontWeight = FontWeight.Bold)
                    Text("USL: 20.0 μm Limit", style = MaterialTheme.typography.bodySmall, color = TechRed, fontSize = 8.sp)
                    Text("60.0 μm (Grit)", style = MaterialTheme.typography.bodySmall, color = Graphite400, fontSize = 8.sp)
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Historical Viscosity Consistency Trend
        Surface(
            shape = RoundedCornerShape(6.dp),
            color = TechnicalSurfaceCard,
            border = androidx.compose.foundation.BorderStroke(1.dp, TechnicalBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Text(
                    text = "CASSON VISCOSITY SHEAR THINNING TREND (CONCHING PHASE)",
                    style = MaterialTheme.typography.labelSmall,
                    color = Graphite200,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    quality.viscosityHistory.forEachIndexed { idx, v ->
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("${v} Pa·s", style = MaterialTheme.typography.labelSmall, color = TechCyan, fontFamily = FontFamily.Monospace)
                            Text("T+${idx * 2}h", style = MaterialTheme.typography.bodySmall, color = Graphite400, fontSize = 8.sp)
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Casson Model Rheogram Curve
        Surface(
            shape = RoundedCornerShape(6.dp),
            color = TechnicalSurfaceCard,
            border = androidx.compose.foundation.BorderStroke(1.dp, TechnicalBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "CASSON RHEOGRAM FLOW CURVE (τ vs γ̇)",
                        style = MaterialTheme.typography.labelSmall,
                        color = ChocolateGold,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "τ₀ = 12.4 Pa // η_ca = 2.41 Pa·s",
                        style = MaterialTheme.typography.bodySmall,
                        color = TechCyan,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 8.5.sp
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                Canvas(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(120.dp)
                        .clip(RoundedCornerShape(4.dp))
                        .background(Graphite950)
                        .border(1.dp, TechnicalBorder, RoundedCornerShape(4.dp))
                ) {
                    val w = size.width
                    val h = size.height

                    // Grid
                    for (i in 1..3) {
                        val y = (h / 4f) * i
                        drawLine(TechnicalGridLine, Offset(0f, y), Offset(w, y), 1f)
                    }

                    // Casson Curve: sqrt(tau) = sqrt(tau0) + sqrt(eta_ca) * sqrt(gamma)
                    // Tau = (sqrt(tau0) + sqrt(eta_ca) * sqrt(gamma))^2
                    val curve = Path()
                    val steps = 30
                    for (s in 0..steps) {
                        val gamma = (s / steps.toFloat()) * 100f // 0 to 100 s^-1
                        val tau = Math.pow(Math.sqrt(12.4) + Math.sqrt(2.41) * Math.sqrt(gamma.toDouble()), 2.0).toFloat()

                        val x = (s / steps.toFloat()) * w
                        val y = h - (tau / 350f) * (h - 20f) - 10f

                        if (s == 0) curve.moveTo(x, y) else curve.lineTo(x, y)
                    }

                    drawPath(curve, color = TechCyan, style = Stroke(2.5f))

                    // Yield stress threshold marker at gamma = 0
                    val yieldY = h - (12.4f / 350f) * (h - 20f) - 10f
                    drawCircle(color = TechAmber, radius = 4f, center = Offset(0f, yieldY))
                }

                Spacer(modifier = Modifier.height(4.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("γ̇ = 0 s⁻¹ (Yield Stress τ₀ = 12.4 Pa)", style = MaterialTheme.typography.bodySmall, color = TechAmber, fontSize = 8.sp)
                    Text("Shear Rate γ̇ = 100 s⁻¹", style = MaterialTheme.typography.bodySmall, color = Graphite400, fontSize = 8.sp)
                }
            }
        }
    }
}

@Composable
private fun QualityCard(
    title: String,
    value: String,
    target: String,
    status: String,
    color: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        shape = RoundedCornerShape(6.dp),
        color = TechnicalSurfaceCard,
        border = androidx.compose.foundation.BorderStroke(1.dp, TechnicalBorder),
        modifier = modifier
    ) {
        Column(modifier = Modifier.padding(10.dp)) {
            Text(
                text = title,
                style = MaterialTheme.typography.labelSmall,
                color = Graphite400,
                fontSize = 8.sp
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = value,
                style = MaterialTheme.typography.labelLarge,
                color = color,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                fontSize = 13.sp
            )
            Text(
                text = target,
                style = MaterialTheme.typography.bodySmall,
                color = Graphite400,
                fontSize = 8.sp
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = status,
                style = MaterialTheme.typography.bodySmall,
                color = color,
                fontWeight = FontWeight.SemiBold,
                fontSize = 8.sp
            )
        }
    }
}
