package com.example.ui.scada

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.model.AlertItem
import com.example.domain.model.AlertSeverity
import com.example.domain.model.MachineId
import com.example.ui.theme.*

@Composable
fun ScadaAlarmView(
    alerts: List<AlertItem>,
    onAcknowledge: (String) -> Unit,
    onDismiss: (String) -> Unit,
    onLocateMachine: (MachineId) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Graphite950)
            .padding(12.dp)
    ) {
        // Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "SCADA ALARM & EVENT MONITOR",
                    style = MaterialTheme.typography.titleMedium,
                    color = TechRed,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Real-time process limit violations // IEC-62682 Alarm Management",
                    style = MaterialTheme.typography.bodySmall,
                    color = Graphite400
                )
            }

            Surface(
                shape = RoundedCornerShape(4.dp),
                color = TechRed.copy(alpha = 0.15f),
                border = androidx.compose.foundation.BorderStroke(1.dp, TechRed.copy(alpha = 0.5f))
            ) {
                Text(
                    text = "${alerts.size} ACTIVE ALERTS",
                    style = MaterialTheme.typography.labelSmall,
                    color = TechRed,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        if (alerts.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(200.dp)
                    .clip(RoundedCornerShape(6.dp))
                    .background(TechnicalSurfaceCard)
                    .border(1.dp, TechnicalBorder, RoundedCornerShape(6.dp)),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Default.CheckCircle,
                        contentDescription = "All Clear",
                        tint = TechGreen,
                        modifier = Modifier.size(36.dp)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "ALL PROCESS PARAMETERS WITHIN NORMAL SPECIFICATIONS",
                        style = MaterialTheme.typography.labelMedium,
                        color = Graphite100
                    )
                    Text(
                        text = "No unacknowledged alarms in queue",
                        style = MaterialTheme.typography.bodySmall,
                        color = Graphite400
                    )
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(alerts) { alert ->
                    val color = when (alert.severity) {
                        AlertSeverity.CRITICAL -> TechRed
                        AlertSeverity.WARNING -> TechAmber
                        AlertSeverity.INFO -> TechCyan
                    }

                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = TechnicalSurfaceCard,
                        border = androidx.compose.foundation.BorderStroke(
                            1.dp,
                            if (alert.acknowledged) TechnicalBorder else color
                        ),
                        modifier = Modifier.fillMaxWidth().testTag("alarm_item_${alert.id}")
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Surface(
                                        shape = RoundedCornerShape(3.dp),
                                        color = color.copy(alpha = 0.2f),
                                        border = androidx.compose.foundation.BorderStroke(1.dp, color)
                                    ) {
                                        Text(
                                            text = alert.severity.name,
                                            style = MaterialTheme.typography.labelSmall,
                                            color = color,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 8.5.sp,
                                            modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                                        )
                                    }

                                    Text(
                                        text = alert.machineName,
                                        style = MaterialTheme.typography.labelMedium,
                                        color = Graphite100,
                                        fontWeight = FontWeight.Bold
                                    )
                                }

                                Text(
                                    text = alert.timestamp,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = Graphite400,
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 8.5.sp
                                )
                            }

                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = alert.title,
                                style = MaterialTheme.typography.titleMedium,
                                color = if (alert.acknowledged) Graphite200 else Color.White,
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(
                                text = alert.message,
                                style = MaterialTheme.typography.bodySmall,
                                color = Graphite300
                            )

                            Spacer(modifier = Modifier.height(6.dp))

                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(Graphite950)
                                    .padding(horizontal = 8.dp, vertical = 4.dp),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = "MEASURED: ${alert.valueStr}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = color,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 9.sp
                                )
                                Text(
                                    text = "LIMIT: ${alert.thresholdStr}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = Graphite400,
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 9.sp
                                )
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                if (!alert.acknowledged) {
                                    Button(
                                        onClick = { onAcknowledge(alert.id) },
                                        colors = ButtonDefaults.buttonColors(
                                            containerColor = Graphite800,
                                            contentColor = TechAmber
                                        ),
                                        shape = RoundedCornerShape(4.dp),
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Text("ACKNOWLEDGE", style = MaterialTheme.typography.labelSmall)
                                    }
                                }

                                Button(
                                    onClick = { onLocateMachine(alert.machineId) },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = Graphite800,
                                        contentColor = TechCyan
                                    ),
                                    shape = RoundedCornerShape(4.dp),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Text("LOCATE MACHINE", style = MaterialTheme.typography.labelSmall)
                                }

                                Button(
                                    onClick = { onDismiss(alert.id) },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = Graphite850,
                                        contentColor = Graphite400
                                    ),
                                    shape = RoundedCornerShape(4.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.DeleteOutline,
                                        contentDescription = "Dismiss",
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

val AlertItem.machineName: String
    get() = machineId.displayName.uppercase()
val Graphite300 = Color(0xFFB0BDCE)
