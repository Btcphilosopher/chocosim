package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.domain.model.MachineId
import com.example.ui.ChocoSimViewModel
import com.example.ui.FactoryViewMode
import com.example.ui.batches.BatchTrackerView
import com.example.ui.components.BackendConnectionDialog
import com.example.ui.components.IndustrialHeader
import com.example.ui.components.IndustrialNavigation
import com.example.ui.components.ScenarioPresetDialog
import com.example.ui.energy.EnergyFlowView
import com.example.ui.factory.FactoryMapCanvas
import com.example.ui.machines.MachineDetailDialog
import com.example.ui.machines.MachineTelemetryView
import com.example.ui.quality.QualityDashboardView
import com.example.ui.scada.ScadaAlarmView
import com.example.ui.simulation.SimulationView
import com.example.ui.tempering.TemperingProcessView
import com.example.ui.theme.Graphite950

@Composable
fun ChocoSimMainScreen(
    viewModel: ChocoSimViewModel = viewModel(),
    modifier: Modifier = Modifier
) {
    val currentMode by viewModel.currentViewMode.collectAsStateWithLifecycle()
    val zoomLevel by viewModel.zoomLevel.collectAsStateWithLifecycle()
    val selectedMachine by viewModel.selectedMachine.collectAsStateWithLifecycle()
    val machineMap by viewModel.machineMap.collectAsStateWithLifecycle()
    val overview by viewModel.overview.collectAsStateWithLifecycle()
    val quality by viewModel.quality.collectAsStateWithLifecycle()
    val temperingProfile by viewModel.temperingProfile.collectAsStateWithLifecycle()
    val batches by viewModel.batches.collectAsStateWithLifecycle()
    val selectedBatchId by viewModel.selectedBatchId.collectAsStateWithLifecycle()
    val alerts by viewModel.alerts.collectAsStateWithLifecycle()
    val flowStreams by viewModel.flowStreams.collectAsStateWithLifecycle()
    val simulationScenario by viewModel.simulationScenario.collectAsStateWithLifecycle()
    val whatIfResult by viewModel.whatIfResult.collectAsStateWithLifecycle()
    val isSimulatingFast by viewModel.isSimulatingFast.collectAsStateWithLifecycle()
    val simulationProgress by viewModel.simulationProgress.collectAsStateWithLifecycle()
    val backendState by viewModel.backendState.collectAsStateWithLifecycle()
    val backendLatency by viewModel.backendLatency.collectAsStateWithLifecycle()
    val panX by viewModel.canvasPanX.collectAsStateWithLifecycle()
    val panY by viewModel.canvasPanY.collectAsStateWithLifecycle()

    val showConnDialog by viewModel.showConnectionDialog.collectAsStateWithLifecycle()
    val showScenarioDialog by viewModel.showScenarioDialog.collectAsStateWithLifecycle()

    Scaffold(
        modifier = modifier
            .fillMaxSize()
            .background(Graphite950),
        topBar = {
            Column {
                IndustrialHeader(
                    overview = overview,
                    backendState = backendState,
                    backendLatency = backendLatency,
                    activeAlertCount = alerts.count { !it.acknowledged },
                    onOpenConnection = { viewModel.openConnectionDialog(true) },
                    onOpenScenarios = { viewModel.openScenarioDialog(true) },
                    onOpenAlarms = { viewModel.setViewMode(FactoryViewMode.SCADA_ALARMS) }
                )

                IndustrialNavigation(
                    currentMode = currentMode,
                    onSelectMode = { viewModel.setViewMode(it) }
                )
            }
        },
        contentWindowInsets = WindowInsets.safeDrawing
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(Graphite950)
        ) {
            when (currentMode) {
                FactoryViewMode.FACTORY_TWIN -> {
                    FactoryMapCanvas(
                        machines = machineMap,
                        flowStreams = flowStreams,
                        selectedMachine = selectedMachine,
                        zoomLevel = zoomLevel,
                        panX = panX,
                        panY = panY,
                        onPanChange = { dx, dy -> viewModel.updatePan(dx, dy) },
                        onZoomChange = { viewModel.setZoomLevel(it) },
                        onSelectMachine = { viewModel.selectMachine(it) },
                        onResetView = { viewModel.resetCanvasView() }
                    )
                }

                FactoryViewMode.TELEMETRY_MATRIX -> {
                    MachineTelemetryView(
                        machines = machineMap,
                        onSelectMachine = { viewModel.selectMachine(it) },
                        onTogglePower = { viewModel.toggleMachinePower(it) }
                    )
                }

                FactoryViewMode.TEMPERING_LAB -> {
                    TemperingProcessView(
                        profile = temperingProfile
                    )
                }

                FactoryViewMode.ENERGY_FLOW -> {
                    EnergyFlowView(
                        overview = overview,
                        machines = machineMap
                    )
                }

                FactoryViewMode.QUALITY_CONTROL -> {
                    QualityDashboardView(
                        quality = quality
                    )
                }

                FactoryViewMode.SIMULATION_WHAT_IF -> {
                    SimulationView(
                        scenario = simulationScenario,
                        whatIfResult = whatIfResult,
                        isSimulating = isSimulatingFast,
                        progress = simulationProgress,
                        onUpdateScenario = { viewModel.updateSimulationScenario(it) },
                        onRunSimulation = { viewModel.runWhatIfSimulation() }
                    )
                }

                FactoryViewMode.BATCH_TRACKER -> {
                    BatchTrackerView(
                        batches = batches,
                        selectedBatchId = selectedBatchId,
                        onSelectBatch = { viewModel.selectBatch(it) }
                    )
                }

                FactoryViewMode.SCADA_ALARMS -> {
                    ScadaAlarmView(
                        alerts = alerts,
                        onAcknowledge = { viewModel.acknowledgeAlert(it) },
                        onDismiss = { viewModel.dismissAlert(it) },
                        onLocateMachine = { id ->
                            viewModel.selectMachineById(id)
                            viewModel.setViewMode(FactoryViewMode.FACTORY_TWIN)
                        }
                    )
                }
            }

            // Machine Detail Inspection Dialog
            if (selectedMachine != null) {
                MachineDetailDialog(
                    telemetry = selectedMachine!!,
                    onDismiss = { viewModel.selectMachine(null) },
                    onSetStatus = { id, st -> viewModel.setMachineStatus(id, st) },
                    onSetTargetTemp = { id, t -> viewModel.setMachineTargetTemp(id, t) },
                    onSetTargetRpm = { id, r -> viewModel.setMachineTargetRpm(id, r) }
                )
            }

            // Connection Dialog
            if (showConnDialog) {
                BackendConnectionDialog(
                    connectionState = backendState,
                    restUrl = "http://127.0.0.1:8080/api/v1",
                    wsUrl = "ws://127.0.0.1:8080/telemetry/ws",
                    onDismiss = { viewModel.openConnectionDialog(false) },
                    onConnect = {
                        viewModel.connectToBackend()
                        viewModel.openConnectionDialog(false)
                    },
                    onSwitchDemo = {
                        viewModel.disconnectToDemoMode()
                        viewModel.openConnectionDialog(false)
                    }
                )
            }

            // Scenario Preset Dialog
            if (showScenarioDialog) {
                ScenarioPresetDialog(
                    onDismiss = { viewModel.openScenarioDialog(false) },
                    onInject = { viewModel.injectScenario(it) }
                )
            }
        }
    }
}
