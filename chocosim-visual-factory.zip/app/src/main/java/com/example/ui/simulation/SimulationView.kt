package com.example.ui.simulation

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.model.SimulationScenario
import com.example.domain.model.WhatIfResult
import com.example.ui.theme.*

@Composable
fun SimulationView(
    scenario: SimulationScenario,
    whatIfResult: WhatIfResult?,
    isSimulating: Boolean,
    progress: Float,
    onUpdateScenario: (SimulationScenario) -> Unit,
    onRunSimulation: () -> Unit,
    modifier: Modifier = Modifier
) {
    var cocoaPrice by remember(scenario) { mutableDoubleStateOf(scenario.cocoaPricePerTon) }
    var energyPrice by remember(scenario) { mutableDoubleStateOf(scenario.energyPricePerKwh) }
    var speedMultiplier by remember(scenario) { mutableDoubleStateOf(scenario.machineSpeedMultiplier) }
    var demandKg by remember(scenario) { mutableDoubleStateOf(scenario.demandKgDay) }
    var conchingHours by remember(scenario) { mutableDoubleStateOf(scenario.conchingDurationHours) }
    var temperingMinutes by remember(scenario) { mutableDoubleStateOf(scenario.temperingDurationMin) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Graphite950)
            .padding(12.dp)
            .verticalScroll(rememberScrollState())
    ) {
        // Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "WHAT-IF SIMULATION & OPTIMIZER SANDBOX",
                    style = MaterialTheme.typography.titleMedium,
                    color = TechAmber,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "High-speed computational simulation // Python Manufacturing Engine Twin",
                    style = MaterialTheme.typography.bodySmall,
                    color = Graphite400
                )
            }

            Button(
                onClick = {
                    onUpdateScenario(
                        scenario.copy(
                            cocoaPricePerTon = cocoaPrice,
                            energyPricePerKwh = energyPrice,
                            machineSpeedMultiplier = speedMultiplier,
                            demandKgDay = demandKg,
                            conchingDurationHours = conchingHours,
                            temperingDurationMin = temperingMinutes
                        )
                    )
                    onRunSimulation()
                },
                enabled = !isSimulating,
                colors = ButtonDefaults.buttonColors(
                    containerColor = TechAmber,
                    contentColor = Graphite950
                ),
                shape = RoundedCornerShape(4.dp),
                modifier = Modifier.testTag("run_simulation_button")
            ) {
                Icon(
                    imageVector = Icons.Default.PlayArrow,
                    contentDescription = "Run",
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = if (isSimulating) "PROCESSING..." else "RUN SIMULATION",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        // Progress Bar while calculating
        AnimatedVisibility(visible = isSimulating) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp)
                    .clip(RoundedCornerShape(4.dp))
                    .background(Graphite900)
                    .border(1.dp, TechAmber, RoundedCornerShape(4.dp))
                    .padding(10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "SIMULATION RUNNING (TIME WARP 100x)",
                        style = MaterialTheme.typography.labelSmall,
                        color = TechAmber,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "08:42 → 14:32 // ${(progress * 100).toInt()}%",
                        style = MaterialTheme.typography.bodySmall,
                        color = Graphite100
                    )
                }
                Spacer(modifier = Modifier.height(4.dp))
                LinearProgressIndicator(
                    progress = { progress },
                    modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)),
                    color = TechAmber,
                    trackColor = Graphite800
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Scenario Input Controls
        Surface(
            shape = RoundedCornerShape(6.dp),
            color = TechnicalSurfaceCard,
            border = androidx.compose.foundation.BorderStroke(1.dp, TechnicalBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Text(
                    text = "SIMULATION PARAMETERS & TARIFF VARIABLES",
                    style = MaterialTheme.typography.labelSmall,
                    color = Graphite200,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Cocoa Price
                SliderParamRow(
                    label = "COCOA MARKET PRICE ($ / ton):",
                    valueStr = "$ ${cocoaPrice.toInt()}",
                    value = cocoaPrice.toFloat(),
                    range = 4000f..12000f,
                    onValueChange = { cocoaPrice = it.toDouble() },
                    color = ChocolateTempered
                )

                // Energy Price
                SliderParamRow(
                    label = "ENERGY TARIFF ($ / kWh):",
                    valueStr = "$ ${String.format("%.2f", energyPrice)}",
                    value = energyPrice.toFloat(),
                    range = 0.10f..0.60f,
                    onValueChange = { energyPrice = it.toDouble() },
                    color = TechCyan
                )

                // Machine Speed Multiplier
                SliderParamRow(
                    label = "LINE SPEED MULTIPLIER:",
                    valueStr = "${String.format("%.2f", speedMultiplier)}x",
                    value = speedMultiplier.toFloat(),
                    range = 0.5f..1.5f,
                    onValueChange = { speedMultiplier = it.toDouble() },
                    color = TechGreen
                )

                // Daily Demand
                SliderParamRow(
                    label = "TARGET DEMAND (kg / day):",
                    valueStr = "${(demandKg / 1000).toInt()} t",
                    value = demandKg.toFloat(),
                    range = 40000f..120000f,
                    onValueChange = { demandKg = it.toDouble() },
                    color = Graphite100
                )

                // Conching Time
                SliderParamRow(
                    label = "CONCHING DURATION (hours):",
                    valueStr = "${String.format("%.1f", conchingHours)} h",
                    value = conchingHours.toFloat(),
                    range = 4f..24f,
                    onValueChange = { conchingHours = it.toDouble() },
                    color = ChocolateRoasted
                )
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Side-by-Side What-If Comparison Matrix
        val res = whatIfResult ?: WhatIfResult()

        Surface(
            shape = RoundedCornerShape(6.dp),
            color = TechnicalSurfaceCard,
            border = androidx.compose.foundation.BorderStroke(1.dp, TechAmber.copy(alpha = 0.6f)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "WHAT-IF COMPARISON: BASELINE vs SIMULATED OPTIMIZATION",
                        style = MaterialTheme.typography.labelSmall,
                        color = TechAmber,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "DELTA IMPACT",
                        style = MaterialTheme.typography.labelSmall,
                        color = TechGreen,
                        fontWeight = FontWeight.Bold
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Table Header
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(3.dp))
                        .background(Graphite950)
                        .padding(horizontal = 8.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("METRIC", style = MaterialTheme.typography.labelSmall, color = Graphite400, modifier = Modifier.weight(1.5f))
                    Text("CURRENT", style = MaterialTheme.typography.labelSmall, color = Graphite400, modifier = Modifier.weight(1f))
                    Text("SIMULATED", style = MaterialTheme.typography.labelSmall, color = TechAmber, modifier = Modifier.weight(1f))
                    Text("DELTA", style = MaterialTheme.typography.labelSmall, color = TechGreen, modifier = Modifier.weight(0.8f))
                }

                Spacer(modifier = Modifier.height(4.dp))

                ComparisonRow(
                    label = "Total Production",
                    current = "${String.format("%,.0f", res.baselineProductionKg)} kg",
                    simulated = "${String.format("%,.0f", res.simulatedProductionKg)} kg",
                    delta = "+${String.format("%.1f", (res.simulatedProductionKg - res.baselineProductionKg) / res.baselineProductionKg * 100)}%",
                    isPositive = res.simulatedProductionKg >= res.baselineProductionKg
                )

                ComparisonRow(
                    label = "Specific Energy",
                    current = "${res.baselineEnergyKwhKg} kWh/kg",
                    simulated = "${res.simulatedEnergyKwhKg} kWh/kg",
                    delta = "${String.format("%.1f", (res.simulatedEnergyKwhKg - res.baselineEnergyKwhKg) / res.baselineEnergyKwhKg * 100)}%",
                    isPositive = res.simulatedEnergyKwhKg <= res.baselineEnergyKwhKg
                )

                ComparisonRow(
                    label = "Waste Factor",
                    current = "${res.baselineWastePercent}%",
                    simulated = "${res.simulatedWastePercent}%",
                    delta = "${String.format("%.1f", res.simulatedWastePercent - res.baselineWastePercent)}%",
                    isPositive = res.simulatedWastePercent <= res.baselineWastePercent
                )

                ComparisonRow(
                    label = "Line Utilisation",
                    current = "${res.baselineUtilisationPercent.toInt()}%",
                    simulated = "${res.simulatedUtilisationPercent.toInt()}%",
                    delta = "+${(res.simulatedUtilisationPercent - res.baselineUtilisationPercent).toInt()}%",
                    isPositive = res.simulatedUtilisationPercent >= res.baselineUtilisationPercent
                )

                ComparisonRow(
                    label = "Manufacturing Cost",
                    current = "$ ${res.baselineCostPerKg}/kg",
                    simulated = "$ ${res.simulatedCostPerKg}/kg",
                    delta = "${String.format("%.1f", (res.simulatedCostPerKg - res.baselineCostPerKg) / res.baselineCostPerKg * 100)}%",
                    isPositive = res.simulatedCostPerKg <= res.baselineCostPerKg
                )
            }
        }
    }
}

@Composable
private fun SliderParamRow(
    label: String,
    valueStr: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    onValueChange: (Float) -> Unit,
    color: Color
) {
    Column(modifier = Modifier.padding(vertical = 4.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(label, style = MaterialTheme.typography.bodySmall, color = Graphite200, fontSize = 8.5.sp)
            Text(valueStr, style = MaterialTheme.typography.labelMedium, color = color, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
        }
        Slider(
            value = value,
            onValueChange = onValueChange,
            valueRange = range,
            colors = SliderDefaults.colors(
                thumbColor = color,
                activeTrackColor = color,
                inactiveTrackColor = Graphite800
            )
        )
    }
}

@Composable
private fun ComparisonRow(
    label: String,
    current: String,
    simulated: String,
    delta: String,
    isPositive: Boolean
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 8.dp, vertical = 5.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, style = MaterialTheme.typography.bodySmall, color = Graphite200, modifier = Modifier.weight(1.5f), fontSize = 9.sp)
        Text(current, style = MaterialTheme.typography.bodySmall, color = Graphite400, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1f), fontSize = 9.sp)
        Text(simulated, style = MaterialTheme.typography.bodySmall, color = TechAmber, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f), fontSize = 9.sp)
        Text(delta, style = MaterialTheme.typography.bodySmall, color = if (isPositive) TechGreen else TechRed, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(0.8f), fontSize = 9.sp)
    }
}
