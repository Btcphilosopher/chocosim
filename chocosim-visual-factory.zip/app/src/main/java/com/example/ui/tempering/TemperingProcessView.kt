package com.example.ui.tempering

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.*
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.model.TemperingProfile
import com.example.ui.theme.*

@OptIn(ExperimentalTextApi::class)
@Composable
fun TemperingProcessView(
    profile: TemperingProfile,
    modifier: Modifier = Modifier
) {
    val textMeasurer = rememberTextMeasurer()

    val infiniteTransition = rememberInfiniteTransition(label = "crystalPulse")
    val pulseAlpha by infiniteTransition.animateFloat(
        initialValue = 0.5f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulseAlpha"
    )

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Graphite950)
            .padding(12.dp)
            .verticalScroll(rememberScrollState())
    ) {
        // Section Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "CONTINUOUS TEMPERING & CRYSTALLISATION LAB",
                    style = MaterialTheme.typography.titleMedium,
                    color = TechAmber,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Beta-V (Form V) Polymorph Seed Nucleation & Thermodynamic State",
                    style = MaterialTheme.typography.bodySmall,
                    color = Graphite400
                )
            }

            Surface(
                shape = RoundedCornerShape(4.dp),
                color = TechGreen.copy(alpha = 0.2f),
                border = androidx.compose.foundation.BorderStroke(1.dp, TechGreen)
            ) {
                Text(
                    text = profile.status,
                    style = MaterialTheme.typography.labelSmall,
                    color = TechGreen,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Dynamic 4-Zone Temperature Curve Canvas
        Surface(
            shape = RoundedCornerShape(6.dp),
            color = TechnicalSurfaceCard,
            border = androidx.compose.foundation.BorderStroke(1.dp, TechnicalBorder),
            modifier = Modifier
                .fillMaxWidth()
                .testTag("tempering_curve_panel")
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "CONTINUOUS 4-ZONE TEMPERING THERMAL CURVE",
                        style = MaterialTheme.typography.labelSmall,
                        color = Graphite200,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "LIVE TEMP: ${String.format("%.1f", profile.currentTemp)} °C",
                        style = MaterialTheme.typography.labelSmall,
                        color = TechAmber,
                        fontWeight = FontWeight.Bold
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Canvas Curve
                Canvas(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(180.dp)
                        .clip(RoundedCornerShape(4.dp))
                        .background(Graphite950)
                        .border(1.dp, TechnicalBorder, RoundedCornerShape(4.dp))
                ) {
                    val w = size.width
                    val h = size.height

                    // Grid
                    for (i in 1..4) {
                        val y = (h / 5f) * i
                        drawLine(
                            color = TechnicalGridLine,
                            start = Offset(0f, y),
                            end = Offset(w, y),
                            strokeWidth = 1f
                        )
                    }

                    // 4 Zone Vertical Backgrounds
                    val zW = w / 4f
                    val zoneLabels = listOf(
                        "ZONE 1: MELTING\n(50.0°C - Decrystallise)",
                        "ZONE 2: PRE-COOL\n(32.0°C - Sensible cooling)",
                        "ZONE 3: CRYSTALLISE\n(27.5°C - Beta V Seeds)",
                        "ZONE 4: REHEAT\n(31.5°C - Working Form V)"
                    )

                    val zoneColors = listOf(
                        TechOrange.copy(alpha = 0.08f),
                        TechCyan.copy(alpha = 0.08f),
                        TechBlue.copy(alpha = 0.15f),
                        TechAmber.copy(alpha = 0.12f)
                    )

                    for (z in 0..3) {
                        drawRect(
                            color = zoneColors[z],
                            topLeft = Offset(z * zW, 0f),
                            size = Size(zW, h)
                        )
                        drawLine(
                            color = TechnicalBorder.copy(alpha = 0.5f),
                            start = Offset(z * zW, 0f),
                            end = Offset(z * zW, h),
                            strokeWidth = 1f
                        )

                        // Zone text
                        val zLayout = textMeasurer.measure(
                            text = AnnotatedString(zoneLabels[z]),
                            style = TextStyle(
                                color = Graphite400,
                                fontSize = 8.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        )
                        drawText(zLayout, topLeft = Offset(z * zW + 6f, 8f))
                    }

                    // The Scientific Tempering Curve Path
                    // Zone 1 (50°C), Zone 2 (32°C), Zone 3 (27.5°C), Zone 4 (31.5°C)
                    // Map 20°C (h - 20) to 55°C (top + 20)
                    fun tempToY(temp: Float): Float {
                        val minT = 22f
                        val maxT = 55f
                        return h - ((temp - minT) / (maxT - minT)) * (h - 40f) - 20f
                    }

                    val p1 = Offset(zW * 0.2f, tempToY(50f))
                    val p2 = Offset(zW * 0.8f, tempToY(50f))
                    val p3 = Offset(zW * 1.8f, tempToY(32f))
                    val p4 = Offset(zW * 2.8f, tempToY(27.5f))
                    val p5 = Offset(zW * 3.8f, tempToY(31.5f))

                    val curvePath = Path().apply {
                        moveTo(0f, p1.y)
                        lineTo(p2.x, p2.y)
                        cubicTo(zW * 1.2f, p2.y, zW * 1.4f, p3.y, p3.x, p3.y)
                        cubicTo(zW * 2.2f, p3.y, zW * 2.4f, p4.y, p4.x, p4.y)
                        cubicTo(zW * 3.2f, p4.y, zW * 3.4f, p5.y, p5.x, p5.y)
                        lineTo(w, p5.y)
                    }

                    // Draw Gradient Fill under curve
                    val fillPath = Path().apply {
                        addPath(curvePath)
                        lineTo(w, h)
                        lineTo(0f, h)
                        close()
                    }
                    drawPath(
                        path = fillPath,
                        brush = Brush.verticalGradient(
                            listOf(ChocolateTempered.copy(alpha = 0.35f), Color.Transparent)
                        )
                    )

                    // Draw Stroke Line
                    drawPath(
                        path = curvePath,
                        color = TechAmber,
                        style = Stroke(width = 2.5f)
                    )

                    // Operating Point Circle
                    val activeY = tempToY(profile.currentTemp.toFloat())
                    drawCircle(
                        color = TechAmber.copy(alpha = 0.4f * pulseAlpha),
                        radius = 10f,
                        center = Offset(p5.x, activeY)
                    )
                    drawCircle(
                        color = Color.White,
                        radius = 4f,
                        center = Offset(p5.x, activeY)
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Phase Legend
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    PhaseLegendItem(color = TechOrange, text = "1. Complete Melt (50°C)")
                    PhaseLegendItem(color = TechCyan, text = "2. Cool (32°C)")
                    PhaseLegendItem(color = TechBlue, text = "3. Seed β-V (27.5°C)")
                    PhaseLegendItem(color = TechAmber, text = "4. Reheat (31.5°C)")
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Beta-V Crystal Index & Tempermeter Analysis
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Crystal Polymorphism Meter
            Surface(
                shape = RoundedCornerShape(6.dp),
                color = TechnicalSurfaceCard,
                border = androidx.compose.foundation.BorderStroke(1.dp, TechnicalBorder),
                modifier = Modifier.weight(1f)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text(
                        text = "CRYSTAL POLYMORPH DISTRIBUTION",
                        style = MaterialTheme.typography.labelSmall,
                        color = Graphite400
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    CrystalBarItem(label = "Form V (β2) - Optimal Gloss & Snap", percent = profile.betaVCrystalIndex.toInt(), color = TechGreen)
                    CrystalBarItem(label = "Form IV (β') - Unstable soft", percent = 4, color = TechAmber)
                    CrystalBarItem(label = "Form VI (β1) - Bloom fat crystal", percent = 1, color = TechRed)

                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Beta V Index: ${profile.betaVCrystalIndex}% (Target > 90%)",
                        style = MaterialTheme.typography.bodySmall,
                        color = TechGreen,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            // Tempermeter Slope (CTI)
            Surface(
                shape = RoundedCornerShape(6.dp),
                color = TechnicalSurfaceCard,
                border = androidx.compose.foundation.BorderStroke(1.dp, TechnicalBorder),
                modifier = Modifier.weight(1f)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text(
                        text = "TEMPERMETER (CTI SLOPE)",
                        style = MaterialTheme.typography.labelSmall,
                        color = Graphite400
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = "CTI: ${profile.temperSlopeCti} °C/min",
                        style = MaterialTheme.typography.titleMedium,
                        color = TechCyan,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    )

                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Optimal Range: 1.2 to 1.6 °C/min\nSlope status: PERFECT TEMPER\nContraction potential: 99.2%",
                        style = MaterialTheme.typography.bodySmall,
                        color = Graphite200,
                        lineHeight = 16.sp
                    )
                }
            }
        }
    }
}

@Composable
private fun PhaseLegendItem(color: Color, text: String) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        Box(modifier = Modifier.size(6.dp).clip(RoundedCornerShape(1.dp)).background(color))
        Text(text = text, style = MaterialTheme.typography.bodySmall, color = Graphite200, fontSize = 8.5.sp)
    }
}

@Composable
private fun CrystalBarItem(label: String, percent: Int, color: Color) {
    Column(modifier = Modifier.padding(vertical = 3.dp)) {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(text = label, style = MaterialTheme.typography.bodySmall, color = Graphite200, fontSize = 8.5.sp)
            Text(text = "$percent%", style = MaterialTheme.typography.bodySmall, color = color, fontWeight = FontWeight.Bold, fontSize = 8.5.sp)
        }
        Spacer(modifier = Modifier.height(2.dp))
        LinearProgressIndicator(
            progress = { percent / 100f },
            modifier = Modifier.fillMaxWidth().height(4.dp).clip(RoundedCornerShape(2.dp)),
            color = color,
            trackColor = Graphite800
        )
    }
}
