package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Industrial Dark Graphite Palette
val Graphite950 = Color(0xFF090B0E)
val Graphite900 = Color(0xFF0F1217)
val Graphite850 = Color(0xFF151921)
val Graphite800 = Color(0xFF1B212C)
val Graphite750 = Color(0xFF232A38)
val Graphite700 = Color(0xFF2E3748)
val Graphite600 = Color(0xFF424E63)
val Graphite400 = Color(0xFF718096)
val Graphite200 = Color(0xFFA0AEC0)
val Graphite100 = Color(0xFFCBD5E1)
val Graphite50 = Color(0xFFF1F5F9)

// Chocolate Material Scale (Liquid, Paste, Solid)
val ChocolateRaw = Color(0xFF381E11)
val ChocolateRoasted = Color(0xFF5A311A)
val ChocolateLiquor = Color(0xFF7C4223)
val ChocolateRefined = Color(0xFF9E562E)
val ChocolateTempered = Color(0xFFC46E3A)
val ChocolateMilk = Color(0xFFDDA15E)
val ChocolateGold = Color(0xFFE9C46A)

// Scientific & Industrial Status Colors
val TechCyan = Color(0xFF38BDF8)
val TechBlue = Color(0xFF60A5FA)
val TechAmber = Color(0xFFF59E0B)
val TechOrange = Color(0xFFF97316)
val TechGreen = Color(0xFF10B981)
val TechRed = Color(0xFFEF4444)
val TechPurple = Color(0xFFA855F7)

// Grid and Structural Line Colors
val TechnicalGridLine = Color(0xFF1E293B)
val TechnicalBorder = Color(0xFF334155)
val TechnicalBorderHighlight = Color(0xFF475569)
val TechnicalSurface = Color(0xFF13171F)
val TechnicalSurfaceCard = Color(0xFF181D26)
val TechnicalSurfaceElevated = Color(0xFF202633)
