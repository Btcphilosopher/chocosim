package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkIndustrialColorScheme = darkColorScheme(
    primary = TechAmber,
    onPrimary = Graphite950,
    primaryContainer = ChocolateRoasted,
    onPrimaryContainer = Graphite50,
    secondary = TechCyan,
    onSecondary = Graphite950,
    secondaryContainer = Graphite750,
    onSecondaryContainer = Graphite100,
    tertiary = ChocolateTempered,
    onTertiary = Graphite950,
    background = Graphite950,
    onBackground = Graphite100,
    surface = TechnicalSurface,
    onSurface = Graphite100,
    surfaceVariant = TechnicalSurfaceCard,
    onSurfaceVariant = Graphite200,
    outline = TechnicalBorder,
    outlineVariant = TechnicalGridLine,
    error = TechRed,
    onError = Color.White
)

@Composable
fun ChocoSimTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = DarkIndustrialColorScheme,
        typography = Typography,
        content = content
    )
}
