"""FastAPI service exposing the simulator."""

from .app import app, create_app

__all__ = ["app", "create_app"]
