"""FastAPI service.

Exposes the endpoints the specification asks for. Two design decisions worth
stating.

**Every response carries its provenance.** A caller receiving a cost per
kilogram over HTTP has no way to see the docstrings and caveats that surround
the model, so the fidelity banner travels with the payload. A number that
leaves the process without its epistemic status attached is a number that will
eventually be quoted as fact.

**Long-running work is bounded.** A Monte Carlo request with ten thousand
replications would tie up a worker for minutes, so replication counts are
capped and the cap is reported rather than silently applied.
"""

from __future__ import annotations

import datetime as dt
from typing import Any

from fastapi import FastAPI, HTTPException, Query
from pydantic import BaseModel, Field

from ..core.config import ChocoSimConfig
from ..core.types import Kilograms, RecipeId
from ..ingredients.registry import build_default_registry
from ..optimisation.factory_opt import FactoryOptimiser
from ..optimisation.solvers import (
    ProductionScheduler,
    RecipeOptimiser,
    ScheduleJob,
)
from ..production.factory import Factory
from ..recipes.engine import RecipeEngine
from ..recipes.library import build_standard_book
from ..simulation.scenarios import (
    MonteCarloEngine,
    ScenarioEngine,
    cocoa_price_rise,
    energy_price_rise,
    standard_scenarios,
    sugar_price_rise,
)

#: Ceiling on Monte Carlo replications accepted over the API.
MAX_REPLICATIONS: int = 200

#: Ceiling on batches in a single simulation request.
MAX_BATCHES: int = 60


# --------------------------------------------------------------------------
# Request and response schemas
# --------------------------------------------------------------------------


class BatchRequest(BaseModel):
    """One batch in a production programme."""

    recipe_id: RecipeId
    mass_kg: Kilograms = Field(gt=0.0, le=20_000.0)


class SimulationRequest(BaseModel):
    """Request to run a production simulation."""

    batches: list[BatchRequest] = Field(min_length=1)
    seed: int | None = None
    deterministic: bool = True
    start_date: dt.date | None = None
    pack_format_id: str | None = "PKG-BAR-100"
    replications: int = Field(default=1, ge=1)


class OptimisationRequest(BaseModel):
    """Request to optimise a production programme."""

    batches: list[BatchRequest] = Field(min_length=1)
    horizon_hours: float = Field(default=168.0, gt=0.0, le=8_760.0)
    optimise_recipes: bool = False
    max_deviation: float = Field(default=0.20, gt=0.0, le=0.9)


class ScenarioRequest(BaseModel):
    """Request to run what-if scenarios."""

    batches: list[BatchRequest] = Field(min_length=1)
    cocoa_multiplier: float | None = Field(default=None, gt=0.0, le=10.0)
    sugar_multiplier: float | None = Field(default=None, gt=0.0, le=10.0)
    energy_multiplier: float | None = Field(default=None, gt=0.0, le=10.0)
    use_standard_scenarios: bool = False
    start_date: dt.date | None = None


def _provenance_payload(provenance: Any) -> dict[str, Any]:
    """Serialise a provenance record for transport."""
    return {
        "model": provenance.model_name,
        "fidelity": provenance.fidelity.label,
        "basis": provenance.basis,
        "assumptions": list(provenance.assumptions),
        "caveats": list(provenance.caveats),
    }


def create_app(config: ChocoSimConfig | None = None) -> FastAPI:
    """Build the ChocoSim API application."""
    base_config = config or ChocoSimConfig.default()
    recipe_book = build_standard_book()

    app = FastAPI(
        title="ChocoSim",
        version="1.0.0",
        description=(
            "Chocolate manufacturing simulator. Every response carries a "
            "fidelity banner: outputs are SIMULATION grade unless explicitly "
            "stated otherwise, and are not validated against a real plant."
        ),
    )

    def _factory(seed: int | None = None, deterministic: bool = True) -> Factory:
        run_config = base_config.model_copy(deep=True)
        if seed is not None:
            run_config.simulation.seed = seed
        run_config.simulation.deterministic = deterministic
        if deterministic:
            run_config.simulation.enable_breakdowns = False
        return Factory(run_config, build_default_registry(), recipe_book)

    # ------------------------------------------------------------------
    # Metadata
    # ------------------------------------------------------------------

    @app.get("/", tags=["meta"])
    def root() -> dict[str, Any]:
        """Service description and the fidelity statement."""
        return {
            "service": "ChocoSim",
            "version": "1.0.0",
            "fidelity": (
                "All outputs are SIMULATION grade. Models are physically "
                "motivated but not calibrated against, or validated on, any "
                "real plant. Do not use for process control, food safety "
                "decisions, or regulatory submissions."
            ),
            "endpoints": [
                "POST /simulation/run",
                "POST /optimisation/run",
                "POST /scenario/run",
                "GET /factory/state",
                "GET /inventory",
                "GET /production",
                "GET /economics",
                "GET /recipes",
                "GET /recipes/{recipe_id}",
                "GET /ingredients",
            ],
        }

    @app.get("/health", tags=["meta"])
    def health() -> dict[str, str]:
        """Liveness check."""
        return {"status": "ok"}

    # ------------------------------------------------------------------
    # Reference data
    # ------------------------------------------------------------------

    @app.get("/recipes", tags=["recipes"])
    def list_recipes() -> dict[str, Any]:
        """Every current recipe with its headline analysis."""
        registry = build_default_registry()
        engine = RecipeEngine(registry)
        recipes = []
        for recipe in recipe_book.current_recipes():
            base, _ = engine.base_composition(recipe)
            recipes.append(
                {
                    "recipe_id": recipe.recipe_id,
                    "version": recipe.version,
                    "name": recipe.name,
                    "type": recipe.chocolate_type.value,
                    "cocoa_solids": round(base.total_cocoa_solids, 4),
                    "ingredient_cost_per_kg": round(engine.cost_per_kg(recipe), 4),
                    "compliant": engine.check_compliance(recipe).compliant,
                    "default_batch_kg": recipe.default_batch_size_kg,
                }
            )
        return {"count": len(recipes), "recipes": recipes}

    @app.get("/recipes/{recipe_id}", tags=["recipes"])
    def get_recipe(recipe_id: str, batch_kg: float = Query(1000.0, gt=0.0)) -> dict[str, Any]:
        """Full analysis of one recipe."""
        if recipe_id not in recipe_book:
            raise HTTPException(status_code=404, detail=f"Unknown recipe {recipe_id!r}")
        registry = build_default_registry()
        engine = RecipeEngine(registry)
        recipe = recipe_book.get(recipe_id)
        analysis = engine.analyse(recipe, batch_kg)
        return {
            "recipe_id": recipe.recipe_id,
            "name": recipe.name,
            "version": recipe.version,
            "type": recipe.chocolate_type.value,
            "components": [
                {
                    "ingredient_id": component.ingredient_id,
                    "percent": round(component.percent, 4),
                    "added_at_stage": component.added_at_stage,
                }
                for component in recipe.components
            ],
            "composition": analysis.composition.as_dict(),
            "base_composition": analysis.base_composition.as_dict(),
            "nutrition_per_100g": analysis.nutrition.model_dump(),
            "compliance": {
                "compliant": analysis.compliance.compliant,
                "failures": analysis.compliance.failures,
            },
            "ingredient_cost_per_kg": round(analysis.ingredient_cost_per_kg, 4),
            "theoretical_yield_kg": round(analysis.theoretical_yield_kg, 3),
            "provenance": _provenance_payload(analysis.provenance),
        }

    @app.get("/ingredients", tags=["ingredients"])
    def list_ingredients() -> dict[str, Any]:
        """The ingredient catalogue with current prices."""
        registry = build_default_registry()
        return {
            "count": len(registry),
            "ingredients": [
                {
                    "ingredient_id": ingredient.ingredient_id,
                    "name": ingredient.name,
                    "class": ingredient.ingredient_class.value,
                    "cost_per_kg": round(
                        registry.unit_cost(ingredient.ingredient_id), 4
                    ),
                    "fat": ingredient.composition.fat,
                    "moisture": ingredient.composition.moisture,
                    "shelf_life_days": ingredient.shelf_life_days,
                    "allergens": list(ingredient.allergens),
                }
                for ingredient in registry
            ],
        }

    # ------------------------------------------------------------------
    # Simulation
    # ------------------------------------------------------------------

    @app.post("/simulation/run", tags=["simulation"])
    def run_simulation(request: SimulationRequest) -> dict[str, Any]:
        """Run a production programme through the factory."""
        if len(request.batches) > MAX_BATCHES:
            raise HTTPException(
                status_code=422,
                detail=f"At most {MAX_BATCHES} batches per request.",
            )
        for batch in request.batches:
            if batch.recipe_id not in recipe_book:
                raise HTTPException(
                    status_code=404, detail=f"Unknown recipe {batch.recipe_id!r}"
                )

        start = request.start_date or dt.date.today()
        schedule = [(batch.recipe_id, batch.mass_kg) for batch in request.batches]

        if request.replications > 1:
            replications = min(request.replications, MAX_REPLICATIONS)
            engine = MonteCarloEngine(
                _factory(request.seed, False).config, recipe_book
            )
            report = engine.run(schedule, start, replications=replications)
            return {
                "mode": "monte_carlo",
                "replications": report.replications,
                "replications_requested": request.replications,
                "replications_capped": request.replications > MAX_REPLICATIONS,
                "results": {
                    name: {
                        "p10": round(result.p10, 6),
                        "p50": round(result.p50, 6),
                        "p90": round(result.p90, 6),
                        "mean": round(result.mean, 6),
                        "std": round(result.std, 6),
                    }
                    for name, result in report.results.items()
                },
                "provenance": _provenance_payload(report.provenance),
            }

        factory = _factory(request.seed, request.deterministic)
        factory.stock_up(start, days_of_cover=45.0, daily_demand_kg=10_000.0)
        outcomes = factory.produce_schedule(
            schedule, start, pack_format_id=request.pack_format_id
        )
        state = factory.state(start)

        return {
            "mode": "single",
            "batches": [
                {
                    "batch_id": outcome.batch_id,
                    "recipe_id": outcome.recipe_id,
                    "recipe_name": outcome.recipe_name,
                    "saleable_kg": round(outcome.saleable_kg, 3),
                    "quality_score": round(outcome.quality.overall_score, 2),
                    "verdict": outcome.quality.verdict.value,
                    "temper_grade": outcome.quality.temper_grade.value,
                    "energy_kwh_per_kg": round(outcome.energy_kwh_per_kg, 5),
                    "cost_per_kg": round(outcome.cost_per_kg, 5),
                    "units": outcome.units_produced,
                    "warnings": list(outcome.process.notes),
                }
                for outcome in outcomes
            ],
            "state": state.model_dump(mode="json", exclude={"provenance"}),
            "provenance": _provenance_payload(state.provenance),
        }

    @app.post("/optimisation/run", tags=["optimisation"])
    def run_optimisation(request: OptimisationRequest) -> dict[str, Any]:
        """Optimise a production programme and report the improvement."""
        for batch in request.batches:
            if batch.recipe_id not in recipe_book:
                raise HTTPException(
                    status_code=404, detail=f"Unknown recipe {batch.recipe_id!r}"
                )

        programme = [(batch.recipe_id, batch.mass_kg) for batch in request.batches]
        optimiser = FactoryOptimiser(base_config, recipe_book)
        result = optimiser.optimise(programme, horizon_hours=request.horizon_hours)

        payload: dict[str, Any] = {
            "current": result.current.model_dump(),
            "optimised": result.optimised.model_dump(),
            "capacity_gain": round(result.capacity_gain, 5),
            "levers": [lever.model_dump() for lever in result.levers],
            "schedule": {
                "status": result.schedule.status.value if result.schedule else None,
                "sequence": list(result.schedule.sequence) if result.schedule else [],
                "changeover_saving_hours": (
                    round(result.schedule.changeover_saving_minutes / 60.0, 3)
                    if result.schedule
                    else 0.0
                ),
            },
            "provenance": _provenance_payload(result.provenance),
        }

        if request.optimise_recipes:
            registry = build_default_registry()
            engine = RecipeEngine(registry)
            recipe_optimiser = RecipeOptimiser(registry, engine, base_config)
            blends = []
            for recipe_id in {batch.recipe_id for batch in request.batches}:
                blend = recipe_optimiser.optimise(
                    recipe_book.get(recipe_id), max_deviation=request.max_deviation
                )
                blends.append(
                    {
                        "recipe_id": recipe_id,
                        "status": blend.status.value,
                        "cost_per_kg": round(blend.cost_per_kg, 5),
                        "baseline_cost_per_kg": round(blend.baseline_cost_per_kg, 5),
                        "saving_fraction": round(blend.saving_fraction, 5),
                        "cocoa_solids_before": round(blend.cocoa_solids_before, 5),
                        "cocoa_solids_after": round(blend.cocoa_solids_after, 5),
                        "binding_constraints": list(blend.binding_constraints),
                    }
                )
            payload["reformulation"] = blends

        return payload

    @app.post("/scenario/run", tags=["simulation"])
    def run_scenario(request: ScenarioRequest) -> dict[str, Any]:
        """Run what-if scenarios against a baseline."""
        for batch in request.batches:
            if batch.recipe_id not in recipe_book:
                raise HTTPException(
                    status_code=404, detail=f"Unknown recipe {batch.recipe_id!r}"
                )

        schedule = [(batch.recipe_id, batch.mass_kg) for batch in request.batches]
        start = request.start_date or dt.date.today()

        scenarios = []
        if request.use_standard_scenarios:
            scenarios.extend(standard_scenarios())
        if request.cocoa_multiplier is not None:
            scenarios.append(cocoa_price_rise(request.cocoa_multiplier))
        if request.sugar_multiplier is not None:
            scenarios.append(sugar_price_rise(request.sugar_multiplier))
        if request.energy_multiplier is not None:
            scenarios.append(energy_price_rise(request.energy_multiplier))
        if not scenarios:
            raise HTTPException(
                status_code=422, detail="No scenario modifications requested."
            )

        engine = ScenarioEngine(base_config.deterministic(), recipe_book)
        comparison = engine.compare(scenarios, schedule, start)

        return {
            "baseline": {
                "name": comparison.baseline.scenario_name,
                "cost_per_kg": round(comparison.baseline.cost_per_kg, 5),
                "saleable_kg": round(comparison.baseline.saleable_kg, 3),
                "energy_kwh_per_kg": round(
                    comparison.baseline.state.energy_kwh_per_kg, 5
                ),
                "quality_score": round(comparison.baseline.mean_quality_score, 2),
            },
            "scenarios": [
                {
                    "name": scenario.scenario_name,
                    "cost_per_kg": round(scenario.cost_per_kg, 5),
                    "delta": {
                        key: round(value, 6)
                        for key, value in scenario.delta_against(
                            comparison.baseline
                        ).items()
                    },
                }
                for scenario in comparison.scenarios
            ],
            "provenance": _provenance_payload(comparison.provenance),
        }

    # ------------------------------------------------------------------
    # State endpoints
    # ------------------------------------------------------------------

    @app.get("/factory/state", tags=["factory"])
    def factory_state(
        batches: int = Query(6, ge=1, le=MAX_BATCHES),
        batch_kg: float = Query(1_500.0, gt=0.0),
    ) -> dict[str, Any]:
        """A factory snapshot from a reference production run."""
        factory = _factory(deterministic=True)
        start = dt.date.today()
        factory.stock_up(start, days_of_cover=45.0, daily_demand_kg=10_000.0)
        recipe_ids = [recipe.recipe_id for recipe in recipe_book.current_recipes()]
        schedule = [
            (recipe_ids[index % len(recipe_ids)], batch_kg)
            for index in range(batches)
        ]
        factory.produce_schedule(schedule, start)
        state = factory.state(start)
        return {
            "state": state.model_dump(mode="json", exclude={"provenance"}),
            "provenance": _provenance_payload(state.provenance),
        }

    @app.get("/inventory", tags=["factory"])
    def inventory(days_of_cover: float = Query(30.0, gt=0.0)) -> dict[str, Any]:
        """The raw material, WIP and finished goods position."""
        factory = _factory(deterministic=True)
        start = dt.date.today()
        factory.stock_up(start, days_of_cover=days_of_cover, daily_demand_kg=10_000.0)
        summary = factory.inventory.summary(start)
        return {
            "as_of": start.isoformat(),
            "summary": summary,
            "total_value": round(factory.inventory.total_value(), 2),
            "raw_material_detail": factory.registry.stock_summary(start),
        }

    @app.get("/production", tags=["factory"])
    def production(
        batches: int = Query(8, ge=1, le=MAX_BATCHES),
        batch_kg: float = Query(1_500.0, gt=0.0),
    ) -> dict[str, Any]:
        """Line performance from a discrete-event simulation."""
        from ..production.line import ProductionLine, build_orders

        line = ProductionLine(config=base_config)
        recipes = recipe_book.current_recipes()
        orders = build_orders(recipes, batches, batch_kg)
        result = line.simulate(orders, horizon_minutes=21 * 24 * 60)
        bottleneck = result.bottleneck()
        return {
            "batches_released": result.batches_released,
            "batches_completed": result.batches_completed,
            "produced_kg": round(result.produced_kg, 2),
            "throughput_kg_per_hour": round(result.throughput_kg_per_hour, 3),
            "mean_cycle_time_hours": round(
                result.mean_cycle_time_minutes / 60.0, 3
            ),
            "flow_efficiency": round(result.mean_flow_efficiency, 4),
            "nominal_capacity_kg_per_hour": round(
                line.nominal_capacity_kg_per_hour(), 2
            ),
            "bottleneck": bottleneck.stage.value if bottleneck else None,
            "stages": [
                {
                    "stage": stat.stage.value,
                    "machine_id": stat.machine_id,
                    "units": stat.parallel_units,
                    "batches": stat.batches,
                    "utilisation": round(stat.utilisation, 4),
                    "mean_wait_hours": round(stat.mean_wait_minutes / 60.0, 3),
                    "changeover_hours": round(stat.changeover_minutes / 60.0, 3),
                    "downtime_hours": round(stat.downtime_minutes / 60.0, 3),
                    "breakdowns": stat.breakdowns,
                }
                for stat in result.stage_statistics
            ],
        }

    @app.get("/economics", tags=["factory"])
    def economics(
        batches: int = Query(6, ge=1, le=MAX_BATCHES),
        batch_kg: float = Query(1_500.0, gt=0.0),
        unit_mass_g: float = Query(100.0, gt=0.0),
    ) -> dict[str, Any]:
        """Unit economics and a period profit statement."""
        factory = _factory(deterministic=True)
        start = dt.date.today()
        factory.stock_up(start, days_of_cover=45.0, daily_demand_kg=10_000.0)
        recipe_ids = [recipe.recipe_id for recipe in recipe_book.current_recipes()]
        schedule = [
            (recipe_ids[index % len(recipe_ids)], batch_kg)
            for index in range(batches)
        ]
        outcomes = factory.produce_schedule(schedule, start)

        products = []
        for outcome in outcomes:
            pack_cost = (
                outcome.packaging.material_cost_per_unit if outcome.packaging else 0.0
            )
            product = factory.economics_engine.product_economics(
                outcome.costing, unit_mass_g, pack_cost
            )
            products.append(
                {
                    "recipe_id": product.recipe_id,
                    "name": product.product_name,
                    "unit_mass_g": product.unit_mass_g,
                    "production_cost": product.production_cost_per_unit,
                    "packaging_cost": product.packaging_cost_per_unit,
                    "energy_cost": product.energy_cost_per_unit,
                    "total_cost": round(product.total_cost_per_unit, 4),
                    "wholesale_price": product.wholesale_price_per_unit,
                    "margin": round(product.margin_per_unit, 4),
                    "margin_fraction": round(product.margin_fraction, 4),
                }
            )

        statement = factory.profit_and_loss(period_days=max(1.0, batches / 4.0))
        return {
            "products": products,
            "profit_and_loss": statement.model_dump(mode="json"),
            "gross_margin": round(statement.gross_margin, 4),
            "operating_margin": round(statement.operating_margin, 4),
            "breakeven_kg": round(statement.breakeven_kg, 1),
        }

    return app


#: Module-level application for ``uvicorn chocosim.api.app:app``.
app = create_app()


__all__ = ["MAX_BATCHES", "MAX_REPLICATIONS", "app", "create_app"]
