"""Command line interface.

Provides the entry points a person would actually reach for: run a batch,
compare roast profiles, price a scenario, optimise a schedule, produce a
dashboard. Argument parsing only -- every command delegates immediately to the
library, so the CLI cannot drift from the API.
"""

from __future__ import annotations

import argparse
import datetime as dt
import json
import sys
from collections.abc import Sequence

from .core.config import ChocoSimConfig
from .core.rng import RandomSource
from .dashboard.console import batch_table, optimisation_panel, status_panel
from .dashboard.report import write_dashboard
from .ingredients.registry import build_default_registry
from .optimisation.factory_opt import FactoryOptimiser
from .optimisation.solvers import ProductionScheduler, RecipeOptimiser, ScheduleJob
from .processing.roasting import (
    STANDARD_ROAST_PROFILES,
    ROAST_B,
    RoastingModel,
    find_equivalent_profile,
)
from .production.factory import Factory
from .production.line import ProductionLine, build_orders
from .recipes.engine import RecipeEngine
from .recipes.library import build_standard_book
from .simulation.scenarios import (
    MonteCarloEngine,
    ScenarioEngine,
    standard_scenarios,
)


def _config(args: argparse.Namespace) -> ChocoSimConfig:
    """Build a configuration from common arguments."""
    config = ChocoSimConfig.default()
    if getattr(args, "seed", None) is not None:
        config.simulation.seed = args.seed
    if getattr(args, "stochastic", False):
        config.simulation.deterministic = False
    else:
        config.simulation.deterministic = True
        config.simulation.enable_breakdowns = False
    return config


def _default_schedule(batch_kg: float, count: int) -> list[tuple[str, float]]:
    """A round-robin programme over the standard recipes."""
    book = build_standard_book()
    ids = [recipe.recipe_id for recipe in book.current_recipes()]
    return [(ids[index % len(ids)], batch_kg) for index in range(count)]


# --------------------------------------------------------------------------
# Commands
# --------------------------------------------------------------------------


def cmd_recipes(args: argparse.Namespace) -> int:
    """List recipes with their analysis."""
    registry = build_default_registry()
    engine = RecipeEngine(registry)
    book = build_standard_book()
    print(f"{'RECIPE':<22}{'NAME':<34}{'COCOA':>8}{'FAT':>8}{'£/kg':>9}{'OK':>4}")
    print("-" * 85)
    for recipe in book.current_recipes():
        analysis = engine.analyse(recipe, recipe.default_batch_size_kg)
        print(
            f"{recipe.recipe_id:<22}{recipe.name[:32]:<34}"
            f"{analysis.base_composition.total_cocoa_solids:>8.2%}"
            f"{analysis.composition.fat:>8.2%}"
            f"{analysis.ingredient_cost_per_kg:>9.3f}"
            f"{('Y' if analysis.compliance.compliant else 'N'):>4}"
        )
    return 0


def cmd_recipe(args: argparse.Namespace) -> int:
    """Full analysis of one recipe."""
    book = build_standard_book()
    if args.recipe_id not in book:
        print(f"Unknown recipe {args.recipe_id!r}", file=sys.stderr)
        print(f"Available: {', '.join(book.recipe_ids)}", file=sys.stderr)
        return 2
    engine = RecipeEngine(build_default_registry())
    print(engine.analyse(book.get(args.recipe_id), args.batch_kg).report())
    return 0


def cmd_batch(args: argparse.Namespace) -> int:
    """Run one batch through the whole factory."""
    config = _config(args)
    book = build_standard_book()
    if args.recipe_id not in book:
        print(f"Unknown recipe {args.recipe_id!r}", file=sys.stderr)
        return 2

    factory = Factory(config, build_default_registry(), book)
    start = dt.date.today()
    factory.stock_up(start, days_of_cover=30.0, daily_demand_kg=10_000.0)
    outcome = factory.produce_batch(args.recipe_id, args.batch_kg, on=start)

    print(outcome.process.report())
    print()
    print(outcome.quality.report())
    print()
    print(outcome.costing.report())
    if outcome.packaging:
        print()
        print("PACKAGING")
        print(f"  {outcome.packaging.summary()}")
    return 0


def cmd_roast(args: argparse.Namespace) -> int:
    """Compare roast profiles."""
    model = RoastingModel(_config(args))
    outcomes = model.compare_profiles(
        STANDARD_ROAST_PROFILES, args.charge_kg, args.moisture
    )
    print(
        f"{'PROFILE':<18}{'TEMP':>7}{'MIN':>7}{'MOISTURE':>10}"
        f"{'DEVEL':>8}{'DAMAGE':>8}{'QUALITY':>9}{'kWh/kg':>9}"
    )
    print("-" * 76)
    for profile, outcome in zip(STANDARD_ROAST_PROFILES, outcomes, strict=True):
        print(
            f"{outcome.profile_name:<18}{profile.temperature_c:>7.0f}"
            f"{profile.duration_minutes:>7.0f}{outcome.final_moisture:>10.2%}"
            f"{outcome.development_ratio:>8.3f}{outcome.damage_ratio:>8.3f}"
            f"{outcome.quality_index:>9.1f}"
            f"{outcome.specific_energy_kwh_per_kg:>9.4f}"
        )
    if args.equivalent_at is not None:
        equivalent = find_equivalent_profile(model, ROAST_B, args.equivalent_at)
        reference = model.roast(ROAST_B, args.charge_kg, args.moisture)
        candidate = model.roast(equivalent, args.charge_kg, args.moisture)
        print()
        print(
            f"Equal-development equivalent of {ROAST_B.name} at "
            f"{args.equivalent_at:.0f} C is {equivalent.duration_minutes:.1f} min."
        )
        print(
            f"  quality {reference.quality_index:.1f} -> "
            f"{candidate.quality_index:.1f}, "
            f"damage ratio {reference.damage_ratio:.3f} -> "
            f"{candidate.damage_ratio:.3f}"
        )
    return 0


def cmd_line(args: argparse.Namespace) -> int:
    """Simulate the production line."""
    config = _config(args)
    book = build_standard_book()
    line = ProductionLine(config=config)
    orders = build_orders(book.current_recipes(), args.batches, args.batch_kg)
    result = line.simulate(orders, horizon_minutes=args.days * 24 * 60)
    print(result.report())
    return 0


def cmd_schedule(args: argparse.Namespace) -> int:
    """Optimise a production sequence."""
    config = _config(args)
    book = build_standard_book()
    engine = RecipeEngine(build_default_registry())
    scheduler = ProductionScheduler(config)

    ids = [recipe.recipe_id for recipe in book.current_recipes()]
    jobs = []
    for index in range(args.batches):
        recipe = book.get(ids[index % len(ids)])
        jobs.append(
            ScheduleJob(
                job_id=f"J{index + 1:03d}",
                recipe_id=recipe.recipe_id,
                chocolate_type=recipe.chocolate_type,
                mass_kg=args.batch_kg,
                processing_minutes=180.0,
                allergens=engine.allergens(recipe),
            )
        )
    print(scheduler.optimise(jobs).report())
    return 0


def cmd_optimise(args: argparse.Namespace) -> int:
    """Optimise the factory and show current versus optimised."""
    config = _config(args)
    optimiser = FactoryOptimiser(config, build_standard_book())
    programme = _default_schedule(args.batch_kg, args.batches)
    result = optimiser.optimise(
        programme,
        horizon_hours=args.days * 24.0,
        energy_kwh_per_kg=args.energy,
        waste_fraction=args.waste,
    )
    print(optimisation_panel(result))
    return 0


def cmd_scenario(args: argparse.Namespace) -> int:
    """Run what-if scenarios."""
    config = _config(args)
    engine = ScenarioEngine(config, build_standard_book())
    schedule = _default_schedule(args.batch_kg, args.batches)
    comparison = engine.compare(standard_scenarios(), schedule, dt.date.today())
    print(comparison.report())
    return 0


def cmd_montecarlo(args: argparse.Namespace) -> int:
    """Run a Monte Carlo study."""
    config = ChocoSimConfig.default()
    if args.seed is not None:
        config.simulation.seed = args.seed
    engine = MonteCarloEngine(config, build_standard_book())
    schedule = _default_schedule(args.batch_kg, args.batches)
    report = engine.run(
        schedule, dt.date.today(), replications=args.replications
    )
    print(report.report())
    return 0


def cmd_reformulate(args: argparse.Namespace) -> int:
    """Find a least-cost reformulation."""
    config = _config(args)
    registry = build_default_registry()
    engine = RecipeEngine(registry)
    book = build_standard_book()
    if args.recipe_id not in book:
        print(f"Unknown recipe {args.recipe_id!r}", file=sys.stderr)
        return 2
    optimiser = RecipeOptimiser(registry, engine, config)
    result = optimiser.optimise(
        book.get(args.recipe_id),
        max_deviation=args.max_deviation,
        preserve_cocoa_content=not args.allow_cocoa_change,
    )
    print(result.report())
    return 0


def cmd_dashboard(args: argparse.Namespace) -> int:
    """Produce the factory dashboard."""
    config = _config(args)
    book = build_standard_book()
    factory = Factory(config, build_default_registry(), book)
    start = dt.date.today()
    factory.stock_up(start, days_of_cover=45.0, daily_demand_kg=10_000.0)
    factory.produce_schedule(
        _default_schedule(args.batch_kg, args.batches), start
    )

    line = ProductionLine(config=config)
    result = line.simulate(
        build_orders(book.current_recipes(), args.batches * 3, args.batch_kg),
        horizon_minutes=args.days * 24 * 60,
    )
    state = factory.state(start)

    if args.output:
        write_dashboard(
            args.output, state=state, outcomes=factory.outcomes, line=result
        )
        print(f"Dashboard written to {args.output}")
    else:
        print(status_panel(state, result))
        print()
        print(batch_table(factory.outcomes))
    return 0


def cmd_serve(args: argparse.Namespace) -> int:
    """Run the API server."""
    try:
        import uvicorn
    except ImportError:
        print("uvicorn is required to serve the API", file=sys.stderr)
        return 2
    from .api.app import create_app

    uvicorn.run(create_app(_config(args)), host=args.host, port=args.port)
    return 0


# --------------------------------------------------------------------------
# Parser
# --------------------------------------------------------------------------


def build_parser() -> argparse.ArgumentParser:
    """Construct the argument parser."""
    parser = argparse.ArgumentParser(
        prog="chocosim",
        description=(
            "Chocolate manufacturing simulator. All output is SIMULATION "
            "grade: physically motivated but not calibrated against or "
            "validated on any real plant."
        ),
    )
    parser.add_argument("--seed", type=int, help="Root RNG seed.")
    parser.add_argument(
        "--stochastic",
        action="store_true",
        help="Enable stochastic variation (deterministic by default).",
    )
    subparsers = parser.add_subparsers(dest="command", required=True)

    recipes = subparsers.add_parser("recipes", help="List recipes.")
    recipes.set_defaults(func=cmd_recipes)

    recipe = subparsers.add_parser("recipe", help="Analyse one recipe.")
    recipe.add_argument("recipe_id")
    recipe.add_argument("--batch-kg", type=float, default=1_000.0)
    recipe.set_defaults(func=cmd_recipe)

    batch = subparsers.add_parser("batch", help="Produce one batch.")
    batch.add_argument("recipe_id")
    batch.add_argument("--batch-kg", type=float, default=1_500.0)
    batch.set_defaults(func=cmd_batch)

    roast = subparsers.add_parser("roast", help="Compare roast profiles.")
    roast.add_argument("--charge-kg", type=float, default=1_000.0)
    roast.add_argument("--moisture", type=float, default=0.070)
    roast.add_argument(
        "--equivalent-at",
        type=float,
        help="Find the equal-development time at this temperature.",
    )
    roast.set_defaults(func=cmd_roast)

    line = subparsers.add_parser("line", help="Simulate the production line.")
    line.add_argument("--batches", type=int, default=40)
    line.add_argument("--batch-kg", type=float, default=1_800.0)
    line.add_argument("--days", type=int, default=14)
    line.set_defaults(func=cmd_line)

    schedule = subparsers.add_parser("schedule", help="Optimise a sequence.")
    schedule.add_argument("--batches", type=int, default=12)
    schedule.add_argument("--batch-kg", type=float, default=1_500.0)
    schedule.set_defaults(func=cmd_schedule)

    optimise = subparsers.add_parser("optimise", help="Current versus optimised.")
    optimise.add_argument("--batches", type=int, default=16)
    optimise.add_argument("--batch-kg", type=float, default=1_500.0)
    optimise.add_argument("--days", type=int, default=14)
    optimise.add_argument("--energy", type=float, default=1.84)
    optimise.add_argument("--waste", type=float, default=0.027)
    optimise.set_defaults(func=cmd_optimise)

    scenario = subparsers.add_parser("scenario", help="Run what-if scenarios.")
    scenario.add_argument("--batches", type=int, default=4)
    scenario.add_argument("--batch-kg", type=float, default=2_000.0)
    scenario.set_defaults(func=cmd_scenario)

    montecarlo = subparsers.add_parser("montecarlo", help="Monte Carlo study.")
    montecarlo.add_argument("--replications", type=int, default=50)
    montecarlo.add_argument("--batches", type=int, default=3)
    montecarlo.add_argument("--batch-kg", type=float, default=2_000.0)
    montecarlo.set_defaults(func=cmd_montecarlo)

    reformulate = subparsers.add_parser(
        "reformulate", help="Least-cost reformulation."
    )
    reformulate.add_argument("recipe_id")
    reformulate.add_argument("--max-deviation", type=float, default=0.20)
    reformulate.add_argument(
        "--allow-cocoa-change",
        action="store_true",
        help="Permit the declared cocoa content to move (changes the product).",
    )
    reformulate.set_defaults(func=cmd_reformulate)

    dashboard = subparsers.add_parser("dashboard", help="Produce the dashboard.")
    dashboard.add_argument("--batches", type=int, default=8)
    dashboard.add_argument("--batch-kg", type=float, default=1_500.0)
    dashboard.add_argument("--days", type=int, default=14)
    dashboard.add_argument("-o", "--output", help="Write HTML to this path.")
    dashboard.set_defaults(func=cmd_dashboard)

    serve = subparsers.add_parser("serve", help="Run the API server.")
    serve.add_argument("--host", default="127.0.0.1")
    serve.add_argument("--port", type=int, default=8000)
    serve.set_defaults(func=cmd_serve)

    return parser


def main(argv: Sequence[str] | None = None) -> int:
    """CLI entry point."""
    parser = build_parser()
    args = parser.parse_args(argv)
    return int(args.func(args))


if __name__ == "__main__":
    raise SystemExit(main())
