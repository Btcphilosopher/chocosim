"""Configuration objects for ChocoSim.

Every tunable parameter in the engine lives in one of the configuration
models here. Nothing in the simulation reads a magic number from its own
module: models take a config object, so a scenario can perturb any parameter
without editing code. This is what makes the what-if engine general rather
than a fixed menu of pre-wired levers.
"""

from __future__ import annotations

from typing import Self

from pydantic import Field, model_validator

from .models import ChocoModel, FrozenChocoModel
from .rng import DEFAULT_SEED
from .types import EnergyCarrier


class SimulationConfig(ChocoModel):
    """Top-level controls for a simulation run."""

    seed: int = Field(default=DEFAULT_SEED, description="Root RNG seed.")
    horizon_days: int = Field(
        default=30, gt=0, description="Length of the simulated period, days."
    )
    shifts_per_day: int = Field(
        default=2, ge=1, le=3, description="Production shifts scheduled per day."
    )
    hours_per_shift: float = Field(
        default=8.0, gt=0.0, le=12.0, description="Length of a shift, hours."
    )
    operating_days_per_week: int = Field(
        default=5, ge=1, le=7, description="Days per week the factory runs."
    )
    warmup_hours: float = Field(
        default=0.0,
        ge=0.0,
        description="Initial period excluded from steady-state statistics.",
    )
    enable_breakdowns: bool = Field(
        default=True, description="Whether stochastic machine failures occur."
    )
    enable_changeovers: bool = Field(
        default=True, description="Whether recipe changeovers consume time."
    )
    deterministic: bool = Field(
        default=False,
        description=(
            "Replace every stochastic draw with its expected value. Used for "
            "reproducible reference scenarios and for optimisation, which needs "
            "a smooth objective."
        ),
    )

    @property
    def operating_hours_per_day(self) -> float:
        """Scheduled production hours in an operating day."""
        return self.shifts_per_day * self.hours_per_shift

    @property
    def continuous_operation(self) -> bool:
        """Whether the configuration amounts to 24/7 running."""
        return (
            self.operating_hours_per_day >= 23.9
            and self.operating_days_per_week == 7
        )

    @property
    def total_operating_hours(self) -> float:
        """Total scheduled production hours over the horizon."""
        weeks = self.horizon_days / 7.0
        operating_days = weeks * self.operating_days_per_week
        return operating_days * self.operating_hours_per_day

    def as_continuous(self) -> SimulationConfig:
        """Return a copy configured for 24/7 operation."""
        return self.model_copy(
            update={
                "shifts_per_day": 3,
                "hours_per_shift": 8.0,
                "operating_days_per_week": 7,
            }
        )


class EnergyTariff(FrozenChocoModel):
    """Price of one energy carrier, with optional time-of-use structure."""

    carrier: EnergyCarrier
    unit_price: float = Field(
        ge=0.0, description="Base price per kWh (or kWh-equivalent) in currency units."
    )
    peak_multiplier: float = Field(
        default=1.0, ge=0.0, description="Multiplier applied during peak hours."
    )
    offpeak_multiplier: float = Field(
        default=1.0, ge=0.0, description="Multiplier applied during off-peak hours."
    )
    peak_hours: tuple[int, int] = Field(
        default=(16, 20),
        description="Half-open [start, end) hour-of-day window treated as peak.",
    )
    carbon_intensity_kg_per_kwh: float = Field(
        default=0.0, ge=0.0, description="Carbon intensity, kg CO2e per kWh."
    )

    @model_validator(mode="after")
    def _valid_window(self) -> Self:
        start, end = self.peak_hours
        if not (0 <= start <= 24 and 0 <= end <= 24):
            raise ValueError(f"peak_hours must lie in [0, 24], got {self.peak_hours}")
        return self

    def price_at(self, hour_of_day: float) -> float:
        """Price per kWh at a given hour of day."""
        start, end = self.peak_hours
        hour = hour_of_day % 24.0
        in_peak = start <= hour < end if start <= end else (hour >= start or hour < end)
        multiplier = self.peak_multiplier if in_peak else self.offpeak_multiplier
        return self.unit_price * multiplier

    def is_peak(self, hour_of_day: float) -> bool:
        """Whether the given hour falls in the peak window."""
        start, end = self.peak_hours
        hour = hour_of_day % 24.0
        return start <= hour < end if start <= end else (hour >= start or hour < end)


class EnergyConfig(ChocoModel):
    """Energy pricing, efficiency and carbon parameters."""

    tariffs: dict[EnergyCarrier, EnergyTariff] = Field(default_factory=dict)
    thermal_efficiency: float = Field(
        default=0.75,
        gt=0.0,
        le=1.0,
        description="Fraction of supplied heat that reaches the product.",
    )
    motor_efficiency: float = Field(
        default=0.90,
        gt=0.0,
        le=1.0,
        description="Electrical-to-mechanical conversion efficiency.",
    )
    refrigeration_cop: float = Field(
        default=2.8,
        gt=0.0,
        description="Coefficient of performance of the cooling plant.",
    )
    standby_power_fraction: float = Field(
        default=0.12,
        ge=0.0,
        le=1.0,
        description="Rated power drawn when a machine is idle rather than running.",
    )
    site_overhead_kw: float = Field(
        default=45.0,
        ge=0.0,
        description="Lighting, HVAC, offices -- load independent of production.",
    )

    @classmethod
    def uk_default(cls) -> EnergyConfig:
        """Representative UK industrial tariff structure.

        Illustrative figures for simulation. Real tariffs are contract-specific.
        """
        return cls(
            tariffs={
                EnergyCarrier.ELECTRICITY: EnergyTariff(
                    carrier=EnergyCarrier.ELECTRICITY,
                    unit_price=0.24,
                    peak_multiplier=1.45,
                    offpeak_multiplier=0.72,
                    peak_hours=(16, 20),
                    carbon_intensity_kg_per_kwh=0.207,
                ),
                EnergyCarrier.NATURAL_GAS: EnergyTariff(
                    carrier=EnergyCarrier.NATURAL_GAS,
                    unit_price=0.068,
                    carbon_intensity_kg_per_kwh=0.183,
                ),
                EnergyCarrier.STEAM: EnergyTariff(
                    carrier=EnergyCarrier.STEAM,
                    unit_price=0.089,
                    carbon_intensity_kg_per_kwh=0.220,
                ),
                EnergyCarrier.CHILLED_WATER: EnergyTariff(
                    carrier=EnergyCarrier.CHILLED_WATER,
                    unit_price=0.031,
                    carbon_intensity_kg_per_kwh=0.074,
                ),
                EnergyCarrier.COMPRESSED_AIR: EnergyTariff(
                    carrier=EnergyCarrier.COMPRESSED_AIR,
                    unit_price=0.115,
                    carbon_intensity_kg_per_kwh=0.207,
                ),
            }
        )

    def tariff(self, carrier: EnergyCarrier) -> EnergyTariff:
        """Return the tariff for a carrier, defaulting to a zero-price tariff."""
        existing = self.tariffs.get(carrier)
        if existing is not None:
            return existing
        return EnergyTariff(carrier=carrier, unit_price=0.0)

    def scaled(self, factor: float) -> EnergyConfig:
        """Return a copy with every unit price multiplied by ``factor``."""
        return self.model_copy(
            update={
                "tariffs": {
                    carrier: tariff.model_copy(
                        update={"unit_price": tariff.unit_price * factor}
                    )
                    for carrier, tariff in self.tariffs.items()
                }
            }
        )


class EconomicConfig(ChocoModel):
    """Cost rates and commercial parameters."""

    currency: str = Field(default="GBP", description="Currency label for reporting.")
    currency_symbol: str = Field(default="\u00a3", description="Symbol for display.")

    labour_rate_per_hour: float = Field(
        default=16.50, ge=0.0, description="Fully loaded operator cost per hour."
    )
    operators_per_line: float = Field(
        default=3.0, ge=0.0, description="Operators required to staff one line."
    )
    supervision_overhead: float = Field(
        default=0.22,
        ge=0.0,
        description="Supervision and indirect labour as a fraction of direct labour.",
    )
    shift_premium_night: float = Field(
        default=0.25, ge=0.0, description="Pay uplift for the night shift."
    )

    maintenance_rate_per_machine_hour: float = Field(
        default=4.20, ge=0.0, description="Planned and reactive maintenance cost."
    )
    breakdown_cost_per_event: float = Field(
        default=180.0, ge=0.0, description="Fixed cost per unplanned stoppage."
    )

    waste_disposal_cost_per_kg: float = Field(
        default=0.14, ge=0.0, description="Cost to dispose of one kg of waste."
    )
    rework_cost_per_kg: float = Field(
        default=0.22, ge=0.0, description="Cost to rework one kg of off-spec product."
    )
    rework_recovery_fraction: float = Field(
        default=0.85,
        ge=0.0,
        le=1.0,
        description="Fraction of reworked mass that becomes saleable product.",
    )

    fixed_overhead_per_day: float = Field(
        default=3_400.0, ge=0.0, description="Site fixed cost per calendar day."
    )
    depreciation_per_day: float = Field(
        default=1_250.0, ge=0.0, description="Capital depreciation per calendar day."
    )

    inventory_holding_rate_annual: float = Field(
        default=0.18,
        ge=0.0,
        description="Annual holding cost as a fraction of inventory value.",
    )
    stockout_penalty_per_kg: float = Field(
        default=2.50, ge=0.0, description="Commercial penalty per kg short."
    )

    target_gross_margin: float = Field(
        default=0.45,
        ge=0.0,
        lt=1.0,
        description="Target gross margin used when deriving indicative prices.",
    )

    def labour_cost(self, line_hours: float, night_fraction: float = 0.0) -> float:
        """Direct plus indirect labour cost for a quantity of line-hours."""
        base = line_hours * self.operators_per_line * self.labour_rate_per_hour
        night_uplift = base * night_fraction * self.shift_premium_night
        direct = base + night_uplift
        return direct * (1.0 + self.supervision_overhead)

    def holding_cost(self, value: float, days: float) -> float:
        """Inventory holding cost for holding ``value`` for ``days`` days."""
        return value * self.inventory_holding_rate_annual * (days / 365.0)


class QualityConfig(ChocoModel):
    """Weights and targets used by the quality scoring model."""

    weight_particle_size: float = Field(default=0.20, ge=0.0)
    weight_viscosity: float = Field(default=0.16, ge=0.0)
    weight_moisture: float = Field(default=0.14, ge=0.0)
    weight_fat: float = Field(default=0.10, ge=0.0)
    weight_temper: float = Field(default=0.24, ge=0.0)
    weight_appearance: float = Field(default=0.08, ge=0.0)
    weight_defects: float = Field(default=0.08, ge=0.0)

    pass_threshold: float = Field(
        default=80.0, ge=0.0, le=100.0, description="Score at or above which a batch passes."
    )
    marginal_threshold: float = Field(
        default=70.0,
        ge=0.0,
        le=100.0,
        description="Score below which a batch fails outright.",
    )
    penalty_steepness: float = Field(
        default=1.8,
        gt=0.0,
        description=(
            "Exponent controlling how sharply the score falls once a metric "
            "leaves specification. Values above 1 punish gross deviations "
            "disproportionately, matching how sensory panels behave."
        ),
    )

    @model_validator(mode="after")
    def _thresholds_ordered(self) -> Self:
        if self.marginal_threshold > self.pass_threshold:
            raise ValueError(
                f"marginal_threshold ({self.marginal_threshold}) must not exceed "
                f"pass_threshold ({self.pass_threshold})"
            )
        return self

    @property
    def total_weight(self) -> float:
        """Sum of all metric weights."""
        return (
            self.weight_particle_size
            + self.weight_viscosity
            + self.weight_moisture
            + self.weight_fat
            + self.weight_temper
            + self.weight_appearance
            + self.weight_defects
        )

    def normalised_weights(self) -> dict[str, float]:
        """Metric weights normalised to sum to one."""
        total = self.total_weight
        if total <= 0.0:
            raise ValueError("quality weights sum to zero")
        return {
            "particle_size": self.weight_particle_size / total,
            "viscosity": self.weight_viscosity / total,
            "moisture": self.weight_moisture / total,
            "fat": self.weight_fat / total,
            "temper": self.weight_temper / total,
            "appearance": self.weight_appearance / total,
            "defects": self.weight_defects / total,
        }


class FactoryConfig(ChocoModel):
    """Site-level physical and operational parameters."""

    name: str = Field(default="ChocoSim Works")
    ambient_temperature_c: float = Field(default=20.0)
    ambient_humidity_fraction: float = Field(default=0.55, ge=0.0, le=1.0)
    changeover_minutes_same_type: float = Field(
        default=25.0, ge=0.0, description="Changeover between recipes of the same type."
    )
    changeover_minutes_different_type: float = Field(
        default=90.0,
        ge=0.0,
        description="Changeover across chocolate types, e.g. dark to milk.",
    )
    allergen_changeover_minutes: float = Field(
        default=150.0,
        ge=0.0,
        description=(
            "Full wet clean between allergen states. Simulation parameter only; "
            "real allergen control is governed by the site's food-safety plan."
        ),
    )
    wip_buffer_capacity_kg: float = Field(
        default=8_000.0, ge=0.0, description="Total inter-stage buffer capacity."
    )
    warehouse_capacity_kg: float = Field(
        default=250_000.0, ge=0.0, description="Finished-goods warehouse capacity."
    )
    raw_store_capacity_kg: float = Field(
        default=180_000.0, ge=0.0, description="Raw-material store capacity."
    )


class ChocoSimConfig(ChocoModel):
    """The complete configuration of a ChocoSim run."""

    simulation: SimulationConfig = Field(default_factory=SimulationConfig)
    energy: EnergyConfig = Field(default_factory=EnergyConfig.uk_default)
    economics: EconomicConfig = Field(default_factory=EconomicConfig)
    quality: QualityConfig = Field(default_factory=QualityConfig)
    factory: FactoryConfig = Field(default_factory=FactoryConfig)

    @classmethod
    def default(cls) -> ChocoSimConfig:
        """The reference configuration used by examples and tests."""
        return cls()

    def with_seed(self, seed: int) -> ChocoSimConfig:
        """Return a copy with a different RNG seed."""
        clone = self.model_copy(deep=True)
        clone.simulation.seed = seed
        return clone

    def deterministic(self) -> ChocoSimConfig:
        """Return a copy with all stochastic behaviour disabled."""
        clone = self.model_copy(deep=True)
        clone.simulation.deterministic = True
        clone.simulation.enable_breakdowns = False
        return clone


__all__ = [
    "ChocoSimConfig",
    "EconomicConfig",
    "EnergyConfig",
    "EnergyTariff",
    "FactoryConfig",
    "QualityConfig",
    "SimulationConfig",
]
