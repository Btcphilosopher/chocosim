"""Exception hierarchy for ChocoSim."""

from __future__ import annotations


class ChocoSimError(Exception):
    """Base class for every error raised by ChocoSim."""


class ConfigurationError(ChocoSimError):
    """Raised when configuration is internally inconsistent or missing."""


class ValidationError(ChocoSimError):
    """Raised when domain input fails a semantic (non-schema) check."""


class MassBalanceError(ValidationError):
    """Raised when a unit operation fails to conserve mass within tolerance.

    Mass conservation is a hard invariant of the process engine: input mass
    must equal output mass plus losses plus waste for every stage.
    """

    def __init__(
        self,
        stage: str,
        mass_in: float,
        mass_out: float,
        tolerance: float,
    ) -> None:
        self.stage = stage
        self.mass_in = mass_in
        self.mass_out = mass_out
        self.tolerance = tolerance
        discrepancy = mass_out - mass_in
        super().__init__(
            f"Mass balance violated in stage {stage!r}: "
            f"in={mass_in:.6f} kg, out+losses={mass_out:.6f} kg, "
            f"discrepancy={discrepancy:+.6e} kg, tolerance={tolerance:.2e} kg"
        )


class RecipeError(ValidationError):
    """Raised when a recipe is malformed (fractions, versioning, components)."""


class IngredientNotFoundError(ChocoSimError):
    """Raised when an ingredient identifier is not present in the registry."""


class RecipeNotFoundError(ChocoSimError):
    """Raised when a recipe identifier or version is not present."""


class ProcessError(ChocoSimError):
    """Raised when a process stage cannot execute with the given input."""


class StageSequenceError(ProcessError):
    """Raised when unit operations are chained out of physical order."""


class TemperingError(ProcessError):
    """Raised when the tempering model receives physically invalid input."""


class InsufficientStockError(ChocoSimError):
    """Raised when an inventory issue would drive a stock level negative."""

    def __init__(self, item_id: str, requested: float, available: float) -> None:
        self.item_id = item_id
        self.requested = requested
        self.available = available
        super().__init__(
            f"Insufficient stock for {item_id!r}: "
            f"requested {requested:.3f} kg, available {available:.3f} kg"
        )


class CapacityError(ChocoSimError):
    """Raised when a machine or line is asked to exceed its physical capacity."""


class OptimisationError(ChocoSimError):
    """Raised when an optimisation model is malformed or cannot be built."""


class InfeasibleModelError(OptimisationError):
    """Raised when a solver proves the constraint set has no solution."""


class SimulationError(ChocoSimError):
    """Raised when a simulation run cannot proceed."""


class FidelityError(ChocoSimError):
    """Raised when a result is used at a fidelity level it does not support."""


__all__ = [
    "CapacityError",
    "ChocoSimError",
    "ConfigurationError",
    "FidelityError",
    "InfeasibleModelError",
    "IngredientNotFoundError",
    "InsufficientStockError",
    "MassBalanceError",
    "OptimisationError",
    "ProcessError",
    "RecipeError",
    "RecipeNotFoundError",
    "SimulationError",
    "StageSequenceError",
    "TemperingError",
    "ValidationError",
]
