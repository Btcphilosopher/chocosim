"""Model fidelity, provenance and the epistemic boundary of ChocoSim.

This module exists because of a single engineering principle:

    A simplified mathematical model is *not* equivalent to validated
    industrial food-processing science.

ChocoSim therefore refuses to present any number without stating what kind of
number it is. Three levels are distinguished, and they are strictly ordered:

``SIMULATION``
    A mechanism-inspired model evaluated on synthetic or assumed inputs. The
    equations are physically motivated but the coefficients are literature
    or plausibility estimates. Useful for *relative* comparison -- roast A
    versus roast B, schedule 1 versus schedule 2. Not a forecast of what a
    specific plant will do.

``PREDICTION``
    A model whose coefficients have been fitted against real production data
    for a specific asset, with a quantified residual error. Useful for
    absolute forecasting within the fitted operating envelope.

``ENGINEERING_VALIDATION``
    A prediction that has additionally been checked against independent
    production data, reviewed by a process engineer, and reconciled with the
    equipment specification, food-safety plan and regulatory requirements.
    Only at this level may a number drive a physical process setpoint.

Every model in ChocoSim ships at ``SIMULATION`` by default. Nothing in this
repository is calibrated against a real factory, so nothing here reaches
``ENGINEERING_VALIDATION``. Calibrating a model is an explicit, recorded act
(:meth:`ModelProvenance.calibrated`), and promoting one to validated status
requires evidence references that a human must supply.

Real-world deployment of any output from this system would require validation
against actual production data, HACCP procedures, equipment specifications,
food-safety requirements and applicable regulation.
"""

from __future__ import annotations

import datetime as dt
from enum import IntEnum
from typing import Any, Self

from pydantic import BaseModel, ConfigDict, Field, field_validator

from .exceptions import FidelityError


class ModelFidelity(IntEnum):
    """Ordered epistemic status of a model output.

    Ordered so that ``fidelity >= ModelFidelity.PREDICTION`` is meaningful.
    """

    #: Physically motivated equations, uncalibrated coefficients.
    SIMULATION = 10
    #: Coefficients fitted to real data with quantified residuals.
    PREDICTION = 20
    #: Independently validated and engineering-reviewed.
    ENGINEERING_VALIDATION = 30

    @property
    def label(self) -> str:
        """Human-readable label."""
        return {
            ModelFidelity.SIMULATION: "SIMULATION",
            ModelFidelity.PREDICTION: "PREDICTION",
            ModelFidelity.ENGINEERING_VALIDATION: "ENGINEERING VALIDATION",
        }[self]

    @property
    def may_drive_physical_process(self) -> bool:
        """Whether a value at this fidelity may set a real plant parameter."""
        return self is ModelFidelity.ENGINEERING_VALIDATION


#: The standard caveat attached to every uncalibrated output.
SIMULATION_CAVEAT: str = (
    "Simulation output from an uncalibrated mechanism-inspired model. "
    "Suitable for relative comparison of scenarios only. Not a forecast of "
    "any specific plant and not a substitute for validated food-manufacturing "
    "process control."
)

PREDICTION_CAVEAT: str = (
    "Prediction from a model fitted to historical data. Valid only inside the "
    "fitted operating envelope and subject to the stated residual error. "
    "Requires engineering review before use in process control."
)


class CalibrationRecord(BaseModel):
    """Evidence that a model was fitted against real data."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    dataset_reference: str = Field(
        description="Identifier of the production dataset used for fitting."
    )
    sample_count: int = Field(gt=0, description="Number of observations fitted.")
    residual_rmse: float = Field(
        ge=0.0, description="Root-mean-square residual in the model's own units."
    )
    residual_units: str = Field(description="Units of the residual, e.g. 'kWh/kg'.")
    envelope: dict[str, tuple[float, float]] = Field(
        default_factory=dict,
        description="Operating envelope over which the fit is considered valid.",
    )
    fitted_on: dt.date = Field(default_factory=dt.date.today)

    def covers(self, **conditions: float) -> bool:
        """Whether ``conditions`` fall inside the fitted operating envelope.

        Conditions with no declared envelope are treated as covered.
        """
        for name, value in conditions.items():
            bounds = self.envelope.get(name)
            if bounds is None:
                continue
            low, high = bounds
            if not (low <= value <= high):
                return False
        return True


class ValidationRecord(BaseModel):
    """Evidence that a prediction was independently validated."""

    model_config = ConfigDict(frozen=True, extra="forbid")

    validated_by: str = Field(description="Responsible engineer or organisation.")
    evidence_references: tuple[str, ...] = Field(
        min_length=1,
        description="References to validation reports, trials or certificates.",
    )
    equipment_specification: str | None = Field(
        default=None, description="Equipment specification the model was checked against."
    )
    food_safety_plan: str | None = Field(
        default=None, description="HACCP or equivalent plan reference."
    )
    regulatory_scope: str | None = Field(
        default=None, description="Regulatory regime under which validation was performed."
    )
    validated_on: dt.date = Field(default_factory=dt.date.today)


class ModelProvenance(BaseModel):
    """The epistemic passport attached to every quantitative model output.

    A provenance record travels with results through the whole engine. When
    results are combined (a batch cost built from an energy model and an
    ingredient model, say), provenance is combined too, and the result takes
    the *weakest* fidelity of its inputs.
    """

    model_config = ConfigDict(frozen=True, extra="forbid")

    model_name: str = Field(description="Name of the model producing the output.")
    fidelity: ModelFidelity = Field(default=ModelFidelity.SIMULATION)
    basis: str = Field(
        default="",
        description="One-line description of the governing equation or method.",
    )
    assumptions: tuple[str, ...] = Field(
        default=(), description="Assumptions that materially affect the output."
    )
    caveats: tuple[str, ...] = Field(
        default=(), description="Limits on how the output may legitimately be used."
    )
    calibration: CalibrationRecord | None = None
    validation: ValidationRecord | None = None

    @field_validator("model_name")
    @classmethod
    def _non_empty_name(cls, value: str) -> str:
        if not value.strip():
            raise ValueError("model_name must not be empty")
        return value

    def model_post_init(self, _context: Any) -> None:
        # Enforce that claimed fidelity is backed by evidence.
        if self.fidelity >= ModelFidelity.PREDICTION and self.calibration is None:
            raise FidelityError(
                f"Model {self.model_name!r} claims {self.fidelity.label} "
                "but carries no calibration record."
            )
        if (
            self.fidelity is ModelFidelity.ENGINEERING_VALIDATION
            and self.validation is None
        ):
            raise FidelityError(
                f"Model {self.model_name!r} claims ENGINEERING VALIDATION "
                "but carries no validation record."
            )

    # ------------------------------------------------------------------
    # Construction helpers
    # ------------------------------------------------------------------

    @classmethod
    def simulation(
        cls,
        model_name: str,
        basis: str = "",
        assumptions: tuple[str, ...] = (),
        extra_caveats: tuple[str, ...] = (),
    ) -> Self:
        """Build a ``SIMULATION``-level provenance record."""
        return cls(
            model_name=model_name,
            fidelity=ModelFidelity.SIMULATION,
            basis=basis,
            assumptions=assumptions,
            caveats=(SIMULATION_CAVEAT, *extra_caveats),
        )

    def calibrated(self, record: CalibrationRecord) -> ModelProvenance:
        """Return a copy promoted to ``PREDICTION`` with a calibration record."""
        caveats = tuple(c for c in self.caveats if c != SIMULATION_CAVEAT)
        return ModelProvenance(
            model_name=self.model_name,
            fidelity=ModelFidelity.PREDICTION,
            basis=self.basis,
            assumptions=self.assumptions,
            caveats=(PREDICTION_CAVEAT, *caveats),
            calibration=record,
            validation=None,
        )

    def validated(self, record: ValidationRecord) -> ModelProvenance:
        """Return a copy promoted to ``ENGINEERING_VALIDATION``.

        Requires that the model has already been calibrated.
        """
        if self.calibration is None:
            raise FidelityError(
                f"Model {self.model_name!r} cannot be validated before it is "
                "calibrated against production data."
            )
        caveats = tuple(c for c in self.caveats if c != PREDICTION_CAVEAT)
        return ModelProvenance(
            model_name=self.model_name,
            fidelity=ModelFidelity.ENGINEERING_VALIDATION,
            basis=self.basis,
            assumptions=self.assumptions,
            caveats=caveats,
            calibration=self.calibration,
            validation=record,
        )

    def with_assumption(self, assumption: str) -> ModelProvenance:
        """Return a copy with an extra assumption recorded."""
        return self.model_copy(update={"assumptions": (*self.assumptions, assumption)})

    # ------------------------------------------------------------------
    # Combination
    # ------------------------------------------------------------------

    @classmethod
    def combine(
        cls, name: str, parts: object, *, basis: str = ""
    ) -> ModelProvenance:
        """Combine provenance from several sub-models.

        The combined record takes the *minimum* fidelity of its parts, on the
        principle that a chain of reasoning is only as sound as its weakest
        link. Assumptions and caveats are unioned with order preserved.
        """
        records = [p for p in parts if isinstance(p, ModelProvenance)]  # type: ignore[union-attr]
        if not records:
            return cls.simulation(name, basis=basis)

        fidelity = min(record.fidelity for record in records)

        assumptions: list[str] = []
        caveats: list[str] = []
        for record in records:
            prefix = record.model_name
            for assumption in record.assumptions:
                tagged = f"[{prefix}] {assumption}"
                if tagged not in assumptions:
                    assumptions.append(tagged)
            for caveat in record.caveats:
                if caveat not in caveats:
                    caveats.append(caveat)

        # A combined record never claims evidence of its own.
        if fidelity is ModelFidelity.SIMULATION and SIMULATION_CAVEAT not in caveats:
            caveats.insert(0, SIMULATION_CAVEAT)

        return cls(
            model_name=name,
            fidelity=ModelFidelity.SIMULATION,
            basis=basis or f"Composite of {len(records)} sub-models",
            assumptions=tuple(assumptions),
            caveats=tuple(caveats),
        )

    # ------------------------------------------------------------------
    # Guards
    # ------------------------------------------------------------------

    def require(self, minimum: ModelFidelity) -> None:
        """Raise :class:`FidelityError` unless this record meets ``minimum``."""
        if self.fidelity < minimum:
            raise FidelityError(
                f"Model {self.model_name!r} is at {self.fidelity.label} but "
                f"{minimum.label} is required for this use."
            )

    def assert_not_process_control(self) -> None:
        """Raise unless this output may legitimately drive a physical process."""
        if not self.fidelity.may_drive_physical_process:
            raise FidelityError(
                f"Model {self.model_name!r} is at {self.fidelity.label}. "
                "It must not be used to set a physical process parameter without "
                "engineering validation against production data, equipment "
                "specifications, food-safety requirements and applicable regulation."
            )

    def banner(self) -> str:
        """One-line banner suitable for printing above a results table."""
        return f"[{self.fidelity.label}] {self.model_name} -- {self.basis}"


class FidelityRegistry:
    """Process-wide record of which models contributed to a session.

    The registry lets a report state honestly what it is built on. Call
    :meth:`record` when a model produces output, then :meth:`report` to obtain
    a summary of every model used and its fidelity.
    """

    def __init__(self) -> None:
        self._records: dict[str, ModelProvenance] = {}

    def record(self, provenance: ModelProvenance) -> ModelProvenance:
        """Register a provenance record and return it unchanged."""
        existing = self._records.get(provenance.model_name)
        if existing is None or provenance.fidelity > existing.fidelity:
            self._records[provenance.model_name] = provenance
        return provenance

    def clear(self) -> None:
        """Forget all recorded models."""
        self._records.clear()

    @property
    def models(self) -> dict[str, ModelProvenance]:
        """All recorded provenance keyed by model name."""
        return dict(self._records)

    def lowest_fidelity(self) -> ModelFidelity:
        """The weakest fidelity present, i.e. the fidelity of the whole session."""
        if not self._records:
            return ModelFidelity.SIMULATION
        return min(record.fidelity for record in self._records.values())

    def unvalidated(self) -> list[str]:
        """Names of models that have not reached engineering validation."""
        return sorted(
            name
            for name, record in self._records.items()
            if record.fidelity is not ModelFidelity.ENGINEERING_VALIDATION
        )

    def report(self) -> str:
        """Render a plain-text fidelity report."""
        lines = [
            "MODEL FIDELITY REPORT",
            "=" * 60,
            f"Session fidelity: {self.lowest_fidelity().label}",
            "",
        ]
        for name in sorted(self._records):
            record = self._records[name]
            lines.append(f"  {record.fidelity.label:<24} {name}")
            if record.basis:
                lines.append(f"    basis: {record.basis}")
        unvalidated = self.unvalidated()
        if unvalidated:
            lines += [
                "",
                f"{len(unvalidated)} model(s) are NOT engineering-validated.",
                "Any real-world deployment requires validation against actual",
                "production data, food-safety requirements, HACCP procedures,",
                "equipment specifications and applicable regulatory requirements.",
            ]
        return "\n".join(lines)


#: Default process-wide registry.
REGISTRY = FidelityRegistry()


__all__ = [
    "PREDICTION_CAVEAT",
    "REGISTRY",
    "SIMULATION_CAVEAT",
    "CalibrationRecord",
    "FidelityRegistry",
    "ModelFidelity",
    "ModelProvenance",
    "ValidationRecord",
]
