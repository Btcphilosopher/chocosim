"""Base model types and the mass-conservation invariant.

Every quantitative object in ChocoSim derives from :class:`ChocoModel`, which
fixes one Pydantic configuration for the whole codebase: strict extra-field
rejection, validated assignment, and enum values preserved as enums.

The other thing living here is :class:`MassBalance`, the invariant that makes
the process engine trustworthy. Chocolate manufacturing is a mass-conserving
sequence of operations: whatever enters a unit operation leaves it as product,
as an intentional loss (moisture driven off, shell removed) or as waste. If
those three do not add up to the input, the model is wrong, and ChocoSim
raises rather than quietly producing chocolate from nothing.
"""

from __future__ import annotations

import math
from typing import Any, Self

from pydantic import BaseModel, ConfigDict, Field, model_validator

from .exceptions import MassBalanceError
from .types import Kilograms

#: Absolute tolerance for mass balance checks, in kilograms.
#: One milligram: far below any process-relevant quantity, far above float noise
#: accumulated over a few dozen arithmetic operations on tonne-scale batches.
MASS_TOLERANCE_KG: float = 1e-6

#: Relative tolerance applied on top of the absolute one for large batches.
MASS_RELATIVE_TOLERANCE: float = 1e-9


class ChocoModel(BaseModel):
    """Base class for all ChocoSim domain models."""

    model_config = ConfigDict(
        extra="forbid",
        validate_assignment=True,
        use_enum_values=False,
        arbitrary_types_allowed=False,
        populate_by_name=True,
        str_strip_whitespace=True,
    )


class FrozenChocoModel(ChocoModel):
    """Immutable variant used for results, snapshots and identity records."""

    model_config = ConfigDict(
        extra="forbid",
        frozen=True,
        use_enum_values=False,
        populate_by_name=True,
        str_strip_whitespace=True,
    )


class MassBalance(FrozenChocoModel):
    """Mass accounting for one unit operation.

    Invariant::

        mass_in == mass_out + mass_loss + mass_waste   (within tolerance)

    ``mass_loss`` covers intended, non-recoverable removals: water evaporated
    during roasting or conching, shell removed at winnowing, volatiles driven
    off. ``mass_waste`` covers unintended losses: line residue, rejected
    product, spillage. The distinction matters because loss is a yield fact
    while waste is a cost and an environmental line item.
    """

    stage: str = Field(description="Name of the unit operation.")
    mass_in: Kilograms = Field(ge=0.0, description="Mass entering the stage, kg.")
    mass_out: Kilograms = Field(ge=0.0, description="Product mass leaving the stage, kg.")
    mass_loss: Kilograms = Field(
        default=0.0, ge=0.0, description="Intended non-recoverable loss, kg."
    )
    mass_waste: Kilograms = Field(
        default=0.0, ge=0.0, description="Unintended waste or reject, kg."
    )

    @model_validator(mode="after")
    def _check_conservation(self) -> Self:
        accounted = self.mass_out + self.mass_loss + self.mass_waste
        tolerance = MASS_TOLERANCE_KG + MASS_RELATIVE_TOLERANCE * max(
            abs(self.mass_in), abs(accounted)
        )
        if not math.isclose(accounted, self.mass_in, abs_tol=tolerance, rel_tol=0.0):
            raise MassBalanceError(
                stage=self.stage,
                mass_in=self.mass_in,
                mass_out=accounted,
                tolerance=tolerance,
            )
        return self

    @property
    def yield_fraction(self) -> float:
        """Product mass out divided by mass in. Zero input yields zero."""
        if self.mass_in <= 0.0:
            return 0.0
        return self.mass_out / self.mass_in

    @property
    def loss_fraction(self) -> float:
        """Intended loss as a fraction of input mass."""
        if self.mass_in <= 0.0:
            return 0.0
        return self.mass_loss / self.mass_in

    @property
    def waste_fraction(self) -> float:
        """Unintended waste as a fraction of input mass."""
        if self.mass_in <= 0.0:
            return 0.0
        return self.mass_waste / self.mass_in

    @classmethod
    def from_yield(
        cls,
        stage: str,
        mass_in: Kilograms,
        loss_fraction: float = 0.0,
        waste_fraction: float = 0.0,
    ) -> Self:
        """Construct a balance from fractional loss and waste.

        The product mass is computed as the residual so that the invariant
        holds exactly rather than to within rounding.
        """
        if loss_fraction < 0.0 or waste_fraction < 0.0:
            raise ValueError("loss and waste fractions must be non-negative")
        if loss_fraction + waste_fraction > 1.0:
            raise ValueError(
                f"loss ({loss_fraction:.4f}) + waste ({waste_fraction:.4f}) "
                "exceeds 1.0; a stage cannot lose more than it receives"
            )
        loss = mass_in * loss_fraction
        waste = mass_in * waste_fraction
        out = mass_in - loss - waste
        return cls(
            stage=stage,
            mass_in=mass_in,
            mass_out=out,
            mass_loss=loss,
            mass_waste=waste,
        )

    def then(self, other: MassBalance) -> MassBalance:
        """Compose two consecutive balances into an overall balance.

        Raises :class:`MassBalanceError` if ``other`` does not start from this
        balance's output, which catches stages wired together incorrectly.
        """
        tolerance = MASS_TOLERANCE_KG + MASS_RELATIVE_TOLERANCE * max(
            abs(self.mass_out), abs(other.mass_in)
        )
        if not math.isclose(
            other.mass_in, self.mass_out, abs_tol=tolerance, rel_tol=0.0
        ):
            raise MassBalanceError(
                stage=f"{self.stage}->{other.stage}",
                mass_in=self.mass_out,
                mass_out=other.mass_in,
                tolerance=tolerance,
            )
        return MassBalance(
            stage=f"{self.stage}+{other.stage}",
            mass_in=self.mass_in,
            mass_out=other.mass_out,
            mass_loss=self.mass_loss + other.mass_loss,
            mass_waste=self.mass_waste + other.mass_waste,
        )

    def __str__(self) -> str:
        return (
            f"{self.stage}: {self.mass_in:.3f} kg in -> {self.mass_out:.3f} kg out "
            f"(loss {self.mass_loss:.3f}, waste {self.mass_waste:.3f}, "
            f"yield {self.yield_fraction:.2%})"
        )


#: Names of the mutually exclusive mass buckets that must close to <= 1.0.
CLOSURE_FIELDS: tuple[str, ...] = (
    "fat",
    "moisture",
    "sugar",
    "cocoa_solids_nonfat",
    "milk_solids_nonfat",
)

#: Fields that are sub-fractions of a closure field rather than buckets of
#: their own. Each maps to the closure field that contains it.
OVERLAY_FIELDS: dict[str, str] = {
    "milk_fat": "fat",
    "other_fat": "fat",
    "lactose": "sugar",
}


class Composition(FrozenChocoModel):
    """Compositional analysis of a material stream, as mass fractions.

    Two kinds of field are distinguished, because getting this wrong is the
    classic source of silent errors in formulation software.

    **Closure buckets** are mutually exclusive and together account for the
    whole stream: ``fat``, ``moisture``, ``sugar``, ``cocoa_solids_nonfat``
    and ``milk_solids_nonfat``. Whatever they leave over is
    :attr:`other_solids` -- nut solids, fruit solids, fibre from non-cocoa
    sources, ash. They may sum to at most 1.0.

    **Overlays** are sub-fractions *of* a closure bucket and are never added
    to the total: ``milk_fat`` and ``other_fat`` are portions of ``fat``,
    ``lactose`` is a portion of ``sugar``, and ``protein`` is spread across
    whichever non-fat solids it belongs to.

    The one convention worth stating explicitly: ``milk_solids_nonfat`` here
    means milk protein and minerals *only*. Lactose is booked under ``sugar``
    like every other sugar, and re-joined via :attr:`dry_milk_solids` when the
    declarable milk-solids figure is needed. Trade usage folds lactose into
    MSNF, which would double-count it against ``sugar``; splitting the two and
    recombining on demand keeps the mass balance honest and still produces the
    conventional number.
    """

    # --- closure buckets ---------------------------------------------------
    fat: float = Field(default=0.0, ge=0.0, le=1.0, description="Total fat fraction.")
    moisture: float = Field(default=0.0, ge=0.0, le=1.0, description="Water fraction.")
    sugar: float = Field(
        default=0.0, ge=0.0, le=1.0, description="Total sugars, lactose included."
    )
    cocoa_solids_nonfat: float = Field(
        default=0.0,
        ge=0.0,
        le=1.0,
        description="Non-fat cocoa solids: cocoa protein, fibre, ash, polyphenols.",
    )
    milk_solids_nonfat: float = Field(
        default=0.0,
        ge=0.0,
        le=1.0,
        description="Milk protein and minerals. Excludes lactose and milk fat.",
    )

    # --- overlays ----------------------------------------------------------
    milk_fat: float = Field(
        default=0.0, ge=0.0, le=1.0, description="Portion of `fat` that is milk fat."
    )
    other_fat: float = Field(
        default=0.0,
        ge=0.0,
        le=1.0,
        description="Portion of `fat` that is neither cocoa butter nor milk fat.",
    )
    lactose: float = Field(
        default=0.0, ge=0.0, le=1.0, description="Portion of `sugar` that is lactose."
    )
    protein: float = Field(
        default=0.0, ge=0.0, le=1.0, description="Total protein, spread across solids."
    )

    @model_validator(mode="after")
    def _check_closure(self) -> Self:
        total = sum(getattr(self, field) for field in CLOSURE_FIELDS)
        if total > 1.0 + 1e-9:
            raise ValueError(
                f"composition closure fields sum to {total:.6f}, which exceeds 1.0 "
                f"({', '.join(f'{f}={getattr(self, f):.4f}' for f in CLOSURE_FIELDS)})"
            )

        for overlay, parent in OVERLAY_FIELDS.items():
            if getattr(self, overlay) > getattr(self, parent) + 1e-9:
                raise ValueError(
                    f"overlay {overlay}={getattr(self, overlay):.6f} exceeds its "
                    f"parent {parent}={getattr(self, parent):.6f}"
                )
        if self.milk_fat + self.other_fat > self.fat + 1e-9:
            raise ValueError(
                f"milk_fat ({self.milk_fat:.6f}) + other_fat ({self.other_fat:.6f}) "
                f"exceeds total fat ({self.fat:.6f})"
            )

        # Protein must fit inside the non-fat, non-sugar, non-water solids.
        protein_capacity = (
            self.cocoa_solids_nonfat
            + self.milk_solids_nonfat
            + max(0.0, 1.0 - total)
        )
        if self.protein > protein_capacity + 1e-9:
            raise ValueError(
                f"protein ({self.protein:.6f}) exceeds the available non-fat solids "
                f"({protein_capacity:.6f})"
            )
        return self

    # ------------------------------------------------------------------
    # Derived quantities
    # ------------------------------------------------------------------

    @property
    def closure_total(self) -> float:
        """Sum of the mutually exclusive buckets."""
        return sum(getattr(self, field) for field in CLOSURE_FIELDS)

    @property
    def other_solids(self) -> float:
        """Dry solids not attributed to cocoa, milk, sugar or fat."""
        return max(0.0, 1.0 - self.closure_total)

    @property
    def total_solids(self) -> float:
        """Everything that is not water."""
        return 1.0 - self.moisture

    @property
    def cocoa_butter(self) -> float:
        """Fat attributable to cocoa butter."""
        return max(0.0, self.fat - self.milk_fat - self.other_fat)

    @property
    def total_cocoa_solids(self) -> float:
        """Cocoa butter plus non-fat cocoa solids.

        This is the figure behind a "70% cocoa" declaration. Fat from milk or
        other sources is excluded, which is why the overlay fields exist.
        """
        return self.cocoa_butter + self.cocoa_solids_nonfat

    @property
    def dry_milk_solids(self) -> float:
        """Total dry milk solids in the conventional sense.

        Milk fat plus lactose plus milk protein and minerals -- the figure a
        milk-chocolate compositional standard refers to.
        """
        return self.milk_fat + self.lactose + self.milk_solids_nonfat

    @property
    def non_lactose_sugar(self) -> float:
        """Added sugars, i.e. total sugar less lactose."""
        return max(0.0, self.sugar - self.lactose)

    # ------------------------------------------------------------------
    # Operations
    # ------------------------------------------------------------------

    def blend(self, other: Composition, self_mass: float, other_mass: float) -> Composition:
        """Mass-weighted blend of two compositions."""
        return blend_compositions([(self, self_mass), (other, other_mass)])[0]

    def after_moisture_loss(self, moisture_removed_fraction_of_total: float) -> Composition:
        """Recompute composition after removing water.

        ``moisture_removed_fraction_of_total`` is the removed water expressed
        as a fraction of the *original total mass*. Remaining components keep
        their absolute masses, so their fractions rise proportionally.
        """
        removed = moisture_removed_fraction_of_total
        if removed <= 0.0:
            return self
        if removed > self.moisture + 1e-12:
            raise ValueError(
                f"cannot remove {removed:.6f} moisture from a stream containing "
                f"{self.moisture:.6f}"
            )
        remaining_mass = 1.0 - removed
        if remaining_mass <= 0.0:
            raise ValueError("moisture removal would consume the entire stream")
        scale = 1.0 / remaining_mass
        scaled = {
            field: min(1.0, getattr(self, field) * scale)
            for field in (*CLOSURE_FIELDS, *OVERLAY_FIELDS, "protein")
            if field != "moisture"
        }
        scaled["moisture"] = max(0.0, (self.moisture - removed) * scale)
        return Composition(**scaled)

    def as_dict(self) -> dict[str, float]:
        """Composition as a plain dictionary including derived fields."""
        base = {
            field: getattr(self, field)
            for field in (*CLOSURE_FIELDS, *OVERLAY_FIELDS, "protein")
        }
        base.update(
            other_solids=self.other_solids,
            total_solids=self.total_solids,
            cocoa_butter=self.cocoa_butter,
            total_cocoa_solids=self.total_cocoa_solids,
            dry_milk_solids=self.dry_milk_solids,
        )
        return base


def blend_compositions(
    parts: list[tuple[Composition, float]],
) -> tuple[Composition, float]:
    """Mass-weighted blend of many compositions.

    Returns the blended composition and the total mass. An empty list yields
    an empty composition and zero mass rather than raising, so that callers
    building a recipe incrementally need no special case.
    """
    total_mass = sum(mass for _, mass in parts)
    if total_mass <= 0.0:
        return Composition(), 0.0

    fields = (*CLOSURE_FIELDS, *OVERLAY_FIELDS, "protein")
    accumulator: dict[str, float] = dict.fromkeys(fields, 0.0)
    for composition, mass in parts:
        if mass <= 0.0:
            continue
        weight = mass / total_mass
        for field in fields:
            accumulator[field] += getattr(composition, field) * weight

    # Guard against float drift pushing the closure a hair over 1.0. Scaling
    # every field by the same factor preserves the overlay relationships.
    closure = sum(accumulator[field] for field in CLOSURE_FIELDS)
    if closure > 1.0:
        scale = 1.0 / closure
        for field in fields:
            accumulator[field] = min(1.0, accumulator[field] * scale)

    return Composition(**accumulator), total_mass


def assert_mass_conserved(
    stage: str,
    mass_in: Kilograms,
    mass_out: Kilograms,
    mass_loss: Kilograms = 0.0,
    mass_waste: Kilograms = 0.0,
) -> MassBalance:
    """Validate and return a mass balance for a stage.

    Thin wrapper that reads clearly at the call site inside a process model.
    """
    return MassBalance(
        stage=stage,
        mass_in=mass_in,
        mass_out=mass_out,
        mass_loss=mass_loss,
        mass_waste=mass_waste,
    )


class Interval(FrozenChocoModel):
    """A closed numeric interval used for specifications and tolerances."""

    low: float
    high: float

    @model_validator(mode="after")
    def _ordered(self) -> Self:
        if self.high < self.low:
            raise ValueError(f"interval high ({self.high}) < low ({self.low})")
        return self

    def contains(self, value: float) -> bool:
        """Whether ``value`` lies within the interval, inclusive."""
        return self.low <= value <= self.high

    @property
    def midpoint(self) -> float:
        """Centre of the interval."""
        return 0.5 * (self.low + self.high)

    @property
    def width(self) -> float:
        """Width of the interval."""
        return self.high - self.low

    def clamp(self, value: float) -> float:
        """Clamp ``value`` into the interval."""
        return min(self.high, max(self.low, value))

    def normalised_deviation(self, value: float) -> float:
        """How far outside the interval ``value`` sits, in half-widths.

        Zero inside the interval, rising linearly outside. Half-width scaling
        makes the measure comparable across specifications with different units.
        """
        if self.contains(value):
            return 0.0
        half_width = max(self.width / 2.0, 1e-12)
        if value < self.low:
            return (self.low - value) / half_width
        return (value - self.high) / half_width

    def __str__(self) -> str:
        return f"[{self.low:g}, {self.high:g}]"


def clamp(value: float, low: float, high: float) -> float:
    """Clamp ``value`` to ``[low, high]``."""
    return min(high, max(low, value))


def safe_divide(numerator: float, denominator: float, default: float = 0.0) -> float:
    """Divide, returning ``default`` when the denominator is zero."""
    if denominator == 0.0:
        return default
    return numerator / denominator


def round_money(value: float, places: int = 4) -> float:
    """Round a monetary quantity.

    Four decimal places by default: unit costs in this domain routinely run to
    fractions of a penny per bar, and rounding to two places at intermediate
    steps accumulates visible error over a million-unit production run.
    """
    return round(value + 0.0, places)


__all__ = [
    "MASS_RELATIVE_TOLERANCE",
    "MASS_TOLERANCE_KG",
    "ChocoModel",
    "Composition",
    "FrozenChocoModel",
    "Interval",
    "MassBalance",
    "assert_mass_conserved",
    "blend_compositions",
    "clamp",
    "round_money",
    "safe_divide",
]
