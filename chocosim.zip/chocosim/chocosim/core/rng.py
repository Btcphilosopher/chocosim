"""Deterministic random-number management.

Reproducibility is a hard requirement of ChocoSim: the same seed and the same
inputs must produce byte-identical results, run after run, on any machine.

That rules out a single global generator shared by every model, because then
the result of a Monte Carlo run would depend on the *order* in which unrelated
sub-models happened to draw numbers. Instead ChocoSim uses a seed *tree*: a
root seed is combined with a stable textual path (``"roasting/moisture"``,
``"supply/lead_time/SUP-0003"``) to derive an independent generator. Adding a
new stochastic model therefore cannot perturb the draws of an existing one.

Derivation uses :class:`numpy.random.SeedSequence` spawning by hashed entropy,
which is designed for exactly this purpose.
"""

from __future__ import annotations

import hashlib
from collections.abc import Iterator, Sequence
from contextlib import contextmanager
from typing import Final

import numpy as np

#: Seed used when the caller does not supply one. Chosen arbitrarily; fixed so
#: that "no seed given" is still reproducible rather than silently random.
DEFAULT_SEED: Final[int] = 20_260_814

_MASK_64: Final[int] = (1 << 64) - 1


def _path_entropy(path: str) -> int:
    """Map a textual path to a stable 64-bit integer.

    Uses BLAKE2b rather than :func:`hash` because Python's string hashing is
    randomised per process unless ``PYTHONHASHSEED`` is fixed.
    """
    digest = hashlib.blake2b(path.encode("utf-8"), digest_size=8).digest()
    return int.from_bytes(digest, "big") & _MASK_64


class RandomSource:
    """A reproducible tree of independent random generators.

    Example
    -------
    >>> source = RandomSource(seed=42)
    >>> a = source.generator("roasting/moisture")
    >>> b = source.generator("demand/weekly")
    >>> first = a.normal()
    >>> _ = b.normal()          # drawing from b cannot affect a
    >>> source2 = RandomSource(seed=42)
    >>> bool(np.isclose(source2.generator("roasting/moisture").normal(), first))
    True
    """

    def __init__(self, seed: int | None = None) -> None:
        self._seed = DEFAULT_SEED if seed is None else int(seed)
        self._cache: dict[str, np.random.Generator] = {}

    @property
    def seed(self) -> int:
        """The root seed of this source."""
        return self._seed

    def generator(self, path: str) -> np.random.Generator:
        """Return the generator for ``path``, creating it on first use.

        The same path always returns the *same* generator object within a
        source, so sequential draws along one path advance one stream.
        """
        cached = self._cache.get(path)
        if cached is not None:
            return cached
        sequence = np.random.SeedSequence(
            entropy=self._seed, spawn_key=(_path_entropy(path),)
        )
        generator = np.random.default_rng(sequence)
        self._cache[path] = generator
        return generator

    def fresh(self, path: str) -> np.random.Generator:
        """Return a brand-new generator for ``path``, ignoring any cached stream.

        Useful when a model must draw the identical sequence on each of several
        calls, for example when re-running one stage in isolation.
        """
        sequence = np.random.SeedSequence(
            entropy=self._seed, spawn_key=(_path_entropy(path),)
        )
        return np.random.default_rng(sequence)

    def child(self, namespace: str) -> RandomSource:
        """Return a sub-source whose paths are prefixed by ``namespace``."""
        return _NamespacedSource(self, namespace)

    def replicate(self, index: int) -> RandomSource:
        """Return an independent source for Monte Carlo replication ``index``.

        Replicate *i* is fully independent of replicate *j*, and replicate *i*
        is identical whether the run executes replicates serially or in
        parallel, and regardless of how many replicates are requested.
        """
        derived = np.random.SeedSequence(
            entropy=self._seed, spawn_key=(_path_entropy("replicate"), int(index))
        )
        # Draw a stable 64-bit seed for the child source.
        (child_seed,) = derived.generate_state(1, dtype=np.uint64)
        return RandomSource(seed=int(child_seed))

    def reset(self) -> None:
        """Discard all cached generators, rewinding every stream."""
        self._cache.clear()

    def __repr__(self) -> str:
        return f"RandomSource(seed={self._seed}, streams={len(self._cache)})"


class _NamespacedSource(RandomSource):
    """A view onto a parent source with every path prefixed."""

    def __init__(self, parent: RandomSource, namespace: str) -> None:
        super().__init__(seed=parent.seed)
        self._parent = parent
        self._namespace = namespace.rstrip("/")

    def _qualify(self, path: str) -> str:
        return f"{self._namespace}/{path}"

    def generator(self, path: str) -> np.random.Generator:
        return self._parent.generator(self._qualify(path))

    def fresh(self, path: str) -> np.random.Generator:
        return self._parent.fresh(self._qualify(path))

    def child(self, namespace: str) -> RandomSource:
        return _NamespacedSource(self._parent, self._qualify(namespace))

    def reset(self) -> None:
        self._parent.reset()

    def __repr__(self) -> str:
        return f"RandomSource(seed={self.seed}, namespace={self._namespace!r})"


# --------------------------------------------------------------------------
# Distribution helpers
# --------------------------------------------------------------------------


def truncated_normal(
    generator: np.random.Generator,
    mean: float,
    sigma: float,
    low: float,
    high: float,
    size: int | None = None,
    max_attempts: int = 64,
) -> float | np.ndarray:
    """Draw from a normal distribution truncated to ``[low, high]``.

    Rejection sampling with a deterministic fallback: any samples still out of
    bounds after ``max_attempts`` rounds are clipped. Clipping is a
    distributional compromise, but it guarantees termination, which matters
    more inside a Monte Carlo loop than the tail being exactly right.
    """
    if high < low:
        raise ValueError(f"high ({high}) must be >= low ({low})")
    if sigma <= 0.0:
        value = float(np.clip(mean, low, high))
        return value if size is None else np.full(size, value)

    count = 1 if size is None else int(size)
    out = generator.normal(mean, sigma, count)
    for _ in range(max_attempts):
        bad = (out < low) | (out > high)
        if not bad.any():
            break
        out[bad] = generator.normal(mean, sigma, int(bad.sum()))
    np.clip(out, low, high, out=out)
    return float(out[0]) if size is None else out


def lognormal_from_moments(
    generator: np.random.Generator,
    mean: float,
    coefficient_of_variation: float,
    size: int | None = None,
) -> float | np.ndarray:
    """Draw a lognormal variate with the given *arithmetic* mean and CV.

    Convenient for prices and durations, which are positive and right-skewed.
    ``coefficient_of_variation`` is the standard deviation divided by the
    mean of the resulting distribution, not of the underlying normal.
    """
    if mean <= 0.0:
        raise ValueError(f"mean must be positive, got {mean}")
    if coefficient_of_variation <= 0.0:
        return mean if size is None else np.full(size or 1, mean)
    sigma_squared = np.log1p(coefficient_of_variation**2)
    sigma = float(np.sqrt(sigma_squared))
    mu = float(np.log(mean) - 0.5 * sigma_squared)
    draw = generator.lognormal(mu, sigma, size)
    return float(draw) if size is None else draw


def triangular(
    generator: np.random.Generator,
    low: float,
    mode: float,
    high: float,
    size: int | None = None,
) -> float | np.ndarray:
    """Draw from a triangular distribution, the standard PERT-style estimate."""
    if not low <= mode <= high:
        raise ValueError(
            f"require low <= mode <= high, got {low}, {mode}, {high}"
        )
    if low == high:
        return low if size is None else np.full(size or 1, low)
    draw = generator.triangular(low, mode, high, size)
    return float(draw) if size is None else draw


def bernoulli(generator: np.random.Generator, probability: float) -> bool:
    """Return ``True`` with the given probability."""
    if probability <= 0.0:
        return False
    if probability >= 1.0:
        return True
    return bool(generator.random() < probability)


def exponential_interval(generator: np.random.Generator, mean: float) -> float:
    """Draw an exponential inter-arrival time with the given mean.

    A mean of zero or below yields zero, meaning "immediately" -- used to
    disable a stochastic process without branching at the call site.
    """
    if mean <= 0.0:
        return 0.0
    return float(generator.exponential(mean))


def weibull_time_to_failure(
    generator: np.random.Generator, scale: float, shape: float
) -> float:
    """Draw a Weibull time-to-failure.

    ``shape < 1`` gives infant mortality, ``shape == 1`` reduces to the
    exponential (constant hazard), ``shape > 1`` gives wear-out. Chocolate
    plant equipment is normally modelled with ``shape`` between 1.2 and 2.5.
    """
    if scale <= 0.0:
        return float("inf")
    if shape <= 0.0:
        raise ValueError(f"shape must be positive, got {shape}")
    return float(scale * generator.weibull(shape))


def percentiles(samples: Sequence[float] | np.ndarray, *levels: float) -> dict[str, float]:
    """Return named percentiles of ``samples``.

    Percentile keys follow the industrial convention where P90 is the
    *pessimistic* case for an output you want to be large: the caller passes
    the levels it wants and reads them back by label.
    """
    array = np.asarray(samples, dtype=float)
    if array.size == 0:
        return {f"p{level:g}": float("nan") for level in levels}
    values = np.percentile(array, list(levels))
    return {f"p{level:g}": float(value) for level, value in zip(levels, np.atleast_1d(values), strict=True)}


@contextmanager
def temporary_seed(source: RandomSource, seed: int) -> Iterator[RandomSource]:
    """Context manager yielding a source with a different root seed."""
    yield RandomSource(seed=seed)
    del source  # the original is untouched; parameter kept for call-site clarity


__all__ = [
    "DEFAULT_SEED",
    "RandomSource",
    "bernoulli",
    "exponential_interval",
    "lognormal_from_moments",
    "percentiles",
    "temporary_seed",
    "triangular",
    "truncated_normal",
    "weibull_time_to_failure",
]
