"""Shared enumerations and type aliases used across ChocoSim."""

from __future__ import annotations

import itertools
import threading
from enum import StrEnum
from typing import TypeAlias

# --------------------------------------------------------------------------
# Type aliases -- documentary, all resolve to float/str
# --------------------------------------------------------------------------

Kilograms: TypeAlias = float
Grams: TypeAlias = float
Minutes: TypeAlias = float
Seconds: TypeAlias = float
Hours: TypeAlias = float
Celsius: TypeAlias = float
KilowattHours: TypeAlias = float
Kilowatts: TypeAlias = float
Micrometres: TypeAlias = float
PascalSeconds: TypeAlias = float
Money: TypeAlias = float
Fraction: TypeAlias = float
Percent: TypeAlias = float

IngredientId: TypeAlias = str
RecipeId: TypeAlias = str
BatchId: TypeAlias = str
MachineId: TypeAlias = str
LineId: TypeAlias = str
LotId: TypeAlias = str
SupplierId: TypeAlias = str
OrderId: TypeAlias = str
SkuId: TypeAlias = str


# --------------------------------------------------------------------------
# Ingredient taxonomy
# --------------------------------------------------------------------------


class IngredientClass(StrEnum):
    """Broad functional class of a raw material."""

    COCOA_BEAN = "cocoa_bean"
    COCOA_NIB = "cocoa_nib"
    COCOA_LIQUOR = "cocoa_liquor"
    COCOA_BUTTER = "cocoa_butter"
    COCOA_POWDER = "cocoa_powder"
    SUGAR = "sugar"
    MILK_POWDER = "milk_powder"
    EMULSIFIER = "emulsifier"
    FLAVOURING = "flavouring"
    NUT = "nut"
    CARAMEL = "caramel"
    FRUIT = "fruit"
    FAT_OTHER = "fat_other"
    INCLUSION = "inclusion"
    OTHER = "other"


class CocoaOrigin(StrEnum):
    """Cocoa growing origin. Affects flavour precursors and price basis."""

    GHANA = "ghana"
    IVORY_COAST = "ivory_coast"
    ECUADOR = "ecuador"
    VENEZUELA = "venezuela"
    MADAGASCAR = "madagascar"
    INDONESIA = "indonesia"
    PERU = "peru"
    DOMINICAN_REPUBLIC = "dominican_republic"
    BLEND = "blend"
    NOT_APPLICABLE = "not_applicable"


class ChocolateType(StrEnum):
    """Finished chocolate category."""

    DARK = "dark"
    MILK = "milk"
    WHITE = "white"
    RUBY = "ruby"
    COMPOUND = "compound"
    FILLED = "filled"


# --------------------------------------------------------------------------
# Process taxonomy
# --------------------------------------------------------------------------


class ProcessStageKind(StrEnum):
    """Canonical unit operations of a chocolate line, in flow order."""

    RECEIVING = "receiving"
    ROASTING = "roasting"
    WINNOWING = "winnowing"
    GRINDING = "grinding"
    MIXING = "mixing"
    REFINING = "refining"
    CONCHING = "conching"
    TEMPERING = "tempering"
    MOULDING = "moulding"
    COOLING = "cooling"
    PACKAGING = "packaging"


#: Canonical ordering of unit operations. Used to validate process chains.
STAGE_ORDER: tuple[ProcessStageKind, ...] = (
    ProcessStageKind.RECEIVING,
    ProcessStageKind.ROASTING,
    ProcessStageKind.WINNOWING,
    ProcessStageKind.GRINDING,
    ProcessStageKind.MIXING,
    ProcessStageKind.REFINING,
    ProcessStageKind.CONCHING,
    ProcessStageKind.TEMPERING,
    ProcessStageKind.MOULDING,
    ProcessStageKind.COOLING,
    ProcessStageKind.PACKAGING,
)

STAGE_INDEX: dict[ProcessStageKind, int] = {
    stage: index for index, stage in enumerate(STAGE_ORDER)
}


class MaterialState(StrEnum):
    """Physical form of the material stream between unit operations."""

    WHOLE_BEAN = "whole_bean"
    ROASTED_BEAN = "roasted_bean"
    NIB = "nib"
    LIQUOR = "liquor"
    PASTE = "paste"
    REFINED_POWDER = "refined_powder"
    CONCHED_MASS = "conched_mass"
    TEMPERED_MASS = "tempered_mass"
    MOULDED_SOLID = "moulded_solid"
    FINISHED_GOOD = "finished_good"


# --------------------------------------------------------------------------
# Machine and line state
# --------------------------------------------------------------------------


class MachineState(StrEnum):
    """Operating state of a machine in the discrete-event simulation."""

    IDLE = "idle"
    RUNNING = "running"
    CHANGEOVER = "changeover"
    DOWN = "down"
    MAINTENANCE = "maintenance"
    STARVED = "starved"
    BLOCKED = "blocked"


class MachineClass(StrEnum):
    """Equipment class. Maps one-to-one onto a unit operation."""

    ROASTER = "roaster"
    WINNOWER = "winnower"
    GRINDER = "grinder"
    MIXER = "mixer"
    REFINER = "refiner"
    CONCHE = "conche"
    TEMPERER = "temperer"
    MOULDER = "moulder"
    COOLING_TUNNEL = "cooling_tunnel"
    PACKAGING_LINE = "packaging_line"


#: Which unit operation each machine class performs.
MACHINE_STAGE: dict[MachineClass, ProcessStageKind] = {
    MachineClass.ROASTER: ProcessStageKind.ROASTING,
    MachineClass.WINNOWER: ProcessStageKind.WINNOWING,
    MachineClass.GRINDER: ProcessStageKind.GRINDING,
    MachineClass.MIXER: ProcessStageKind.MIXING,
    MachineClass.REFINER: ProcessStageKind.REFINING,
    MachineClass.CONCHE: ProcessStageKind.CONCHING,
    MachineClass.TEMPERER: ProcessStageKind.TEMPERING,
    MachineClass.MOULDER: ProcessStageKind.MOULDING,
    MachineClass.COOLING_TUNNEL: ProcessStageKind.COOLING,
    MachineClass.PACKAGING_LINE: ProcessStageKind.PACKAGING,
}


class BatchStatus(StrEnum):
    """Lifecycle status of a production batch."""

    PLANNED = "planned"
    RELEASED = "released"
    IN_PROGRESS = "in_progress"
    COMPLETE = "complete"
    QUARANTINED = "quarantined"
    REWORK = "rework"
    SCRAPPED = "scrapped"


# --------------------------------------------------------------------------
# Quality and tempering
# --------------------------------------------------------------------------


class CrystalForm(StrEnum):
    """Cocoa butter polymorphic forms.

    Forms I to VI in order of increasing melting point and stability. Form V
    (beta-V) is the target for well-tempered chocolate; form VI is the slow
    ageing product associated with fat bloom.
    """

    FORM_I = "form_i"
    FORM_II = "form_ii"
    FORM_III = "form_iii"
    FORM_IV = "form_iv"
    FORM_V = "form_v"
    FORM_VI = "form_vi"


class TemperGrade(StrEnum):
    """Qualitative temper assessment derived from the tempering model."""

    UNTEMPERED = "untempered"
    UNDER_TEMPERED = "under_tempered"
    ACCEPTABLE = "acceptable"
    GOOD = "good"
    EXCELLENT = "excellent"
    OVER_TEMPERED = "over_tempered"


class QualityVerdict(StrEnum):
    """Overall disposition of a batch against the quality specification."""

    PASS = "pass"
    MARGINAL = "marginal"
    FAIL = "fail"


class DefectKind(StrEnum):
    """Defect modes tracked by the quality model."""

    FAT_BLOOM = "fat_bloom"
    SUGAR_BLOOM = "sugar_bloom"
    AIR_BUBBLE = "air_bubble"
    INCOMPLETE_FILL = "incomplete_fill"
    DEMOULD_FAILURE = "demould_failure"
    GRITTY_TEXTURE = "gritty_texture"
    HIGH_VISCOSITY = "high_viscosity"
    MOISTURE_OUT_OF_SPEC = "moisture_out_of_spec"
    COLOUR_DEVIATION = "colour_deviation"
    FOREIGN_BODY = "foreign_body"

    # --- appearance and set defects attributable to temper and cooling ----
    DULL_SURFACE = "dull_surface"
    STREAKING = "streaking"
    SOFT_SET = "soft_set"
    WEIGHT_VARIANCE = "weight_variance"


# --------------------------------------------------------------------------
# Inventory and supply chain
# --------------------------------------------------------------------------


class StockCategory(StrEnum):
    """Where a stock lot sits in the material flow."""

    RAW_MATERIAL = "raw_material"
    WORK_IN_PROGRESS = "work_in_progress"
    FINISHED_GOODS = "finished_goods"
    PACKAGING_MATERIAL = "packaging_material"


class StockMoveKind(StrEnum):
    """Reason for an inventory movement."""

    RECEIPT = "receipt"
    ISSUE = "issue"
    PRODUCTION = "production"
    SALE = "sale"
    WASTE = "waste"
    EXPIRY = "expiry"
    ADJUSTMENT = "adjustment"
    TRANSFER = "transfer"


class DisruptionKind(StrEnum):
    """Supply-chain disruption modes."""

    NONE = "none"

    # --- delivery performance -------------------------------------------
    LATE_DELIVERY = "late_delivery"
    SHORT_DELIVERY = "short_delivery"
    QUALITY_REJECTION = "quality_rejection"
    SUPPLIER_OUTAGE = "supplier_outage"

    # --- market and upstream causes -------------------------------------
    # Kept distinct from the delivery-performance modes above even where the
    # mechanism is similar, because the remedies differ: a price shock is
    # hedged, a shortage is buffered, a logistics delay is planned around,
    # and a quality failure is inspected for.
    PRICE_SHOCK = "price_shock"
    CROP_FAILURE = "crop_failure"
    SUPPLY_SHORTAGE = "supply_shortage"
    SUPPLIER_FAILURE = "supplier_failure"
    LOGISTICS_DELAY = "logistics_delay"
    PORT_CONGESTION = "port_congestion"
    QUALITY_FAILURE = "quality_failure"


# --------------------------------------------------------------------------
# Energy and economics
# --------------------------------------------------------------------------


class EnergyCarrier(StrEnum):
    """Energy carriers consumed by the factory."""

    ELECTRICITY = "electricity"
    NATURAL_GAS = "natural_gas"
    STEAM = "steam"
    CHILLED_WATER = "chilled_water"
    COMPRESSED_AIR = "compressed_air"


class CostCategory(StrEnum):
    """Cost buckets used by the economic engine."""

    INGREDIENTS = "ingredients"
    PACKAGING = "packaging"
    ENERGY = "energy"
    LABOUR = "labour"
    MAINTENANCE = "maintenance"
    WASTE = "waste"
    OVERHEAD = "overhead"
    LOGISTICS = "logistics"
    DEPRECIATION = "depreciation"


class OptimisationSense(StrEnum):
    """Direction of an optimisation objective."""

    MINIMISE = "minimise"
    MAXIMISE = "maximise"


class SolverStatus(StrEnum):
    """Normalised solver outcome across OR-Tools backends."""

    OPTIMAL = "optimal"
    FEASIBLE = "feasible"
    INFEASIBLE = "infeasible"
    UNBOUNDED = "unbounded"
    NOT_SOLVED = "not_solved"
    ERROR = "error"

    @property
    def is_usable(self) -> bool:
        """Whether a solution can be read from this status."""
        return self in (SolverStatus.OPTIMAL, SolverStatus.FEASIBLE)


# --------------------------------------------------------------------------
# Deterministic identifier generation
# --------------------------------------------------------------------------

_counter_lock = threading.Lock()
_counters: dict[str, itertools.count] = {}


def next_id(prefix: str, width: int = 4) -> str:
    """Return a deterministic monotonically increasing identifier.

    Identifiers are sequential per prefix so that a simulation replayed with
    the same seed produces identical identifiers. Call :func:`reset_ids`
    between independent runs (the test suite does this in a fixture).
    """
    with _counter_lock:
        counter = _counters.get(prefix)
        if counter is None:
            counter = itertools.count(1)
            _counters[prefix] = counter
        value = next(counter)
    return f"{prefix}-{value:0{width}d}"


def reset_ids() -> None:
    """Reset all identifier counters. Used to make runs reproducible."""
    with _counter_lock:
        _counters.clear()


__all__ = [
    "MACHINE_STAGE",
    "STAGE_INDEX",
    "STAGE_ORDER",
    "BatchId",
    "BatchStatus",
    "Celsius",
    "ChocolateType",
    "CocoaOrigin",
    "CostCategory",
    "CrystalForm",
    "DefectKind",
    "DisruptionKind",
    "EnergyCarrier",
    "Fraction",
    "Grams",
    "Hours",
    "IngredientClass",
    "IngredientId",
    "Kilograms",
    "KilowattHours",
    "Kilowatts",
    "LineId",
    "LotId",
    "MachineClass",
    "MachineId",
    "MachineState",
    "MaterialState",
    "Micrometres",
    "Minutes",
    "Money",
    "OptimisationSense",
    "OrderId",
    "PascalSeconds",
    "Percent",
    "ProcessStageKind",
    "QualityVerdict",
    "RecipeId",
    "Seconds",
    "SkuId",
    "SolverStatus",
    "StockCategory",
    "StockMoveKind",
    "SupplierId",
    "TemperGrade",
    "next_id",
    "reset_ids",
]
