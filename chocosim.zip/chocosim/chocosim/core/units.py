"""Unit conventions and physical constants for ChocoSim.

ChocoSim uses a single canonical unit system throughout the engine. Every
quantity crossing a module boundary is expressed in these units. Conversion
helpers exist for presentation only -- the simulation core never works in
mixed units.

Canonical units
---------------
mass            kilogram (kg)
time            second (s) internally, minute (min) for process recipes
temperature     degree Celsius (degC)
energy          kilowatt-hour (kWh)
power           kilowatt (kW)
length          metre (m); particle sizes in micrometre (um)
viscosity       pascal-second (Pa.s)
money           GBP (configurable via EconomicConfig.currency label only)
pressure        pascal (Pa)

The thermophysical constants below are representative literature values for
cocoa-derived materials. They are *simulation inputs*, not measured plant
data, and are tagged as such wherever they influence a model output.
"""

from __future__ import annotations

from typing import Final

# --------------------------------------------------------------------------
# Time conversions
# --------------------------------------------------------------------------

SECONDS_PER_MINUTE: Final[float] = 60.0
SECONDS_PER_HOUR: Final[float] = 3600.0
MINUTES_PER_HOUR: Final[float] = 60.0
HOURS_PER_DAY: Final[float] = 24.0
SECONDS_PER_DAY: Final[float] = 86_400.0


def minutes_to_seconds(minutes: float) -> float:
    """Convert minutes to seconds."""
    return minutes * SECONDS_PER_MINUTE


def seconds_to_minutes(seconds: float) -> float:
    """Convert seconds to minutes."""
    return seconds / SECONDS_PER_MINUTE


def hours_to_minutes(hours: float) -> float:
    """Convert hours to minutes."""
    return hours * MINUTES_PER_HOUR


def minutes_to_hours(minutes: float) -> float:
    """Convert minutes to hours."""
    return minutes / MINUTES_PER_HOUR


# --------------------------------------------------------------------------
# Mass conversions
# --------------------------------------------------------------------------

GRAMS_PER_KILOGRAM: Final[float] = 1000.0
KILOGRAMS_PER_TONNE: Final[float] = 1000.0


def grams_to_kilograms(grams: float) -> float:
    """Convert grams to kilograms."""
    return grams / GRAMS_PER_KILOGRAM


def kilograms_to_grams(kilograms: float) -> float:
    """Convert kilograms to grams."""
    return kilograms * GRAMS_PER_KILOGRAM


def tonnes_to_kilograms(tonnes: float) -> float:
    """Convert metric tonnes to kilograms."""
    return tonnes * KILOGRAMS_PER_TONNE


# --------------------------------------------------------------------------
# Energy conversions
# --------------------------------------------------------------------------

JOULES_PER_KWH: Final[float] = 3.6e6
KJ_PER_KWH: Final[float] = 3600.0


def joules_to_kwh(joules: float) -> float:
    """Convert joules to kilowatt-hours."""
    return joules / JOULES_PER_KWH


def kwh_to_joules(kwh: float) -> float:
    """Convert kilowatt-hours to joules."""
    return kwh * JOULES_PER_KWH


def kj_to_kwh(kilojoules: float) -> float:
    """Convert kilojoules to kilowatt-hours."""
    return kilojoules / KJ_PER_KWH


def kw_for(kwh: float, duration_minutes: float) -> float:
    """Average power (kW) drawn to deliver ``kwh`` over ``duration_minutes``."""
    if duration_minutes <= 0.0:
        return 0.0
    return kwh / minutes_to_hours(duration_minutes)


# --------------------------------------------------------------------------
# Temperature conversions
# --------------------------------------------------------------------------

KELVIN_OFFSET: Final[float] = 273.15


def celsius_to_kelvin(celsius: float) -> float:
    """Convert degrees Celsius to kelvin."""
    return celsius + KELVIN_OFFSET


def kelvin_to_celsius(kelvin: float) -> float:
    """Convert kelvin to degrees Celsius."""
    return kelvin - KELVIN_OFFSET


def celsius_to_fahrenheit(celsius: float) -> float:
    """Convert degrees Celsius to degrees Fahrenheit (presentation only)."""
    return celsius * 9.0 / 5.0 + 32.0


# --------------------------------------------------------------------------
# Thermophysical constants (simulation inputs -- see module docstring)
# --------------------------------------------------------------------------

#: Specific heat capacity of liquid chocolate mass, kJ/(kg.K).
CP_CHOCOLATE_LIQUID: Final[float] = 1.6

#: Specific heat capacity of solid chocolate, kJ/(kg.K).
CP_CHOCOLATE_SOLID: Final[float] = 1.4

#: Specific heat capacity of cocoa beans (dry basis), kJ/(kg.K).
CP_COCOA_BEAN: Final[float] = 1.42

#: Specific heat capacity of liquid water, kJ/(kg.K).
CP_WATER: Final[float] = 4.186

#: Latent heat of vaporisation of water at ~100 degC, kJ/kg.
LATENT_HEAT_VAPORISATION_WATER: Final[float] = 2257.0

#: Latent heat of crystallisation of cocoa butter, kJ/kg of fat.
#: Representative value for the beta-V polymorph.
LATENT_HEAT_COCOA_BUTTER_CRYSTALLISATION: Final[float] = 157.0

#: Bulk density of tempered chocolate mass, kg/m^3.
DENSITY_CHOCOLATE: Final[float] = 1300.0

#: Bulk density of whole cocoa beans, kg/m^3.
DENSITY_COCOA_BEAN_BULK: Final[float] = 600.0

#: Universal gas constant, J/(mol.K).
GAS_CONSTANT_R: Final[float] = 8.314462618

#: Reference ambient temperature used when no site condition is supplied, degC.
AMBIENT_TEMPERATURE_C: Final[float] = 20.0

#: Nominal shell fraction of a whole cocoa bean removed at winnowing.
COCOA_SHELL_FRACTION: Final[float] = 0.12

#: Metabolisable energy densities, kcal/g, used by the nutrition model.
KCAL_PER_G_FAT: Final[float] = 9.0
KCAL_PER_G_CARBOHYDRATE: Final[float] = 4.0
KCAL_PER_G_PROTEIN: Final[float] = 4.0
KJ_PER_KCAL: Final[float] = 4.184


# --------------------------------------------------------------------------
# Particle size conversions
# --------------------------------------------------------------------------

MICROMETRES_PER_METRE: Final[float] = 1e6


def micrometres_to_metres(micrometres: float) -> float:
    """Convert micrometres to metres."""
    return micrometres / MICROMETRES_PER_METRE


def metres_to_micrometres(metres: float) -> float:
    """Convert metres to micrometres."""
    return metres * MICROMETRES_PER_METRE


# --------------------------------------------------------------------------
# Fractions and percentages
# --------------------------------------------------------------------------


def percent_to_fraction(percent: float) -> float:
    """Convert a percentage (0-100) to a fraction (0-1)."""
    return percent / 100.0


def fraction_to_percent(fraction: float) -> float:
    """Convert a fraction (0-1) to a percentage (0-100)."""
    return fraction * 100.0


__all__ = [
    "AMBIENT_TEMPERATURE_C",
    "COCOA_SHELL_FRACTION",
    "CP_CHOCOLATE_LIQUID",
    "CP_CHOCOLATE_SOLID",
    "CP_COCOA_BEAN",
    "CP_WATER",
    "DENSITY_CHOCOLATE",
    "DENSITY_COCOA_BEAN_BULK",
    "GAS_CONSTANT_R",
    "GRAMS_PER_KILOGRAM",
    "HOURS_PER_DAY",
    "JOULES_PER_KWH",
    "KCAL_PER_G_CARBOHYDRATE",
    "KCAL_PER_G_FAT",
    "KCAL_PER_G_PROTEIN",
    "KELVIN_OFFSET",
    "KILOGRAMS_PER_TONNE",
    "KJ_PER_KCAL",
    "KJ_PER_KWH",
    "LATENT_HEAT_COCOA_BUTTER_CRYSTALLISATION",
    "LATENT_HEAT_VAPORISATION_WATER",
    "MICROMETRES_PER_METRE",
    "MINUTES_PER_HOUR",
    "SECONDS_PER_DAY",
    "SECONDS_PER_HOUR",
    "SECONDS_PER_MINUTE",
    "celsius_to_fahrenheit",
    "celsius_to_kelvin",
    "fraction_to_percent",
    "grams_to_kilograms",
    "hours_to_minutes",
    "joules_to_kwh",
    "kelvin_to_celsius",
    "kilograms_to_grams",
    "kj_to_kwh",
    "kw_for",
    "kwh_to_joules",
    "metres_to_micrometres",
    "micrometres_to_metres",
    "minutes_to_hours",
    "minutes_to_seconds",
    "percent_to_fraction",
    "seconds_to_minutes",
    "tonnes_to_kilograms",
]
