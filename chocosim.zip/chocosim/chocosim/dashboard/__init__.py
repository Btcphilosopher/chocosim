"""Dashboards: console panels and the HTML report."""

from .console import (
    bar,
    batch_table,
    gauge,
    optimisation_panel,
    sparkline,
    status_panel,
)
from .report import render_dashboard, write_dashboard

__all__ = [
    "bar", "batch_table", "gauge", "optimisation_panel", "render_dashboard",
    "sparkline", "status_panel", "write_dashboard",
]
