"""Console dashboard.

Renders the factory status as a fixed-width panel of the kind that sits on a
control room screen. Text rather than graphics on purpose: it works over SSH,
it survives being pasted into an email, and it forces every number to justify
its place on a 78-column line.
"""

from __future__ import annotations

from collections.abc import Sequence

from ..core.models import clamp, safe_divide
from ..optimisation.factory_opt import FactoryOptimisationResult
from ..production.factory import BatchOutcome, FactoryState
from ..production.line import LineRunResult

#: Panel width. 78 columns fits an 80-column terminal with a margin.
WIDTH: int = 78

#: Characters used to draw bars, from empty to full.
BAR_FULL: str = "\u2588"
BAR_PARTIAL: tuple[str, ...] = ("", "\u258f", "\u258e", "\u258d", "\u258c", "\u258b", "\u258a", "\u2589")


def rule(character: str = "\u2500", width: int = WIDTH) -> str:
    """A horizontal rule."""
    return character * width


def boxed(title: str, width: int = WIDTH) -> str:
    """A section header."""
    label = f" {title.upper()} "
    padding = width - len(label) - 2
    left = 2
    right = max(0, padding - left)
    return f"\u250c{'\u2500' * left}{label}{'\u2500' * right}\u2510"


def bar(fraction: float, width: int = 28) -> str:
    """A horizontal bar for a fraction between zero and one.

    Sub-character resolution via the eighth-block glyphs, so a bar can
    distinguish 71% from 74% at this width instead of rounding both to the
    same number of blocks.
    """
    value = clamp(fraction, 0.0, 1.0)
    total_eighths = int(round(value * width * 8))
    full = total_eighths // 8
    remainder = total_eighths % 8
    filled = BAR_FULL * full + BAR_PARTIAL[remainder]
    return filled.ljust(width, "\u00b7")


def gauge(label: str, fraction: float, display: str | None = None) -> str:
    """A labelled bar with a value."""
    shown = display if display is not None else f"{fraction:.1%}"
    return f"  {label:<22}{bar(fraction)} {shown:>10}"


def status_panel(
    state: FactoryState,
    line: LineRunResult | None = None,
    title: str = "CHOCOSIM FACTORY STATUS",
) -> str:
    """The main factory status panel."""
    lines = [
        rule("\u2550"),
        f"  {title}".ljust(WIDTH - 20) + f"{state.as_of.isoformat():>18}  ",
        rule("\u2550"),
        "",
        "  PRODUCTION",
        rule(),
        f"  Batches produced      {state.batches_produced:>12,}",
        f"  Produced              {state.produced_kg:>12,.1f} kg",
        f"  Saleable              {state.saleable_kg:>12,.1f} kg",
        f"  Waste                 {state.waste_kg:>12,.1f} kg",
        "",
        gauge("Pass rate", state.pass_rate),
        gauge("Quality score", state.mean_quality_score / 100.0,
              f"{state.mean_quality_score:.1f}/100"),
        gauge("Waste", state.waste_fraction, f"{state.waste_fraction:.2%}"),
        "",
        "  INVENTORY",
        rule(),
        f"  Raw materials         {state.raw_material_kg:>12,.1f} kg",
        f"  Work in progress      {state.wip_kg:>12,.1f} kg",
        f"  Finished goods        {state.finished_goods_kg:>12,.1f} kg",
        "",
        "  ENERGY",
        rule(),
        f"  Total consumed        {state.total_energy_kwh:>12,.1f} kWh",
        f"  Intensity             {state.energy_kwh_per_kg:>12,.3f} kWh/kg",
    ]

    if line is not None:
        bottleneck = line.bottleneck()
        lines += [
            "",
            "  LINE",
            rule(),
            f"  Throughput            {line.throughput_kg_per_hour:>12,.1f} kg/h",
            f"  Mean cycle time       {line.mean_cycle_time_minutes / 60.0:>12,.2f} h",
            "",
            gauge("Flow efficiency", line.mean_flow_efficiency),
            gauge("Completion rate", line.completion_rate),
            "",
            "  MACHINE UTILISATION",
            rule(),
        ]
        for stat in sorted(
            line.stage_statistics, key=lambda s: -s.utilisation
        ):
            marker = " <-- BOTTLENECK" if bottleneck and stat.stage is bottleneck.stage else ""
            lines.append(
                f"  {stat.stage.value:<14}{bar(stat.utilisation, 22)} "
                f"{stat.utilisation:>6.1%}{marker}"
            )

    lines += [
        "",
        rule("\u2550"),
        "  SIMULATION OUTPUT. Models are physically motivated but not",
        "  calibrated against or validated on any real plant. Not for",
        "  process control, food safety, or regulatory use.",
        rule("\u2550"),
    ]
    return "\n".join(lines)


def optimisation_panel(result: FactoryOptimisationResult) -> str:
    """The current-versus-optimised comparison panel."""
    current, optimised = result.current, result.optimised

    def compare(
        label: str, before: float, after: float, fmt: str, higher_is_better: bool
    ) -> str:
        delta = after - before
        improved = delta > 0 if higher_is_better else delta < 0
        marker = "\u25b2" if improved else ("\u25bc" if abs(delta) > 1e-9 else "\u00b7")
        before_text = format(before, fmt)
        after_text = format(after, fmt)
        delta_text = format(delta, "+" + fmt)
        return (
            f"  {label:<22}{before_text:>12}{after_text:>12}"
            f"{delta_text:>13}  {marker}"
        )

    lines = [
        rule("\u2550"),
        "  FACTORY OPTIMISATION".ljust(WIDTH),
        rule("\u2550"),
        "",
        f"  {'MEASURE':<22}{'CURRENT':>12}{'OPTIMISED':>12}{'CHANGE':>13}",
        rule(),
        compare(
            "Capacity utilisation",
            current.capacity_utilisation,
            optimised.capacity_utilisation,
            ".1%",
            True,
        ),
        compare(
            "Machine utilisation",
            current.machine_utilisation,
            optimised.machine_utilisation,
            ".1%",
            True,
        ),
        compare(
            "Energy intensity",
            current.energy_kwh_per_kg,
            optimised.energy_kwh_per_kg,
            ".3f",
            False,
        ),
        compare(
            "Waste", current.waste_fraction, optimised.waste_fraction, ".2%", False
        ),
        compare(
            "Changeover hours",
            current.changeover_hours,
            optimised.changeover_hours,
            ".1f",
            False,
        ),
        compare(
            "Cycle time hours",
            current.mean_cycle_time_hours,
            optimised.mean_cycle_time_hours,
            ".1f",
            False,
        ),
        rule(),
        f"  BOTTLENECK  {current.bottleneck_stage.upper() or 'n/a'} "
        f"({current.bottleneck_utilisation:.1%})",
        "",
        "  LEVERS",
        rule(),
    ]
    for lever in result.levers:
        lines.append(f"  {lever.summary()}")
    lines += [
        "",
        rule("\u2550"),
        "  SIMULATION OUTPUT. Improvements are measured by re-running the",
        "  model under optimised settings, not assumed. They are not a",
        "  forecast of what a real plant would achieve.",
        rule("\u2550"),
    ]
    return "\n".join(lines)


def batch_table(outcomes: Sequence[BatchOutcome], symbol: str = "\u00a3") -> str:
    """A table of batch outcomes."""
    if not outcomes:
        return "  No batches produced."
    lines = [
        f"  {'BATCH':<12}{'PRODUCT':<30}{'kg':>10}{'SCORE':>7}"
        f"{'kWh/kg':>9}{'COST/kg':>10}",
        rule(),
    ]
    for outcome in outcomes:
        lines.append(
            f"  {outcome.batch_id:<12}{outcome.recipe_name[:28]:<30}"
            f"{outcome.saleable_kg:>10,.1f}"
            f"{outcome.quality.overall_score:>7.1f}"
            f"{outcome.energy_kwh_per_kg:>9.3f}"
            f"{symbol + f'{outcome.cost_per_kg:.3f}':>10}"
        )
    total_kg = sum(outcome.saleable_kg for outcome in outcomes)
    mean_score = sum(
        outcome.quality.overall_score for outcome in outcomes
    ) / len(outcomes)
    lines += [
        rule(),
        f"  {'TOTAL':<12}{len(outcomes):<30}{total_kg:>10,.1f}{mean_score:>7.1f}",
    ]
    return "\n".join(lines)


def sparkline(values: Sequence[float], width: int = 40) -> str:
    """A single-line trace of a series."""
    blocks = "\u2581\u2582\u2583\u2584\u2585\u2586\u2587\u2588"
    if not values:
        return ""
    sampled = list(values)
    if len(sampled) > width:
        step = len(sampled) / width
        sampled = [sampled[int(index * step)] for index in range(width)]
    low, high = min(sampled), max(sampled)
    span = high - low
    if span <= 0.0:
        return blocks[0] * len(sampled)
    return "".join(
        blocks[min(len(blocks) - 1, int((value - low) / span * len(blocks)))]
        for value in sampled
    )


__all__ = [
    "WIDTH",
    "bar",
    "batch_table",
    "boxed",
    "gauge",
    "optimisation_panel",
    "rule",
    "sparkline",
    "status_panel",
]
