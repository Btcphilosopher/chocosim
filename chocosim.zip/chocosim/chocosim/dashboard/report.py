"""HTML dashboard.

Renders the factory state, batch results and optimisation comparison as a
self-contained HTML file with Plotly charts. Written to a single file with no
build step and no external assets beyond the Plotly CDN, so the output can be
emailed, committed, or opened from a USB stick on a factory floor machine that
has never seen a package manager.

The palette is near-black with gold and electric cyan, and the type is Bebas
Neue for headings against DM Mono for figures. Monospaced numerals matter more
than they sound: columns of figures that do not align are columns of figures
that get misread.
"""

from __future__ import annotations

import datetime as dt
import json
from collections.abc import Sequence

import plotly.graph_objects as go

from ..core.models import safe_divide
from ..optimisation.factory_opt import FactoryOptimisationResult
from ..production.factory import BatchOutcome, FactoryState
from ..production.line import LineRunResult
from ..simulation.scenarios import MonteCarloReport, ScenarioComparison

# --- palette ---------------------------------------------------------------

BACKGROUND = "#0A0A0C"
SURFACE = "#131318"
SURFACE_ALT = "#1A1A21"
GOLD = "#C9A84C"
CYAN = "#00E5FF"
TEXT = "#E8E6E1"
MUTED = "#8A8780"
GOOD = "#4CC98A"
WARN = "#E5A00D"
BAD = "#E5484D"

PLOT_TEMPLATE = {
    "layout": {
        "paper_bgcolor": SURFACE,
        "plot_bgcolor": SURFACE,
        "font": {"family": "DM Mono, monospace", "color": TEXT, "size": 12},
        "xaxis": {
            "gridcolor": "#26262E",
            "linecolor": "#33333D",
            "zerolinecolor": "#33333D",
        },
        "yaxis": {
            "gridcolor": "#26262E",
            "linecolor": "#33333D",
            "zerolinecolor": "#33333D",
        },
        "colorway": [GOLD, CYAN, GOOD, WARN, BAD, MUTED],
        "margin": {"l": 60, "r": 24, "t": 44, "b": 48},
    }
}

_STYLE = f"""
@import url('https://fonts.googleapis.com/css2?family=Bebas+Neue&family=DM+Mono:wght@300;400;500&display=swap');

* {{ box-sizing: border-box; }}
body {{
  margin: 0;
  padding: 0 0 64px;
  background: {BACKGROUND};
  color: {TEXT};
  font-family: 'DM Mono', ui-monospace, monospace;
  font-size: 14px;
  line-height: 1.55;
}}
header {{
  padding: 40px 48px 28px;
  border-bottom: 1px solid #26262E;
  background: linear-gradient(180deg, {SURFACE} 0%, {BACKGROUND} 100%);
}}
h1 {{
  font-family: 'Bebas Neue', sans-serif;
  font-size: 52px;
  letter-spacing: 4px;
  margin: 0;
  color: {GOLD};
  font-weight: 400;
}}
h2 {{
  font-family: 'Bebas Neue', sans-serif;
  font-size: 26px;
  letter-spacing: 2.5px;
  color: {CYAN};
  margin: 44px 0 16px;
  font-weight: 400;
}}
.subtitle {{ color: {MUTED}; letter-spacing: 1.5px; font-size: 13px; }}
main {{ padding: 0 48px; max-width: 1420px; margin: 0 auto; }}
.grid {{
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
  gap: 16px;
  margin: 20px 0;
}}
.card {{
  background: {SURFACE};
  border: 1px solid #26262E;
  border-left: 2px solid {GOLD};
  padding: 18px 20px;
}}
.card .label {{
  color: {MUTED};
  font-size: 11px;
  letter-spacing: 1.6px;
  text-transform: uppercase;
}}
.card .value {{
  font-size: 30px;
  color: {TEXT};
  margin-top: 6px;
  font-weight: 500;
}}
.card .unit {{ font-size: 14px; color: {MUTED}; margin-left: 5px; }}
.card.cyan {{ border-left-color: {CYAN}; }}
.card.good {{ border-left-color: {GOOD}; }}
.card.warn {{ border-left-color: {WARN}; }}
.card.bad  {{ border-left-color: {BAD}; }}
table {{
  width: 100%;
  border-collapse: collapse;
  margin: 14px 0 8px;
  font-size: 13px;
}}
th {{
  text-align: right;
  padding: 10px 12px;
  color: {CYAN};
  font-weight: 400;
  letter-spacing: 1.2px;
  font-size: 11px;
  text-transform: uppercase;
  border-bottom: 1px solid #33333D;
}}
th:first-child, td:first-child {{ text-align: left; }}
td {{
  text-align: right;
  padding: 9px 12px;
  border-bottom: 1px solid #1E1E25;
}}
tbody tr:hover {{ background: {SURFACE_ALT}; }}
.pass {{ color: {GOOD}; }}
.marginal {{ color: {WARN}; }}
.fail {{ color: {BAD}; }}
.delta-good {{ color: {GOOD}; }}
.delta-bad {{ color: {BAD}; }}
.chart {{
  background: {SURFACE};
  border: 1px solid #26262E;
  padding: 8px;
  margin: 16px 0;
}}
.notice {{
  margin: 40px 0 0;
  padding: 20px 24px;
  background: {SURFACE};
  border: 1px solid {GOLD};
  border-left-width: 3px;
  color: {MUTED};
  font-size: 12.5px;
  line-height: 1.7;
}}
.notice strong {{
  color: {GOLD};
  letter-spacing: 1.6px;
  display: block;
  margin-bottom: 8px;
  font-family: 'Bebas Neue', sans-serif;
  font-size: 17px;
}}
.warnings {{ margin: 12px 0; }}
.warnings li {{ color: {WARN}; margin-bottom: 5px; font-size: 12.5px; }}
footer {{
  padding: 28px 48px;
  color: {MUTED};
  font-size: 11.5px;
  letter-spacing: 1.2px;
  border-top: 1px solid #26262E;
  margin-top: 48px;
}}
"""

FIDELITY_NOTICE = """
<div class="notice">
  <strong>Simulation output</strong>
  Every figure on this page is produced by a physically motivated but
  <em>uncalibrated</em> model. Rate constants, kinetic parameters and cost
  rates are literature-scale values and configuration, not measurements from
  any real plant. Nothing here has been validated against a physical factory.
  <br><br>
  These outputs are suitable for comparing process options, exploring
  trade-offs and sizing the direction and rough magnitude of a change. They are
  <em>not</em> suitable for setting process parameters, making food-safety
  decisions, supporting regulatory submissions, or as a substitute for
  laboratory analysis and sensory assessment.
</div>
"""


def _figure_html(figure: go.Figure, height: int = 340) -> str:
    """Render a Plotly figure as an embeddable div."""
    figure.update_layout(template=PLOT_TEMPLATE, height=height)
    return figure.to_html(
        full_html=False, include_plotlyjs=False, config={"displayModeBar": False}
    )


def _card(label: str, value: str, unit: str = "", tone: str = "") -> str:
    """One metric card."""
    unit_html = f'<span class="unit">{unit}</span>' if unit else ""
    return (
        f'<div class="card {tone}"><div class="label">{label}</div>'
        f'<div class="value">{value}{unit_html}</div></div>'
    )


def _energy_chart(outcomes: Sequence[BatchOutcome]) -> go.Figure:
    """Energy intensity by batch."""
    figure = go.Figure()
    figure.add_trace(
        go.Bar(
            x=[outcome.recipe_name for outcome in outcomes],
            y=[outcome.energy_kwh_per_kg for outcome in outcomes],
            marker_color=GOLD,
            name="kWh/kg",
        )
    )
    figure.update_layout(
        title="ENERGY INTENSITY BY PRODUCT",
        yaxis_title="kWh per kg",
        xaxis_tickangle=-25,
    )
    return figure


def _cost_chart(outcomes: Sequence[BatchOutcome]) -> go.Figure:
    """Stacked cost breakdown by batch."""
    categories: dict[str, list[float]] = {}
    names = [outcome.recipe_name for outcome in outcomes]
    for outcome in outcomes:
        shares = outcome.costing.by_category()
        for category in shares:
            categories.setdefault(category, [])
    for outcome in outcomes:
        shares = outcome.costing.by_category()
        saleable = max(outcome.saleable_kg, 1e-9)
        for category in categories:
            categories[category].append(shares.get(category, 0.0) / saleable)

    figure = go.Figure()
    for category, values in categories.items():
        figure.add_trace(go.Bar(x=names, y=values, name=category))
    figure.update_layout(
        barmode="stack",
        title="COST PER KG BY CATEGORY",
        yaxis_title="cost per kg",
        xaxis_tickangle=-25,
    )
    return figure


def _quality_chart(outcomes: Sequence[BatchOutcome]) -> go.Figure:
    """Quality score by batch with the pass threshold marked."""
    scores = [outcome.quality.overall_score for outcome in outcomes]
    colours = [
        GOOD if score >= 80 else (WARN if score >= 70 else BAD) for score in scores
    ]
    figure = go.Figure()
    figure.add_trace(
        go.Bar(
            x=[outcome.batch_id for outcome in outcomes],
            y=scores,
            marker_color=colours,
            text=[f"{score:.1f}" for score in scores],
            textposition="outside",
        )
    )
    figure.add_hline(
        y=80,
        line_dash="dash",
        line_color=CYAN,
        annotation_text="pass threshold",
        annotation_font_color=CYAN,
    )
    figure.update_layout(
        title="BATCH QUALITY SCORE", yaxis_title="score", yaxis_range=[0, 108]
    )
    return figure


def _utilisation_chart(line: LineRunResult) -> go.Figure:
    """Machine utilisation, bottleneck highlighted."""
    bottleneck = line.bottleneck()
    stats = sorted(line.stage_statistics, key=lambda s: s.utilisation)
    colours = [
        CYAN if bottleneck and stat.stage is bottleneck.stage else GOLD
        for stat in stats
    ]
    figure = go.Figure()
    figure.add_trace(
        go.Bar(
            x=[stat.utilisation for stat in stats],
            y=[stat.stage.value for stat in stats],
            orientation="h",
            marker_color=colours,
            text=[f"{stat.utilisation:.1%}" for stat in stats],
            textposition="outside",
        )
    )
    figure.update_layout(
        title="MACHINE UTILISATION (BOTTLENECK IN CYAN)",
        xaxis_title="utilisation",
        xaxis_tickformat=".0%",
    )
    return figure


def _monte_carlo_chart(report: MonteCarloReport, metric: str) -> go.Figure | None:
    """Distribution of a Monte Carlo metric with percentile markers."""
    result = report.get(metric)
    if result is None:
        return None
    figure = go.Figure()
    figure.add_trace(
        go.Histogram(x=list(result.samples), marker_color=GOLD, nbinsx=28, name=metric)
    )
    for level, value, colour in (
        ("P10", result.p10, CYAN),
        ("P50", result.p50, TEXT),
        ("P90", result.p90, CYAN),
    ):
        figure.add_vline(
            x=value,
            line_dash="dash",
            line_color=colour,
            annotation_text=level,
            annotation_font_color=colour,
        )
    figure.update_layout(
        title=f"DISTRIBUTION -- {metric.upper().replace('_', ' ')}",
        xaxis_title=metric,
        yaxis_title="replications",
        showlegend=False,
    )
    return figure


def _scenario_chart(comparison: ScenarioComparison) -> go.Figure:
    """Scenario impact on unit cost."""
    names = [comparison.baseline.scenario_name] + [
        scenario.scenario_name for scenario in comparison.scenarios
    ]
    costs = [comparison.baseline.cost_per_kg] + [
        scenario.cost_per_kg for scenario in comparison.scenarios
    ]
    colours = [CYAN] + [GOLD] * len(comparison.scenarios)
    figure = go.Figure()
    figure.add_trace(
        go.Bar(
            x=names,
            y=costs,
            marker_color=colours,
            text=[f"{cost:.3f}" for cost in costs],
            textposition="outside",
        )
    )
    figure.update_layout(
        title="SCENARIO IMPACT ON UNIT COST",
        yaxis_title="cost per kg",
        xaxis_tickangle=-20,
    )
    return figure


def _batch_table(outcomes: Sequence[BatchOutcome], symbol: str = "\u00a3") -> str:
    """Batch results table."""
    rows = []
    for outcome in outcomes:
        verdict = outcome.quality.verdict.value
        rows.append(
            f"<tr><td>{outcome.batch_id}</td>"
            f"<td>{outcome.recipe_name}</td>"
            f"<td>{outcome.saleable_kg:,.1f}</td>"
            f'<td class="{verdict}">{outcome.quality.overall_score:.1f}</td>'
            f'<td class="{verdict}">{verdict}</td>'
            f"<td>{outcome.quality.temper_grade.value}</td>"
            f"<td>{outcome.energy_kwh_per_kg:.3f}</td>"
            f"<td>{symbol}{outcome.cost_per_kg:.4f}</td>"
            f"<td>{outcome.units_produced:,}</td></tr>"
        )
    return (
        "<table><thead><tr>"
        "<th>Batch</th><th>Product</th><th>Saleable kg</th><th>Score</th>"
        "<th>Verdict</th><th>Temper</th><th>kWh/kg</th><th>Cost/kg</th>"
        "<th>Units</th>"
        "</tr></thead><tbody>" + "".join(rows) + "</tbody></table>"
    )


def _optimisation_table(result: FactoryOptimisationResult) -> str:
    """Current versus optimised table."""

    def row(
        label: str, before: float, after: float, fmt: str, higher_is_better: bool
    ) -> str:
        delta = after - before
        improved = delta > 0 if higher_is_better else delta < 0
        css = "delta-good" if improved else ("delta-bad" if abs(delta) > 1e-9 else "")
        return (
            f"<tr><td>{label}</td><td>{format(before, fmt)}</td>"
            f"<td>{format(after, fmt)}</td>"
            f'<td class="{css}">{format(delta, "+" + fmt)}</td></tr>'
        )

    current, optimised = result.current, result.optimised
    rows = [
        row(
            "Capacity utilisation",
            current.capacity_utilisation,
            optimised.capacity_utilisation,
            ".1%",
            True,
        ),
        row(
            "Machine utilisation",
            current.machine_utilisation,
            optimised.machine_utilisation,
            ".1%",
            True,
        ),
        row(
            "Energy intensity kWh/kg",
            current.energy_kwh_per_kg,
            optimised.energy_kwh_per_kg,
            ".3f",
            False,
        ),
        row("Waste", current.waste_fraction, optimised.waste_fraction, ".2%", False),
        row(
            "Changeover hours",
            current.changeover_hours,
            optimised.changeover_hours,
            ".1f",
            False,
        ),
        row(
            "Cycle time hours",
            current.mean_cycle_time_hours,
            optimised.mean_cycle_time_hours,
            ".1f",
            False,
        ),
    ]
    return (
        "<table><thead><tr><th>Measure</th><th>Current</th>"
        "<th>Optimised</th><th>Change</th></tr></thead><tbody>"
        + "".join(rows)
        + "</tbody></table>"
    )


def render_dashboard(
    state: FactoryState,
    outcomes: Sequence[BatchOutcome],
    line: LineRunResult | None = None,
    optimisation: FactoryOptimisationResult | None = None,
    scenarios: ScenarioComparison | None = None,
    monte_carlo: MonteCarloReport | None = None,
    title: str = "CHOCOSIM",
    symbol: str = "\u00a3",
) -> str:
    """Render the complete dashboard as a self-contained HTML document."""
    total_cost = sum(outcome.costing.total_cost for outcome in outcomes)
    total_saleable = sum(outcome.saleable_kg for outcome in outcomes)
    cost_per_kg = safe_divide(total_cost, total_saleable)
    total_units = sum(outcome.units_produced for outcome in outcomes)

    pass_tone = (
        "good" if state.pass_rate >= 0.9 else ("warn" if state.pass_rate >= 0.75 else "bad")
    )
    waste_tone = (
        "good"
        if state.waste_fraction <= 0.02
        else ("warn" if state.waste_fraction <= 0.035 else "bad")
    )

    cards = "".join(
        [
            _card("Batches", f"{state.batches_produced:,}"),
            _card("Saleable", f"{state.saleable_kg:,.0f}", "kg", "cyan"),
            _card("Units packed", f"{total_units:,}"),
            _card("Cost per kg", f"{symbol}{cost_per_kg:.3f}"),
            _card(
                "Energy intensity",
                f"{state.energy_kwh_per_kg:.3f}",
                "kWh/kg",
                "cyan",
            ),
            _card("Mean quality", f"{state.mean_quality_score:.1f}", "/100"),
            _card("Pass rate", f"{state.pass_rate:.0%}", "", pass_tone),
            _card("Waste", f"{state.waste_fraction:.2%}", "", waste_tone),
        ]
    )

    sections: list[str] = [
        '<div class="grid">' + cards + "</div>",
        "<h2>Batch results</h2>",
        _batch_table(outcomes, symbol),
    ]

    warnings = [note for outcome in outcomes for note in outcome.process.notes]
    if warnings:
        unique = list(dict.fromkeys(warnings))[:12]
        sections += [
            "<h2>Process warnings</h2>",
            '<ul class="warnings">'
            + "".join(f"<li>{warning}</li>" for warning in unique)
            + "</ul>",
        ]

    if outcomes:
        sections += [
            "<h2>Quality</h2>",
            f'<div class="chart">{_figure_html(_quality_chart(outcomes))}</div>',
            "<h2>Energy and cost</h2>",
            f'<div class="chart">{_figure_html(_energy_chart(outcomes))}</div>',
            f'<div class="chart">{_figure_html(_cost_chart(outcomes))}</div>',
        ]

    if line is not None:
        sections += [
            "<h2>Line performance</h2>",
            f'<div class="chart">{_figure_html(_utilisation_chart(line))}</div>',
        ]

    if optimisation is not None:
        sections += [
            "<h2>Current versus optimised</h2>",
            _optimisation_table(optimisation),
        ]

    if scenarios is not None:
        sections += [
            "<h2>Scenarios</h2>",
            f'<div class="chart">{_figure_html(_scenario_chart(scenarios))}</div>',
        ]

    if monte_carlo is not None:
        sections.append("<h2>Monte Carlo</h2>")
        for metric in ("cost_per_kg", "energy_kwh_per_kg", "mean_quality_score"):
            figure = _monte_carlo_chart(monte_carlo, metric)
            if figure is not None:
                sections.append(f'<div class="chart">{_figure_html(figure)}</div>')

    generated = dt.datetime.now().strftime("%Y-%m-%d %H:%M")

    return f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>{title} -- Factory Dashboard</title>
<script src="https://cdn.plot.ly/plotly-2.35.2.min.js"></script>
<style>{_STYLE}</style>
</head>
<body>
<header>
  <h1>{title}</h1>
  <div class="subtitle">
    CHOCOLATE MANUFACTURING SIMULATOR &nbsp;&middot;&nbsp;
    {state.as_of.isoformat()} &nbsp;&middot;&nbsp; GENERATED {generated}
  </div>
</header>
<main>
{"".join(sections)}
{FIDELITY_NOTICE}
</main>
<footer>
  CHOCOSIM &nbsp;&middot;&nbsp; SIMULATION GRADE OUTPUT &nbsp;&middot;&nbsp;
  NOT VALIDATED AGAINST A PHYSICAL PLANT
</footer>
</body>
</html>"""


def write_dashboard(path: str, **kwargs: object) -> str:
    """Render the dashboard and write it to a file."""
    html = render_dashboard(**kwargs)  # type: ignore[arg-type]
    with open(path, "w", encoding="utf-8") as handle:
        handle.write(html)
    return path


__all__ = ["render_dashboard", "write_dashboard"]
