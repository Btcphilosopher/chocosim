"""Economics: unit costing and profitability.

Builds the cost of a kilogram of chocolate from the bottom up, keeping the
categories separate so that a change in one is traceable. The categories are
the ones a factory controller would recognise:

    ingredients   what went into the formulation
    energy        priced by carrier and time of use
    labour        direct operators plus supervision
    maintenance   planned rate plus a charge per breakdown
    packaging     film, board, cases
    waste         disposal of scrap, net of rework recovery
    overhead      fixed site cost and depreciation, absorbed per kg

The one modelling decision worth flagging: fixed overhead is absorbed over
*actual* production, not budgeted production. That makes unit cost rise when
volume falls, which is the correct and uncomfortable behaviour -- a line
running at half capacity carries twice the overhead per kilogram, and a model
that hides this makes underutilisation look free.
"""

from __future__ import annotations

from collections.abc import Sequence

from pydantic import Field

from ..core.config import ChocoSimConfig, EconomicConfig
from ..core.fidelity import ModelProvenance
from ..core.models import FrozenChocoModel, round_money, safe_divide
from ..core.types import CostCategory, Kilograms, Money, RecipeId
from ..energy.model import EnergyUse
from ..processing.pipeline import ProcessRun
from ..quality.scoring import QualityAssessment
from ..recipes.engine import RecipeEngine
from ..recipes.models import Recipe


class CostLine(FrozenChocoModel):
    """One category of cost for a batch."""

    category: CostCategory
    amount: Money = Field(ge=0.0)
    note: str = ""

    def per_kg(self, mass_kg: Kilograms) -> Money:
        """This cost per kilogram of output."""
        return safe_divide(self.amount, mass_kg)


class BatchCosting(FrozenChocoModel):
    """Complete cost breakdown for one batch."""

    batch_id: str
    recipe_id: RecipeId
    recipe_name: str
    input_mass_kg: Kilograms = Field(gt=0.0)
    saleable_mass_kg: Kilograms = Field(ge=0.0)
    lines: tuple[CostLine, ...]
    currency_symbol: str = "\u00a3"
    provenance: ModelProvenance

    @property
    def total_cost(self) -> Money:
        """Total cost of the batch."""
        return sum(line.amount for line in self.lines)

    @property
    def cost_per_kg(self) -> Money:
        """Cost per kilogram of saleable product.

        Divided by saleable rather than input mass: the kilograms that were
        wasted still cost money, and that cost has to be carried by the ones
        that can be sold.
        """
        return safe_divide(self.total_cost, self.saleable_mass_kg)

    def cost_per_unit(self, unit_mass_g: float) -> Money:
        """Cost of one finished unit of a given mass."""
        return self.cost_per_kg * (unit_mass_g / 1000.0)

    def by_category(self) -> dict[str, Money]:
        """Cost by category, largest first."""
        totals: dict[str, Money] = {}
        for line in self.lines:
            totals[line.category.value] = totals.get(line.category.value, 0.0) + line.amount
        return dict(sorted(totals.items(), key=lambda item: -item[1]))

    def category_shares(self) -> dict[str, float]:
        """Each category's share of total cost."""
        total = self.total_cost
        if total <= 0.0:
            return {}
        return {name: amount / total for name, amount in self.by_category().items()}

    def indicative_price(self, config: EconomicConfig) -> Money:
        """Wholesale price implied by the target gross margin.

        Indicative only. Real pricing is a commercial decision driven by the
        market, the customer and the category, not by a cost-plus formula.
        """
        margin = config.target_gross_margin
        if margin >= 1.0:
            raise ValueError("target margin must be below 1.0")
        return self.cost_per_kg / (1.0 - margin)

    def report(self, unit_mass_g: float = 100.0) -> str:
        """Plain-text costing sheet."""
        symbol = self.currency_symbol
        lines = [
            f"COSTING -- {self.batch_id}  {self.recipe_name}",
            "=" * 62,
            f"Input           {self.input_mass_kg:>12,.2f} kg",
            f"Saleable        {self.saleable_mass_kg:>12,.2f} kg "
            f"({safe_divide(self.saleable_mass_kg, self.input_mass_kg):.2%})",
            "",
            f"{'CATEGORY':<16}{'TOTAL':>14}{'PER KG':>12}{'SHARE':>9}",
            "-" * 62,
        ]
        shares = self.category_shares()
        for category, amount in self.by_category().items():
            lines.append(
                f"{category:<16}"
                f"{symbol + f'{amount:,.2f}':>14}"
                f"{symbol + f'{safe_divide(amount, self.saleable_mass_kg):.4f}':>12}"
                f"{shares.get(category, 0.0):>9.1%}"
            )
        lines += [
            "-" * 62,
            f"{'TOTAL':<16}"
            f"{symbol + f'{self.total_cost:,.2f}':>14}"
            f"{symbol + f'{self.cost_per_kg:.4f}':>12}"
            f"{1.0:>9.1%}",
            "",
            f"Cost per {unit_mass_g:.0f} g unit   "
            f"{symbol}{self.cost_per_unit(unit_mass_g):.4f}",
        ]
        return "\n".join(lines)


class ProductEconomics(FrozenChocoModel):
    """Unit economics of a finished product."""

    recipe_id: RecipeId
    product_name: str
    unit_mass_g: float = Field(gt=0.0)

    production_cost_per_unit: Money = Field(ge=0.0)
    packaging_cost_per_unit: Money = Field(ge=0.0)
    energy_cost_per_unit: Money = Field(ge=0.0)
    wholesale_price_per_unit: Money = Field(ge=0.0)
    currency_symbol: str = "\u00a3"

    @property
    def total_cost_per_unit(self) -> Money:
        """Full cost of one unit."""
        return (
            self.production_cost_per_unit
            + self.packaging_cost_per_unit
            + self.energy_cost_per_unit
        )

    @property
    def margin_per_unit(self) -> Money:
        """Gross margin per unit."""
        return self.wholesale_price_per_unit - self.total_cost_per_unit

    @property
    def margin_fraction(self) -> float:
        """Gross margin as a share of price."""
        return safe_divide(self.margin_per_unit, self.wholesale_price_per_unit)

    def breakeven_volume(self, fixed_cost: Money) -> float:
        """Units needed to cover a given fixed cost."""
        if self.margin_per_unit <= 0.0:
            return float("inf")
        return fixed_cost / self.margin_per_unit

    def summary(self) -> str:
        """The one-line unit economics statement."""
        symbol = self.currency_symbol
        return (
            f"{self.product_name} ({self.unit_mass_g:.0f} g): "
            f"production {symbol}{self.production_cost_per_unit:.2f} + "
            f"packaging {symbol}{self.packaging_cost_per_unit:.2f} + "
            f"energy {symbol}{self.energy_cost_per_unit:.2f} = "
            f"{symbol}{self.total_cost_per_unit:.2f} | "
            f"wholesale {symbol}{self.wholesale_price_per_unit:.2f} | "
            f"margin {symbol}{self.margin_per_unit:.2f} "
            f"({self.margin_fraction:.1%})"
        )


class ProfitAndLoss(FrozenChocoModel):
    """Period profit and loss for the factory."""

    period_days: float = Field(gt=0.0)
    produced_kg: Kilograms = Field(ge=0.0)
    sold_kg: Kilograms = Field(ge=0.0)
    revenue: Money = Field(ge=0.0)

    ingredient_cost: Money = Field(ge=0.0)
    energy_cost: Money = Field(ge=0.0)
    labour_cost: Money = Field(ge=0.0)
    maintenance_cost: Money = Field(ge=0.0)
    packaging_cost: Money = Field(ge=0.0)
    waste_cost: Money = Field(ge=0.0)
    holding_cost: Money = Field(ge=0.0)
    stockout_cost: Money = Field(ge=0.0)
    fixed_overhead: Money = Field(ge=0.0)
    depreciation: Money = Field(ge=0.0)
    currency_symbol: str = "\u00a3"

    @property
    def variable_cost(self) -> Money:
        """Costs that scale with production."""
        return (
            self.ingredient_cost
            + self.energy_cost
            + self.packaging_cost
            + self.waste_cost
        )

    @property
    def semi_fixed_cost(self) -> Money:
        """Costs that scale with running time rather than volume."""
        return self.labour_cost + self.maintenance_cost

    @property
    def fixed_cost(self) -> Money:
        """Costs incurred regardless of production."""
        return self.fixed_overhead + self.depreciation

    @property
    def total_cost(self) -> Money:
        """All costs for the period."""
        return (
            self.variable_cost
            + self.semi_fixed_cost
            + self.fixed_cost
            + self.holding_cost
            + self.stockout_cost
        )

    @property
    def gross_profit(self) -> Money:
        """Revenue less variable cost."""
        return self.revenue - self.variable_cost

    @property
    def gross_margin(self) -> float:
        """Gross profit as a share of revenue."""
        return safe_divide(self.gross_profit, self.revenue)

    @property
    def operating_profit(self) -> Money:
        """Revenue less all costs."""
        return self.revenue - self.total_cost

    @property
    def operating_margin(self) -> float:
        """Operating profit as a share of revenue."""
        return safe_divide(self.operating_profit, self.revenue)

    @property
    def cost_per_kg(self) -> Money:
        """Total cost per kilogram produced."""
        return safe_divide(self.total_cost, self.produced_kg)

    @property
    def contribution_per_kg(self) -> Money:
        """Contribution towards fixed cost per kilogram sold."""
        return safe_divide(self.gross_profit, self.sold_kg)

    @property
    def breakeven_kg(self) -> float:
        """Volume at which the period would break even."""
        contribution = self.contribution_per_kg
        if contribution <= 0.0:
            return float("inf")
        return (self.fixed_cost + self.semi_fixed_cost) / contribution

    def report(self) -> str:
        """Plain-text profit and loss statement."""
        symbol = self.currency_symbol

        def money(value: Money) -> str:
            return f"{symbol}{value:>14,.2f}"

        return "\n".join(
            [
                f"PROFIT AND LOSS -- {self.period_days:.0f} days",
                "=" * 46,
                f"Produced            {self.produced_kg:>14,.1f} kg",
                f"Sold                {self.sold_kg:>14,.1f} kg",
                "",
                f"Revenue             {money(self.revenue)}",
                "",
                "VARIABLE COST",
                f"  Ingredients       {money(self.ingredient_cost)}",
                f"  Energy            {money(self.energy_cost)}",
                f"  Packaging         {money(self.packaging_cost)}",
                f"  Waste             {money(self.waste_cost)}",
                f"  Subtotal          {money(self.variable_cost)}",
                "",
                f"Gross profit        {money(self.gross_profit)}"
                f"   ({self.gross_margin:.1%})",
                "",
                "OPERATING COST",
                f"  Labour            {money(self.labour_cost)}",
                f"  Maintenance       {money(self.maintenance_cost)}",
                f"  Inventory holding {money(self.holding_cost)}",
                f"  Stockout penalty  {money(self.stockout_cost)}",
                f"  Fixed overhead    {money(self.fixed_overhead)}",
                f"  Depreciation      {money(self.depreciation)}",
                "",
                f"Operating profit    {money(self.operating_profit)}"
                f"   ({self.operating_margin:.1%})",
                "",
                f"Cost per kg         {symbol}{self.cost_per_kg:.4f}",
                f"Contribution per kg {symbol}{self.contribution_per_kg:.4f}",
                f"Breakeven volume    {self.breakeven_kg:,.0f} kg",
            ]
        )


class EconomicsEngine:
    """Builds costings and profit statements."""

    MODEL_NAME = "economics_engine"

    def __init__(
        self,
        recipe_engine: RecipeEngine,
        config: ChocoSimConfig | None = None,
    ) -> None:
        self.recipe_engine = recipe_engine
        self.config = config or ChocoSimConfig.default()

    @property
    def economics(self) -> EconomicConfig:
        """The cost rates in force."""
        return self.config.economics

    def cost_batch(
        self,
        run: ProcessRun,
        recipe: Recipe,
        quality: QualityAssessment | None = None,
        packaging_cost_per_kg: Money = 0.0,
        breakdown_events: int = 0,
        machine_hours: float | None = None,
        hour_of_day: float | None = None,
        absorb_overhead: bool = True,
        daily_production_kg: Kilograms | None = None,
    ) -> BatchCosting:
        """Build the full cost of one batch."""
        economics = self.economics
        input_mass = run.overall_balance.mass_in

        saleable = quality.saleable_kg if quality is not None else run.output_kg
        rework_kg = quality.reworkable_kg if quality is not None else 0.0
        scrap_kg = quality.scrap_kg if quality is not None else 0.0
        recovered = rework_kg * economics.rework_recovery_fraction
        saleable += recovered

        lines: list[CostLine] = []

        ingredient_cost = self.recipe_engine.cost(recipe, input_mass).total_cost
        lines.append(
            CostLine(
                category=CostCategory.INGREDIENTS,
                amount=ingredient_cost,
                note=f"{input_mass:,.1f} kg at formulation prices",
            )
        )

        energy_cost = run.total_energy.cost(self.config.energy, hour_of_day)
        lines.append(
            CostLine(
                category=CostCategory.ENERGY,
                amount=energy_cost,
                note=f"{run.total_energy.total_kwh:,.1f} kWh",
            )
        )

        # Attended time, not elapsed time: see ProcessRun.attended_minutes.
        hours = (
            machine_hours
            if machine_hours is not None
            else run.attended_minutes / 60.0
        )
        lines.append(
            CostLine(
                category=CostCategory.LABOUR,
                amount=economics.labour_cost(hours),
                note=f"{hours:,.1f} line-hours",
            )
        )

        # Maintenance, unlike labour, is charged on total elapsed machine time:
        # a conche wears whether or not anyone is watching it.
        maintenance = (
            run.total_minutes / 60.0 * economics.maintenance_rate_per_machine_hour
            + breakdown_events * economics.breakdown_cost_per_event
        )
        lines.append(
            CostLine(
                category=CostCategory.MAINTENANCE,
                amount=maintenance,
                note=f"{breakdown_events} breakdown event(s)",
            )
        )

        if packaging_cost_per_kg > 0.0:
            lines.append(
                CostLine(
                    category=CostCategory.PACKAGING,
                    amount=packaging_cost_per_kg * saleable,
                    note=f"{packaging_cost_per_kg:.4f} per kg",
                )
            )

        disposed = run.waste_kg + scrap_kg
        waste_cost = disposed * economics.waste_disposal_cost_per_kg
        waste_cost += rework_kg * economics.rework_cost_per_kg
        lines.append(
            CostLine(
                category=CostCategory.WASTE,
                amount=waste_cost,
                note=f"{disposed:,.1f} kg disposed, {rework_kg:,.1f} kg reworked",
            )
        )

        if absorb_overhead:
            # Absorbed over what the factory actually made, not what it hoped
            # to make. Under-absorption is a real cost, not an accounting
            # artefact, and hiding it makes idle capacity look free.
            daily = daily_production_kg or max(run.output_kg, 1.0)
            share = safe_divide(input_mass, daily)
            overhead = (
                economics.fixed_overhead_per_day + economics.depreciation_per_day
            ) * share
            lines.append(
                CostLine(
                    category=CostCategory.OVERHEAD,
                    amount=overhead,
                    note=f"absorbed over {daily:,.0f} kg/day",
                )
            )

        return BatchCosting(
            batch_id=run.batch_id,
            recipe_id=recipe.recipe_id,
            recipe_name=recipe.name,
            input_mass_kg=input_mass,
            saleable_mass_kg=max(saleable, 0.0),
            lines=tuple(lines),
            currency_symbol=economics.currency_symbol,
            provenance=ModelProvenance.simulation(
                self.MODEL_NAME,
                basis="Bottom-up absorption costing over simulated process outputs",
                assumptions=(
                    "Fixed overhead is absorbed over actual, not budgeted, volume",
                    "Rework recovers a fixed fraction of its mass",
                    "Cost rates are configuration, not audited accounts",
                ),
            ),
        )

    def product_economics(
        self,
        costing: BatchCosting,
        unit_mass_g: float,
        packaging_cost_per_unit: Money,
        wholesale_price_per_unit: Money | None = None,
    ) -> ProductEconomics:
        """Unit economics for a finished product."""
        by_category = costing.by_category()
        energy_total = by_category.get(CostCategory.ENERGY.value, 0.0)
        packaging_total = by_category.get(CostCategory.PACKAGING.value, 0.0)
        production_total = costing.total_cost - energy_total - packaging_total

        mass_ratio = unit_mass_g / 1000.0
        saleable = max(costing.saleable_mass_kg, 1e-9)

        production_per_unit = production_total / saleable * mass_ratio
        energy_per_unit = energy_total / saleable * mass_ratio

        price = wholesale_price_per_unit
        if price is None:
            total = production_per_unit + energy_per_unit + packaging_cost_per_unit
            price = total / (1.0 - self.economics.target_gross_margin)

        return ProductEconomics(
            recipe_id=costing.recipe_id,
            product_name=costing.recipe_name,
            unit_mass_g=unit_mass_g,
            production_cost_per_unit=round_money(production_per_unit),
            packaging_cost_per_unit=round_money(packaging_cost_per_unit),
            energy_cost_per_unit=round_money(energy_per_unit),
            wholesale_price_per_unit=round_money(price),
            currency_symbol=self.economics.currency_symbol,
        )

    def profit_and_loss(
        self,
        costings: Sequence[BatchCosting],
        period_days: float,
        sold_kg: Kilograms | None = None,
        average_price_per_kg: Money | None = None,
        line_hours: float | None = None,
        breakdown_events: int = 0,
        average_inventory_value: Money = 0.0,
        stockout_kg: Kilograms = 0.0,
    ) -> ProfitAndLoss:
        """Aggregate batch costings into a period profit statement."""
        economics = self.economics
        produced = sum(costing.saleable_mass_kg for costing in costings)
        sold = sold_kg if sold_kg is not None else produced

        totals: dict[str, Money] = {}
        for costing in costings:
            for category, amount in costing.by_category().items():
                totals[category] = totals.get(category, 0.0) + amount

        if average_price_per_kg is None:
            unit_cost = safe_divide(
                sum(costing.total_cost for costing in costings), max(produced, 1e-9)
            )
            average_price_per_kg = unit_cost / (1.0 - economics.target_gross_margin)

        hours = (
            line_hours
            if line_hours is not None
            else period_days * self.config.simulation.operating_hours_per_day
        )

        return ProfitAndLoss(
            period_days=period_days,
            produced_kg=produced,
            sold_kg=sold,
            revenue=sold * average_price_per_kg,
            ingredient_cost=totals.get(CostCategory.INGREDIENTS.value, 0.0),
            energy_cost=totals.get(CostCategory.ENERGY.value, 0.0),
            labour_cost=totals.get(
                CostCategory.LABOUR.value, economics.labour_cost(hours)
            ),
            maintenance_cost=totals.get(
                CostCategory.MAINTENANCE.value,
                hours * economics.maintenance_rate_per_machine_hour
                + breakdown_events * economics.breakdown_cost_per_event,
            ),
            packaging_cost=totals.get(CostCategory.PACKAGING.value, 0.0),
            waste_cost=totals.get(CostCategory.WASTE.value, 0.0),
            holding_cost=economics.holding_cost(average_inventory_value, period_days),
            stockout_cost=stockout_kg * economics.stockout_penalty_per_kg,
            fixed_overhead=economics.fixed_overhead_per_day * period_days,
            depreciation=economics.depreciation_per_day * period_days,
            currency_symbol=economics.currency_symbol,
        )


__all__ = [
    "BatchCosting",
    "CostLine",
    "EconomicsEngine",
    "ProductEconomics",
    "ProfitAndLoss",
]
