"""Energy accounting.

:class:`EnergyUse` is the unit of energy accounting in ChocoSim: every process
stage returns one, and they compose additively up through batches, lines and
the whole factory. Energy is tracked *by carrier* rather than as a single
number because electricity, gas, steam and refrigeration have different
prices, different carbon intensities and different time-of-use behaviour, and
collapsing them early throws all of that away.

The physical basis is straightforward first-law accounting: heating a stream
takes ``m * cp * dT``, evaporating water takes the latent heat, and mechanical
work takes shaft power divided by drive efficiency. Cooling duty is divided by
the coefficient of performance of the refrigeration plant, so removing a
kilojoule of heat costs rather less than a kilojoule of electricity.
"""

from __future__ import annotations

from collections.abc import Iterable

from pydantic import Field

from ..core.config import EnergyConfig
from ..core.models import FrozenChocoModel, safe_divide
from ..core.types import EnergyCarrier, Kilograms, KilowattHours, Money
from ..core.units import kj_to_kwh


class EnergyUse(FrozenChocoModel):
    """Energy consumed by an operation, broken down by carrier."""

    by_carrier: dict[EnergyCarrier, KilowattHours] = Field(default_factory=dict)

    @property
    def total_kwh(self) -> KilowattHours:
        """Total energy across all carriers."""
        return sum(self.by_carrier.values())

    @property
    def electricity_kwh(self) -> KilowattHours:
        """Electrical energy only."""
        return self.by_carrier.get(EnergyCarrier.ELECTRICITY, 0.0)

    @property
    def thermal_kwh(self) -> KilowattHours:
        """Combustion and steam energy."""
        return self.by_carrier.get(EnergyCarrier.NATURAL_GAS, 0.0) + self.by_carrier.get(
            EnergyCarrier.STEAM, 0.0
        )

    @property
    def cooling_kwh(self) -> KilowattHours:
        """Refrigeration energy."""
        return self.by_carrier.get(EnergyCarrier.CHILLED_WATER, 0.0)

    @classmethod
    def zero(cls) -> EnergyUse:
        """An empty energy record."""
        return cls(by_carrier={})

    @classmethod
    def of(cls, carrier: EnergyCarrier, kwh: KilowattHours) -> EnergyUse:
        """Energy from a single carrier."""
        if kwh <= 0.0:
            return cls.zero()
        return cls(by_carrier={carrier: kwh})

    @classmethod
    def electrical(cls, kwh: KilowattHours) -> EnergyUse:
        """Electrical energy."""
        return cls.of(EnergyCarrier.ELECTRICITY, kwh)

    def __add__(self, other: EnergyUse) -> EnergyUse:
        combined = dict(self.by_carrier)
        for carrier, kwh in other.by_carrier.items():
            combined[carrier] = combined.get(carrier, 0.0) + kwh
        return EnergyUse(by_carrier=combined)

    def __radd__(self, other: object) -> EnergyUse:
        # Supports sum() over an iterable of EnergyUse starting from 0.
        if other == 0 or other is None:
            return self
        raise TypeError(f"cannot add {type(other).__name__} to EnergyUse")

    def __mul__(self, factor: float) -> EnergyUse:
        return EnergyUse(
            by_carrier={
                carrier: kwh * factor for carrier, kwh in self.by_carrier.items()
            }
        )

    __rmul__ = __mul__

    def scaled(self, factor: float) -> EnergyUse:
        """Return this energy record scaled by a factor."""
        return self * factor

    def per_kg(self, mass_kg: Kilograms) -> KilowattHours:
        """Specific energy in kWh per kilogram."""
        return safe_divide(self.total_kwh, mass_kg)

    def cost(self, config: EnergyConfig, hour_of_day: float | None = None) -> Money:
        """Cost of this energy at the configured tariffs.

        When ``hour_of_day`` is supplied, time-of-use multipliers apply. This
        is what makes load shifting worth optimising: the same kilowatt-hour is
        materially cheaper at 03:00 than at 18:00.
        """
        total = 0.0
        for carrier, kwh in self.by_carrier.items():
            tariff = config.tariff(carrier)
            price = (
                tariff.unit_price if hour_of_day is None else tariff.price_at(hour_of_day)
            )
            total += kwh * price
        return total

    def carbon_kg(self, config: EnergyConfig) -> float:
        """Carbon dioxide equivalent emissions, kg."""
        return sum(
            kwh * config.tariff(carrier).carbon_intensity_kg_per_kwh
            for carrier, kwh in self.by_carrier.items()
        )

    def as_dict(self) -> dict[str, float]:
        """Energy by carrier name, plus the total."""
        result = {carrier.value: kwh for carrier, kwh in self.by_carrier.items()}
        result["total"] = self.total_kwh
        return result

    def __str__(self) -> str:
        parts = ", ".join(
            f"{carrier.value}={kwh:.3f}"
            for carrier, kwh in sorted(
                self.by_carrier.items(), key=lambda item: -item[1]
            )
        )
        return f"EnergyUse({self.total_kwh:.3f} kWh: {parts})"


def combine(uses: Iterable[EnergyUse]) -> EnergyUse:
    """Sum an iterable of energy records."""
    total = EnergyUse.zero()
    for use in uses:
        total = total + use
    return total


# --------------------------------------------------------------------------
# First-law duty calculators
# --------------------------------------------------------------------------


def sensible_heat_kwh(
    mass_kg: Kilograms, cp_kj_per_kg_k: float, delta_t: float
) -> KilowattHours:
    """Energy to change a stream's temperature by ``delta_t`` kelvin.

    Returns the *magnitude* of the duty; the caller decides whether it is a
    heating load on a burner or a cooling load on a chiller, because those cost
    very different amounts per kilojoule moved.
    """
    return kj_to_kwh(abs(mass_kg * cp_kj_per_kg_k * delta_t))


def latent_heat_kwh(mass_kg: Kilograms, latent_kj_per_kg: float) -> KilowattHours:
    """Energy for a phase change of ``mass_kg``."""
    return kj_to_kwh(abs(mass_kg * latent_kj_per_kg))


def heating_energy(
    duty_kwh: KilowattHours,
    config: EnergyConfig,
    carrier: EnergyCarrier = EnergyCarrier.NATURAL_GAS,
) -> EnergyUse:
    """Fuel energy required to deliver a heating duty to the product."""
    if duty_kwh <= 0.0:
        return EnergyUse.zero()
    return EnergyUse.of(carrier, duty_kwh / config.thermal_efficiency)


def cooling_energy(duty_kwh: KilowattHours, config: EnergyConfig) -> EnergyUse:
    """Electrical energy required to remove a cooling duty.

    Divided by the coefficient of performance: a chiller with a COP of 2.8
    moves 2.8 kWh of heat per kWh of electricity consumed.
    """
    if duty_kwh <= 0.0:
        return EnergyUse.zero()
    return EnergyUse.of(
        EnergyCarrier.CHILLED_WATER, duty_kwh / config.refrigeration_cop
    )


def mechanical_energy(shaft_kwh: KilowattHours, config: EnergyConfig) -> EnergyUse:
    """Electrical energy required to deliver mechanical shaft work."""
    if shaft_kwh <= 0.0:
        return EnergyUse.zero()
    return EnergyUse.electrical(shaft_kwh / config.motor_efficiency)


def standby_energy(
    rated_kw: float, hours: float, config: EnergyConfig
) -> EnergyUse:
    """Energy drawn by an idle machine over a period."""
    if rated_kw <= 0.0 or hours <= 0.0:
        return EnergyUse.zero()
    return EnergyUse.electrical(rated_kw * config.standby_power_fraction * hours)


def site_overhead_energy(hours: float, config: EnergyConfig) -> EnergyUse:
    """Site load independent of production: lighting, HVAC, offices."""
    if hours <= 0.0:
        return EnergyUse.zero()
    return EnergyUse.electrical(config.site_overhead_kw * hours)


__all__ = [
    "EnergyUse",
    "combine",
    "cooling_energy",
    "heating_energy",
    "latent_heat_kwh",
    "mechanical_energy",
    "sensible_heat_kwh",
    "site_overhead_energy",
    "standby_energy",
]
