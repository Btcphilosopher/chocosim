"""Ingredient domain models.

An *ingredient* is a specification: what cocoa butter is, what it costs on
average, how it behaves in a recipe. A *lot* is a physical delivery of that
ingredient with a batch number, a supplier, an expiry date and a purchase
price that may differ from the specification price. Recipes are written
against ingredients; inventory and traceability work on lots.

Keeping the two apart is what allows the simulator to answer both "what does
dark chocolate cost to make" (specification prices) and "what did batch 1842
actually cost" (the lots consumed).
"""

from __future__ import annotations

import datetime as dt
from typing import Self

from pydantic import Field, model_validator

from ..core.models import ChocoModel, Composition, FrozenChocoModel
from ..core.types import (
    CocoaOrigin,
    IngredientClass,
    IngredientId,
    Kilograms,
    LotId,
    Money,
    SupplierId,
)


class Supplier(FrozenChocoModel):
    """A raw-material supplier.

    Lead-time and reliability parameters drive the supply-chain simulation.
    ``reliability`` is the probability that a purchase order arrives complete
    and on time; the remainder is split across the disruption modes weighted
    by :attr:`disruption_weights`.
    """

    supplier_id: SupplierId
    name: str
    country: str = Field(default="")
    lead_time_days_mean: float = Field(
        default=14.0, gt=0.0, description="Mean order-to-delivery time, days."
    )
    lead_time_days_sigma: float = Field(
        default=3.0, ge=0.0, description="Standard deviation of lead time, days."
    )
    reliability: float = Field(
        default=0.94,
        ge=0.0,
        le=1.0,
        description="Probability a purchase order arrives complete and on time.",
    )
    minimum_order_kg: Kilograms = Field(
        default=1_000.0, ge=0.0, description="Minimum order quantity."
    )
    order_multiple_kg: Kilograms = Field(
        default=25.0, gt=0.0, description="Orders must be a multiple of this quantity."
    )
    price_premium: float = Field(
        default=0.0,
        ge=-0.5,
        description="Price uplift versus the market reference, as a fraction.",
    )
    quality_grade: float = Field(
        default=1.0,
        ge=0.0,
        le=1.0,
        description=(
            "Relative incoming quality, 1.0 being the specification. Feeds the "
            "quality model as a small modifier on achievable batch score."
        ),
    )
    certifications: tuple[str, ...] = Field(
        default=(), description="e.g. Rainforest Alliance, Fairtrade, organic."
    )

    def round_order(self, quantity_kg: Kilograms) -> Kilograms:
        """Round an order quantity up to the supplier's commercial constraints."""
        if quantity_kg <= 0.0:
            return 0.0
        quantity = max(quantity_kg, self.minimum_order_kg)
        multiples = -(-quantity // self.order_multiple_kg)  # ceiling division
        return multiples * self.order_multiple_kg


class Ingredient(FrozenChocoModel):
    """Specification of a raw material.

    ``composition`` describes the material's own analysis, so that recipe
    composition can be computed by mass-weighted blending rather than being
    entered by hand and drifting out of step with the formulation.
    """

    ingredient_id: IngredientId
    name: str
    ingredient_class: IngredientClass

    reference_cost_per_kg: Money = Field(
        ge=0.0, description="Market reference price per kg."
    )
    composition: Composition = Field(default_factory=Composition)

    origin: CocoaOrigin = Field(default=CocoaOrigin.NOT_APPLICABLE)
    shelf_life_days: int = Field(
        default=365, gt=0, description="Shelf life from manufacture, days."
    )
    storage_temperature_c: float = Field(
        default=18.0, description="Recommended storage temperature."
    )

    #: Whether this material contributes to the declared cocoa content.
    counts_as_cocoa: bool = Field(default=False)
    #: Whether the fat in this material is cocoa butter (relevant to legal
    #: definitions of chocolate and to the tempering model).
    fat_is_cocoa_butter: bool = Field(default=False)

    allergens: tuple[str, ...] = Field(
        default=(),
        description=(
            "Allergen declarations. Simulation metadata for changeover logic; "
            "real allergen management is governed by the site food-safety plan."
        ),
    )

    #: Particle size of the material as received, micrometres. Sugar and cocoa
    #: solids arrive coarse and are reduced by refining; liquid fats have no
    #: meaningful particle size and use zero.
    incoming_particle_size_um: float = Field(default=0.0, ge=0.0)

    #: Fraction of this material lost as residue during handling and transfer.
    handling_loss_fraction: float = Field(default=0.002, ge=0.0, le=0.2)

    default_supplier_id: SupplierId | None = Field(default=None)
    price_volatility: float = Field(
        default=0.10,
        ge=0.0,
        description="Annualised coefficient of variation of the market price.",
    )

    @property
    def fat_fraction(self) -> float:
        """Fat content as a mass fraction."""
        return self.composition.fat

    @property
    def moisture_fraction(self) -> float:
        """Moisture content as a mass fraction."""
        return self.composition.moisture

    @property
    def is_fat_phase(self) -> bool:
        """Whether this material forms part of the continuous fat phase.

        Materials above roughly 90% fat behave as the carrier liquid in a
        chocolate mass rather than as dispersed solids. This drives the
        viscosity model's fat-phase calculation.
        """
        return self.composition.fat >= 0.90

    def cost_from(self, supplier: Supplier | None) -> Money:
        """Reference cost adjusted by a supplier's price premium."""
        if supplier is None:
            return self.reference_cost_per_kg
        return self.reference_cost_per_kg * (1.0 + supplier.price_premium)


class IngredientLot(ChocoModel):
    """A physical delivery of an ingredient.

    Lots are the unit of traceability. Consumption draws down lots, normally
    oldest-expiry-first, and the lot identifiers consumed are recorded against
    the production batch.
    """

    lot_id: LotId
    ingredient_id: IngredientId
    supplier_id: SupplierId | None = None

    quantity_kg: Kilograms = Field(ge=0.0, description="Quantity remaining in the lot.")
    original_quantity_kg: Kilograms = Field(
        ge=0.0, description="Quantity at goods-in, before any consumption."
    )
    unit_cost: Money = Field(ge=0.0, description="Actual purchase price per kg.")

    received_on: dt.date
    expires_on: dt.date

    #: Per-lot analysis, which may deviate from the ingredient specification.
    measured_moisture: float | None = Field(default=None, ge=0.0, le=1.0)
    measured_fat: float | None = Field(default=None, ge=0.0, le=1.0)
    quality_grade: float = Field(default=1.0, ge=0.0, le=1.0)

    quarantined: bool = Field(
        default=False, description="Held pending disposition; not available to issue."
    )

    @model_validator(mode="after")
    def _check_quantities(self) -> Self:
        if self.quantity_kg > self.original_quantity_kg + 1e-9:
            raise ValueError(
                f"lot {self.lot_id}: remaining quantity {self.quantity_kg} exceeds "
                f"original {self.original_quantity_kg}"
            )
        if self.expires_on < self.received_on:
            raise ValueError(
                f"lot {self.lot_id}: expiry {self.expires_on} precedes receipt "
                f"{self.received_on}"
            )
        return self

    @property
    def consumed_kg(self) -> Kilograms:
        """Quantity already issued from this lot."""
        return self.original_quantity_kg - self.quantity_kg

    @property
    def value(self) -> Money:
        """Book value of the remaining quantity."""
        return self.quantity_kg * self.unit_cost

    @property
    def is_empty(self) -> bool:
        """Whether the lot has been fully consumed."""
        return self.quantity_kg <= 1e-9

    def is_expired(self, on: dt.date) -> bool:
        """Whether the lot has passed its expiry date."""
        return on > self.expires_on

    def days_to_expiry(self, on: dt.date) -> int:
        """Days remaining before expiry; negative once expired."""
        return (self.expires_on - on).days

    def is_available(self, on: dt.date) -> bool:
        """Whether the lot may be issued to production."""
        return not self.quarantined and not self.is_expired(on) and not self.is_empty

    def draw(self, quantity_kg: Kilograms) -> Kilograms:
        """Consume up to ``quantity_kg`` from the lot, returning what was taken."""
        if quantity_kg <= 0.0:
            return 0.0
        taken = min(quantity_kg, self.quantity_kg)
        self.quantity_kg -= taken
        return taken


class IngredientRequirement(FrozenChocoModel):
    """A quantity of one ingredient needed for a batch."""

    ingredient_id: IngredientId
    ingredient_name: str
    mass_fraction: float = Field(
        ge=0.0, le=1.0, description="Share of total batch mass."
    )
    required_kg: Kilograms = Field(ge=0.0, description="Mass required, kg.")
    unit_cost: Money = Field(ge=0.0, description="Cost per kg used for this batch.")

    @property
    def line_cost(self) -> Money:
        """Total cost of this requirement."""
        return self.required_kg * self.unit_cost


class NutritionProfile(FrozenChocoModel):
    """Nutritional analysis of a formulation, per 100 g.

    Computed from the mass-weighted composition. Indicative simulation output
    for formulation work: a declarable nutrition panel requires laboratory
    analysis and must comply with the applicable food-labelling regulations.
    """

    energy_kcal_per_100g: float = Field(ge=0.0)
    energy_kj_per_100g: float = Field(ge=0.0)
    fat_g_per_100g: float = Field(ge=0.0)
    saturates_g_per_100g: float = Field(ge=0.0)
    carbohydrate_g_per_100g: float = Field(ge=0.0)
    sugars_g_per_100g: float = Field(ge=0.0)
    protein_g_per_100g: float = Field(ge=0.0)
    salt_g_per_100g: float = Field(ge=0.0)
    fibre_g_per_100g: float = Field(ge=0.0)

    def scaled_to(self, portion_g: float) -> dict[str, float]:
        """Nutrition for a portion of the given mass in grams."""
        factor = portion_g / 100.0
        return {
            "energy_kcal": self.energy_kcal_per_100g * factor,
            "energy_kj": self.energy_kj_per_100g * factor,
            "fat_g": self.fat_g_per_100g * factor,
            "saturates_g": self.saturates_g_per_100g * factor,
            "carbohydrate_g": self.carbohydrate_g_per_100g * factor,
            "sugars_g": self.sugars_g_per_100g * factor,
            "protein_g": self.protein_g_per_100g * factor,
            "salt_g": self.salt_g_per_100g * factor,
            "fibre_g": self.fibre_g_per_100g * factor,
        }


__all__ = [
    "Ingredient",
    "IngredientLot",
    "IngredientRequirement",
    "NutritionProfile",
    "Supplier",
]
