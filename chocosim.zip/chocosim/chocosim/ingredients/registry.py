"""Registry of ingredients, suppliers and physical lots."""

from __future__ import annotations

import datetime as dt
from collections.abc import Iterable, Iterator

from ..core.exceptions import IngredientNotFoundError
from ..core.rng import RandomSource, lognormal_from_moments
from ..core.types import (
    IngredientClass,
    IngredientId,
    Kilograms,
    LotId,
    Money,
    SupplierId,
    next_id,
)
from .catalog import default_ingredients, default_suppliers
from .models import Ingredient, IngredientLot, Supplier


class IngredientRegistry:
    """Lookup and lifecycle management for raw materials.

    The registry owns three things: the ingredient specifications, the supplier
    list, and the physical lots on site. It also owns the *current* price of
    each ingredient, which starts at the specification reference price and can
    be moved by a scenario (a cocoa price shock, say) without mutating the
    specification itself.
    """

    def __init__(
        self,
        ingredients: Iterable[Ingredient] | None = None,
        suppliers: Iterable[Supplier] | None = None,
    ) -> None:
        self._ingredients: dict[IngredientId, Ingredient] = {}
        self._suppliers: dict[SupplierId, Supplier] = {}
        self._lots: dict[LotId, IngredientLot] = {}
        self._price_multipliers: dict[IngredientId, float] = {}

        for supplier in suppliers if suppliers is not None else default_suppliers():
            self.add_supplier(supplier)
        for ingredient in (
            ingredients if ingredients is not None else default_ingredients()
        ):
            self.add_ingredient(ingredient)

    # ------------------------------------------------------------------
    # Registration
    # ------------------------------------------------------------------

    def add_ingredient(self, ingredient: Ingredient) -> Ingredient:
        """Register an ingredient specification, replacing any existing entry."""
        self._ingredients[ingredient.ingredient_id] = ingredient
        self._price_multipliers.setdefault(ingredient.ingredient_id, 1.0)
        return ingredient

    def add_supplier(self, supplier: Supplier) -> Supplier:
        """Register a supplier, replacing any existing entry."""
        self._suppliers[supplier.supplier_id] = supplier
        return supplier

    # ------------------------------------------------------------------
    # Lookup
    # ------------------------------------------------------------------

    def get(self, ingredient_id: IngredientId) -> Ingredient:
        """Return an ingredient specification or raise."""
        try:
            return self._ingredients[ingredient_id]
        except KeyError:
            raise IngredientNotFoundError(
                f"Unknown ingredient {ingredient_id!r}. "
                f"Registered: {sorted(self._ingredients)}"
            ) from None

    def find(self, ingredient_id: IngredientId) -> Ingredient | None:
        """Return an ingredient specification or ``None``."""
        return self._ingredients.get(ingredient_id)

    def supplier(self, supplier_id: SupplierId) -> Supplier | None:
        """Return a supplier or ``None``."""
        return self._suppliers.get(supplier_id)

    def supplier_for(self, ingredient_id: IngredientId) -> Supplier | None:
        """Return the default supplier of an ingredient, if any."""
        ingredient = self.get(ingredient_id)
        if ingredient.default_supplier_id is None:
            return None
        return self._suppliers.get(ingredient.default_supplier_id)

    def by_class(self, ingredient_class: IngredientClass) -> list[Ingredient]:
        """All registered ingredients of a given functional class."""
        return [
            ingredient
            for ingredient in self._ingredients.values()
            if ingredient.ingredient_class is ingredient_class
        ]

    @property
    def ingredients(self) -> dict[IngredientId, Ingredient]:
        """All registered ingredient specifications."""
        return dict(self._ingredients)

    @property
    def suppliers(self) -> dict[SupplierId, Supplier]:
        """All registered suppliers."""
        return dict(self._suppliers)

    def __contains__(self, ingredient_id: object) -> bool:
        return ingredient_id in self._ingredients

    def __len__(self) -> int:
        return len(self._ingredients)

    def __iter__(self) -> Iterator[Ingredient]:
        return iter(self._ingredients.values())

    # ------------------------------------------------------------------
    # Pricing
    # ------------------------------------------------------------------

    def unit_cost(self, ingredient_id: IngredientId) -> Money:
        """Current price per kg, including any scenario multiplier."""
        ingredient = self.get(ingredient_id)
        multiplier = self._price_multipliers.get(ingredient_id, 1.0)
        supplier = self.supplier_for(ingredient_id)
        return ingredient.cost_from(supplier) * multiplier

    def set_price_multiplier(
        self, ingredient_id: IngredientId, multiplier: float
    ) -> None:
        """Set the scenario price multiplier for one ingredient."""
        if multiplier < 0.0:
            raise ValueError(f"price multiplier must be non-negative, got {multiplier}")
        self.get(ingredient_id)  # existence check
        self._price_multipliers[ingredient_id] = multiplier

    def shock_class(self, ingredient_class: IngredientClass, multiplier: float) -> int:
        """Apply a price multiplier to every ingredient of a class.

        Returns the number of ingredients affected. This is how "what if cocoa
        prices rise 20%" is expressed: the shock lands on every cocoa-derived
        material at once, which is what actually happens in the market.
        """
        affected = 0
        for ingredient in self.by_class(ingredient_class):
            self._price_multipliers[ingredient.ingredient_id] = multiplier
            affected += 1
        return affected

    def shock_cocoa_complex(self, multiplier: float) -> int:
        """Apply a price multiplier across the whole cocoa complex.

        Beans, nibs, liquor, butter and powder all move together, because they
        are the same physical commodity at different stages of processing.
        """
        cocoa_classes = (
            IngredientClass.COCOA_BEAN,
            IngredientClass.COCOA_NIB,
            IngredientClass.COCOA_LIQUOR,
            IngredientClass.COCOA_BUTTER,
            IngredientClass.COCOA_POWDER,
        )
        return sum(self.shock_class(cls, multiplier) for cls in cocoa_classes)

    def reset_prices(self) -> None:
        """Clear all scenario price multipliers."""
        for ingredient_id in self._price_multipliers:
            self._price_multipliers[ingredient_id] = 1.0

    def price_multiplier(self, ingredient_id: IngredientId) -> float:
        """The current scenario multiplier for one ingredient."""
        return self._price_multipliers.get(ingredient_id, 1.0)

    def sample_price(
        self,
        ingredient_id: IngredientId,
        source: RandomSource,
        horizon_years: float = 1.0,
        deterministic: bool = False,
    ) -> Money:
        """Draw a stochastic future price for an ingredient.

        Prices follow a lognormal distribution whose coefficient of variation
        scales with the square root of the horizon, the standard random-walk
        assumption. In deterministic mode the current price is returned
        unchanged so that reference scenarios stay reproducible.
        """
        current = self.unit_cost(ingredient_id)
        if deterministic or current <= 0.0:
            return current
        ingredient = self.get(ingredient_id)
        volatility = ingredient.price_volatility * max(horizon_years, 0.0) ** 0.5
        if volatility <= 0.0:
            return current
        generator = source.generator(f"price/{ingredient_id}")
        return float(
            lognormal_from_moments(generator, current, volatility)
        )

    # ------------------------------------------------------------------
    # Lots
    # ------------------------------------------------------------------

    def create_lot(
        self,
        ingredient_id: IngredientId,
        quantity_kg: Kilograms,
        received_on: dt.date,
        supplier_id: SupplierId | None = None,
        unit_cost: Money | None = None,
        quality_grade: float | None = None,
        lot_id: LotId | None = None,
    ) -> IngredientLot:
        """Create and register a physical lot of an ingredient."""
        ingredient = self.get(ingredient_id)
        supplier = (
            self._suppliers.get(supplier_id)
            if supplier_id is not None
            else self.supplier_for(ingredient_id)
        )
        cost = unit_cost if unit_cost is not None else self.unit_cost(ingredient_id)
        grade = (
            quality_grade
            if quality_grade is not None
            else (supplier.quality_grade if supplier else 1.0)
        )
        lot = IngredientLot(
            lot_id=lot_id or next_id("LOT", width=6),
            ingredient_id=ingredient_id,
            supplier_id=supplier.supplier_id if supplier else supplier_id,
            quantity_kg=quantity_kg,
            original_quantity_kg=quantity_kg,
            unit_cost=cost,
            received_on=received_on,
            expires_on=received_on + dt.timedelta(days=ingredient.shelf_life_days),
            quality_grade=grade,
        )
        self._lots[lot.lot_id] = lot
        return lot

    def add_lot(self, lot: IngredientLot) -> IngredientLot:
        """Register an externally constructed lot."""
        self.get(lot.ingredient_id)  # existence check
        self._lots[lot.lot_id] = lot
        return lot

    def lot(self, lot_id: LotId) -> IngredientLot | None:
        """Return a lot by identifier."""
        return self._lots.get(lot_id)

    def lots_for(
        self, ingredient_id: IngredientId, on: dt.date | None = None
    ) -> list[IngredientLot]:
        """Lots of an ingredient, ordered oldest-expiry-first.

        When ``on`` is given, only lots available for issue on that date are
        returned. FEFO ordering (first expired, first out) is the right default
        for perishable food materials: it minimises write-off, whereas FIFO can
        leave a short-dated lot stranded behind a long-dated one.
        """
        lots = [
            lot for lot in self._lots.values() if lot.ingredient_id == ingredient_id
        ]
        if on is not None:
            lots = [lot for lot in lots if lot.is_available(on)]
        return sorted(lots, key=lambda lot: (lot.expires_on, lot.lot_id))

    def available_quantity(
        self, ingredient_id: IngredientId, on: dt.date
    ) -> Kilograms:
        """Total issuable quantity of an ingredient on a date."""
        return sum(lot.quantity_kg for lot in self.lots_for(ingredient_id, on))

    def consume(
        self, ingredient_id: IngredientId, quantity_kg: Kilograms, on: dt.date
    ) -> tuple[list[tuple[LotId, Kilograms, Money]], Kilograms]:
        """Draw ``quantity_kg`` from available lots, FEFO.

        Returns the list of ``(lot_id, quantity, unit_cost)`` draws made and
        the shortfall that could not be satisfied. The caller decides whether a
        shortfall is an error -- during a supply-disruption scenario it is the
        thing being measured, not a bug.
        """
        remaining = quantity_kg
        draws: list[tuple[LotId, Kilograms, Money]] = []
        for lot in self.lots_for(ingredient_id, on):
            if remaining <= 1e-12:
                break
            taken = lot.draw(remaining)
            if taken > 0.0:
                draws.append((lot.lot_id, taken, lot.unit_cost))
                remaining -= taken
        return draws, max(0.0, remaining)

    def expire_lots(self, on: dt.date) -> list[tuple[LotId, Kilograms, Money]]:
        """Write off every lot past its expiry date.

        Returns the written-off lots with their quantities and values, so the
        economics engine can book the loss.
        """
        written_off: list[tuple[LotId, Kilograms, Money]] = []
        for lot in self._lots.values():
            if lot.is_expired(on) and not lot.is_empty:
                written_off.append((lot.lot_id, lot.quantity_kg, lot.value))
                lot.quantity_kg = 0.0
        return written_off

    def expiring_within(
        self, days: int, on: dt.date
    ) -> list[tuple[IngredientLot, int]]:
        """Lots expiring within ``days``, with days remaining, soonest first."""
        at_risk = [
            (lot, lot.days_to_expiry(on))
            for lot in self._lots.values()
            if not lot.is_empty and 0 <= lot.days_to_expiry(on) <= days
        ]
        return sorted(at_risk, key=lambda pair: (pair[1], pair[0].lot_id))

    def purge_empty_lots(self) -> int:
        """Remove fully consumed lots. Returns the number removed."""
        empty = [lot_id for lot_id, lot in self._lots.items() if lot.is_empty]
        for lot_id in empty:
            del self._lots[lot_id]
        return len(empty)

    @property
    def lots(self) -> dict[LotId, IngredientLot]:
        """All registered lots."""
        return dict(self._lots)

    def total_value(self) -> Money:
        """Book value of all raw-material lots on hand."""
        return sum(lot.value for lot in self._lots.values())

    def stock_summary(self, on: dt.date) -> dict[IngredientId, dict[str, float]]:
        """Per-ingredient stock position."""
        summary: dict[IngredientId, dict[str, float]] = {}
        for ingredient_id in self._ingredients:
            lots = self.lots_for(ingredient_id)
            available = sum(lot.quantity_kg for lot in lots if lot.is_available(on))
            total = sum(lot.quantity_kg for lot in lots)
            value = sum(lot.value for lot in lots)
            if total > 0.0 or available > 0.0:
                summary[ingredient_id] = {
                    "available_kg": available,
                    "total_kg": total,
                    "value": value,
                    "lot_count": float(len(lots)),
                }
        return summary


def build_default_registry() -> IngredientRegistry:
    """Construct a registry populated with the default catalogue."""
    return IngredientRegistry()


__all__ = ["IngredientRegistry", "build_default_registry"]
