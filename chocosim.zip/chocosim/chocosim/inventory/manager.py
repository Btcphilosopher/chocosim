"""Inventory: raw materials, work in progress and finished goods.

Three stock categories with different behaviour. Raw materials are lot-tracked
and perishable, and are managed by the ingredient registry. Work in progress
sits between stages and is bounded by physical buffer capacity. Finished goods
are batch-tracked, carry a shelf life, and are consumed by demand.

The reorder logic implements a continuous-review policy: when position falls
below a reorder point, order up to a target. The reorder point is derived from
demand during the lead time plus safety stock sized to a service level, which
is the standard formulation and, importantly, makes the cost of supplier
unreliability visible -- a supplier with a volatile lead time forces more
safety stock, and that stock costs money to hold.
"""

from __future__ import annotations

import datetime as dt
import math
from collections.abc import Iterable, Sequence

from pydantic import Field

from ..core.config import ChocoSimConfig
from ..core.exceptions import CapacityError, InsufficientStockError
from ..core.models import ChocoModel, FrozenChocoModel, safe_divide
from ..core.types import (
    BatchId,
    IngredientId,
    Kilograms,
    Money,
    RecipeId,
    StockCategory,
    StockMoveKind,
    next_id,
)
from ..ingredients.registry import IngredientRegistry

#: Standard normal quantiles for common service levels, for safety stock.
#: Tabulated rather than computed so the module does not need scipy at import.
SERVICE_LEVEL_Z: dict[float, float] = {
    0.50: 0.0000,
    0.80: 0.8416,
    0.90: 1.2816,
    0.95: 1.6449,
    0.975: 1.9600,
    0.98: 2.0537,
    0.99: 2.3263,
    0.995: 2.5758,
}


def service_level_z(service_level: float) -> float:
    """Standard normal quantile for a service level, interpolated."""
    if service_level in SERVICE_LEVEL_Z:
        return SERVICE_LEVEL_Z[service_level]
    if service_level <= 0.5:
        return 0.0
    if service_level >= 0.995:
        return 2.5758
    levels = sorted(SERVICE_LEVEL_Z)
    for lower, upper in zip(levels, levels[1:], strict=False):
        if lower <= service_level <= upper:
            span = upper - lower
            weight = (service_level - lower) / span if span > 0 else 0.0
            return SERVICE_LEVEL_Z[lower] + weight * (
                SERVICE_LEVEL_Z[upper] - SERVICE_LEVEL_Z[lower]
            )
    return 1.6449


class StockMove(FrozenChocoModel):
    """A single movement of stock."""

    move_id: str
    kind: StockMoveKind
    category: StockCategory
    item_id: str
    quantity_kg: Kilograms
    value: Money = 0.0
    occurred_on: dt.date
    reference: str = ""

    @property
    def is_inbound(self) -> bool:
        """Whether this move increases stock."""
        return self.kind in (
            StockMoveKind.RECEIPT,
            StockMoveKind.PRODUCTION,
            StockMoveKind.ADJUSTMENT,
        )


class FinishedGoodsLot(ChocoModel):
    """A batch of finished product in the warehouse."""

    lot_id: str
    batch_id: BatchId
    recipe_id: RecipeId
    product_name: str
    quantity_kg: Kilograms = Field(ge=0.0)
    original_quantity_kg: Kilograms = Field(ge=0.0)
    unit_cost: Money = Field(ge=0.0)
    produced_on: dt.date
    expires_on: dt.date
    quality_score: float = Field(default=100.0, ge=0.0, le=100.0)

    @property
    def value(self) -> Money:
        """Book value of remaining stock."""
        return self.quantity_kg * self.unit_cost

    @property
    def is_empty(self) -> bool:
        """Whether the lot is exhausted."""
        return self.quantity_kg <= 1e-9

    def days_to_expiry(self, on: dt.date) -> int:
        """Days of shelf life remaining."""
        return (self.expires_on - on).days

    def is_saleable(self, on: dt.date) -> bool:
        """Whether the lot can still be sold."""
        return not self.is_empty and on <= self.expires_on

    def draw(self, quantity_kg: Kilograms) -> Kilograms:
        """Take stock from the lot, returning what was available."""
        taken = min(max(0.0, quantity_kg), self.quantity_kg)
        self.quantity_kg -= taken
        return taken


class ReorderPolicy(FrozenChocoModel):
    """Continuous-review reorder policy for one ingredient."""

    ingredient_id: IngredientId
    daily_demand_kg: float = Field(ge=0.0)
    demand_sigma_kg: float = Field(default=0.0, ge=0.0)
    lead_time_days: float = Field(gt=0.0)
    lead_time_sigma_days: float = Field(default=0.0, ge=0.0)
    service_level: float = Field(default=0.95, gt=0.0, lt=1.0)
    review_days: float = Field(default=1.0, gt=0.0)

    @property
    def safety_stock_kg(self) -> Kilograms:
        """Safety stock for the target service level.

        Combines demand variability and lead-time variability, which is the
        full formulation rather than the demand-only shortcut. Lead-time
        variance usually dominates for imported cocoa, and a policy that
        ignores it under-stocks precisely the materials that matter most.
        """
        demand_variance = self.lead_time_days * self.demand_sigma_kg**2
        lead_variance = (self.daily_demand_kg * self.lead_time_sigma_days) ** 2
        return service_level_z(self.service_level) * math.sqrt(
            demand_variance + lead_variance
        )

    @property
    def reorder_point_kg(self) -> Kilograms:
        """Stock level at which a replenishment order is placed."""
        return self.daily_demand_kg * self.lead_time_days + self.safety_stock_kg

    @property
    def order_up_to_kg(self) -> Kilograms:
        """Target position after ordering."""
        return (
            self.daily_demand_kg * (self.lead_time_days + self.review_days)
            + self.safety_stock_kg
        )

    def order_quantity(self, position_kg: Kilograms) -> Kilograms:
        """Quantity to order given the current inventory position."""
        if position_kg > self.reorder_point_kg:
            return 0.0
        return max(0.0, self.order_up_to_kg - position_kg)

    def economic_order_quantity(
        self, order_cost: Money, unit_cost: Money, holding_rate: float
    ) -> Kilograms:
        """Classical EOQ, for comparison against the policy quantity."""
        annual_demand = self.daily_demand_kg * 365.0
        holding_cost = unit_cost * holding_rate
        if holding_cost <= 0.0 or annual_demand <= 0.0:
            return 0.0
        return math.sqrt(2.0 * annual_demand * order_cost / holding_cost)


class PurchaseOrder(ChocoModel):
    """An outstanding order with a supplier."""

    order_id: str
    ingredient_id: IngredientId
    supplier_id: str | None
    quantity_kg: Kilograms = Field(ge=0.0)
    unit_cost: Money = Field(ge=0.0)
    ordered_on: dt.date
    expected_on: dt.date
    received_on: dt.date | None = None
    received_kg: Kilograms = 0.0
    cancelled: bool = False

    @property
    def value(self) -> Money:
        """Order value."""
        return self.quantity_kg * self.unit_cost

    @property
    def is_open(self) -> bool:
        """Whether the order is still outstanding."""
        return self.received_on is None and not self.cancelled

    def days_late(self, actual: dt.date) -> int:
        """How many days after the promise the order arrived."""
        return (actual - self.expected_on).days


class InventoryPosition(FrozenChocoModel):
    """Snapshot of stock for one item."""

    item_id: str
    category: StockCategory
    on_hand_kg: Kilograms = Field(ge=0.0)
    on_order_kg: Kilograms = Field(default=0.0, ge=0.0)
    allocated_kg: Kilograms = Field(default=0.0, ge=0.0)
    value: Money = Field(default=0.0, ge=0.0)

    @property
    def available_kg(self) -> Kilograms:
        """Stock free to be consumed."""
        return max(0.0, self.on_hand_kg - self.allocated_kg)

    @property
    def position_kg(self) -> Kilograms:
        """Inventory position: on hand plus on order less allocated.

        The correct quantity to compare against a reorder point. Using on-hand
        alone causes repeated ordering while deliveries are already in transit,
        which is one of the classic ways a naive policy builds a bullwhip.
        """
        return self.on_hand_kg + self.on_order_kg - self.allocated_kg


class InventoryManager:
    """Tracks stock across raw, WIP and finished goods."""

    def __init__(
        self,
        registry: IngredientRegistry,
        config: ChocoSimConfig | None = None,
    ) -> None:
        self.registry = registry
        self.config = config or ChocoSimConfig.default()
        self.finished: dict[str, FinishedGoodsLot] = {}
        self.wip_kg: dict[str, Kilograms] = {}
        self.open_orders: dict[str, PurchaseOrder] = {}
        self.moves: list[StockMove] = []
        self.policies: dict[IngredientId, ReorderPolicy] = {}
        self.stockout_kg: dict[IngredientId, Kilograms] = {}

    # ------------------------------------------------------------------
    # Raw materials
    # ------------------------------------------------------------------

    def raw_position(self, ingredient_id: IngredientId, on: dt.date) -> InventoryPosition:
        """Stock position for a raw material."""
        lots = self.registry.lots_for(ingredient_id)
        on_hand = sum(lot.quantity_kg for lot in lots if lot.is_available(on))
        value = sum(lot.value for lot in lots)
        on_order = sum(
            order.quantity_kg
            for order in self.open_orders.values()
            if order.ingredient_id == ingredient_id and order.is_open
        )
        return InventoryPosition(
            item_id=ingredient_id,
            category=StockCategory.RAW_MATERIAL,
            on_hand_kg=on_hand,
            on_order_kg=on_order,
            value=value,
        )

    def consume_raw(
        self, ingredient_id: IngredientId, quantity_kg: Kilograms, on: dt.date, reference: str = ""
    ) -> tuple[Money, Kilograms]:
        """Issue raw material to production, FEFO.

        Returns the cost of what was issued and any shortfall. A shortfall is
        recorded rather than raised: during a supply-disruption scenario the
        shortfall is the thing being measured.
        """
        draws, shortfall = self.registry.consume(ingredient_id, quantity_kg, on)
        cost = sum(taken * unit_cost for _, taken, unit_cost in draws)
        issued = sum(taken for _, taken, _ in draws)

        if issued > 0.0:
            self.moves.append(
                StockMove(
                    move_id=next_id("MOVE", width=6),
                    kind=StockMoveKind.ISSUE,
                    category=StockCategory.RAW_MATERIAL,
                    item_id=ingredient_id,
                    quantity_kg=-issued,
                    value=cost,
                    occurred_on=on,
                    reference=reference,
                )
            )
        if shortfall > 1e-9:
            self.stockout_kg[ingredient_id] = (
                self.stockout_kg.get(ingredient_id, 0.0) + shortfall
            )
        return cost, shortfall

    def require_raw(
        self, ingredient_id: IngredientId, quantity_kg: Kilograms, on: dt.date
    ) -> Money:
        """Issue raw material, raising if there is not enough.

        Used where a shortfall is a programming error rather than a scenario
        outcome, such as a deterministic reference run.
        """
        cost, shortfall = self.consume_raw(ingredient_id, quantity_kg, on)
        if shortfall > 1e-9:
            raise InsufficientStockError(
                f"Insufficient {ingredient_id}: short by {shortfall:,.2f} kg "
                f"of {quantity_kg:,.2f} kg required on {on}"
            )
        return cost

    # ------------------------------------------------------------------
    # Reorder policies
    # ------------------------------------------------------------------

    def set_policy(self, policy: ReorderPolicy) -> ReorderPolicy:
        """Register a reorder policy."""
        self.policies[policy.ingredient_id] = policy
        return policy

    def policy_from_usage(
        self,
        ingredient_id: IngredientId,
        daily_demand_kg: float,
        demand_cv: float = 0.20,
        service_level: float = 0.95,
    ) -> ReorderPolicy:
        """Derive a reorder policy from usage and the supplier's performance."""
        supplier = self.registry.supplier_for(ingredient_id)
        lead_time = supplier.lead_time_days_mean if supplier else 14.0
        lead_sigma = supplier.lead_time_days_sigma if supplier else 3.0
        return self.set_policy(
            ReorderPolicy(
                ingredient_id=ingredient_id,
                daily_demand_kg=daily_demand_kg,
                demand_sigma_kg=daily_demand_kg * demand_cv,
                lead_time_days=lead_time,
                lead_time_sigma_days=lead_sigma,
                service_level=service_level,
            )
        )

    def check_reorders(self, on: dt.date) -> list[PurchaseOrder]:
        """Place any orders the policies call for."""
        placed: list[PurchaseOrder] = []
        for ingredient_id, policy in self.policies.items():
            position = self.raw_position(ingredient_id, on)
            quantity = policy.order_quantity(position.position_kg)
            if quantity <= 0.0:
                continue
            placed.append(self.place_order(ingredient_id, quantity, on))
        return placed

    def place_order(
        self, ingredient_id: IngredientId, quantity_kg: Kilograms, on: dt.date
    ) -> PurchaseOrder:
        """Place a purchase order, rounded to the supplier's constraints."""
        supplier = self.registry.supplier_for(ingredient_id)
        rounded = supplier.round_order(quantity_kg) if supplier else quantity_kg
        lead_time = supplier.lead_time_days_mean if supplier else 14.0
        order = PurchaseOrder(
            order_id=next_id("PO", width=5),
            ingredient_id=ingredient_id,
            supplier_id=supplier.supplier_id if supplier else None,
            quantity_kg=rounded,
            unit_cost=self.registry.unit_cost(ingredient_id),
            ordered_on=on,
            expected_on=on + dt.timedelta(days=round(lead_time)),
        )
        self.open_orders[order.order_id] = order
        return order

    def receive_order(
        self,
        order_id: str,
        on: dt.date,
        received_kg: Kilograms | None = None,
    ) -> PurchaseOrder:
        """Book in a delivery, creating the lot."""
        order = self.open_orders[order_id]
        quantity = received_kg if received_kg is not None else order.quantity_kg
        order.received_on = on
        order.received_kg = quantity

        if quantity > 0.0:
            self.registry.create_lot(
                order.ingredient_id,
                quantity,
                on,
                supplier_id=order.supplier_id,
                unit_cost=order.unit_cost,
            )
            self.moves.append(
                StockMove(
                    move_id=next_id("MOVE", width=6),
                    kind=StockMoveKind.RECEIPT,
                    category=StockCategory.RAW_MATERIAL,
                    item_id=order.ingredient_id,
                    quantity_kg=quantity,
                    value=quantity * order.unit_cost,
                    occurred_on=on,
                    reference=order.order_id,
                )
            )
        return order

    def due_orders(self, on: dt.date) -> list[PurchaseOrder]:
        """Orders expected on or before a date."""
        return [
            order
            for order in self.open_orders.values()
            if order.is_open and order.expected_on <= on
        ]

    # ------------------------------------------------------------------
    # Work in progress
    # ------------------------------------------------------------------

    def add_wip(self, stage: str, quantity_kg: Kilograms) -> Kilograms:
        """Add material to an inter-stage buffer."""
        capacity = self.config.factory.wip_buffer_capacity_kg
        current = self.total_wip_kg
        if current + quantity_kg > capacity:
            raise CapacityError(
                f"WIP buffer full: {current:,.0f} kg held, "
                f"{quantity_kg:,.0f} kg offered, {capacity:,.0f} kg capacity"
            )
        self.wip_kg[stage] = self.wip_kg.get(stage, 0.0) + quantity_kg
        return self.wip_kg[stage]

    def draw_wip(self, stage: str, quantity_kg: Kilograms) -> Kilograms:
        """Take material from an inter-stage buffer."""
        available = self.wip_kg.get(stage, 0.0)
        taken = min(available, quantity_kg)
        self.wip_kg[stage] = available - taken
        return taken

    @property
    def total_wip_kg(self) -> Kilograms:
        """Total work in progress across all buffers."""
        return sum(self.wip_kg.values())

    # ------------------------------------------------------------------
    # Finished goods
    # ------------------------------------------------------------------

    def receive_finished(
        self,
        batch_id: BatchId,
        recipe_id: RecipeId,
        product_name: str,
        quantity_kg: Kilograms,
        unit_cost: Money,
        produced_on: dt.date,
        shelf_life_days: int = 365,
        quality_score: float = 100.0,
    ) -> FinishedGoodsLot:
        """Book finished product into the warehouse."""
        held = self.finished_goods_kg
        capacity = self.config.factory.warehouse_capacity_kg
        if held + quantity_kg > capacity:
            raise CapacityError(
                f"Warehouse full: {held:,.0f} kg held, {quantity_kg:,.0f} kg "
                f"offered, {capacity:,.0f} kg capacity"
            )

        lot = FinishedGoodsLot(
            lot_id=next_id("FG", width=6),
            batch_id=batch_id,
            recipe_id=recipe_id,
            product_name=product_name,
            quantity_kg=quantity_kg,
            original_quantity_kg=quantity_kg,
            unit_cost=unit_cost,
            produced_on=produced_on,
            expires_on=produced_on + dt.timedelta(days=shelf_life_days),
            quality_score=quality_score,
        )
        self.finished[lot.lot_id] = lot
        self.moves.append(
            StockMove(
                move_id=next_id("MOVE", width=6),
                kind=StockMoveKind.PRODUCTION,
                category=StockCategory.FINISHED_GOODS,
                item_id=recipe_id,
                quantity_kg=quantity_kg,
                value=quantity_kg * unit_cost,
                occurred_on=produced_on,
                reference=batch_id,
            )
        )
        return lot

    def ship(
        self, recipe_id: RecipeId, quantity_kg: Kilograms, on: dt.date
    ) -> tuple[Kilograms, Money, Kilograms]:
        """Ship finished product, FEFO. Returns shipped, cost, shortfall."""
        lots = sorted(
            (
                lot
                for lot in self.finished.values()
                if lot.recipe_id == recipe_id and lot.is_saleable(on)
            ),
            key=lambda lot: (lot.expires_on, lot.lot_id),
        )
        remaining = quantity_kg
        shipped = 0.0
        cost = 0.0
        for lot in lots:
            if remaining <= 1e-12:
                break
            taken = lot.draw(remaining)
            shipped += taken
            cost += taken * lot.unit_cost
            remaining -= taken

        if shipped > 0.0:
            self.moves.append(
                StockMove(
                    move_id=next_id("MOVE", width=6),
                    kind=StockMoveKind.SALE,
                    category=StockCategory.FINISHED_GOODS,
                    item_id=recipe_id,
                    quantity_kg=-shipped,
                    value=cost,
                    occurred_on=on,
                )
            )
        return shipped, cost, max(0.0, remaining)

    @property
    def finished_goods_kg(self) -> Kilograms:
        """Total finished stock on hand."""
        return sum(lot.quantity_kg for lot in self.finished.values())

    @property
    def finished_goods_value(self) -> Money:
        """Book value of finished stock."""
        return sum(lot.value for lot in self.finished.values())

    def expire_finished(self, on: dt.date) -> tuple[Kilograms, Money]:
        """Write off expired finished goods."""
        written_kg = 0.0
        written_value = 0.0
        for lot in self.finished.values():
            if not lot.is_empty and on > lot.expires_on:
                written_kg += lot.quantity_kg
                written_value += lot.value
                self.moves.append(
                    StockMove(
                        move_id=next_id("MOVE", width=6),
                        kind=StockMoveKind.EXPIRY,
                        category=StockCategory.FINISHED_GOODS,
                        item_id=lot.recipe_id,
                        quantity_kg=-lot.quantity_kg,
                        value=lot.value,
                        occurred_on=on,
                        reference=lot.lot_id,
                    )
                )
                lot.quantity_kg = 0.0
        return written_kg, written_value

    # ------------------------------------------------------------------
    # Valuation
    # ------------------------------------------------------------------

    def total_value(self, wip_unit_cost: Money = 5.0) -> Money:
        """Book value of all inventory."""
        return (
            self.registry.total_value()
            + self.total_wip_kg * wip_unit_cost
            + self.finished_goods_value
        )

    def summary(self, on: dt.date) -> dict[str, dict[str, float]]:
        """Stock summary by category."""
        raw_value = self.registry.total_value()
        raw_kg = sum(
            position["total_kg"] for position in self.registry.stock_summary(on).values()
        )
        return {
            "raw_material": {"kg": raw_kg, "value": raw_value},
            "work_in_progress": {"kg": self.total_wip_kg, "value": self.total_wip_kg * 5.0},
            "finished_goods": {
                "kg": self.finished_goods_kg,
                "value": self.finished_goods_value,
            },
        }

    def report(self, on: dt.date) -> str:
        """Plain-text inventory report."""
        summary = self.summary(on)
        symbol = self.config.economics.currency_symbol
        lines = [
            f"INVENTORY POSITION -- {on.isoformat()}",
            "=" * 52,
            f"{'CATEGORY':<20}{'KG':>14}{'VALUE':>16}",
            "-" * 52,
        ]
        for category, values in summary.items():
            lines.append(
                f"{category:<20}{values['kg']:>14,.1f}"
                f"{symbol + f'{values[chr(118) + chr(97) + chr(108) + chr(117) + chr(101)]:,.2f}':>16}"
            )
        total_kg = sum(values["kg"] for values in summary.values())
        total_value = sum(values["value"] for values in summary.values())
        lines += [
            "-" * 52,
            f"{'TOTAL':<20}{total_kg:>14,.1f}{symbol + f'{total_value:,.2f}':>16}",
        ]
        open_orders = [order for order in self.open_orders.values() if order.is_open]
        if open_orders:
            lines += ["", f"OPEN ORDERS ({len(open_orders)})"]
            for order in sorted(open_orders, key=lambda o: o.expected_on)[:10]:
                lines.append(
                    f"  {order.order_id}  {order.ingredient_id:<22} "
                    f"{order.quantity_kg:>10,.0f} kg  due {order.expected_on}"
                )
        if self.stockout_kg:
            lines += ["", "STOCKOUTS"]
            for ingredient_id, quantity in sorted(
                self.stockout_kg.items(), key=lambda item: -item[1]
            ):
                lines.append(f"  {ingredient_id:<24}{quantity:>12,.1f} kg short")
        return "\n".join(lines)


__all__ = [
    "SERVICE_LEVEL_Z",
    "FinishedGoodsLot",
    "InventoryManager",
    "InventoryPosition",
    "PurchaseOrder",
    "ReorderPolicy",
    "StockMove",
    "service_level_z",
]
