"""Supply chain: lead times, disruptions and price shocks.

Answers the question the specification poses directly -- what happens if cocoa
prices rise 20% -- and the harder questions around it: what if the shock is a
supply interruption rather than a price move, what if it lands on one supplier
rather than the market, and what does it cost to hold enough stock to ride it
out.

Disruptions are modelled as discrete events with a start, a duration and a
severity, each affecting supply, lead time, price or quality. That structure
matters because the four have different remedies: a price shock is hedged, a
supply interruption is buffered, a lead-time extension is planned around, and
a quality problem is inspected for.
"""

from __future__ import annotations

import datetime as dt
from collections.abc import Sequence

from pydantic import Field

from ..core.config import ChocoSimConfig
from ..core.fidelity import ModelProvenance
from ..core.models import FrozenChocoModel, clamp, safe_divide
from ..core.rng import RandomSource, bernoulli, lognormal_from_moments, truncated_normal
from ..core.types import (
    DisruptionKind,
    IngredientClass,
    IngredientId,
    Kilograms,
    Money,
    SupplierId,
)
from ..ingredients.registry import IngredientRegistry
from ..inventory.manager import InventoryManager, PurchaseOrder


class Disruption(FrozenChocoModel):
    """A supply chain disruption event."""

    kind: DisruptionKind
    start_day: int = Field(ge=0)
    duration_days: int = Field(gt=0)
    severity: float = Field(
        gt=0.0,
        description=(
            "Meaning depends on kind: a multiplier for price and lead time, a "
            "fraction of supply withheld for shortage, a quality derate for "
            "quality events."
        ),
    )
    supplier_id: SupplierId | None = None
    ingredient_class: IngredientClass | None = None
    description: str = ""

    @property
    def end_day(self) -> int:
        """Day after which the disruption has passed."""
        return self.start_day + self.duration_days

    def is_active(self, day: int) -> bool:
        """Whether the disruption is in force on a day."""
        return self.start_day <= day < self.end_day

    def affects(
        self, ingredient_id: IngredientId, registry: IngredientRegistry
    ) -> bool:
        """Whether this disruption touches a given ingredient."""
        ingredient = registry.find(ingredient_id)
        if ingredient is None:
            return False
        if self.ingredient_class is not None:
            return ingredient.ingredient_class is self.ingredient_class
        if self.supplier_id is not None:
            return ingredient.default_supplier_id == self.supplier_id
        return True


class DeliveryOutcome(FrozenChocoModel):
    """What actually happened to one purchase order."""

    order_id: str
    ingredient_id: IngredientId
    ordered_kg: Kilograms = Field(ge=0.0)
    delivered_kg: Kilograms = Field(ge=0.0)
    expected_day: int
    actual_day: int
    unit_cost: Money = Field(ge=0.0)
    quality_grade: float = Field(ge=0.0, le=1.0)
    disrupted: bool = False

    @property
    def days_late(self) -> int:
        """Days beyond the promise."""
        return self.actual_day - self.expected_day

    @property
    def fill_rate(self) -> float:
        """Share of the order actually delivered."""
        return safe_divide(self.delivered_kg, self.ordered_kg)

    @property
    def on_time_in_full(self) -> bool:
        """The standard supplier performance measure."""
        return self.days_late <= 0 and self.fill_rate >= 0.99


class SupplyChainResult(FrozenChocoModel):
    """Outcome of a supply chain simulation."""

    horizon_days: int = Field(gt=0)
    deliveries: tuple[DeliveryOutcome, ...]
    disruptions: tuple[Disruption, ...]
    total_purchase_cost: Money = Field(ge=0.0)
    shortfall_kg: dict[str, float] = Field(default_factory=dict)
    provenance: ModelProvenance

    @property
    def on_time_in_full_rate(self) -> float:
        """Share of deliveries that arrived on time and complete."""
        if not self.deliveries:
            return 0.0
        return sum(
            1 for delivery in self.deliveries if delivery.on_time_in_full
        ) / len(self.deliveries)

    @property
    def mean_days_late(self) -> float:
        """Average lateness across deliveries."""
        if not self.deliveries:
            return 0.0
        return sum(delivery.days_late for delivery in self.deliveries) / len(
            self.deliveries
        )

    @property
    def mean_fill_rate(self) -> float:
        """Average fill rate across deliveries."""
        if not self.deliveries:
            return 0.0
        return sum(delivery.fill_rate for delivery in self.deliveries) / len(
            self.deliveries
        )

    @property
    def total_shortfall_kg(self) -> Kilograms:
        """Total material the plant could not get."""
        return sum(self.shortfall_kg.values())

    def report(self) -> str:
        """Plain-text supply chain summary."""
        lines = [
            f"SUPPLY CHAIN -- {self.horizon_days} days",
            "=" * 56,
            f"Deliveries        {len(self.deliveries)}",
            f"On time in full   {self.on_time_in_full_rate:.1%}",
            f"Mean lateness     {self.mean_days_late:.1f} days",
            f"Mean fill rate    {self.mean_fill_rate:.1%}",
            f"Purchase cost     {self.total_purchase_cost:,.2f}",
        ]
        if self.disruptions:
            lines += ["", "DISRUPTIONS"]
            for disruption in self.disruptions:
                target = (
                    disruption.ingredient_class.value
                    if disruption.ingredient_class
                    else disruption.supplier_id or "all"
                )
                lines.append(
                    f"  day {disruption.start_day:>3}-{disruption.end_day:<3} "
                    f"{disruption.kind.value:<18} {target:<16} "
                    f"severity {disruption.severity:.2f}"
                )
        if self.shortfall_kg:
            lines += ["", "SHORTFALLS"]
            for ingredient_id, quantity in sorted(
                self.shortfall_kg.items(), key=lambda item: -item[1]
            ):
                lines.append(f"  {ingredient_id:<26}{quantity:>12,.1f} kg")
        return "\n".join(lines)


class SupplyChainSimulator:
    """Simulates purchasing under uncertainty and disruption."""

    MODEL_NAME = "supply_chain"

    def __init__(
        self,
        registry: IngredientRegistry,
        inventory: InventoryManager,
        config: ChocoSimConfig | None = None,
    ) -> None:
        self.registry = registry
        self.inventory = inventory
        self.config = config or ChocoSimConfig.default()
        self.disruptions: list[Disruption] = []

    def add_disruption(self, disruption: Disruption) -> Disruption:
        """Register a disruption event."""
        self.disruptions.append(disruption)
        return disruption

    def active_disruptions(
        self, day: int, ingredient_id: IngredientId
    ) -> list[Disruption]:
        """Disruptions in force on a day for an ingredient."""
        return [
            disruption
            for disruption in self.disruptions
            if disruption.is_active(day) and disruption.affects(ingredient_id, self.registry)
        ]

    def price_multiplier(self, day: int, ingredient_id: IngredientId) -> float:
        """Combined price effect of active disruptions.

        Multiplicative rather than additive: two events that each raise price
        20% give 44%, not 40%, which is how compounding shocks actually behave.
        """
        multiplier = 1.0
        for disruption in self.active_disruptions(day, ingredient_id):
            if disruption.kind is DisruptionKind.PRICE_SHOCK:
                multiplier *= disruption.severity
        return multiplier

    def lead_time_multiplier(self, day: int, ingredient_id: IngredientId) -> float:
        """Combined lead-time effect of active disruptions."""
        multiplier = 1.0
        for disruption in self.active_disruptions(day, ingredient_id):
            if disruption.kind in (
                DisruptionKind.LOGISTICS_DELAY,
                DisruptionKind.PORT_CONGESTION,
            ):
                multiplier *= disruption.severity
        return multiplier

    def supply_fraction(self, day: int, ingredient_id: IngredientId) -> float:
        """Share of an order that can be supplied on a day."""
        fraction = 1.0
        for disruption in self.active_disruptions(day, ingredient_id):
            if disruption.kind in (
                DisruptionKind.SUPPLY_SHORTAGE,
                DisruptionKind.CROP_FAILURE,
                DisruptionKind.SUPPLIER_FAILURE,
            ):
                fraction *= max(0.0, 1.0 - disruption.severity)
        return clamp(fraction, 0.0, 1.0)

    def simulate_delivery(
        self,
        order: PurchaseOrder,
        order_day: int,
        source: RandomSource,
    ) -> DeliveryOutcome:
        """Simulate one delivery against supplier performance and disruptions."""
        supplier = (
            self.registry.supplier(order.supplier_id) if order.supplier_id else None
        )
        deterministic = self.config.simulation.deterministic

        mean_lead = supplier.lead_time_days_mean if supplier else 14.0
        sigma_lead = supplier.lead_time_days_sigma if supplier else 3.0
        reliability = supplier.reliability if supplier else 0.94
        grade = supplier.quality_grade if supplier else 1.0

        lead_multiplier = self.lead_time_multiplier(order_day, order.ingredient_id)
        expected_day = order_day + round(mean_lead)

        if deterministic:
            actual_lead = mean_lead * lead_multiplier
        else:
            generator = source.generator(f"supply/lead/{order.order_id}")
            actual_lead = float(
                truncated_normal(
                    generator,
                    mean_lead * lead_multiplier,
                    sigma_lead * lead_multiplier,
                    low=1.0,
                    high=mean_lead * lead_multiplier * 4.0 + 10.0,
                )
            )
            # An unreliable supplier occasionally misses badly rather than
            # slightly. Modelling this as a separate failure mode rather than a
            # fat tail keeps the two causes distinguishable in the output.
            if not bernoulli(
                source.generator(f"supply/reliable/{order.order_id}"), reliability
            ):
                actual_lead *= float(
                    lognormal_from_moments(
                        source.generator(f"supply/delay/{order.order_id}"), 1.8, 0.35
                    )
                )

        actual_day = order_day + max(1, round(actual_lead))

        supply_fraction = self.supply_fraction(actual_day, order.ingredient_id)
        delivered = order.quantity_kg * supply_fraction

        price_multiplier = self.price_multiplier(order_day, order.ingredient_id)
        unit_cost = order.unit_cost * price_multiplier

        quality_disruptions = [
            disruption
            for disruption in self.active_disruptions(actual_day, order.ingredient_id)
            if disruption.kind is DisruptionKind.QUALITY_FAILURE
        ]
        for disruption in quality_disruptions:
            grade *= max(0.0, 1.0 - disruption.severity)

        return DeliveryOutcome(
            order_id=order.order_id,
            ingredient_id=order.ingredient_id,
            ordered_kg=order.quantity_kg,
            delivered_kg=delivered,
            expected_day=expected_day,
            actual_day=actual_day,
            unit_cost=unit_cost,
            quality_grade=clamp(grade, 0.0, 1.0),
            disrupted=bool(self.active_disruptions(actual_day, order.ingredient_id)),
        )

    def run(
        self,
        daily_demand: dict[IngredientId, float],
        horizon_days: int,
        start_date: dt.date,
        source: RandomSource | None = None,
        service_level: float = 0.95,
    ) -> SupplyChainResult:
        """Simulate purchasing and consumption over a horizon."""
        source = source or RandomSource(self.config.simulation.seed)

        for ingredient_id, demand in daily_demand.items():
            self.inventory.policy_from_usage(
                ingredient_id, demand, service_level=service_level
            )

        deliveries: list[DeliveryOutcome] = []
        pending: dict[int, list[DeliveryOutcome]] = {}
        purchase_cost = 0.0

        for day in range(horizon_days):
            date = start_date + dt.timedelta(days=day)

            # Receive anything arriving today.
            for outcome in pending.pop(day, []):
                if outcome.delivered_kg > 0.0:
                    self.registry.create_lot(
                        outcome.ingredient_id,
                        outcome.delivered_kg,
                        date,
                        unit_cost=outcome.unit_cost,
                        quality_grade=outcome.quality_grade,
                    )
                    purchase_cost += outcome.delivered_kg * outcome.unit_cost
                order = self.inventory.open_orders.get(outcome.order_id)
                if order is not None:
                    order.received_on = date
                    order.received_kg = outcome.delivered_kg

            # Consume the day's requirement.
            for ingredient_id, demand in daily_demand.items():
                if demand > 0.0:
                    self.inventory.consume_raw(
                        ingredient_id, demand, date, reference=f"day-{day}"
                    )

            # Expire anything past date.
            self.registry.expire_lots(date)

            # Reorder.
            for order in self.inventory.check_reorders(date):
                outcome = self.simulate_delivery(order, day, source)
                deliveries.append(outcome)
                pending.setdefault(outcome.actual_day, []).append(outcome)

        return SupplyChainResult(
            horizon_days=horizon_days,
            deliveries=tuple(deliveries),
            disruptions=tuple(self.disruptions),
            total_purchase_cost=purchase_cost,
            shortfall_kg=dict(self.inventory.stockout_kg),
            provenance=ModelProvenance.simulation(
                self.MODEL_NAME,
                basis=(
                    "Continuous-review reorder policy against stochastic lead "
                    "times and discrete disruption events"
                ),
                assumptions=(
                    "Demand is known and constant within the horizon",
                    "Suppliers are independent; no correlated failures",
                    "Disruption severities are scenario inputs, not forecasts",
                ),
            ),
        )


def cocoa_price_shock(
    magnitude: float = 1.20,
    start_day: int = 0,
    duration_days: int = 180,
) -> Disruption:
    """A market-wide cocoa price shock.

    The specification's worked example. Applied to the cocoa complex as a
    class, so beans, nibs, liquor, butter and powder all move together --
    which is what happens, because they are the same commodity at different
    stages of processing.
    """
    return Disruption(
        kind=DisruptionKind.PRICE_SHOCK,
        start_day=start_day,
        duration_days=duration_days,
        severity=magnitude,
        ingredient_class=IngredientClass.COCOA_LIQUOR,
        description=f"Cocoa market price rises {(magnitude - 1.0):.0%}",
    )


def cocoa_complex_shock(
    magnitude: float = 1.20,
    start_day: int = 0,
    duration_days: int = 180,
) -> list[Disruption]:
    """Price shock applied across every cocoa-derived material."""
    classes = (
        IngredientClass.COCOA_BEAN,
        IngredientClass.COCOA_NIB,
        IngredientClass.COCOA_LIQUOR,
        IngredientClass.COCOA_BUTTER,
        IngredientClass.COCOA_POWDER,
    )
    return [
        Disruption(
            kind=DisruptionKind.PRICE_SHOCK,
            start_day=start_day,
            duration_days=duration_days,
            severity=magnitude,
            ingredient_class=ingredient_class,
            description=f"Cocoa complex price rises {(magnitude - 1.0):.0%}",
        )
        for ingredient_class in classes
    ]


def west_africa_crop_failure(
    severity: float = 0.35, start_day: int = 30, duration_days: int = 120
) -> Disruption:
    """A harvest shortfall restricting physical supply."""
    return Disruption(
        kind=DisruptionKind.CROP_FAILURE,
        start_day=start_day,
        duration_days=duration_days,
        severity=severity,
        supplier_id="SUP-COCOA-WA",
        description=f"West African harvest short by {severity:.0%}",
    )


def port_congestion(
    multiplier: float = 1.8, start_day: int = 45, duration_days: int = 60
) -> Disruption:
    """Shipping delays extending lead times."""
    return Disruption(
        kind=DisruptionKind.PORT_CONGESTION,
        start_day=start_day,
        duration_days=duration_days,
        severity=multiplier,
        description=f"Port congestion extends lead times {multiplier:.1f}x",
    )


__all__ = [
    "DeliveryOutcome",
    "Disruption",
    "SupplyChainResult",
    "SupplyChainSimulator",
    "cocoa_complex_shock",
    "cocoa_price_shock",
    "port_congestion",
    "west_africa_crop_failure",
]
