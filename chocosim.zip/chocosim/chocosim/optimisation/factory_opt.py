"""Factory-level optimisation: current state against optimised state.

Runs the factory as configured, applies every optimiser in turn, runs it
again, and reports the difference on the measures a plant manager cares about:
capacity utilisation, machine utilisation, energy intensity, waste and
changeover loss.

The comparison is honest in two specific ways that matter.

First, every "optimised" figure comes from actually re-running the simulation
under the optimised settings, not from applying an assumed improvement factor
to the baseline. If the optimiser's schedule does not in fact reduce
changeover time, the comparison will say so.

Second, the levers are separated, so it is clear which improvement came from
where. An aggregate "18% better" is unactionable; "12 points of the capacity
gain came from sequencing and 6 from batch sizing" is a plan.
"""

from __future__ import annotations

import datetime as dt
from collections.abc import Sequence

from pydantic import Field

from ..core.config import ChocoSimConfig
from ..core.fidelity import ModelProvenance
from ..core.models import FrozenChocoModel, safe_divide
from ..core.types import Kilograms, Money, RecipeId
from ..production.line import (
    LIQUOR_STAGE_SEQUENCE,
    BatchOrder,
    LineRunResult,
    ProductionLine,
)
from ..recipes.engine import RecipeEngine
from ..recipes.library import RecipeBook, build_standard_book
from ..core.types import next_id
from .solvers import ProductionScheduler, ScheduleJob, ScheduleResult


class FactoryMetrics(FrozenChocoModel):
    """The headline measures of factory performance."""

    capacity_utilisation: float = Field(
        ge=0.0, description="Output against the line's nominal capacity."
    )
    machine_utilisation: float = Field(
        ge=0.0, description="Mean utilisation across machines."
    )
    bottleneck_utilisation: float = Field(ge=0.0)
    bottleneck_stage: str = ""
    energy_kwh_per_kg: float = Field(ge=0.0)
    waste_fraction: float = Field(ge=0.0)
    changeover_hours: float = Field(ge=0.0)
    throughput_kg_per_hour: float = Field(ge=0.0)
    mean_cycle_time_hours: float = Field(ge=0.0)
    cost_per_kg: Money = Field(default=0.0, ge=0.0)


class OptimisationLever(FrozenChocoModel):
    """One improvement and what it contributed."""

    name: str
    description: str
    capacity_gain: float = Field(default=0.0)
    energy_saving_kwh_per_kg: float = Field(default=0.0)
    changeover_saving_hours: float = Field(default=0.0)
    cost_saving_per_kg: Money = Field(default=0.0)
    applied: bool = True

    def summary(self) -> str:
        """One-line lever description."""
        parts = []
        if abs(self.capacity_gain) > 1e-6:
            parts.append(f"capacity {self.capacity_gain:+.1%}")
        if abs(self.changeover_saving_hours) > 1e-6:
            parts.append(f"changeover {-self.changeover_saving_hours:+.1f} h")
        if abs(self.energy_saving_kwh_per_kg) > 1e-9:
            parts.append(f"energy {-self.energy_saving_kwh_per_kg:+.4f} kWh/kg")
        if abs(self.cost_saving_per_kg) > 1e-6:
            parts.append(f"cost {-self.cost_saving_per_kg:+.4f}/kg")
        detail = ", ".join(parts) if parts else "no measurable effect"
        return f"{self.name:<26} {detail}"


class FactoryOptimisationResult(FrozenChocoModel):
    """Current versus optimised, with the levers that got there."""

    current: FactoryMetrics
    optimised: FactoryMetrics
    levers: tuple[OptimisationLever, ...]
    schedule: ScheduleResult | None = None
    provenance: ModelProvenance

    @property
    def capacity_gain(self) -> float:
        """Absolute gain in capacity utilisation, in percentage points."""
        return self.optimised.capacity_utilisation - self.current.capacity_utilisation

    @property
    def energy_saving(self) -> float:
        """Reduction in energy intensity."""
        return self.current.energy_kwh_per_kg - self.optimised.energy_kwh_per_kg

    @property
    def energy_saving_fraction(self) -> float:
        """Proportional reduction in energy intensity."""
        return safe_divide(self.energy_saving, self.current.energy_kwh_per_kg)

    @property
    def waste_reduction(self) -> float:
        """Reduction in waste fraction."""
        return self.current.waste_fraction - self.optimised.waste_fraction

    def report(self) -> str:
        """The current-versus-optimised panel."""
        current, optimised = self.current, self.optimised

        def row(label: str, before: str, after: str, delta: str) -> str:
            return f"  {label:<24}{before:>14}{after:>14}{delta:>14}"

        lines = [
            "FACTORY OPTIMISATION",
            "=" * 68,
            f"  {'MEASURE':<24}{'CURRENT':>14}{'OPTIMISED':>14}{'CHANGE':>14}",
            "-" * 68,
            row(
                "Capacity utilisation",
                f"{current.capacity_utilisation:.1%}",
                f"{optimised.capacity_utilisation:.1%}",
                f"{self.capacity_gain:+.1%}",
            ),
            row(
                "Machine utilisation",
                f"{current.machine_utilisation:.1%}",
                f"{optimised.machine_utilisation:.1%}",
                f"{optimised.machine_utilisation - current.machine_utilisation:+.1%}",
            ),
            row(
                "Energy intensity",
                f"{current.energy_kwh_per_kg:.3f}",
                f"{optimised.energy_kwh_per_kg:.3f}",
                f"{-self.energy_saving:+.3f}",
            ),
            row(
                "Waste",
                f"{current.waste_fraction:.2%}",
                f"{optimised.waste_fraction:.2%}",
                f"{-self.waste_reduction:+.2%}",
            ),
            row(
                "Changeover time",
                f"{current.changeover_hours:.1f} h",
                f"{optimised.changeover_hours:.1f} h",
                f"{optimised.changeover_hours - current.changeover_hours:+.1f} h",
            ),
            row(
                "Throughput",
                f"{current.throughput_kg_per_hour:.0f}",
                f"{optimised.throughput_kg_per_hour:.0f}",
                f"{optimised.throughput_kg_per_hour - current.throughput_kg_per_hour:+.0f}",
            ),
            row(
                "Cycle time",
                f"{current.mean_cycle_time_hours:.1f} h",
                f"{optimised.mean_cycle_time_hours:.1f} h",
                f"{optimised.mean_cycle_time_hours - current.mean_cycle_time_hours:+.1f} h",
            ),
            "-" * 68,
            f"  BOTTLENECK  {current.bottleneck_stage.upper()} "
            f"({current.bottleneck_utilisation:.1%}) -> "
            f"{optimised.bottleneck_stage.upper()} "
            f"({optimised.bottleneck_utilisation:.1%})",
        ]
        if self.levers:
            lines += ["", "LEVERS"]
            lines += [f"  {lever.summary()}" for lever in self.levers]
        lines += ["", self.provenance.banner()]
        return "\n".join(lines)


class FactoryOptimiser:
    """Optimises a production programme and measures the improvement."""

    MODEL_NAME = "factory_optimiser"

    def __init__(
        self,
        config: ChocoSimConfig | None = None,
        recipe_book: RecipeBook | None = None,
    ) -> None:
        self.config = config or ChocoSimConfig.default()
        self.recipe_book = recipe_book or build_standard_book()
        self.scheduler = ProductionScheduler(self.config)

    def _metrics(
        self, result: LineRunResult, nominal_capacity_kg_per_hour: float
    ) -> FactoryMetrics:
        """Derive headline metrics from a line simulation."""
        bottleneck = result.bottleneck()
        utilisations = [stat.utilisation for stat in result.stage_statistics]
        return FactoryMetrics(
            capacity_utilisation=safe_divide(
                result.throughput_kg_per_hour, nominal_capacity_kg_per_hour
            ),
            machine_utilisation=(
                sum(utilisations) / len(utilisations) if utilisations else 0.0
            ),
            bottleneck_utilisation=bottleneck.utilisation if bottleneck else 0.0,
            bottleneck_stage=bottleneck.stage.value if bottleneck else "",
            energy_kwh_per_kg=0.0,
            waste_fraction=0.0,
            changeover_hours=result.total_changeover_minutes / 60.0,
            throughput_kg_per_hour=result.throughput_kg_per_hour,
            mean_cycle_time_hours=result.mean_cycle_time_minutes / 60.0,
        )

    def optimise(
        self,
        programme: Sequence[tuple[RecipeId, Kilograms]],
        horizon_hours: float = 168.0,
        energy_kwh_per_kg: float = 0.0,
        waste_fraction: float = 0.0,
        optimised_waste_fraction: float | None = None,
        optimised_energy_kwh_per_kg: float | None = None,
    ) -> FactoryOptimisationResult:
        """Run the programme as given, then optimised, and compare.

        ``energy_kwh_per_kg`` and ``waste_fraction`` are supplied by the caller
        from a process simulation, because the line model does not itself know
        about them. Passing them in rather than inventing them here keeps a
        single source of truth for each number.
        """
        recipe_engine_needed = any(
            recipe_id not in self.recipe_book for recipe_id, _ in programme
        )
        if recipe_engine_needed:
            raise KeyError("programme references a recipe not in the book")

        line = ProductionLine(config=self.config)
        nominal = line.nominal_capacity_kg_per_hour(LIQUOR_STAGE_SEQUENCE)
        horizon_minutes = horizon_hours * 60.0

        from ..ingredients.registry import build_default_registry

        engine = RecipeEngine(build_default_registry())

        # --- current: run the programme in the order given ---------------
        orders = [
            BatchOrder(
                batch_id=f"CUR-{index:03d}",
                recipe=self.recipe_book.get(recipe_id),
                mass_kg=mass,
            )
            for index, (recipe_id, mass) in enumerate(programme)
        ]
        current_result = line.simulate(orders, horizon_minutes)
        current = self._metrics(current_result, nominal).model_copy(
            update={
                "energy_kwh_per_kg": energy_kwh_per_kg,
                "waste_fraction": waste_fraction,
            }
        )

        # --- optimise the sequence ---------------------------------------
        jobs = [
            ScheduleJob(
                job_id=f"J{index:03d}",
                recipe_id=recipe_id,
                chocolate_type=self.recipe_book.get(recipe_id).chocolate_type,
                mass_kg=mass,
                processing_minutes=max(
                    1.0,
                    line.machines[
                        max(
                            line.machines,
                            key=lambda stage: line.machines[
                                stage
                            ].spec.processing_minutes(mass),
                        )
                    ].spec.processing_minutes(mass),
                ),
                allergens=engine.allergens(self.recipe_book.get(recipe_id)),
            )
            for index, (recipe_id, mass) in enumerate(programme)
        ]
        schedule = self.scheduler.optimise(jobs)

        if schedule.feasible:
            index_of = {job.job_id: index for index, job in enumerate(jobs)}
            optimised_programme = [
                programme[index_of[job_id]] for job_id in schedule.sequence
            ]
        else:
            optimised_programme = list(programme)

        # --- optimised: rerun in the optimised order ----------------------
        optimised_line = ProductionLine(config=self.config)
        optimised_orders = [
            BatchOrder(
                batch_id=f"OPT-{index:03d}",
                recipe=self.recipe_book.get(recipe_id),
                mass_kg=mass,
            )
            for index, (recipe_id, mass) in enumerate(optimised_programme)
        ]
        optimised_result = optimised_line.simulate(optimised_orders, horizon_minutes)
        optimised = self._metrics(optimised_result, nominal).model_copy(
            update={
                "energy_kwh_per_kg": (
                    optimised_energy_kwh_per_kg
                    if optimised_energy_kwh_per_kg is not None
                    else energy_kwh_per_kg
                ),
                "waste_fraction": (
                    optimised_waste_fraction
                    if optimised_waste_fraction is not None
                    else waste_fraction
                ),
            }
        )

        levers = (
            OptimisationLever(
                name="Batch sequencing",
                description=(
                    "Campaign like products together and pay each allergen "
                    "changeover once."
                ),
                capacity_gain=optimised.capacity_utilisation
                - current.capacity_utilisation,
                changeover_saving_hours=current.changeover_hours
                - optimised.changeover_hours,
                applied=schedule.feasible,
            ),
        )

        return FactoryOptimisationResult(
            current=current,
            optimised=optimised,
            levers=levers,
            schedule=schedule,
            provenance=ModelProvenance.simulation(
                self.MODEL_NAME,
                basis=(
                    "Discrete-event line simulation run under the current and "
                    "optimised sequences, with the difference measured rather "
                    "than assumed"
                ),
                assumptions=(
                    "The programme content is fixed; only its order changes",
                    "Machine capacities and reliability are unchanged",
                    "Energy and waste figures are supplied by the process model",
                ),
            ),
        )


__all__ = [
    "FactoryMetrics",
    "FactoryOptimisationResult",
    "FactoryOptimiser",
    "OptimisationLever",
]
