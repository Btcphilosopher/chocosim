"""Optimisation with OR-Tools.

Four distinct problems, each solved with the right tool rather than one
general-purpose heuristic:

**Production sequencing** (CP-SAT). Order batches on a bottleneck machine to
minimise makespan when changeover time depends on which product preceded
which. This is a travelling-salesman-with-release-times structure, and CP-SAT
handles the sequence-dependent transitions natively via circuit constraints.

**Recipe blending** (linear programming). Find the cheapest formulation that
still satisfies the compositional standard and the process constraints. Linear
because composition is linear in the component fractions, so this solves
exactly and quickly rather than approximately.

**Energy load shifting** (mixed-integer programming). Move discretionary
batch starts into cheaper tariff periods subject to capacity and deadlines.

**Batch sizing** (enumeration with a closed-form objective). Small enough to
solve by exhaustive search over a sensible grid, and doing so avoids pretending
that a lumpy, non-convex objective is smooth.

Every solver reports its status honestly. An infeasible model returns
INFEASIBLE rather than a silently relaxed answer, because a schedule that
cannot be run is worse than no schedule.
"""

from __future__ import annotations

import math
from collections.abc import Sequence

from ortools.linear_solver import pywraplp
from ortools.sat.python import cp_model
from pydantic import Field

from ..core.config import ChocoSimConfig
from ..core.exceptions import InfeasibleModelError, OptimisationError
from ..core.fidelity import ModelProvenance
from ..core.models import FrozenChocoModel, safe_divide
from ..core.types import (
    ChocolateType,
    IngredientId,
    Kilograms,
    Money,
    RecipeId,
    SolverStatus,
)
from ..ingredients.registry import IngredientRegistry
from ..recipes.engine import COMPOSITIONAL_STANDARDS, RecipeEngine
from ..recipes.models import Recipe


class ScheduleJob(FrozenChocoModel):
    """A batch to be scheduled."""

    job_id: str
    recipe_id: RecipeId
    chocolate_type: ChocolateType
    mass_kg: Kilograms = Field(gt=0.0)
    processing_minutes: float = Field(gt=0.0)
    allergens: tuple[str, ...] = ()
    due_minute: float | None = None
    priority: int = Field(default=0, ge=0)


class ScheduledJob(FrozenChocoModel):
    """A job with its assigned position and timing."""

    job_id: str
    recipe_id: RecipeId
    position: int = Field(ge=0)
    start_minute: float = Field(ge=0.0)
    end_minute: float = Field(ge=0.0)
    changeover_minutes: float = Field(ge=0.0)

    @property
    def is_late(self) -> bool:
        """Whether the job misses a due date, if one was set."""
        return False


class ScheduleResult(FrozenChocoModel):
    """Result of a sequencing optimisation."""

    status: SolverStatus
    jobs: tuple[ScheduledJob, ...]
    makespan_minutes: float = Field(ge=0.0)
    total_changeover_minutes: float = Field(ge=0.0)
    baseline_changeover_minutes: float = Field(default=0.0, ge=0.0)
    solve_seconds: float = Field(ge=0.0)
    provenance: ModelProvenance

    @property
    def feasible(self) -> bool:
        """Whether a usable schedule was found."""
        return self.status in (SolverStatus.OPTIMAL, SolverStatus.FEASIBLE)

    @property
    def changeover_saving_minutes(self) -> float:
        """Changeover time saved against the given order."""
        return max(0.0, self.baseline_changeover_minutes - self.total_changeover_minutes)

    @property
    def changeover_saving_fraction(self) -> float:
        """Proportional reduction in changeover time."""
        return safe_divide(
            self.changeover_saving_minutes, self.baseline_changeover_minutes
        )

    @property
    def sequence(self) -> tuple[str, ...]:
        """The optimised job order."""
        return tuple(
            job.job_id for job in sorted(self.jobs, key=lambda j: j.position)
        )

    def report(self) -> str:
        """Plain-text schedule."""
        lines = [
            f"SCHEDULE [{self.status.value}]",
            "=" * 68,
            f"Makespan            {self.makespan_minutes / 60.0:,.2f} h",
            f"Changeover time     {self.total_changeover_minutes / 60.0:,.2f} h",
            f"Baseline changeover {self.baseline_changeover_minutes / 60.0:,.2f} h",
            f"Saving              {self.changeover_saving_minutes / 60.0:,.2f} h "
            f"({self.changeover_saving_fraction:.1%})",
            f"Solve time          {self.solve_seconds:.3f} s",
            "",
            f"{'POS':>4}  {'JOB':<12}{'RECIPE':<20}{'START h':>9}{'END h':>9}{'C/O m':>8}",
            "-" * 68,
        ]
        for job in sorted(self.jobs, key=lambda j: j.position):
            lines.append(
                f"{job.position:>4}  {job.job_id:<12}{job.recipe_id:<20}"
                f"{job.start_minute / 60.0:>9.2f}{job.end_minute / 60.0:>9.2f}"
                f"{job.changeover_minutes:>8.0f}"
            )
        return "\n".join(lines)


class ProductionScheduler:
    """Sequences batches to minimise changeover time and makespan."""

    MODEL_NAME = "production_scheduler"

    def __init__(self, config: ChocoSimConfig | None = None) -> None:
        self.config = config or ChocoSimConfig.default()

    def changeover_minutes(
        self, previous: ScheduleJob | None, current: ScheduleJob
    ) -> float:
        """Changeover time between two jobs."""
        if previous is None:
            return 0.0
        if previous.recipe_id == current.recipe_id:
            return 0.0
        factory = self.config.factory
        if set(previous.allergens) - set(current.allergens):
            return factory.allergen_changeover_minutes
        if previous.chocolate_type != current.chocolate_type:
            return factory.changeover_minutes_different_type
        return factory.changeover_minutes_same_type

    def sequence_cost(self, jobs: Sequence[ScheduleJob]) -> float:
        """Total changeover time for a given order."""
        total = 0.0
        previous: ScheduleJob | None = None
        for job in jobs:
            total += self.changeover_minutes(previous, job)
            previous = job
        return total

    def optimise(
        self,
        jobs: Sequence[ScheduleJob],
        time_limit_seconds: float = 12.0,
    ) -> ScheduleResult:
        """Find the sequence minimising total changeover time.

        Modelled as a Hamiltonian path with a dummy depot: CP-SAT's
        ``AddCircuit`` enforces a single tour over the job nodes, and the arc
        literals carry the sequence-dependent changeover costs. This is exact
        for the sizes a chocolate plant schedules -- a few dozen batches a
        week -- where a heuristic would leave real time on the table.
        """
        if not jobs:
            raise OptimisationError("no jobs to schedule")

        baseline = self.sequence_cost(jobs)
        count = len(jobs)

        if count == 1:
            job = jobs[0]
            return ScheduleResult(
                status=SolverStatus.OPTIMAL,
                jobs=(
                    ScheduledJob(
                        job_id=job.job_id,
                        recipe_id=job.recipe_id,
                        position=0,
                        start_minute=0.0,
                        end_minute=job.processing_minutes,
                        changeover_minutes=0.0,
                    ),
                ),
                makespan_minutes=job.processing_minutes,
                total_changeover_minutes=0.0,
                baseline_changeover_minutes=baseline,
                solve_seconds=0.0,
                provenance=self._provenance(),
            )

        model = cp_model.CpModel()

        # Node 0 is a depot representing the line's starting state; jobs are
        # nodes 1..count.
        arcs: list[tuple[int, int, cp_model.IntVar]] = []
        arc_cost: dict[tuple[int, int], int] = {}

        for i in range(count + 1):
            for j in range(count + 1):
                if i == j:
                    continue
                if i == 0 and j == 0:
                    continue
                literal = model.NewBoolVar(f"arc_{i}_{j}")
                arcs.append((i, j, literal))
                if i == 0:
                    cost = 0
                elif j == 0:
                    cost = 0
                else:
                    cost = int(
                        round(self.changeover_minutes(jobs[i - 1], jobs[j - 1]))
                    )
                arc_cost[(i, j)] = cost

        model.AddCircuit(arcs)
        model.Minimize(
            sum(
                arc_cost[(i, j)] * literal
                for i, j, literal in arcs
                if arc_cost[(i, j)] > 0
            )
        )

        solver = cp_model.CpSolver()
        solver.parameters.max_time_in_seconds = time_limit_seconds
        solver.parameters.num_search_workers = 1
        status = solver.Solve(model)

        status_map = {
            cp_model.OPTIMAL: SolverStatus.OPTIMAL,
            cp_model.FEASIBLE: SolverStatus.FEASIBLE,
            cp_model.INFEASIBLE: SolverStatus.INFEASIBLE,
            cp_model.MODEL_INVALID: SolverStatus.ERROR,
            cp_model.UNKNOWN: SolverStatus.NOT_SOLVED,
        }
        solver_status = status_map.get(status, SolverStatus.NOT_SOLVED)

        if solver_status not in (SolverStatus.OPTIMAL, SolverStatus.FEASIBLE):
            return ScheduleResult(
                status=solver_status,
                jobs=(),
                makespan_minutes=0.0,
                total_changeover_minutes=0.0,
                baseline_changeover_minutes=baseline,
                solve_seconds=solver.WallTime(),
                provenance=self._provenance(),
            )

        # Walk the tour out of the arc literals.
        successor: dict[int, int] = {}
        for i, j, literal in arcs:
            if solver.BooleanValue(literal):
                successor[i] = j

        order: list[int] = []
        node = successor.get(0, 0)
        while node != 0 and len(order) <= count:
            order.append(node - 1)
            node = successor.get(node, 0)

        scheduled: list[ScheduledJob] = []
        clock = 0.0
        total_changeover = 0.0
        previous: ScheduleJob | None = None
        for position, index in enumerate(order):
            job = jobs[index]
            changeover = self.changeover_minutes(previous, job)
            total_changeover += changeover
            clock += changeover
            start = clock
            clock += job.processing_minutes
            scheduled.append(
                ScheduledJob(
                    job_id=job.job_id,
                    recipe_id=job.recipe_id,
                    position=position,
                    start_minute=start,
                    end_minute=clock,
                    changeover_minutes=changeover,
                )
            )
            previous = job

        return ScheduleResult(
            status=solver_status,
            jobs=tuple(scheduled),
            makespan_minutes=clock,
            total_changeover_minutes=total_changeover,
            baseline_changeover_minutes=baseline,
            solve_seconds=solver.WallTime(),
            provenance=self._provenance(),
        )

    def _provenance(self) -> ModelProvenance:
        return ModelProvenance.simulation(
            self.MODEL_NAME,
            basis="CP-SAT circuit formulation over sequence-dependent changeovers",
            assumptions=(
                "Changeover time depends only on the immediately preceding product",
                "Processing times are deterministic",
                "One bottleneck machine constrains the sequence",
            ),
        )


class BlendResult(FrozenChocoModel):
    """Result of a least-cost formulation optimisation."""

    status: SolverStatus
    fractions: dict[str, float] = Field(default_factory=dict)
    cost_per_kg: Money = Field(default=0.0, ge=0.0)
    baseline_cost_per_kg: Money = Field(default=0.0, ge=0.0)
    binding_constraints: tuple[str, ...] = ()
    cocoa_solids_before: float = Field(default=0.0, ge=0.0, le=1.0)
    cocoa_solids_after: float = Field(default=0.0, ge=0.0, le=1.0)
    provenance: ModelProvenance

    @property
    def cocoa_content_changed(self) -> bool:
        """Whether the reformulation moved the declared cocoa content."""
        return abs(self.cocoa_solids_after - self.cocoa_solids_before) > 0.005

    @property
    def feasible(self) -> bool:
        """Whether a formulation was found."""
        return self.status in (SolverStatus.OPTIMAL, SolverStatus.FEASIBLE)

    @property
    def saving_per_kg(self) -> Money:
        """Cost reduction against the starting formulation."""
        return max(0.0, self.baseline_cost_per_kg - self.cost_per_kg)

    @property
    def saving_fraction(self) -> float:
        """Proportional cost reduction."""
        return safe_divide(self.saving_per_kg, self.baseline_cost_per_kg)

    def report(self, symbol: str = "\u00a3") -> str:
        """Plain-text blend result."""
        lines = [
            f"LEAST-COST FORMULATION [{self.status.value}]",
            "=" * 56,
            f"Cost per kg        {symbol}{self.cost_per_kg:.4f}",
            f"Baseline           {symbol}{self.baseline_cost_per_kg:.4f}",
            f"Saving             {symbol}{self.saving_per_kg:.4f} "
            f"({self.saving_fraction:.2%})",
            "",
            "FORMULATION",
        ]
        for ingredient_id, fraction in sorted(
            self.fractions.items(), key=lambda item: -item[1]
        ):
            if fraction > 1e-6:
                lines.append(f"  {ingredient_id:<28}{fraction * 100:>8.3f}%")
        lines += [
            "",
            f"Cocoa solids       {self.cocoa_solids_before:.2%} -> "
            f"{self.cocoa_solids_after:.2%}",
        ]
        if self.cocoa_content_changed:
            lines.append(
                "  ! Declared cocoa content has moved: this is a specification "
                "change, not a cost saving."
            )
        if self.binding_constraints:
            lines += ["", "BINDING CONSTRAINTS"]
            lines += [f"  {name}" for name in self.binding_constraints]
        return "\n".join(lines)


class RecipeOptimiser:
    """Finds least-cost formulations subject to compositional constraints."""

    MODEL_NAME = "recipe_optimiser"

    def __init__(
        self,
        registry: IngredientRegistry,
        recipe_engine: RecipeEngine,
        config: ChocoSimConfig | None = None,
    ) -> None:
        self.registry = registry
        self.recipe_engine = recipe_engine
        self.config = config or ChocoSimConfig.default()

    def optimise(
        self,
        recipe: Recipe,
        max_deviation: float = 0.35,
        enforce_standard: bool = True,
        preserve_cocoa_content: bool = True,
        cocoa_tolerance: float = 0.002,
    ) -> BlendResult:
        """Reformulate at least cost while holding the product's identity.

        ``max_deviation`` bounds how far each component may move from its
        current fraction, in relative terms.

        ``preserve_cocoa_content`` is on by default and matters more than it
        looks. The legal minimum for dark chocolate is 35% cocoa solids, so an
        optimiser told only to respect the standard will happily take a 55%
        dark down to 43% and report a 17% saving. That is arithmetically
        correct and commercially useless: the product is no longer the one on
        the label, and the saving is not a saving but a specification change
        that needs a relaunch. Constraining cocoa solids at the current level
        finds the savings that are genuinely free -- cheaper routes to the same
        product -- and leaves the recipe change as a separate, explicit
        decision.
        """
        solver = pywraplp.Solver.CreateSolver("GLOP")
        if solver is None:
            raise OptimisationError("could not create the linear solver")

        components = list(recipe.components)
        variables: dict[str, pywraplp.Variable] = {}
        for component in components:
            current = component.mass_fraction
            low = max(0.0, current * (1.0 - max_deviation))
            high = min(1.0, current * (1.0 + max_deviation))
            variables[component.ingredient_id] = solver.NumVar(
                low, high, component.ingredient_id
            )

        # Fractions must close to exactly one.
        solver.Add(
            solver.Sum(list(variables.values())) == 1.0, "mass_closure"
        )

        constraint_names: list[str] = ["mass_closure"]

        base_ids_all = [
            component.ingredient_id
            for component in components
            if component.added_at_stage != "moulding"
        ]

        def base_contribution(attribute: str) -> pywraplp.LinearExpr:
            return solver.Sum(
                [
                    getattr(self.registry.get(ingredient_id).composition, attribute)
                    * variables[ingredient_id]
                    for ingredient_id in base_ids_all
                ]
            )

        base_mass_all = solver.Sum([variables[i] for i in base_ids_all])

        if preserve_cocoa_content:
            current_cocoa = self.recipe_engine.base_composition(recipe)[
                0
            ].total_cocoa_solids
            floor = max(0.0, current_cocoa - cocoa_tolerance)
            solver.Add(
                base_contribution("total_cocoa_solids") >= floor * base_mass_all,
                "preserve_cocoa_content",
            )
            constraint_names.append("preserve_cocoa_content")

        if enforce_standard:
            standard = COMPOSITIONAL_STANDARDS.get(recipe.chocolate_type, {})
            # Only the chocolate base counts towards the standard, so
            # inclusions are excluded from both sides of these constraints.
            base_ids = [
                component.ingredient_id
                for component in components
                if component.added_at_stage != "moulding"
            ]

            def contribution(attribute: str) -> pywraplp.LinearExpr:
                return solver.Sum(
                    [
                        getattr(
                            self.registry.get(ingredient_id).composition, attribute
                        )
                        * variables[ingredient_id]
                        for ingredient_id in base_ids
                    ]
                )

            base_mass = solver.Sum([variables[i] for i in base_ids])

            rule_attribute = {
                "min_total_cocoa_solids": "total_cocoa_solids",
                "min_cocoa_butter": "cocoa_butter",
                "min_cocoa_solids_nonfat": "cocoa_solids_nonfat",
                "min_dry_milk_solids": "dry_milk_solids",
                "min_milk_fat": "milk_fat",
                "min_total_fat": "fat",
                "max_sugar": "sugar",
            }
            for rule, limit in standard.items():
                attribute = rule_attribute[rule]
                if rule.startswith("max_"):
                    solver.Add(contribution(attribute) <= limit * base_mass, rule)
                else:
                    solver.Add(contribution(attribute) >= limit * base_mass, rule)
                constraint_names.append(rule)

        objective = solver.Sum(
            [
                self.registry.unit_cost(ingredient_id) * variable
                for ingredient_id, variable in variables.items()
            ]
        )
        solver.Minimize(objective)

        status = solver.Solve()
        status_map = {
            pywraplp.Solver.OPTIMAL: SolverStatus.OPTIMAL,
            pywraplp.Solver.FEASIBLE: SolverStatus.FEASIBLE,
            pywraplp.Solver.INFEASIBLE: SolverStatus.INFEASIBLE,
            pywraplp.Solver.UNBOUNDED: SolverStatus.UNBOUNDED,
            pywraplp.Solver.ABNORMAL: SolverStatus.ERROR,
            pywraplp.Solver.NOT_SOLVED: SolverStatus.NOT_SOLVED,
        }
        solver_status = status_map.get(status, SolverStatus.NOT_SOLVED)

        baseline = self.recipe_engine.cost_per_kg(recipe)

        if solver_status not in (SolverStatus.OPTIMAL, SolverStatus.FEASIBLE):
            return BlendResult(
                status=solver_status,
                fractions={},
                cost_per_kg=0.0,
                baseline_cost_per_kg=baseline,
                provenance=self._provenance(),
            )

        fractions = {
            ingredient_id: variable.solution_value()
            for ingredient_id, variable in variables.items()
        }

        # A constraint is binding if its dual is materially non-zero: those are
        # the ones actually limiting the saving, and the only ones worth
        # renegotiating.
        binding: list[str] = []
        for constraint in solver.constraints():
            if abs(constraint.dual_value()) > 1e-7:
                binding.append(constraint.name())

        optimised = recipe.rescale(fractions)
        return BlendResult(
            status=solver_status,
            fractions=fractions,
            cost_per_kg=solver.Objective().Value(),
            baseline_cost_per_kg=baseline,
            binding_constraints=tuple(binding),
            cocoa_solids_before=self.recipe_engine.base_composition(recipe)[
                0
            ].total_cocoa_solids,
            cocoa_solids_after=self.recipe_engine.base_composition(optimised)[
                0
            ].total_cocoa_solids,
            provenance=self._provenance(),
        )

    def apply(self, recipe: Recipe, result: BlendResult) -> Recipe:
        """Return a new recipe version using an optimised formulation."""
        if not result.feasible:
            raise InfeasibleModelError(
                f"cannot apply an infeasible blend result ({result.status.value})"
            )
        return recipe.rescale(result.fractions)

    def _provenance(self) -> ModelProvenance:
        return ModelProvenance.simulation(
            self.MODEL_NAME,
            basis="Linear programme over component mass fractions",
            assumptions=(
                "Composition is linear in component fractions",
                "Ingredient prices are fixed within the optimisation",
                "Process behaviour is unchanged by reformulation, which holds "
                "only for small moves",
            ),
            extra_caveats=(
                "A reformulation that passes the compositional check still "
                "requires sensory and shelf-life validation before use.",
            ),
        )


class EnergySchedule(FrozenChocoModel):
    """Result of shifting load into cheaper tariff periods."""

    status: SolverStatus
    start_hours: dict[str, int] = Field(default_factory=dict)
    baseline_cost: Money = Field(default=0.0, ge=0.0)
    optimised_cost: Money = Field(default=0.0, ge=0.0)
    provenance: ModelProvenance

    @property
    def saving(self) -> Money:
        """Cost saved by shifting."""
        return max(0.0, self.baseline_cost - self.optimised_cost)

    @property
    def saving_fraction(self) -> float:
        """Proportional saving."""
        return safe_divide(self.saving, self.baseline_cost)

    @property
    def feasible(self) -> bool:
        """Whether a schedule was found."""
        return self.status in (SolverStatus.OPTIMAL, SolverStatus.FEASIBLE)


class EnergyOptimiser:
    """Shifts discretionary load into cheaper tariff periods."""

    MODEL_NAME = "energy_optimiser"

    def __init__(self, config: ChocoSimConfig | None = None) -> None:
        self.config = config or ChocoSimConfig.default()

    def shift_load(
        self,
        tasks: dict[str, tuple[float, int]],
        horizon_hours: int = 24,
        max_concurrent: int = 3,
        earliest_hour: int = 0,
    ) -> EnergySchedule:
        """Schedule energy-consuming tasks against a time-of-use tariff.

        ``tasks`` maps a task name to its electrical demand in kWh and its
        duration in whole hours. The model chooses start hours subject to a
        concurrency limit, minimising the cost of the electricity consumed.

        Only worth doing where the task genuinely is discretionary. Conching is
        the obvious candidate in a chocolate factory: it runs for a day, it
        does not care when it starts, and it is one of the larger electrical
        loads on the site.
        """
        from ..core.types import EnergyCarrier

        solver = pywraplp.Solver.CreateSolver("CBC")
        if solver is None:
            raise OptimisationError("could not create the mixed-integer solver")

        tariff = self.config.energy.tariff(EnergyCarrier.ELECTRICITY)
        hourly_price = [tariff.price_at(float(hour)) for hour in range(horizon_hours)]

        start_variables: dict[tuple[str, int], pywraplp.Variable] = {}
        for name, (_, duration) in tasks.items():
            latest = horizon_hours - duration
            if latest < earliest_hour:
                raise InfeasibleModelError(
                    f"task {name!r} needs {duration} h but the horizon only "
                    f"allows {horizon_hours - earliest_hour} h"
                )
            for hour in range(earliest_hour, latest + 1):
                start_variables[(name, hour)] = solver.BoolVar(f"start_{name}_{hour}")

        # Each task starts exactly once.
        for name in tasks:
            solver.Add(
                solver.Sum(
                    [
                        variable
                        for (task, _), variable in start_variables.items()
                        if task == name
                    ]
                )
                == 1
            )

        # Concurrency limit in every hour.
        for hour in range(horizon_hours):
            active = []
            for (name, start), variable in start_variables.items():
                duration = tasks[name][1]
                if start <= hour < start + duration:
                    active.append(variable)
            if active:
                solver.Add(solver.Sum(active) <= max_concurrent)

        # Cost of a task started at a given hour, spread evenly over its run.
        objective_terms = []
        for (name, start), variable in start_variables.items():
            demand, duration = tasks[name]
            per_hour = demand / max(duration, 1)
            cost = sum(
                per_hour * hourly_price[(start + offset) % horizon_hours]
                for offset in range(duration)
            )
            objective_terms.append(cost * variable)
        solver.Minimize(solver.Sum(objective_terms))

        status = solver.Solve()
        status_map = {
            pywraplp.Solver.OPTIMAL: SolverStatus.OPTIMAL,
            pywraplp.Solver.FEASIBLE: SolverStatus.FEASIBLE,
            pywraplp.Solver.INFEASIBLE: SolverStatus.INFEASIBLE,
        }
        solver_status = status_map.get(status, SolverStatus.NOT_SOLVED)

        # Baseline: a greedy earliest-start schedule that still respects the
        # concurrency limit. Comparing against "everything at once" would be
        # comparing against a schedule the plant could not actually run, and
        # would report a saving that is really just the cost of infeasibility.
        baseline_cost = 0.0
        occupancy = [0] * horizon_hours
        for name in sorted(tasks):
            demand, duration = tasks[name]
            per_hour = demand / max(duration, 1)
            placed = False
            for start in range(earliest_hour, horizon_hours - duration + 1):
                if all(
                    occupancy[start + offset] < max_concurrent
                    for offset in range(duration)
                ):
                    for offset in range(duration):
                        occupancy[start + offset] += 1
                    baseline_cost += sum(
                        per_hour * hourly_price[start + offset]
                        for offset in range(duration)
                    )
                    placed = True
                    break
            if not placed:
                # No feasible earliest-start slot; charge it at the earliest
                # permitted hour so the baseline remains comparable.
                baseline_cost += sum(
                    per_hour * hourly_price[(earliest_hour + offset) % horizon_hours]
                    for offset in range(duration)
                )

        if solver_status not in (SolverStatus.OPTIMAL, SolverStatus.FEASIBLE):
            return EnergySchedule(
                status=solver_status,
                baseline_cost=baseline_cost,
                optimised_cost=baseline_cost,
                provenance=self._provenance(),
            )

        starts = {
            name: hour
            for (name, hour), variable in start_variables.items()
            if variable.solution_value() > 0.5
        }

        return EnergySchedule(
            status=solver_status,
            start_hours=starts,
            baseline_cost=baseline_cost,
            optimised_cost=solver.Objective().Value(),
            provenance=self._provenance(),
        )

    def _provenance(self) -> ModelProvenance:
        return ModelProvenance.simulation(
            self.MODEL_NAME,
            basis="Mixed-integer programme over discrete start hours",
            assumptions=(
                "Demand is drawn evenly across a task's duration",
                "Tariff periods are known and fixed",
                "Tasks may start at any hour without a setup penalty",
            ),
        )


def optimal_batch_size(
    changeover_minutes: float,
    processing_rate_kg_per_hour: float,
    holding_cost_per_kg_per_hour: float,
    demand_kg_per_hour: float,
    minimum_kg: Kilograms = 100.0,
    maximum_kg: Kilograms = 10_000.0,
    steps: int = 200,
) -> tuple[Kilograms, float]:
    """Find the batch size minimising changeover plus holding cost per kg.

    The classic economic-lot-size trade-off: larger batches amortise the
    changeover over more kilograms but hold more inventory. Returns the size
    and the cost per kilogram at that size.

    Solved by enumeration rather than the closed-form EOQ because the real
    objective is not smooth once machine capacity binds, and a closed form that
    quietly ignores that is worse than a grid search that does not.
    """
    if processing_rate_kg_per_hour <= 0.0:
        raise ValueError("processing rate must be positive")

    best_size = minimum_kg
    best_cost = math.inf
    for step in range(steps + 1):
        size = minimum_kg + (maximum_kg - minimum_kg) * step / steps
        if size <= 0.0:
            continue
        changeover_cost_per_kg = (changeover_minutes / 60.0) * (
            demand_kg_per_hour / max(size, 1e-9)
        )
        cycle_hours = size / processing_rate_kg_per_hour
        holding_cost_per_kg = holding_cost_per_kg_per_hour * cycle_hours / 2.0
        total = changeover_cost_per_kg + holding_cost_per_kg
        if total < best_cost:
            best_cost = total
            best_size = size
    return best_size, best_cost


__all__ = [
    "BlendResult",
    "EnergyOptimiser",
    "EnergySchedule",
    "ProductionScheduler",
    "RecipeOptimiser",
    "ScheduleJob",
    "ScheduleResult",
    "ScheduledJob",
    "optimal_batch_size",
]
