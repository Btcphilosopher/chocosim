"""Packaging: formats, materials and line performance.

Packaging is where a bulk mass becomes a number of sellable units, and where
several costs that are invisible upstream suddenly matter: film, board, case
count, pallet efficiency and give-away.

Give-away deserves a note. A depositor cannot hit a target weight exactly, so
it aims slightly high to keep the proportion of underweight units within the
tolerance the weights and measures regime allows. That deliberate overshoot is
free chocolate the factory gives to the consumer, and at scale it is a
material cost -- a 1.5% give-away on a 100 g bar produced at 20 tonnes a day
is 300 kg of chocolate a day. The model computes it from the target weight,
the filling standard deviation, and the tolerance, which is the same
calculation a packaging engineer would do.
"""

from __future__ import annotations

import math

from pydantic import Field

from ..core.config import ChocoSimConfig
from ..core.models import FrozenChocoModel, clamp, safe_divide
from ..core.types import Kilograms, Money, RecipeId

#: Standard normal quantile helper for the give-away calculation.
_UNDERWEIGHT_Z: dict[float, float] = {
    0.005: 2.5758,
    0.010: 2.3263,
    0.025: 1.9600,
    0.050: 1.6449,
    0.100: 1.2816,
}


def underweight_z(tolerance_fraction: float) -> float:
    """Standard normal quantile for a permitted underweight proportion."""
    if tolerance_fraction in _UNDERWEIGHT_Z:
        return _UNDERWEIGHT_Z[tolerance_fraction]
    levels = sorted(_UNDERWEIGHT_Z)
    if tolerance_fraction <= levels[0]:
        return _UNDERWEIGHT_Z[levels[0]]
    if tolerance_fraction >= levels[-1]:
        return _UNDERWEIGHT_Z[levels[-1]]
    for lower, upper in zip(levels, levels[1:], strict=False):
        if lower <= tolerance_fraction <= upper:
            weight = (tolerance_fraction - lower) / (upper - lower)
            return _UNDERWEIGHT_Z[lower] + weight * (
                _UNDERWEIGHT_Z[upper] - _UNDERWEIGHT_Z[lower]
            )
    return 1.6449


class PackagingFormat(FrozenChocoModel):
    """A finished pack format."""

    format_id: str
    name: str
    unit_mass_g: float = Field(gt=0.0)
    units_per_case: int = Field(default=24, gt=0)
    cases_per_pallet: int = Field(default=80, gt=0)

    primary_cost_per_unit: Money = Field(
        default=0.045, ge=0.0, description="Wrapper or flowpack film."
    )
    secondary_cost_per_case: Money = Field(
        default=0.38, ge=0.0, description="Case board."
    )
    tertiary_cost_per_pallet: Money = Field(
        default=9.50, ge=0.0, description="Pallet, wrap and label."
    )

    line_speed_units_per_minute: float = Field(default=280.0, gt=0.0)
    #: Standard deviation of fill weight as a fraction of target.
    fill_sigma_fraction: float = Field(default=0.011, ge=0.0)
    #: Permitted proportion of packs below the nominal weight.
    underweight_tolerance: float = Field(default=0.025, gt=0.0, lt=0.5)
    changeover_minutes: float = Field(default=18.0, ge=0.0)
    efficiency: float = Field(
        default=0.86,
        gt=0.0,
        le=1.0,
        description="Overall equipment effectiveness of the packing line.",
    )

    @property
    def units_per_pallet(self) -> int:
        """Units on a full pallet."""
        return self.units_per_case * self.cases_per_pallet

    @property
    def target_fill_g(self) -> float:
        """Weight the filler actually aims at.

        Nominal weight plus enough headroom that the proportion of underweight
        packs stays inside the permitted tolerance.
        """
        return self.unit_mass_g * (
            1.0 + underweight_z(self.underweight_tolerance) * self.fill_sigma_fraction
        )

    @property
    def giveaway_fraction(self) -> float:
        """Chocolate given away above nominal weight, as a fraction."""
        return safe_divide(
            self.target_fill_g - self.unit_mass_g, self.unit_mass_g
        )

    @property
    def throughput_kg_per_hour(self) -> float:
        """Effective packing throughput."""
        return (
            self.line_speed_units_per_minute
            * 60.0
            * self.target_fill_g
            / 1000.0
            * self.efficiency
        )

    def material_cost_per_unit(self) -> Money:
        """Total packaging material cost for one unit."""
        case_share = self.secondary_cost_per_case / self.units_per_case
        pallet_share = self.tertiary_cost_per_pallet / self.units_per_pallet
        return self.primary_cost_per_unit + case_share + pallet_share

    def units_from(self, mass_kg: Kilograms) -> int:
        """How many units a mass of chocolate yields, allowing for give-away."""
        if self.target_fill_g <= 0.0:
            return 0
        return int(mass_kg * 1000.0 // self.target_fill_g)


class PackagingRun(FrozenChocoModel):
    """Result of packing a batch."""

    format_id: str
    recipe_id: RecipeId
    input_mass_kg: Kilograms = Field(ge=0.0)
    units_produced: int = Field(ge=0)
    packed_mass_kg: Kilograms = Field(ge=0.0)
    giveaway_kg: Kilograms = Field(ge=0.0)
    remnant_kg: Kilograms = Field(ge=0.0)
    reject_units: int = Field(ge=0)

    cases: int = Field(ge=0)
    pallets: int = Field(ge=0)
    material_cost: Money = Field(ge=0.0)
    duration_minutes: float = Field(ge=0.0)

    @property
    def nominal_mass_kg(self) -> Kilograms:
        """Mass that would have been packed at exactly nominal weight."""
        return max(0.0, self.packed_mass_kg - self.giveaway_kg)

    @property
    def material_cost_per_unit(self) -> Money:
        """Packaging cost per unit produced."""
        return safe_divide(self.material_cost, self.units_produced)

    @property
    def giveaway_fraction(self) -> float:
        """Give-away as a share of packed mass."""
        return safe_divide(self.giveaway_kg, self.packed_mass_kg)

    @property
    def utilisation(self) -> float:
        """Share of input mass that left as saleable packs."""
        return safe_divide(self.packed_mass_kg, self.input_mass_kg)

    def summary(self) -> str:
        """One-line packing summary."""
        return (
            f"{self.units_produced:,} units ({self.cases:,} cases, "
            f"{self.pallets:,} pallets) from {self.input_mass_kg:,.1f} kg; "
            f"give-away {self.giveaway_kg:,.1f} kg ({self.giveaway_fraction:.2%}); "
            f"remnant {self.remnant_kg:,.1f} kg"
        )


class PackagingLine:
    """Models a packing line."""

    def __init__(self, config: ChocoSimConfig | None = None) -> None:
        self.config = config or ChocoSimConfig.default()

    def pack(
        self,
        pack_format: PackagingFormat,
        mass_kg: Kilograms,
        recipe_id: RecipeId,
        reject_rate: float = 0.004,
    ) -> PackagingRun:
        """Pack a mass of chocolate into a format."""
        if mass_kg <= 0.0:
            return PackagingRun(
                format_id=pack_format.format_id,
                recipe_id=recipe_id,
                input_mass_kg=0.0,
                units_produced=0,
                packed_mass_kg=0.0,
                giveaway_kg=0.0,
                remnant_kg=0.0,
                reject_units=0,
                cases=0,
                pallets=0,
                material_cost=0.0,
                duration_minutes=0.0,
            )

        gross_units = pack_format.units_from(mass_kg)
        rejects = int(gross_units * clamp(reject_rate, 0.0, 1.0))
        units = max(0, gross_units - rejects)

        packed_mass = units * pack_format.target_fill_g / 1000.0
        giveaway = units * (pack_format.target_fill_g - pack_format.unit_mass_g) / 1000.0
        # The remnant is what the format cannot absorb: rejected packs plus the
        # tail too small to fill one more unit. It is recoverable as rework,
        # not lost, but it does not leave the factory as product.
        remnant = max(0.0, mass_kg - packed_mass)

        cases = -(-units // pack_format.units_per_case) if units else 0
        pallets = -(-cases // pack_format.cases_per_pallet) if cases else 0

        material_cost = (
            units * pack_format.primary_cost_per_unit
            + cases * pack_format.secondary_cost_per_case
            + pallets * pack_format.tertiary_cost_per_pallet
        )

        duration = safe_divide(
            units, pack_format.line_speed_units_per_minute * pack_format.efficiency
        )

        return PackagingRun(
            format_id=pack_format.format_id,
            recipe_id=recipe_id,
            input_mass_kg=mass_kg,
            units_produced=units,
            packed_mass_kg=packed_mass,
            giveaway_kg=giveaway,
            remnant_kg=remnant,
            reject_units=rejects,
            cases=cases,
            pallets=pallets,
            material_cost=material_cost,
            duration_minutes=duration,
        )

    def giveaway_cost_per_year(
        self,
        pack_format: PackagingFormat,
        annual_units: int,
        product_cost_per_kg: Money,
    ) -> Money:
        """Annual cost of deliberate over-fill.

        Usually the single largest saving available from a filler upgrade, and
        the one most often left unquantified.
        """
        giveaway_kg = (
            annual_units
            * (pack_format.target_fill_g - pack_format.unit_mass_g)
            / 1000.0
        )
        return giveaway_kg * product_cost_per_kg

    def sigma_for_target_giveaway(
        self, pack_format: PackagingFormat, target_giveaway: float
    ) -> float:
        """Filling sigma needed to hit a give-away target.

        Answers "how accurate would the filler have to be", which is the
        question that turns a give-away number into a capital case.
        """
        z = underweight_z(pack_format.underweight_tolerance)
        if z <= 0.0:
            return 0.0
        return target_giveaway / z


def standard_formats() -> tuple[PackagingFormat, ...]:
    """The reference pack formats."""
    return (
        PackagingFormat(
            format_id="PKG-BAR-100",
            name="100 g Bar",
            unit_mass_g=100.0,
            units_per_case=24,
            cases_per_pallet=80,
            primary_cost_per_unit=0.045,
            secondary_cost_per_case=0.38,
            line_speed_units_per_minute=280.0,
            fill_sigma_fraction=0.011,
        ),
        PackagingFormat(
            format_id="PKG-BAR-45",
            name="45 g Countline",
            unit_mass_g=45.0,
            units_per_case=48,
            cases_per_pallet=100,
            primary_cost_per_unit=0.028,
            secondary_cost_per_case=0.34,
            line_speed_units_per_minute=520.0,
            fill_sigma_fraction=0.014,
            efficiency=0.83,
        ),
        PackagingFormat(
            format_id="PKG-BOX-200",
            name="200 g Gift Box",
            unit_mass_g=200.0,
            units_per_case=12,
            cases_per_pallet=64,
            primary_cost_per_unit=0.310,
            secondary_cost_per_case=0.52,
            tertiary_cost_per_pallet=11.00,
            line_speed_units_per_minute=95.0,
            fill_sigma_fraction=0.009,
            changeover_minutes=32.0,
            efficiency=0.78,
        ),
        PackagingFormat(
            format_id="PKG-BULK-5000",
            name="5 kg Callet Bag",
            unit_mass_g=5_000.0,
            units_per_case=4,
            cases_per_pallet=48,
            primary_cost_per_unit=0.72,
            secondary_cost_per_case=0.65,
            line_speed_units_per_minute=9.0,
            fill_sigma_fraction=0.006,
            underweight_tolerance=0.010,
            efficiency=0.90,
        ),
    )


__all__ = [
    "PackagingFormat",
    "PackagingLine",
    "PackagingRun",
    "standard_formats",
    "underweight_z",
]
