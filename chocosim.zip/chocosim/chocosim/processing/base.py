"""Base types for process stages.

Every unit operation in ChocoSim implements :class:`ProcessStage`. A stage
takes a :class:`MaterialStream` in and returns a :class:`StageResult`
containing the stream out, a validated :class:`MassBalance`, the energy
consumed, the elapsed time and whatever stage-specific metrics it computed.

Two invariants are enforced for every stage, in the base class, so that no
individual model can forget them:

1. **Mass is conserved.** Output plus intended loss plus waste equals input.
2. **Streams are ordered.** A stage cannot receive material that has already
   passed a later unit operation.

Both raise rather than warn. A process model that quietly loses mass is worse
than no model at all, because its outputs look plausible.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any, Self

from pydantic import Field, model_validator

from ..core.config import ChocoSimConfig
from ..core.exceptions import ProcessError, StageSequenceError
from ..core.fidelity import ModelProvenance
from ..core.models import Composition, FrozenChocoModel, MassBalance, safe_divide
from ..core.rng import RandomSource
from ..core.types import (
    STAGE_INDEX,
    Celsius,
    Kilograms,
    MaterialState,
    Micrometres,
    Minutes,
    PascalSeconds,
    ProcessStageKind,
)
from ..energy.model import EnergyUse
from ..recipes.models import Recipe


class MaterialStream(FrozenChocoModel):
    """The material passing between unit operations.

    Carries everything a downstream stage needs to know: how much there is,
    what it is made of, how hot it is, how fine it is and how it flows.
    """

    mass_kg: Kilograms = Field(ge=0.0)
    composition: Composition
    temperature_c: Celsius = Field(default=20.0)
    state: MaterialState = Field(default=MaterialState.WHOLE_BEAN)

    #: Volume-based d90 particle size: 90% of the mass lies below this size.
    #: d90 rather than a mean because grittiness is perceived from the coarse
    #: tail, not the average -- a mass with a fine mean and a coarse tail
    #: still eats gritty.
    particle_size_d90_um: Micrometres = Field(default=0.0, ge=0.0)
    particle_size_d50_um: Micrometres = Field(default=0.0, ge=0.0)

    #: Plastic viscosity in the Casson sense, at 40 degC.
    viscosity_pas: PascalSeconds = Field(default=0.0, ge=0.0)
    #: Casson yield value, Pa. Governs whether the mass flows off a depositor.
    yield_value_pa: float = Field(default=0.0, ge=0.0)

    #: Fraction of fat crystallised into the stable beta-V polymorph.
    stable_crystal_fraction: float = Field(default=0.0, ge=0.0, le=1.0)

    #: Cumulative index of thermal and oxidative history, used by the quality
    #: model. Rises with time at temperature; there is no way back down.
    flavour_development: float = Field(default=0.0, ge=0.0)
    thermal_damage: float = Field(default=0.0, ge=0.0)

    @model_validator(mode="after")
    def _check_sizes(self) -> Self:
        if self.particle_size_d50_um > self.particle_size_d90_um + 1e-9:
            raise ValueError(
                f"d50 ({self.particle_size_d50_um:.3f} um) exceeds d90 "
                f"({self.particle_size_d90_um:.3f} um)"
            )
        return self

    def with_mass(self, mass_kg: Kilograms) -> MaterialStream:
        """Return a copy with a different mass."""
        return self.model_copy(update={"mass_kg": mass_kg})

    def evolve(self, **changes: Any) -> MaterialStream:
        """Return a copy with the given fields changed."""
        return self.model_copy(update=changes)

    @property
    def fat_fraction(self) -> float:
        """Total fat as a mass fraction."""
        return self.composition.fat

    @property
    def moisture_fraction(self) -> float:
        """Water as a mass fraction."""
        return self.composition.moisture

    @property
    def solids_mass_kg(self) -> Kilograms:
        """Dry mass of the stream."""
        return self.mass_kg * self.composition.total_solids

    @property
    def water_mass_kg(self) -> Kilograms:
        """Water mass of the stream."""
        return self.mass_kg * self.composition.moisture


class StageResult(FrozenChocoModel):
    """Everything one unit operation produced."""

    stage: ProcessStageKind
    machine_id: str | None = None

    stream_in: MaterialStream
    stream_out: MaterialStream
    mass_balance: MassBalance

    duration_minutes: Minutes = Field(ge=0.0)
    energy: EnergyUse
    provenance: ModelProvenance

    metrics: dict[str, float] = Field(default_factory=dict)
    notes: tuple[str, ...] = ()

    @property
    def throughput_kg_per_hour(self) -> float:
        """Average throughput over the stage duration."""
        return safe_divide(self.stream_out.mass_kg * 60.0, self.duration_minutes)

    @property
    def specific_energy_kwh_per_kg(self) -> float:
        """Energy per kilogram of product leaving the stage."""
        return self.energy.per_kg(self.stream_out.mass_kg)

    @property
    def yield_fraction(self) -> float:
        """Product mass out over mass in."""
        return self.mass_balance.yield_fraction

    def summary(self) -> str:
        """One-line summary of the stage."""
        return (
            f"{self.stage.value:<11} "
            f"{self.stream_in.mass_kg:>9.2f} -> {self.stream_out.mass_kg:>9.2f} kg  "
            f"{self.duration_minutes:>7.1f} min  "
            f"{self.energy.total_kwh:>9.2f} kWh  "
            f"({self.specific_energy_kwh_per_kg:.4f} kWh/kg)"
        )


class ProcessStage(ABC):
    """Base class for a unit operation.

    Subclasses implement :meth:`_run`, which does the physics. The base class
    handles validation, mass-balance enforcement and provenance, so those
    cannot be skipped by a subclass author in a hurry.
    """

    #: The unit operation this stage performs.
    kind: ProcessStageKind
    #: States this stage will accept as input. Empty means any.
    accepts: tuple[MaterialState, ...] = ()

    def __init__(self, config: ChocoSimConfig | None = None) -> None:
        self.config = config or ChocoSimConfig.default()

    # ------------------------------------------------------------------
    # Public interface
    # ------------------------------------------------------------------

    def run(
        self,
        stream: MaterialStream,
        recipe: Recipe,
        source: RandomSource,
        machine_id: str | None = None,
        **kwargs: Any,
    ) -> StageResult:
        """Execute the stage, enforcing the invariants around it."""
        if stream.mass_kg < 0.0:
            raise ProcessError(
                f"{self.kind.value}: negative input mass {stream.mass_kg}"
            )
        if self.accepts and stream.state not in self.accepts:
            raise StageSequenceError(
                f"{self.kind.value} received material in state "
                f"{stream.state.value!r}; it accepts "
                f"{[state.value for state in self.accepts]}"
            )

        result = self._run(stream, recipe, source, machine_id=machine_id, **kwargs)

        # Re-validate the balance the subclass built against the streams it
        # actually returned. A subclass that computes a balance from one set of
        # numbers and a stream from another is caught here rather than three
        # stages downstream.
        balance = MassBalance(
            stage=self.kind.value,
            mass_in=result.stream_in.mass_kg,
            mass_out=result.stream_out.mass_kg,
            mass_loss=result.mass_balance.mass_loss,
            mass_waste=result.mass_balance.mass_waste,
        )
        if balance != result.mass_balance:
            return result.model_copy(update={"mass_balance": balance})
        return result

    @abstractmethod
    def _run(
        self,
        stream: MaterialStream,
        recipe: Recipe,
        source: RandomSource,
        machine_id: str | None = None,
        **kwargs: Any,
    ) -> StageResult:
        """Perform the unit operation. Implemented by each stage."""

    # ------------------------------------------------------------------
    # Helpers for subclasses
    # ------------------------------------------------------------------

    def _draw(self, source: RandomSource, path: str) -> Any:
        """Return the RNG stream for a named quantity within this stage."""
        return source.generator(f"process/{self.kind.value}/{path}")

    def _noise(
        self, source: RandomSource, path: str, sigma: float, clip: float = 3.0
    ) -> float:
        """Draw a multiplicative noise factor around 1.0.

        Returns exactly 1.0 in deterministic mode, so a reference run is free
        of stochastic wobble without every call site needing a branch.
        """
        if self.config.simulation.deterministic or sigma <= 0.0:
            return 1.0
        generator = self._draw(source, path)
        value = float(generator.normal(0.0, sigma))
        return 1.0 + max(-clip * sigma, min(clip * sigma, value))

    def _provenance(
        self, basis: str, assumptions: tuple[str, ...] = ()
    ) -> ModelProvenance:
        """Build the provenance record for this stage."""
        return ModelProvenance.simulation(
            f"process.{self.kind.value}", basis=basis, assumptions=assumptions
        )


__all__ = ["MaterialStream", "ProcessStage", "StageResult"]
