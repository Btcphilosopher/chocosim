"""Conching.

Conching is the longest and least visible operation in the plant, and the one
most often treated as a black box. Four things happen simultaneously, and the
model tracks each on its own kinetics because they finish at different times --
which is precisely why "how long should I conche" has a non-obvious answer.

**Drying.** Refined mass carries 1-2% moisture. Water bridges sugar crystals
and drives the yield value up, so removing it is the single biggest lever on
flow. Modelled as first-order in the moisture above an asymptote, with the
rate scaling on temperature and on shear, since the mass has to be turned over
to expose new surface.

**Acid removal.** Fermentation leaves acetic and other short-chain acids in
the bean. They are volatile and leave with the water vapour, which is why a
dry conche and an acid conche are the same operation. Dark chocolate needs
this; milk chocolate largely does not, which is part of why milk conches are
shorter.

**Flavour development.** Continued Maillard chemistry at conche temperature.
Slower than roasting because it is much cooler, but it runs for a day.

**Emulsifier activation and particle coating.** Lecithin dosed into the mass
does nothing until shear drives it onto particle surfaces. This is modelled as
a saturating function of accumulated shear work, and it feeds straight into
the rheology model's packing fraction.

The important structural point: conching returns *diminishing* returns on all
four, on different timescales. The optimiser can therefore find a genuinely
non-trivial stopping point rather than "run it as long as possible".
"""

from __future__ import annotations

import math
from typing import Any

from pydantic import Field

from ..core.config import ChocoSimConfig
from ..core.models import FrozenChocoModel, MassBalance, clamp
from ..core.rng import RandomSource
from ..core.types import (
    Celsius,
    Kilograms,
    KilowattHours,
    MaterialState,
    Minutes,
    ProcessStageKind,
)
from ..core.units import (
    CP_CHOCOLATE_LIQUID,
    GAS_CONSTANT_R,
    LATENT_HEAT_VAPORISATION_WATER,
    celsius_to_kelvin,
    hours_to_minutes,
)
from ..energy.model import (
    EnergyUse,
    heating_energy,
    latent_heat_kwh,
    mechanical_energy,
    sensible_heat_kwh,
)
from ..recipes.models import Recipe
from .base import MaterialStream, ProcessStage, StageResult
from .rheology import compute_rheology

#: Moisture the mass asymptotes towards in a well-run conche.
CONCHE_EQUILIBRIUM_MOISTURE: float = 0.0035

#: Pre-exponential for conche drying, 1/h. Calibrated so a dark conche at
#: 72 degC is roughly 90% dried after 9 hours, matching plant practice where
#: the dry conche phase occupies the first third of the cycle.
CONCHE_DRYING_PREEXPONENTIAL: float = 3.85e4
#: Activation energy for conche drying, J/mol.
CONCHE_DRYING_ACTIVATION: float = 34_000.0

#: Time constant for acetic acid stripping at reference conditions, hours.
ACID_STRIPPING_TIME_CONSTANT_H: float = 9.0
#: Fraction of volatile acid that cannot be removed however long the conche runs.
ACID_IRREDUCIBLE_FRACTION: float = 0.18

#: Pre-exponential for conche flavour development, 1/h.
CONCHE_FLAVOUR_PREEXPONENTIAL: float = 2.05e7
#: Activation energy for conche flavour development, J/mol.
CONCHE_FLAVOUR_ACTIVATION: float = 62_000.0

#: Shear work at which emulsifier coating is essentially complete, kWh/tonne.
COATING_SATURATION_KWH_PER_TONNE: float = 22.0

#: Specific mechanical power of a conche, kW per tonne of charge.
CONCHE_POWER_KW_PER_TONNE: float = 11.0

#: Heat lost through the conche shell, kW per tonne, at typical temperature.
CONCHE_HEAT_LOSS_KW_PER_TONNE: float = 1.6

#: Mass fraction of volatiles (acids, aldehydes) driven off, dry basis.
CONCHE_VOLATILE_LOSS: float = 0.0022

#: Temperature above which milk solids begin to scorch and the product
#: develops a cooked, caramelised off-note.
MILK_SCORCH_TEMPERATURE_C: Celsius = 65.0


class ConcheOutcome(FrozenChocoModel):
    """Result of a conching cycle."""

    hours: float = Field(ge=0.0)
    temperature_c: Celsius
    shear_intensity: float = Field(gt=0.0, le=1.0)

    initial_moisture: float = Field(ge=0.0, le=1.0)
    final_moisture: float = Field(ge=0.0, le=1.0)
    water_removed_kg: Kilograms = Field(ge=0.0)
    volatiles_removed_kg: Kilograms = Field(ge=0.0)

    acid_remaining_fraction: float = Field(ge=0.0, le=1.0)
    flavour_gain: float = Field(ge=0.0)
    thermal_damage_gain: float = Field(ge=0.0)
    emulsifier_efficiency: float = Field(ge=0.0, le=1.0)
    specific_shear_kwh_per_tonne: float = Field(ge=0.0)

    energy: EnergyUse

    @property
    def acid_removed_fraction(self) -> float:
        """Share of the original volatile acid load that has been driven off."""
        return 1.0 - self.acid_remaining_fraction

    def describe(self) -> str:
        """Plain-text conche summary."""
        return "\n".join(
            [
                f"Conche {self.hours:.1f} h at {self.temperature_c:.0f} C, "
                f"shear {self.shear_intensity:.2f}",
                f"  Moisture      {self.initial_moisture:.3%} -> {self.final_moisture:.3%}",
                f"  Acid removed  {self.acid_removed_fraction:.1%}",
                f"  Coating       {self.emulsifier_efficiency:.1%} complete",
                f"  Flavour gain  {self.flavour_gain:.3f}",
                f"  Energy        {self.energy.total_kwh:,.1f} kWh",
            ]
        )


class ConchingModel(ProcessStage):
    """Simulates conching."""

    kind = ProcessStageKind.CONCHING
    accepts = (MaterialState.REFINED_POWDER, MaterialState.PASTE)

    def drying_rate(self, temperature_c: Celsius, shear_intensity: float) -> float:
        """First-order drying rate constant, 1/h.

        Shear enters sub-linearly: turning the mass over faster exposes new
        surface, but the limit is vapour transport away from the surface, not
        surface availability, so doubling the shear does not double the rate.
        """
        arrhenius = CONCHE_DRYING_PREEXPONENTIAL * math.exp(
            -CONCHE_DRYING_ACTIVATION / (GAS_CONSTANT_R * celsius_to_kelvin(temperature_c))
        )
        return arrhenius * (0.45 + 0.55 * math.sqrt(clamp(shear_intensity, 0.0, 1.0)))

    def conche(
        self,
        mass_kg: Kilograms,
        initial_moisture: float,
        hours: float,
        temperature_c: Celsius,
        shear_intensity: float,
        is_milk: bool,
        source: RandomSource | None = None,
    ) -> ConcheOutcome:
        """Run a conching cycle and report what it achieved."""
        source = source or RandomSource(self.config.simulation.seed)

        # --- drying ---
        rate = self.drying_rate(temperature_c, shear_intensity)
        driving = max(0.0, initial_moisture - CONCHE_EQUILIBRIUM_MOISTURE)
        final_moisture = CONCHE_EQUILIBRIUM_MOISTURE + driving * math.exp(-rate * hours)
        final_moisture *= self._noise(source, "moisture", 0.05)
        final_moisture = clamp(final_moisture, 0.0, initial_moisture)

        # --- acid stripping ---
        # Shares the vapour-transport mechanism with drying, so it scales the
        # same way, but with its own time constant.
        acid_rate = (
            (1.0 / ACID_STRIPPING_TIME_CONSTANT_H)
            * (0.5 + 0.5 * shear_intensity)
            * math.exp((temperature_c - 60.0) / 28.0)
        )
        acid_remaining = ACID_IRREDUCIBLE_FRACTION + (
            1.0 - ACID_IRREDUCIBLE_FRACTION
        ) * math.exp(-acid_rate * hours)

        # --- flavour and damage ---
        flavour_rate = CONCHE_FLAVOUR_PREEXPONENTIAL * math.exp(
            -CONCHE_FLAVOUR_ACTIVATION
            / (GAS_CONSTANT_R * celsius_to_kelvin(temperature_c))
        )
        flavour_gain = flavour_rate * hours * self._noise(source, "flavour", 0.04)

        damage_gain = 0.0
        if is_milk and temperature_c > MILK_SCORCH_TEMPERATURE_C:
            # Milk solids scorch: the penalty is superlinear in the overshoot.
            overshoot = temperature_c - MILK_SCORCH_TEMPERATURE_C
            damage_gain = 0.004 * (overshoot**1.6) * hours / 12.0

        # --- shear work and emulsifier coating ---
        specific_shear = CONCHE_POWER_KW_PER_TONNE * shear_intensity * hours
        emulsifier_efficiency = 1.0 - math.exp(
            -specific_shear / COATING_SATURATION_KWH_PER_TONNE
        )

        # --- mass changes ---
        water_removed = mass_kg * (initial_moisture - final_moisture)
        volatiles = (
            mass_kg
            * (1.0 - initial_moisture)
            * CONCHE_VOLATILE_LOSS
            * (1.0 - acid_remaining)
        )

        # --- energy ---
        shaft_kwh = specific_shear * (mass_kg / 1000.0)
        energy = mechanical_energy(shaft_kwh, self.config.energy)

        # Shear work heats the mass; the conche needs net heating only if the
        # jacket has to make up the difference against shell losses and the
        # latent load of evaporation.
        shear_heat_kwh = shaft_kwh * 0.95
        shell_loss_kwh = CONCHE_HEAT_LOSS_KW_PER_TONNE * (mass_kg / 1000.0) * hours
        latent_kwh = latent_heat_kwh(water_removed, LATENT_HEAT_VAPORISATION_WATER)
        heat_deficit = shell_loss_kwh + latent_kwh - shear_heat_kwh

        if heat_deficit > 0.0:
            energy = energy + heating_energy(heat_deficit, self.config.energy)
        # A surplus is dumped through the jacket; on a long conche this is a
        # real refrigeration load, not a rounding error.
        elif heat_deficit < 0.0:
            from ..energy.model import cooling_energy

            energy = energy + cooling_energy(-heat_deficit, self.config.energy)

        return ConcheOutcome(
            hours=hours,
            temperature_c=temperature_c,
            shear_intensity=shear_intensity,
            initial_moisture=initial_moisture,
            final_moisture=final_moisture,
            water_removed_kg=water_removed,
            volatiles_removed_kg=volatiles,
            acid_remaining_fraction=clamp(acid_remaining, 0.0, 1.0),
            flavour_gain=flavour_gain,
            thermal_damage_gain=damage_gain,
            emulsifier_efficiency=clamp(emulsifier_efficiency, 0.0, 1.0),
            specific_shear_kwh_per_tonne=specific_shear,
            energy=energy,
        )

    def _run(
        self,
        stream: MaterialStream,
        recipe: Recipe,
        source: RandomSource,
        machine_id: str | None = None,
        **kwargs: Any,
    ) -> StageResult:
        hours = float(kwargs.get("hours", recipe.process.conche_hours))
        temperature = float(
            kwargs.get("temperature_c", recipe.process.conche_temperature_c)
        )
        shear = float(
            kwargs.get("shear_intensity", recipe.process.conche_shear_intensity)
        )
        lecithin_fraction = float(kwargs.get("lecithin_fraction", 0.0))
        is_milk = recipe.chocolate_type.value in ("milk", "white")

        outcome = self.conche(
            stream.mass_kg,
            stream.composition.moisture,
            hours,
            temperature,
            shear,
            is_milk,
            source,
        )

        removed_fraction = (
            outcome.water_removed_kg / stream.mass_kg if stream.mass_kg > 0 else 0.0
        )
        composition = stream.composition.after_moisture_loss(removed_fraction)

        output_mass = (
            stream.mass_kg - outcome.water_removed_kg - outcome.volatiles_removed_kg
        )

        rheology = compute_rheology(
            composition,
            max(stream.particle_size_d50_um, 1.0),
            span=1.75,
            temperature_c=temperature,
            lecithin_fraction=lecithin_fraction,
            emulsifier_efficiency=outcome.emulsifier_efficiency,
        )
        # Specifications are written against a 40 degC measurement, because
        # that is the temperature the standard viscometry method uses. The
        # value at conche temperature is a different number entirely -- at
        # 72 degC a dark mass reads several times thinner -- so both are
        # recorded and the quality engine compares against the right one.
        milk_fat_share = (
            composition.milk_fat / composition.fat if composition.fat > 0.0 else 0.0
        )
        reference_rheology = rheology.at_temperature(40.0, milk_fat_share)

        stream_out = stream.evolve(
            mass_kg=output_mass,
            composition=composition,
            state=MaterialState.CONCHED_MASS,
            temperature_c=temperature,
            viscosity_pas=rheology.plastic_viscosity_pas,
            yield_value_pa=rheology.yield_value_pa,
            flavour_development=stream.flavour_development + outcome.flavour_gain,
            thermal_damage=stream.thermal_damage + outcome.thermal_damage_gain,
        )

        notes: list[str] = []
        if outcome.final_moisture > 0.010:
            notes.append(
                f"Residual moisture {outcome.final_moisture:.2%} is above 1%; the "
                "mass will be difficult to temper and mould."
            )
        if is_milk and temperature > MILK_SCORCH_TEMPERATURE_C:
            notes.append(
                f"Conching milk chocolate at {temperature:.0f} C exceeds the "
                f"{MILK_SCORCH_TEMPERATURE_C:.0f} C scorch threshold; expect "
                "cooked notes."
            )
        if outcome.emulsifier_efficiency < 0.75 and lecithin_fraction > 0.0:
            notes.append(
                f"Emulsifier only {outcome.emulsifier_efficiency:.0%} activated; "
                "the lecithin is not earning its keep at this shear and duration."
            )
        if not rheology.is_workable:
            notes.append("Conched mass is too viscous to mould; add fat.")

        return StageResult(
            stage=self.kind,
            machine_id=machine_id,
            stream_in=stream,
            stream_out=stream_out,
            mass_balance=MassBalance(
                stage=self.kind.value,
                mass_in=stream.mass_kg,
                mass_out=output_mass,
                mass_loss=outcome.water_removed_kg + outcome.volatiles_removed_kg,
                mass_waste=0.0,
            ),
            duration_minutes=hours_to_minutes(hours),
            energy=outcome.energy,
            provenance=self._provenance(
                basis=(
                    "First-order drying and acid stripping with Arrhenius rates, "
                    "saturating emulsifier activation on accumulated shear work"
                ),
                assumptions=(
                    "Vapour transport limits both drying and acid removal",
                    "Emulsifier activation depends on shear work, not elapsed time",
                    f"Irreducible acid fraction is {ACID_IRREDUCIBLE_FRACTION:.0%}",
                ),
            ),
            metrics={
                "final_moisture": outcome.final_moisture,
                "water_removed_kg": outcome.water_removed_kg,
                "acid_remaining_fraction": outcome.acid_remaining_fraction,
                "acid_removed_fraction": outcome.acid_removed_fraction,
                "emulsifier_efficiency": outcome.emulsifier_efficiency,
                "flavour_gain": outcome.flavour_gain,
                "thermal_damage_gain": outcome.thermal_damage_gain,
                "specific_shear_kwh_per_tonne": outcome.specific_shear_kwh_per_tonne,
                "viscosity_pas": reference_rheology.plastic_viscosity_pas,
                "viscosity_at_process_temp_pas": rheology.plastic_viscosity_pas,
                "process_temperature_c": temperature,
                "yield_value_pa": rheology.yield_value_pa,
                "conche_hours": hours,
            },
            notes=tuple(notes),
        )

    def marginal_benefit_curve(
        self,
        recipe: Recipe,
        initial_moisture: float = 0.014,
        max_hours: float = 48.0,
        step_hours: float = 2.0,
    ) -> list[dict[str, float]]:
        """Tabulate what each additional block of conching time buys.

        The point of the exercise: moisture and acid removal saturate within
        the first half of a typical conche, while energy cost keeps climbing
        linearly. Somewhere on this curve is the economically right answer, and
        it is usually well before the traditional 72 hours.
        """
        is_milk = recipe.chocolate_type.value in ("milk", "white")
        rows: list[dict[str, float]] = []
        previous_quality = 0.0
        hours = step_hours
        while hours <= max_hours + 1e-9:
            outcome = self.conche(
                1_000.0,
                initial_moisture,
                hours,
                recipe.process.conche_temperature_c,
                recipe.process.conche_shear_intensity,
                is_milk,
            )
            # A crude composite of the things conching is for.
            quality = (
                0.45 * (1.0 - outcome.final_moisture / max(initial_moisture, 1e-9))
                + 0.35 * outcome.acid_removed_fraction
                + 0.20 * outcome.emulsifier_efficiency
            )
            rows.append(
                {
                    "hours": hours,
                    "final_moisture": outcome.final_moisture,
                    "acid_removed": outcome.acid_removed_fraction,
                    "emulsifier_efficiency": outcome.emulsifier_efficiency,
                    "energy_kwh_per_tonne": outcome.energy.total_kwh,
                    "quality_index": quality,
                    "marginal_quality_per_hour": (quality - previous_quality)
                    / step_hours,
                }
            )
            previous_quality = quality
            hours += step_hours
        return rows


__all__ = [
    "ACID_IRREDUCIBLE_FRACTION",
    "CONCHE_EQUILIBRIUM_MOISTURE",
    "MILK_SCORCH_TEMPERATURE_C",
    "ConcheOutcome",
    "ConchingModel",
]
