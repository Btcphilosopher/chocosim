"""Winnowing and grinding.

**Winnowing** cracks the roasted bean and separates shell from nib. The shell
is about 12% of bean mass and is a genuine yield loss, not waste in the
disposal sense -- it is normally sold on as fuel or animal feed. Some nib
inevitably leaves with the shell, and pushing the separator harder to recover
it drags shell into the nib, which shows up later as grittiness and, at the
regulatory level, as a shell-content limit. That trade-off is modelled.

**Grinding** turns nib into liquor. Cocoa nib is roughly 54% fat, and grinding
ruptures the cell walls holding it, so the mass liquefies as it is ground --
the "liquor" is not dissolved in anything, it is fat released from the cells.

Comminution energy uses the Hukki generalisation of the classical laws:

    E = K * (d_out ** -n - d_in ** -n)

Rittinger (``n = 1``) over-predicts badly at chocolate fineness, Kick
(``n -> 0``) under-predicts, and Bond's ``n = 0.5`` sits between them and fits
the fine-grinding regime the confectionery industry actually works in.
"""

from __future__ import annotations

from typing import Any

from pydantic import Field

from ..core.config import ChocoSimConfig
from ..core.models import FrozenChocoModel, MassBalance
from ..core.rng import RandomSource
from ..core.types import (
    Kilograms,
    KilowattHours,
    MaterialState,
    Micrometres,
    Minutes,
    ProcessStageKind,
)
from ..core.units import COCOA_SHELL_FRACTION, CP_CHOCOLATE_LIQUID, minutes_to_hours
from ..energy.model import EnergyUse, cooling_energy, mechanical_energy, sensible_heat_kwh
from ..recipes.models import Recipe
from .base import MaterialStream, ProcessStage, StageResult
from .rheology import compute_rheology

#: Hukki exponent for fine comminution.
HUKKI_EXPONENT: float = 0.5

#: Comminution constant for nib grinding, kWh.um^0.5 per tonne.
GRINDING_CONSTANT: float = 600.0

#: Comminution constant for chocolate mass refining, kWh.um^0.5 per tonne.
#: Lower than grinding because a refined mass is already fluid and the rolls
#: work in shear rather than impact.
REFINING_CONSTANT: float = 405.0

#: Fraction of comminution work that appears as heat in the product.
FRICTIONAL_HEATING_FRACTION: float = 0.82

#: Nib carried out with the shell at nominal separator settings.
NIB_IN_SHELL_LOSS: float = 0.018

#: Shell remaining in the nib at nominal separator settings.
SHELL_IN_NIB_CARRYOVER: float = 0.011

#: Winnower throughput, kg per hour per unit of nominal capacity.
WINNOWER_SPECIFIC_POWER_KWH_PER_TONNE: float = 8.5


def comminution_energy_kwh_per_tonne(
    d_in_um: Micrometres,
    d_out_um: Micrometres,
    constant: float,
    exponent: float = HUKKI_EXPONENT,
) -> KilowattHours:
    """Specific comminution energy to reduce particle size.

    Returns zero when the material is already at or below the target: grinding
    does not run backwards, and a negative energy would be silently absurd.
    """
    if d_out_um <= 0.0 or d_in_um <= 0.0 or d_out_um >= d_in_um:
        return 0.0
    return constant * (d_out_um ** (-exponent) - d_in_um ** (-exponent))


class WinnowingModel(ProcessStage):
    """Separates shell from roasted nib."""

    kind = ProcessStageKind.WINNOWING
    accepts = (MaterialState.ROASTED_BEAN,)

    def __init__(
        self,
        config: ChocoSimConfig | None = None,
        separator_aggression: float = 1.0,
    ) -> None:
        super().__init__(config)
        #: Above 1.0 the separator recovers more nib but lets more shell
        #: through; below 1.0 it runs clean at the cost of yield.
        self.separator_aggression = separator_aggression

    def _run(
        self,
        stream: MaterialStream,
        recipe: Recipe,
        source: RandomSource,
        machine_id: str | None = None,
        **kwargs: Any,
    ) -> StageResult:
        aggression = float(kwargs.get("separator_aggression", self.separator_aggression))

        shell_fraction = COCOA_SHELL_FRACTION
        # Aggression trades one impurity against the other, in opposite
        # directions. This is the separator's actual operating curve.
        nib_lost = NIB_IN_SHELL_LOSS / max(aggression, 0.2)
        shell_carryover = SHELL_IN_NIB_CARRYOVER * aggression

        nib_lost *= self._noise(source, "nib_loss", 0.10)
        shell_carryover *= self._noise(source, "shell_carryover", 0.12)

        nib_mass_available = stream.mass_kg * (1.0 - shell_fraction)
        shell_mass = stream.mass_kg * shell_fraction

        nib_out = nib_mass_available * (1.0 - nib_lost)
        shell_retained = shell_mass * shell_carryover
        output_mass = nib_out + shell_retained
        removed = stream.mass_kg - output_mass

        # Composition: shell is low fat and high fibre relative to nib, so
        # removing it concentrates fat in what remains.
        composition = stream.composition
        nib_scale = 1.0 / (1.0 - shell_fraction) if shell_fraction < 1.0 else 1.0
        concentrated = composition.model_copy(
            update={
                "fat": min(1.0, composition.fat * nib_scale * 0.94),
                "cocoa_solids_nonfat": min(
                    1.0, composition.cocoa_solids_nonfat * nib_scale * 0.86
                ),
            }
        )

        hours = minutes_to_hours(self._duration(stream.mass_kg))
        shaft_kwh = WINNOWER_SPECIFIC_POWER_KWH_PER_TONNE * (stream.mass_kg / 1000.0)
        energy = mechanical_energy(shaft_kwh, self.config.energy)

        stream_out = stream.evolve(
            mass_kg=output_mass,
            composition=concentrated,
            state=MaterialState.NIB,
            particle_size_d90_um=3_000.0,
            particle_size_d50_um=1_800.0,
            temperature_c=max(
                self.config.factory.ambient_temperature_c, stream.temperature_c - 35.0
            ),
        )

        balance = MassBalance(
            stage=self.kind.value,
            mass_in=stream.mass_kg,
            mass_out=output_mass,
            mass_loss=shell_mass - shell_retained,
            mass_waste=nib_mass_available * nib_lost,
        )

        notes: list[str] = []
        residual_shell = shell_retained / output_mass if output_mass > 0 else 0.0
        if residual_shell > 0.016:
            notes.append(
                f"Residual shell {residual_shell:.2%} of nib is high; expect "
                "grittiness and check against the applicable shell-content limit."
            )

        return StageResult(
            stage=self.kind,
            machine_id=machine_id,
            stream_in=stream,
            stream_out=stream_out,
            mass_balance=balance,
            duration_minutes=self._duration(stream.mass_kg),
            energy=energy,
            provenance=self._provenance(
                basis="Fixed shell fraction with a separator efficiency trade-off curve",
                assumptions=(
                    f"Shell is {COCOA_SHELL_FRACTION:.0%} of roasted bean mass",
                    "Nib recovery and shell carryover move in opposite directions "
                    "with separator aggression",
                ),
            ),
            metrics={
                "shell_removed_kg": shell_mass - shell_retained,
                "nib_lost_kg": nib_mass_available * nib_lost,
                "residual_shell_fraction": residual_shell,
                "separator_aggression": aggression,
            },
            notes=tuple(notes),
        )

    @staticmethod
    def _duration(mass_kg: Kilograms) -> Minutes:
        """Winnowing time for a charge, at 2,500 kg/h nominal."""
        return max(2.0, mass_kg / 2_500.0 * 60.0)


class GrindingModel(ProcessStage):
    """Grinds nib into cocoa liquor."""

    kind = ProcessStageKind.GRINDING
    accepts = (MaterialState.NIB,)

    #: Particle size leaving a liquor mill, micrometres (d90).
    TARGET_D90_UM: Micrometres = 100.0
    #: Nominal mill throughput, kg/h.
    THROUGHPUT_KG_PER_HOUR: float = 1_800.0
    #: Temperature above which cocoa liquor begins to scorch.
    SCORCH_TEMPERATURE_C: float = 85.0

    def _run(
        self,
        stream: MaterialStream,
        recipe: Recipe,
        source: RandomSource,
        machine_id: str | None = None,
        **kwargs: Any,
    ) -> StageResult:
        target_d90 = float(kwargs.get("target_d90_um", self.TARGET_D90_UM))
        d_in = max(stream.particle_size_d90_um, target_d90 * 1.01)

        specific_kwh = comminution_energy_kwh_per_tonne(
            d_in, target_d90, GRINDING_CONSTANT
        )
        specific_kwh *= self._noise(source, "energy", 0.06)
        shaft_kwh = specific_kwh * (stream.mass_kg / 1000.0)
        energy = mechanical_energy(shaft_kwh, self.config.energy)

        # Frictional heating. A liquor mill needs no external heat at all --
        # the grinding work alone melts the fat and then some, which is why
        # mills are jacketed for cooling rather than heating.
        heat_kwh = shaft_kwh * FRICTIONAL_HEATING_FRACTION
        delta_t = (
            (heat_kwh * 3600.0) / (stream.mass_kg * CP_CHOCOLATE_LIQUID)
            if stream.mass_kg > 0.0
            else 0.0
        )
        uncontrolled_temperature = stream.temperature_c + delta_t

        # Jacket cooling holds the mass below the scorch point.
        target_temperature = min(uncontrolled_temperature, 60.0)
        cooling_duty = 0.0
        if uncontrolled_temperature > target_temperature:
            cooling_duty = sensible_heat_kwh(
                stream.mass_kg,
                CP_CHOCOLATE_LIQUID,
                uncontrolled_temperature - target_temperature,
            )
            energy = energy + cooling_energy(cooling_duty, self.config.energy)

        waste_fraction = 0.0035 * self._noise(source, "waste", 0.15)
        output_mass = stream.mass_kg * (1.0 - waste_fraction)

        d50 = target_d90 * 0.42
        composition = stream.composition
        rheology = compute_rheology(
            composition, d50, span=2.1, temperature_c=target_temperature
        )

        stream_out = stream.evolve(
            mass_kg=output_mass,
            state=MaterialState.LIQUOR,
            temperature_c=target_temperature,
            particle_size_d90_um=target_d90,
            particle_size_d50_um=d50,
            viscosity_pas=rheology.plastic_viscosity_pas,
            yield_value_pa=rheology.yield_value_pa,
        )

        balance = MassBalance(
            stage=self.kind.value,
            mass_in=stream.mass_kg,
            mass_out=output_mass,
            mass_loss=0.0,
            mass_waste=stream.mass_kg * waste_fraction,
        )

        duration = max(3.0, stream.mass_kg / self.THROUGHPUT_KG_PER_HOUR * 60.0)

        notes: list[str] = []
        if uncontrolled_temperature > self.SCORCH_TEMPERATURE_C:
            notes.append(
                f"Uncooled grinding would reach {uncontrolled_temperature:.0f} C, "
                f"above the {self.SCORCH_TEMPERATURE_C:.0f} C scorch point; "
                f"{cooling_duty:.1f} kWh of jacket cooling applied."
            )

        return StageResult(
            stage=self.kind,
            machine_id=machine_id,
            stream_in=stream,
            stream_out=stream_out,
            mass_balance=balance,
            duration_minutes=duration,
            energy=energy,
            provenance=self._provenance(
                basis=(
                    f"Hukki comminution law with exponent {HUKKI_EXPONENT} and "
                    "frictional heat balance on the mill jacket"
                ),
                assumptions=(
                    f"{FRICTIONAL_HEATING_FRACTION:.0%} of shaft work appears as "
                    "heat in the product",
                    "Cell rupture releases fat fast enough that the mass is fluid "
                    "throughout grinding",
                ),
            ),
            metrics={
                "specific_energy_kwh_per_tonne": specific_kwh,
                "frictional_heating_c": delta_t,
                "uncontrolled_temperature_c": uncontrolled_temperature,
                "cooling_duty_kwh": cooling_duty,
                "d90_um": target_d90,
                "d50_um": d50,
                "viscosity_pas": rheology.plastic_viscosity_pas,
            },
            notes=tuple(notes),
        )


__all__ = [
    "FRICTIONAL_HEATING_FRACTION",
    "GRINDING_CONSTANT",
    "HUKKI_EXPONENT",
    "REFINING_CONSTANT",
    "GrindingModel",
    "WinnowingModel",
    "comminution_energy_kwh_per_tonne",
]
