"""Moulding, depositing and cooling.

Depositing is where rheology becomes visible. A mass with too high a yield
value will not level in the mould and leaves ragged edges and trapped air; too
low and it runs before it sets. The cooling tunnel then has to remove both the
sensible heat and the latent heat of crystallisation, on a schedule slow
enough that the Form V seeds template the bulk crystallisation rather than
being outrun by fresh nucleation at the surface.

Cooling too fast is the classic mistake: the surface quenches into unstable
forms regardless of how well the mass was tempered, and the bar comes out dull
and sticks in the mould. Cooling too slowly wastes tunnel length and lets
Form VI grow. The model penalises both.
"""

from __future__ import annotations

import math
from typing import Any

from pydantic import Field

from ..core.models import FrozenChocoModel, MassBalance, clamp
from ..core.rng import RandomSource
from ..core.types import (
    Celsius,
    DefectKind,
    Kilograms,
    MaterialState,
    Minutes,
    ProcessStageKind,
)
from ..core.units import CP_CHOCOLATE_LIQUID
from ..energy.model import (
    EnergyUse,
    cooling_energy,
    mechanical_energy,
    sensible_heat_kwh,
)
from ..recipes.models import Recipe
from ..tempering.crystals import ENTHALPY_OF_FUSION, CrystalForm
from .base import MaterialStream, ProcessStage, StageResult

#: Yield value above which the mass will not level cleanly in a mould, Pa.
DEPOSIT_YIELD_LIMIT_PA: float = 12.0

#: Plastic viscosity above which depositor accuracy degrades, Pa.s.
DEPOSIT_VISCOSITY_LIMIT_PAS: float = 6.0

#: Mould release requires contraction, which requires stable crystal.
MINIMUM_RELEASE_CRYSTAL_FRACTION: float = 0.012

#: Cooling rate above which the surface quenches into unstable forms, C/min.
QUENCH_RATE_LIMIT_C_PER_MIN: float = 2.6

#: Cooling rate below which the tunnel is simply wasting length, C/min.
SLOW_COOLING_THRESHOLD_C_PER_MIN: float = 0.45

#: Specific power of a depositor and mould handling line, kW per tonne/h.
DEPOSITOR_POWER_KW_PER_TONNE_HOUR: float = 4.4

#: Fan and conveyor power of a cooling tunnel, kW per tonne/h.
TUNNEL_FAN_POWER_KW_PER_TONNE_HOUR: float = 7.8

#: Fraction of tunnel cooling duty lost to the ambient through the enclosure.
TUNNEL_HEAT_INGRESS: float = 0.22


class MouldingModel(ProcessStage):
    """Deposits tempered mass into moulds."""

    kind = ProcessStageKind.MOULDING
    accepts = (MaterialState.TEMPERED_MASS,)

    #: Nominal depositor throughput, kg/h.
    THROUGHPUT_KG_PER_HOUR: float = 1_600.0

    def _run(
        self,
        stream: MaterialStream,
        recipe: Recipe,
        source: RandomSource,
        machine_id: str | None = None,
        **kwargs: Any,
    ) -> StageResult:
        mould_temperature = float(
            kwargs.get("mould_temperature_c", recipe.process.mould_temperature_c)
        )
        # Inclusions are merged into the stream by the caller before the stage
        # runs, so that the mass entering the stage is the mass the balance
        # validates against. This parameter is metadata only: it records how
        # much of the incoming mass carries no crystal structure.
        inclusion_mass = float(kwargs.get("inclusion_mass_kg", 0.0))

        # Depositing accuracy depends on how the mass behaves *at the
        # depositor*, which is 15-40 degrees cooler than the conche it came
        # from. Carrying the conche-temperature viscosity forward would
        # understate the stiffness by a factor of several and make the
        # depositor look far more tolerant than it is.
        from .rheology import compute_rheology

        milk_fat_share = (
            stream.composition.milk_fat / stream.composition.fat
            if stream.composition.fat > 0.0
            else 0.0
        )
        deposit_rheology = compute_rheology(
            stream.composition,
            max(stream.particle_size_d50_um, 1.0),
            span=1.75,
            temperature_c=mould_temperature,
        )
        deposit_viscosity = deposit_rheology.plastic_viscosity_pas
        deposit_yield = deposit_rheology.yield_value_pa

        yield_excess = max(
            0.0, deposit_yield - DEPOSIT_YIELD_LIMIT_PA
        ) / DEPOSIT_YIELD_LIMIT_PA
        viscosity_excess = max(
            0.0, deposit_viscosity - DEPOSIT_VISCOSITY_LIMIT_PAS
        ) / DEPOSIT_VISCOSITY_LIMIT_PAS

        base_waste = 0.004
        waste_fraction = base_waste * (1.0 + 3.2 * yield_excess + 2.1 * viscosity_excess)
        waste_fraction = clamp(
            waste_fraction * self._noise(source, "waste", 0.15), 0.0, 0.25
        )

        input_mass = stream.mass_kg
        output_mass = input_mass * (1.0 - waste_fraction)

        composition = stream.composition
        crystal_fraction = stream.stable_crystal_fraction

        duration = max(3.0, input_mass / self.THROUGHPUT_KG_PER_HOUR * 60.0)
        hours = duration / 60.0

        shaft_kwh = DEPOSITOR_POWER_KW_PER_TONNE_HOUR * (input_mass / 1000.0)
        energy = mechanical_energy(shaft_kwh, self.config.energy)

        # Moulds are pre-warmed to the deposit temperature so the mass does not
        # chill on contact and set in unstable forms at the interface.
        mould_mass = input_mass * 1.8
        if mould_temperature > self.config.factory.ambient_temperature_c:
            duty = sensible_heat_kwh(
                mould_mass,
                0.90,
                mould_temperature - self.config.factory.ambient_temperature_c,
            )
            from ..energy.model import heating_energy

            energy = energy + heating_energy(duty * 0.35, self.config.energy)

        stream_out = stream.evolve(
            mass_kg=output_mass,
            composition=composition,
            state=MaterialState.MOULDED_SOLID,
            temperature_c=mould_temperature,
            stable_crystal_fraction=crystal_fraction,
            viscosity_pas=deposit_viscosity,
            yield_value_pa=deposit_yield,
        )

        notes: list[str] = []
        if yield_excess > 0.0:
            notes.append(
                f"Yield value {deposit_yield:.1f} Pa at the depositor exceeds the "
                f"{DEPOSIT_YIELD_LIMIT_PA:.0f} Pa depositing limit; expect poor "
                "levelling and trapped air."
            )
        if viscosity_excess > 0.0:
            notes.append(
                f"Viscosity {deposit_viscosity:.2f} Pa.s at the depositor exceeds the "
                "limit; weight accuracy will suffer."
            )
        if stream.stable_crystal_fraction < MINIMUM_RELEASE_CRYSTAL_FRACTION:
            notes.append(
                "Insufficient stable crystal for contraction; bars will not "
                "release cleanly from the mould."
            )

        return StageResult(
            stage=self.kind,
            machine_id=machine_id,
            stream_in=stream,
            stream_out=stream_out,
            mass_balance=MassBalance(
                stage=self.kind.value,
                mass_in=input_mass,
                mass_out=output_mass,
                mass_loss=0.0,
                mass_waste=input_mass * waste_fraction,
            ),
            duration_minutes=duration,
            energy=energy,
            provenance=self._provenance(
                basis="Rheology-driven depositing accuracy with a mould heat balance",
                assumptions=(
                    "Deposit rejects scale linearly with rheological excess",
                    "Moulds carry 1.8x the product mass in steel",
                ),
            ),
            metrics={
                "waste_fraction": waste_fraction,
                "deposit_viscosity_pas": deposit_viscosity,
                "deposit_yield_value_pa": deposit_yield,
                "yield_excess": yield_excess,
                "viscosity_excess": viscosity_excess,
                "inclusion_mass_kg": inclusion_mass,
                "mould_temperature_c": mould_temperature,
            },
            notes=tuple(notes),
        )


class CoolingModel(ProcessStage):
    """Cooling tunnel: solidifies the moulded product."""

    kind = ProcessStageKind.COOLING
    accepts = (MaterialState.MOULDED_SOLID,)

    def _run(
        self,
        stream: MaterialStream,
        recipe: Recipe,
        source: RandomSource,
        machine_id: str | None = None,
        **kwargs: Any,
    ) -> StageResult:
        tunnel_temperature = float(
            kwargs.get("tunnel_temperature_c", recipe.process.cooling_tunnel_c)
        )
        duration = float(kwargs.get("minutes", recipe.process.cooling_minutes))

        exit_temperature = max(
            tunnel_temperature + 2.0,
            self.config.factory.ambient_temperature_c - 3.0,
        )
        temperature_drop = max(0.0, stream.temperature_c - exit_temperature)
        cooling_rate = temperature_drop / max(duration, 1e-6)

        # Sensible heat plus the latent heat of the bulk crystallisation that
        # happens here. The latent term is not a detail: crystallising the
        # remaining fat releases roughly as much heat as cooling the bar by
        # fifteen degrees.
        sensible = sensible_heat_kwh(
            stream.mass_kg, CP_CHOCOLATE_LIQUID, temperature_drop
        )
        fat_fraction = stream.composition.fat
        crystallising = max(
            0.0, fat_fraction - stream.stable_crystal_fraction * fat_fraction
        )
        latent = (
            stream.mass_kg
            * crystallising
            * ENTHALPY_OF_FUSION[CrystalForm.FORM_V]
            / 3600.0
        )
        duty = (sensible + latent) * (1.0 + TUNNEL_HEAT_INGRESS)

        energy = cooling_energy(duty, self.config.energy)
        fan_kwh = TUNNEL_FAN_POWER_KW_PER_TONNE_HOUR * (stream.mass_kg / 1000.0) * (
            duration / 60.0
        )
        energy = energy + mechanical_energy(fan_kwh, self.config.energy)

        # Quench damage: cooling faster than the crystal front can propagate
        # nucleates unstable forms at the surface, undoing the tempering.
        quench_excess = max(0.0, cooling_rate - QUENCH_RATE_LIMIT_C_PER_MIN)
        quench_damage = 1.0 - math.exp(-1.8 * quench_excess)
        surviving_crystal = stream.stable_crystal_fraction * (1.0 - 0.55 * quench_damage)

        waste_fraction = clamp(
            (0.003 + 0.09 * quench_damage) * self._noise(source, "waste", 0.15),
            0.0,
            0.3,
        )
        output_mass = stream.mass_kg * (1.0 - waste_fraction)

        stream_out = stream.evolve(
            mass_kg=output_mass,
            state=MaterialState.MOULDED_SOLID,
            temperature_c=exit_temperature,
            stable_crystal_fraction=surviving_crystal,
        )

        notes: list[str] = []
        defects: list[str] = []
        if quench_excess > 0.0:
            notes.append(
                f"Cooling at {cooling_rate:.2f} C/min exceeds the "
                f"{QUENCH_RATE_LIMIT_C_PER_MIN:.1f} C/min quench limit; surface "
                "will set in unstable forms and the product will be dull."
            )
            defects.append(DefectKind.DULL_SURFACE.value)
        if cooling_rate < SLOW_COOLING_THRESHOLD_C_PER_MIN and temperature_drop > 1.0:
            notes.append(
                f"Cooling at only {cooling_rate:.2f} C/min; the tunnel is longer "
                "than it needs to be for this product."
            )
        if exit_temperature < self.config.factory.ambient_temperature_c - 8.0:
            notes.append(
                "Product leaves well below ambient; condensation on unwrapping "
                "risks sugar bloom."
            )

        return StageResult(
            stage=self.kind,
            machine_id=machine_id,
            stream_in=stream,
            stream_out=stream_out,
            mass_balance=MassBalance(
                stage=self.kind.value,
                mass_in=stream.mass_kg,
                mass_out=output_mass,
                mass_loss=0.0,
                mass_waste=stream.mass_kg * waste_fraction,
            ),
            duration_minutes=duration,
            energy=energy,
            provenance=self._provenance(
                basis=(
                    "Sensible plus latent cooling duty with a quench-rate penalty "
                    "on crystal survival"
                ),
                assumptions=(
                    "The bar is thermally lumped; no internal gradient is resolved",
                    f"Tunnel heat ingress is {TUNNEL_HEAT_INGRESS:.0%} of duty",
                ),
            ),
            metrics={
                "cooling_rate_c_per_min": cooling_rate,
                "exit_temperature_c": exit_temperature,
                "quench_damage": quench_damage,
                "latent_load_kwh": latent,
                "sensible_load_kwh": sensible,
                "surviving_crystal_fraction": surviving_crystal,
            },
            notes=tuple(notes),
        )


__all__ = [
    "DEPOSIT_VISCOSITY_LIMIT_PAS",
    "DEPOSIT_YIELD_LIMIT_PA",
    "QUENCH_RATE_LIMIT_C_PER_MIN",
    "CoolingModel",
    "MouldingModel",
]
