"""The process chain: bean to bar, end to end.

:class:`ProcessChain` runs the full sequence of unit operations and composes
their results. Its job beyond simple sequencing is to keep two things honest:

**Mass across the whole chain.** Each stage validates its own balance, but the
chain also composes them, so the overall figure is derived from the individual
stages rather than asserted independently. If the numbers disagree the
composition raises.

**The formulation.** Only the cocoa components pass through roasting, grinding
and winnowing. Sugar, milk powder and the rest join at mixing; lecithin and
flavours join at conching; inclusions join at moulding. Feeding the whole
formulation through the roaster would be both physically absurd and a silent
50% error in the energy figures, so the chain splits the recipe by stage and
introduces each component where it actually belongs.
"""

from __future__ import annotations

from collections.abc import Sequence

from pydantic import Field

from ..core.config import ChocoSimConfig
from ..core.exceptions import ProcessError
from ..core.fidelity import ModelProvenance
from ..core.models import (
    Composition,
    FrozenChocoModel,
    MassBalance,
    blend_compositions,
    safe_divide,
)
from ..core.rng import RandomSource
from ..core.types import (
    BatchId,
    Kilograms,
    MaterialState,
    Minutes,
    ProcessStageKind,
    next_id,
)
from ..energy.model import EnergyUse, combine
from ..ingredients.registry import IngredientRegistry
from ..recipes.engine import RecipeEngine
from ..recipes.models import Recipe
from ..tempering.model import TemperingModel
from .base import MaterialStream, ProcessStage, StageResult
from .conching import ConchingModel
from .grinding import GrindingModel, WinnowingModel
from .moulding import CoolingModel, MouldingModel
from .refining import MixingModel, RefiningModel
from .roasting import RoastingModel

#: Ingredient classes that pass through the bean-processing front end.
BEAN_CLASSES: frozenset[str] = frozenset({"cocoa_bean"})


class ProcessRun(FrozenChocoModel):
    """The complete result of running a batch through the chain."""

    batch_id: BatchId
    recipe_key: str
    recipe_name: str
    target_mass_kg: Kilograms = Field(gt=0.0)

    results: tuple[StageResult, ...]
    overall_balance: MassBalance
    final_stream: MaterialStream
    provenance: ModelProvenance

    @property
    def total_energy(self) -> EnergyUse:
        """Energy consumed across every stage."""
        return combine(result.energy for result in self.results)

    @property
    def total_minutes(self) -> Minutes:
        """Total processing time, ignoring queueing between stages."""
        return sum(result.duration_minutes for result in self.results)

    @property
    def attended_minutes(self) -> Minutes:
        """Processing time that requires an operator present.

        Conching is excluded. A conche runs unattended overnight -- that is
        most of the reason plants tolerate a thirty-hour cycle at all -- so
        charging it at three operators per hour would triple the labour cost
        of every dark chocolate and make long conching look ruinous for
        entirely fictional reasons.
        """
        return sum(
            result.duration_minutes
            for result in self.results
            if result.stage is not ProcessStageKind.CONCHING
        )

    @property
    def output_kg(self) -> Kilograms:
        """Saleable mass produced."""
        return self.final_stream.mass_kg

    @property
    def specific_energy_kwh_per_kg(self) -> float:
        """Energy per kilogram of finished product."""
        return self.total_energy.per_kg(self.output_kg)

    @property
    def waste_kg(self) -> Kilograms:
        """Total unintended waste across the chain."""
        return sum(result.mass_balance.mass_waste for result in self.results)

    @property
    def loss_kg(self) -> Kilograms:
        """Total intended loss -- shell, water, volatiles."""
        return sum(result.mass_balance.mass_loss for result in self.results)

    @property
    def waste_fraction(self) -> float:
        """Waste as a share of total input mass."""
        return safe_divide(self.waste_kg, self.overall_balance.mass_in)

    @property
    def notes(self) -> tuple[str, ...]:
        """Every warning raised by every stage, tagged with its stage."""
        return tuple(
            f"[{result.stage.value}] {note}"
            for result in self.results
            for note in result.notes
        )

    def stage(self, kind: ProcessStageKind) -> StageResult | None:
        """The result of one stage, if it ran."""
        for result in self.results:
            if result.stage is kind:
                return result
        return None

    def stage_metrics(self, stage_name: str) -> dict[str, float]:
        """Metrics reported by a named stage, empty if the stage did not run.

        Returning an empty mapping rather than raising is deliberate: a recipe
        that starts from bought-in liquor never runs the roaster, and callers
        should not have to branch on which front end was used.
        """
        for result in self.results:
            if result.stage.value == stage_name:
                return dict(result.metrics)
        return {}

    def energy_by_stage(self) -> dict[str, float]:
        """Energy in kWh attributed to each stage, largest first."""
        totals = {
            result.stage.value: result.energy.total_kwh for result in self.results
        }
        return dict(sorted(totals.items(), key=lambda item: -item[1]))

    def bottleneck_stage(self) -> tuple[str, Minutes]:
        """The slowest stage and its duration."""
        if not self.results:
            return ("", 0.0)
        slowest = max(self.results, key=lambda result: result.duration_minutes)
        return (slowest.stage.value, slowest.duration_minutes)

    def report(self) -> str:
        """Plain-text process report."""
        lines = [
            f"PROCESS RUN {self.batch_id} -- {self.recipe_name}",
            "=" * 74,
            f"{'STAGE':<12}{'IN kg':>10}{'OUT kg':>10}{'MIN':>8}"
            f"{'kWh':>10}{'kWh/kg':>10}",
            "-" * 74,
        ]
        for result in self.results:
            lines.append(
                f"{result.stage.value:<12}"
                f"{result.stream_in.mass_kg:>10.2f}"
                f"{result.stream_out.mass_kg:>10.2f}"
                f"{result.duration_minutes:>8.1f}"
                f"{result.energy.total_kwh:>10.2f}"
                f"{result.specific_energy_kwh_per_kg:>10.4f}"
            )
        bottleneck, minutes = self.bottleneck_stage()
        lines += [
            "-" * 74,
            f"{'TOTAL':<12}"
            f"{self.overall_balance.mass_in:>10.2f}"
            f"{self.output_kg:>10.2f}"
            f"{self.total_minutes:>8.1f}"
            f"{self.total_energy.total_kwh:>10.2f}"
            f"{self.specific_energy_kwh_per_kg:>10.4f}",
            "",
            f"Yield          {self.overall_balance.yield_fraction:.2%}",
            f"Loss           {self.loss_kg:,.2f} kg "
            f"({self.overall_balance.loss_fraction:.2%})",
            f"Waste          {self.waste_kg:,.2f} kg ({self.waste_fraction:.2%})",
            f"Bottleneck     {bottleneck} ({minutes:.0f} min)",
        ]
        if self.notes:
            lines += ["", "WARNINGS"]
            lines += [f"  {note}" for note in self.notes]
        lines += ["", self.provenance.banner()]
        return "\n".join(lines)


class ProcessChain:
    """Runs a recipe through every unit operation in sequence."""

    def __init__(
        self,
        registry: IngredientRegistry,
        config: ChocoSimConfig | None = None,
    ) -> None:
        self.registry = registry
        self.config = config or ChocoSimConfig.default()
        self.recipe_engine = RecipeEngine(registry)

        self.roasting = RoastingModel(self.config)
        self.winnowing = WinnowingModel(self.config)
        self.grinding = GrindingModel(self.config)
        self.mixing = MixingModel(self.config)
        self.refining = RefiningModel(self.config)
        self.conching = ConchingModel(self.config)
        self.tempering = TemperingModel(self.config)
        self.moulding = MouldingModel(self.config)
        self.cooling = CoolingModel(self.config)

    # ------------------------------------------------------------------
    # Formulation splitting
    # ------------------------------------------------------------------

    def _split_components(
        self, recipe: Recipe, batch_mass_kg: Kilograms
    ) -> dict[str, list[tuple[str, Kilograms]]]:
        """Group the formulation by the stage at which each part is introduced.

        Beans are separated from everything else because only they need
        roasting, winnowing and grinding. A recipe formulated with bought-in
        liquor instead of beans skips the front end entirely, which is exactly
        what happens in a plant that does not roast its own.
        """
        requirements = self.recipe_engine.requirements(recipe, batch_mass_kg)
        groups: dict[str, list[tuple[str, Kilograms]]] = {
            "beans": [],
            "mixing": [],
            "conching": [],
            "moulding": [],
        }
        for requirement, component in zip(
            requirements, recipe.components, strict=True
        ):
            ingredient = self.registry.get(requirement.ingredient_id)
            stage = component.added_at_stage
            if stage == "moulding":
                groups["moulding"].append(
                    (requirement.ingredient_id, requirement.required_kg)
                )
            elif stage == "conching":
                groups["conching"].append(
                    (requirement.ingredient_id, requirement.required_kg)
                )
            elif ingredient.ingredient_class.value in BEAN_CLASSES:
                groups["beans"].append(
                    (requirement.ingredient_id, requirement.required_kg)
                )
            else:
                groups["mixing"].append(
                    (requirement.ingredient_id, requirement.required_kg)
                )
        return groups

    def _blend(self, parts: Sequence[tuple[str, Kilograms]]) -> tuple[Composition, Kilograms]:
        """Blend a set of ingredient quantities into one composition."""
        if not parts:
            return Composition(), 0.0
        return blend_compositions(
            [
                (self.registry.get(ingredient_id).composition, mass)
                for ingredient_id, mass in parts
            ]
        )

    def _merge_into(
        self,
        stream: MaterialStream,
        parts: Sequence[tuple[str, Kilograms]],
        state: MaterialState | None = None,
    ) -> MaterialStream:
        """Add ingredients into an existing stream, blending composition."""
        added_composition, added_mass = self._blend(parts)
        if added_mass <= 0.0:
            return stream
        merged, total = blend_compositions(
            [(stream.composition, stream.mass_kg), (added_composition, added_mass)]
        )
        coarsest = max(
            (
                self.registry.get(ingredient_id).incoming_particle_size_um
                for ingredient_id, _ in parts
            ),
            default=0.0,
        )
        return stream.evolve(
            mass_kg=total,
            composition=merged,
            state=state or stream.state,
            particle_size_d90_um=max(stream.particle_size_d90_um, coarsest),
            particle_size_d50_um=max(
                stream.particle_size_d50_um, coarsest * 0.5
            ),
        )

    # ------------------------------------------------------------------
    # Execution
    # ------------------------------------------------------------------

    def run(
        self,
        recipe: Recipe,
        batch_mass_kg: Kilograms | None = None,
        source: RandomSource | None = None,
        batch_id: BatchId | None = None,
    ) -> ProcessRun:
        """Run a batch through the entire chain."""
        mass = (
            batch_mass_kg
            if batch_mass_kg is not None
            else recipe.default_batch_size_kg
        )
        if mass <= 0.0:
            raise ProcessError(f"batch mass must be positive, got {mass}")

        source = source or RandomSource(self.config.simulation.seed)
        batch = batch_id or next_id("BATCH", width=4)
        groups = self._split_components(recipe, mass)

        results: list[StageResult] = []
        total_input = mass

        # --- bean front end -------------------------------------------
        bean_parts = groups["beans"]
        if bean_parts:
            composition, bean_mass = self._blend(bean_parts)
            stream = MaterialStream(
                mass_kg=bean_mass,
                composition=composition,
                temperature_c=self.config.factory.ambient_temperature_c,
                state=MaterialState.WHOLE_BEAN,
                particle_size_d90_um=12_000.0,
                particle_size_d50_um=9_000.0,
            )
            for stage in (self.roasting, self.winnowing, self.grinding):
                result = stage.run(stream, recipe, source)
                results.append(result)
                stream = result.stream_out
        else:
            # No beans: the formulation starts from bought-in liquor and other
            # prepared materials, which is the common case for a plant that
            # does not run its own bean line.
            composition, liquor_mass = self._blend(groups["mixing"])
            if liquor_mass <= 0.0:
                raise ProcessError(
                    f"recipe {recipe.recipe_id!r} has no ingredients available "
                    "at the mixing stage"
                )
            stream = MaterialStream(
                mass_kg=liquor_mass,
                composition=composition,
                temperature_c=45.0,
                state=MaterialState.LIQUOR,
                particle_size_d90_um=max(
                    (
                        self.registry.get(ingredient_id).incoming_particle_size_um
                        for ingredient_id, _ in groups["mixing"]
                    ),
                    default=450.0,
                ),
                particle_size_d50_um=200.0,
            )
            groups = {**groups, "mixing": []}

        # --- mixing ----------------------------------------------------
        stream = self._merge_into(stream, groups["mixing"])
        result = self.mixing.run(stream, recipe, source)
        results.append(result)
        stream = result.stream_out

        # --- refining --------------------------------------------------
        result = self.refining.run(stream, recipe, source)
        results.append(result)
        stream = result.stream_out

        # --- conching (emulsifier and flavours added here) --------------
        stream = self._merge_into(
            stream, groups["conching"], state=MaterialState.REFINED_POWDER
        )
        lecithin_mass = sum(
            quantity
            for ingredient_id, quantity in groups["conching"]
            if self.registry.get(ingredient_id).ingredient_class.value == "emulsifier"
        )
        lecithin_fraction = safe_divide(lecithin_mass, stream.mass_kg)
        result = self.conching.run(
            stream, recipe, source, lecithin_fraction=lecithin_fraction
        )
        results.append(result)
        stream = result.stream_out

        # --- tempering -------------------------------------------------
        result = self.tempering.run(stream, recipe, source)
        results.append(result)
        stream = result.stream_out

        # --- moulding (inclusions added here) --------------------------
        inclusion_mass = sum(quantity for _, quantity in groups["moulding"])
        if inclusion_mass > 0.0:
            inclusion_composition, _ = self._blend(groups["moulding"])
            merged, total = blend_compositions(
                [
                    (stream.composition, stream.mass_kg),
                    (inclusion_composition, inclusion_mass),
                ]
            )
            # Inclusions carry no crystal structure of their own, so the stable
            # crystal fraction of the combined mass is diluted in proportion.
            crystal_scale = safe_divide(stream.mass_kg, total)
            moulding_input = stream.evolve(
                mass_kg=total,
                composition=merged,
                stable_crystal_fraction=stream.stable_crystal_fraction * crystal_scale,
            )
            result = self.moulding.run(
                moulding_input, recipe, source, inclusion_mass_kg=inclusion_mass
            )
        else:
            result = self.moulding.run(stream, recipe, source)
        results.append(result)
        stream = result.stream_out

        # --- cooling ---------------------------------------------------
        result = self.cooling.run(stream, recipe, source)
        results.append(result)
        stream = result.stream_out

        overall = MassBalance(
            stage="process_chain",
            mass_in=total_input,
            mass_out=stream.mass_kg,
            mass_loss=sum(result.mass_balance.mass_loss for result in results),
            mass_waste=sum(result.mass_balance.mass_waste for result in results),
        )

        provenance = ModelProvenance.combine(
            "process_chain",
            [result.provenance for result in results],
            basis="Sequential composition of individually validated unit operations",
        )

        return ProcessRun(
            batch_id=batch,
            recipe_key=recipe.key,
            recipe_name=recipe.name,
            target_mass_kg=mass,
            results=tuple(results),
            overall_balance=overall,
            final_stream=stream,
            provenance=provenance,
        )


__all__ = ["ProcessChain", "ProcessRun"]
