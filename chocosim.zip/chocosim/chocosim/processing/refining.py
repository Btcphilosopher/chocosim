"""Mixing and refining.

**Mixing** brings the formulation together into a plastic paste. Nothing much
happens chemically; the point is a homogeneous feed for the refiner, since a
refiner fed unevenly produces an uneven particle size distribution and no
amount of downstream conching will fix that.

**Refining** is the size-reduction step that decides mouthfeel. The tongue
detects individual particles above roughly 25-30 micrometres, so a chocolate
refined to a d90 of 18 um reads as smooth and one at 40 um reads as gritty.
Below about 15 um the mass becomes disproportionately viscous, because the
surface area needing to be coated with fat grows as the particles shrink --
so there is a genuine optimum rather than "finer is better".

The particle size distribution is modelled as lognormal, which is what roll
refiners actually produce, and is reported by the percentiles a plant would
measure: d10, d50, d90 and the span.
"""

from __future__ import annotations

import math
from typing import Any

import numpy as np
from pydantic import Field

from ..core.config import ChocoSimConfig
from ..core.models import FrozenChocoModel, MassBalance, clamp
from ..core.rng import RandomSource
from ..core.types import (
    Kilograms,
    KilowattHours,
    MaterialState,
    Micrometres,
    Minutes,
    ProcessStageKind,
)
from ..core.units import CP_CHOCOLATE_LIQUID, minutes_to_hours
from ..energy.model import (
    EnergyUse,
    cooling_energy,
    heating_energy,
    mechanical_energy,
    sensible_heat_kwh,
)
from ..recipes.models import Recipe
from .base import MaterialStream, ProcessStage, StageResult
from .grinding import (
    FRICTIONAL_HEATING_FRACTION,
    REFINING_CONSTANT,
    comminution_energy_kwh_per_tonne,
)
from .rheology import compute_rheology

#: Geometric standard deviation of the distribution a roll refiner produces.
#: 1.85 gives a span of about 1.6, which is what a five-roll refiner achieves.
REFINER_GEOMETRIC_SIGMA: float = 1.85

#: Geometric sigma achievable with an extra refining pass. Narrower, because
#: the coarse tail is preferentially reduced.
REFINER_SIGMA_PER_PASS: float = 0.075

#: Threshold above which particles are individually perceptible, micrometres.
SENSORY_THRESHOLD_UM: Micrometres = 28.0

#: Nominal refiner throughput, kg/h.
REFINER_THROUGHPUT_KG_PER_HOUR: float = 1_200.0

#: Nominal mixer throughput, kg/h.
MIXER_THROUGHPUT_KG_PER_HOUR: float = 4_000.0

#: Specific mixing energy, kWh per tonne.
MIXER_SPECIFIC_ENERGY_KWH_PER_TONNE: float = 6.8


class ParticleSizeDistribution(FrozenChocoModel):
    """A lognormal particle size distribution.

    Parameterised by the median ``d50`` and the geometric standard deviation,
    which is how comminution products are conventionally described.
    """

    d50_um: Micrometres = Field(gt=0.0)
    geometric_sigma: float = Field(gt=1.0)

    def quantile(self, fraction: float) -> Micrometres:
        """Particle size below which ``fraction`` of the mass lies."""
        if not 0.0 < fraction < 1.0:
            raise ValueError(f"fraction must lie in (0, 1), got {fraction}")
        from scipy.stats import norm

        z = float(norm.ppf(fraction))
        return self.d50_um * math.exp(z * math.log(self.geometric_sigma))

    @property
    def d10_um(self) -> Micrometres:
        """Tenth percentile of the mass distribution."""
        return self.quantile(0.10)

    @property
    def d90_um(self) -> Micrometres:
        """Ninetieth percentile -- the figure a plant specifies against."""
        return self.quantile(0.90)

    @property
    def d99_um(self) -> Micrometres:
        """Coarse tail. Drives perceived grittiness more than d90 does."""
        return self.quantile(0.99)

    @property
    def span(self) -> float:
        """Distribution width, ``(d90 - d10) / d50``."""
        return (self.d90_um - self.d10_um) / self.d50_um

    @property
    def specific_surface_area_m2_per_kg(self) -> float:
        """Surface area per unit mass, assuming spherical particles.

        For a lognormal distribution the surface-weighted mean diameter is
        ``d50 * exp(-0.5 * ln(sigma)**2)``, which is where the closed form
        below comes from. Surface area matters because every square metre of
        it must be wetted by cocoa butter, and that fat is then unavailable to
        thin the mass.
        """
        ln_sigma = math.log(self.geometric_sigma)
        surface_mean_d = self.d50_um * math.exp(-0.5 * ln_sigma**2)
        diameter_m = surface_mean_d * 1e-6
        density = 1_500.0
        if diameter_m <= 0.0:
            return 0.0
        return 6.0 / (density * diameter_m)

    def fraction_above(self, size_um: Micrometres) -> float:
        """Mass fraction coarser than a given size."""
        from scipy.stats import norm

        if size_um <= 0.0:
            return 1.0
        z = math.log(size_um / self.d50_um) / math.log(self.geometric_sigma)
        return float(1.0 - norm.cdf(z))

    @property
    def perceptible_fraction(self) -> float:
        """Mass fraction coarse enough to be felt on the tongue."""
        return self.fraction_above(SENSORY_THRESHOLD_UM)

    def sample(self, count: int, generator: np.random.Generator) -> np.ndarray:
        """Draw particle diameters from the distribution."""
        return self.d50_um * np.exp(
            generator.normal(0.0, math.log(self.geometric_sigma), count)
        )

    def histogram(self, bins: int = 24) -> tuple[np.ndarray, np.ndarray]:
        """Mass-weighted histogram over log-spaced bins.

        Returns bin centres and the mass fraction in each bin, ready to plot.
        """
        from scipy.stats import norm

        low = self.quantile(0.001)
        high = self.quantile(0.999)
        edges = np.geomspace(low, high, bins + 1)
        ln_sigma = math.log(self.geometric_sigma)
        z = np.log(edges / self.d50_um) / ln_sigma
        cumulative = norm.cdf(z)
        density = np.diff(cumulative)
        centres = np.sqrt(edges[:-1] * edges[1:])
        return centres, density

    @classmethod
    def from_d90(
        cls, d90_um: Micrometres, geometric_sigma: float = REFINER_GEOMETRIC_SIGMA
    ) -> ParticleSizeDistribution:
        """Construct a distribution with a given d90."""
        from scipy.stats import norm

        z = float(norm.ppf(0.90))
        d50 = d90_um / math.exp(z * math.log(geometric_sigma))
        return cls(d50_um=d50, geometric_sigma=geometric_sigma)

    def describe(self) -> str:
        """Plain-text summary of the distribution."""
        return (
            f"d10={self.d10_um:.2f} d50={self.d50_um:.2f} d90={self.d90_um:.2f} "
            f"d99={self.d99_um:.2f} um, span={self.span:.2f}, "
            f"SSA={self.specific_surface_area_m2_per_kg:.1f} m2/kg, "
            f"perceptible={self.perceptible_fraction:.2%}"
        )


class MixingModel(ProcessStage):
    """Combines the formulation into a homogeneous paste."""

    kind = ProcessStageKind.MIXING
    accepts = (MaterialState.LIQUOR, MaterialState.PASTE, MaterialState.NIB)

    def _run(
        self,
        stream: MaterialStream,
        recipe: Recipe,
        source: RandomSource,
        machine_id: str | None = None,
        **kwargs: Any,
    ) -> StageResult:
        duration = max(4.0, stream.mass_kg / MIXER_THROUGHPUT_KG_PER_HOUR * 60.0)

        shaft_kwh = MIXER_SPECIFIC_ENERGY_KWH_PER_TONNE * (stream.mass_kg / 1000.0)
        shaft_kwh *= self._noise(source, "energy", 0.05)
        energy = mechanical_energy(shaft_kwh, self.config.energy)

        # Mixers are jacketed to hold the mass at a workable temperature.
        target_temperature = 45.0
        if stream.temperature_c < target_temperature:
            duty = sensible_heat_kwh(
                stream.mass_kg,
                CP_CHOCOLATE_LIQUID,
                target_temperature - stream.temperature_c,
            )
            energy = energy + heating_energy(duty, self.config.energy)
        elif stream.temperature_c > target_temperature + 5.0:
            duty = sensible_heat_kwh(
                stream.mass_kg,
                CP_CHOCOLATE_LIQUID,
                stream.temperature_c - target_temperature,
            )
            energy = energy + cooling_energy(duty, self.config.energy)

        waste_fraction = 0.0025 * self._noise(source, "waste", 0.2)
        output_mass = stream.mass_kg * (1.0 - waste_fraction)

        rheology = compute_rheology(
            stream.composition,
            max(stream.particle_size_d50_um, 1.0),
            span=2.4,
            temperature_c=target_temperature,
            lecithin_fraction=0.0,
        )

        stream_out = stream.evolve(
            mass_kg=output_mass,
            state=MaterialState.PASTE,
            temperature_c=target_temperature,
            viscosity_pas=rheology.plastic_viscosity_pas,
            yield_value_pa=rheology.yield_value_pa,
        )

        return StageResult(
            stage=self.kind,
            machine_id=machine_id,
            stream_in=stream,
            stream_out=stream_out,
            mass_balance=MassBalance(
                stage=self.kind.value,
                mass_in=stream.mass_kg,
                mass_out=output_mass,
                mass_loss=0.0,
                mass_waste=stream.mass_kg * waste_fraction,
            ),
            duration_minutes=duration,
            energy=energy,
            provenance=self._provenance(
                basis="Fixed specific mixing energy with a jacket heat balance",
                assumptions=("Mixing achieves complete homogeneity",),
            ),
            metrics={
                "target_temperature_c": target_temperature,
                "viscosity_pas": rheology.plastic_viscosity_pas,
            },
        )


class RefiningModel(ProcessStage):
    """Reduces particle size to the specification."""

    kind = ProcessStageKind.REFINING
    accepts = (MaterialState.PASTE, MaterialState.LIQUOR)

    def _run(
        self,
        stream: MaterialStream,
        recipe: Recipe,
        source: RandomSource,
        machine_id: str | None = None,
        **kwargs: Any,
    ) -> StageResult:
        target_d90 = float(
            kwargs.get("target_d90_um", recipe.process.target_particle_size_um)
        )
        passes = int(kwargs.get("passes", recipe.process.refining_passes))

        d_in = max(stream.particle_size_d90_um, target_d90 * 1.01)

        # Extra passes narrow the distribution: the rolls preferentially catch
        # the coarse tail, which is the whole reason to run more than one.
        sigma = max(
            1.35, REFINER_GEOMETRIC_SIGMA - REFINER_SIGMA_PER_PASS * (passes - 1)
        )
        sigma *= self._noise(source, "sigma", 0.02)
        sigma = max(1.30, sigma)

        achieved_d90 = target_d90 * self._noise(source, "d90", 0.035)
        distribution = ParticleSizeDistribution.from_d90(achieved_d90, sigma)

        specific_kwh = comminution_energy_kwh_per_tonne(
            d_in, achieved_d90, REFINING_CONSTANT
        )
        # Each additional pass costs energy without proportionate size gain.
        specific_kwh *= 1.0 + 0.34 * (passes - 1)
        specific_kwh *= self._noise(source, "energy", 0.05)

        shaft_kwh = specific_kwh * (stream.mass_kg / 1000.0)
        energy = mechanical_energy(shaft_kwh, self.config.energy)

        heat_kwh = shaft_kwh * FRICTIONAL_HEATING_FRACTION
        delta_t = (
            (heat_kwh * 3600.0) / (stream.mass_kg * CP_CHOCOLATE_LIQUID)
            if stream.mass_kg > 0.0
            else 0.0
        )
        uncontrolled = stream.temperature_c + delta_t
        target_temperature = min(uncontrolled, 50.0)
        cooling_duty = 0.0
        if uncontrolled > target_temperature:
            cooling_duty = sensible_heat_kwh(
                stream.mass_kg, CP_CHOCOLATE_LIQUID, uncontrolled - target_temperature
            )
            energy = energy + cooling_energy(cooling_duty, self.config.energy)

        waste_fraction = 0.004 * passes * self._noise(source, "waste", 0.18)
        output_mass = stream.mass_kg * (1.0 - waste_fraction)

        rheology = compute_rheology(
            stream.composition,
            distribution.d50_um,
            span=distribution.span,
            temperature_c=target_temperature,
            lecithin_fraction=0.0,
        )

        stream_out = stream.evolve(
            mass_kg=output_mass,
            state=MaterialState.REFINED_POWDER,
            temperature_c=target_temperature,
            particle_size_d90_um=distribution.d90_um,
            particle_size_d50_um=distribution.d50_um,
            viscosity_pas=rheology.plastic_viscosity_pas,
            yield_value_pa=rheology.yield_value_pa,
        )

        duration = max(
            5.0,
            stream.mass_kg / REFINER_THROUGHPUT_KG_PER_HOUR * 60.0 * passes,
        )

        notes: list[str] = []
        if distribution.perceptible_fraction > 0.05:
            notes.append(
                f"{distribution.perceptible_fraction:.1%} of mass is coarser than "
                f"{SENSORY_THRESHOLD_UM:.0f} um; the product will read as gritty."
            )
        if distribution.d90_um < 14.0:
            notes.append(
                f"d90 of {distribution.d90_um:.1f} um is very fine: surface area "
                f"{distribution.specific_surface_area_m2_per_kg:.0f} m2/kg will "
                "demand extra cocoa butter to stay workable."
            )
        if not rheology.is_workable:
            notes.append(
                f"Refined mass is unworkable (crowding {rheology.crowding:.2f}); "
                "add fat or coarsen the grind."
            )

        return StageResult(
            stage=self.kind,
            machine_id=machine_id,
            stream_in=stream,
            stream_out=stream_out,
            mass_balance=MassBalance(
                stage=self.kind.value,
                mass_in=stream.mass_kg,
                mass_out=output_mass,
                mass_loss=0.0,
                mass_waste=stream.mass_kg * waste_fraction,
            ),
            duration_minutes=duration,
            energy=energy,
            provenance=self._provenance(
                basis=(
                    "Hukki comminution law with a lognormal product size "
                    "distribution and a roll heat balance"
                ),
                assumptions=(
                    "Refiner output is lognormal with a pass-dependent width",
                    "Additional passes narrow the distribution but do not shift "
                    "the median",
                ),
            ),
            metrics={
                "d10_um": distribution.d10_um,
                "d50_um": distribution.d50_um,
                "d90_um": distribution.d90_um,
                "d99_um": distribution.d99_um,
                "span": distribution.span,
                "geometric_sigma": sigma,
                "specific_surface_m2_per_kg": distribution.specific_surface_area_m2_per_kg,
                "perceptible_fraction": distribution.perceptible_fraction,
                "specific_energy_kwh_per_tonne": specific_kwh,
                "frictional_heating_c": delta_t,
                "cooling_duty_kwh": cooling_duty,
                "viscosity_pas": rheology.plastic_viscosity_pas,
                "passes": float(passes),
            },
            notes=tuple(notes),
        )

    def distribution_for(
        self, recipe: Recipe, passes: int | None = None
    ) -> ParticleSizeDistribution:
        """The nominal distribution this recipe should produce."""
        count = passes if passes is not None else recipe.process.refining_passes
        sigma = max(1.35, REFINER_GEOMETRIC_SIGMA - REFINER_SIGMA_PER_PASS * (count - 1))
        return ParticleSizeDistribution.from_d90(
            recipe.process.target_particle_size_um, sigma
        )


__all__ = [
    "REFINER_GEOMETRIC_SIGMA",
    "SENSORY_THRESHOLD_UM",
    "MixingModel",
    "ParticleSizeDistribution",
    "RefiningModel",
]
