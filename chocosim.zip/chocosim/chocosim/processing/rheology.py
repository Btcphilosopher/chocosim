"""Rheology of chocolate masses.

Viscosity is the pivot of the whole process model. It decides whether a mass
can be pumped, whether it fills a mould cleanly, how much cocoa butter the
formulation needs, and how long the conche has to run. Getting it from a
lookup table would make the rest of the simulator decorative, so it is derived
mechanistically here and every downstream stage reads from this module.

Molten chocolate is a concentrated suspension of sugar, cocoa and milk solids
in a continuous fat phase. It is not Newtonian: it has a yield stress, and
below that stress it does not flow at all. The industry standard description
is the Casson model,

    sqrt(tau) = sqrt(tau_0) + sqrt(eta_ca * shear_rate)

with a Casson yield value ``tau_0`` and a Casson plastic viscosity ``eta_ca``.
Both are computed here from composition and particle size.

**Plastic viscosity** follows Krieger-Dougherty,

    eta_r = (1 - phi / phi_max) ** (-[eta] * phi_max)

where ``phi`` is the volume fraction of solids and ``phi_max`` is the maximum
packing fraction. Everything a chocolatier does to thin a mass acts through
one of those two terms: adding cocoa butter lowers ``phi``, lecithin raises
``phi_max`` by thinning the adsorbed fat layer, and a wider particle-size
distribution raises ``phi_max`` because small particles pack into the gaps
between large ones.

**Yield value** comes from particle-particle contact, so it rises steeply with
fineness (more contacts per unit volume) and with moisture (water forms
capillary bridges between sugar crystals). This is why a trace of water is so
destructive to a chocolate mass, and why conching is as much about drying as
about flavour.

Coefficients are literature-scale values chosen so that standard formulations
land in the ranges a plant would measure. They are not fitted to a specific
product.
"""

from __future__ import annotations

import math

from pydantic import Field

from ..core.models import Composition, FrozenChocoModel, clamp
from ..core.types import Celsius, Micrometres, PascalSeconds

# --- Component densities, kg/m^3 -------------------------------------------

DENSITY_SUGAR: float = 1_590.0
DENSITY_COCOA_SOLIDS: float = 1_450.0
DENSITY_MILK_SOLIDS: float = 1_300.0
DENSITY_OTHER_SOLIDS: float = 1_350.0
DENSITY_FAT_LIQUID: float = 900.0

# --- Krieger-Dougherty parameters ------------------------------------------

#: Maximum packing fraction of an ideal chocolate suspension, before the
#: corrections below. Lower than the 0.64 of random close-packed spheres
#: because cocoa and sugar particles are angular and irregular.
PHI_MAX_BASE: float = 0.600

#: Intrinsic viscosity. Above the 2.5 of Einstein spheres, again because the
#: particles are not spheres.
INTRINSIC_VISCOSITY: float = 3.5

#: Maximum increase in packing fraction achievable with emulsifier.
LECITHIN_PHI_MAX_GAIN: float = 0.055
#: Lecithin fraction at which most of that gain is realised. Beyond roughly
#: 0.5% lecithin the surface is saturated and further addition does very
#: little -- one of the few genuinely sharp diminishing returns in the process.
LECITHIN_SATURATION: float = 0.0045

#: Packing penalty for fineness, um. Finer particles have more surface per
#: unit volume, so the adsorbed fat layer immobilises a larger share of the
#: continuous phase.
FINENESS_PHI_MAX_PENALTY_UM: float = 0.55

#: Packing gain from a wide particle size distribution.
POLYDISPERSITY_PHI_MAX_GAIN: float = 0.045

# --- Fat phase viscosity ---------------------------------------------------

#: Viscosity of cocoa butter at the 40 degC reference, Pa.s.
FAT_VISCOSITY_40C: float = 0.0450
#: Arrhenius activation energy for cocoa butter viscosity, J/mol.
FAT_VISCOSITY_ACTIVATION: float = 26_500.0
#: Milk fat is more mobile than cocoa butter and thins the continuous phase.
MILK_FAT_THINNING: float = 0.35

# --- Yield value -----------------------------------------------------------

#: Scale factor for the Casson yield value, Pa.um. Set so that standard
#: formulations land in the 3-10 Pa band a plant would measure on a rotational
#: viscometer following the ICA/CAOBISCO method.
YIELD_VALUE_SCALE: float = 600.0
#: Exponent on solids volume fraction in the yield value.
YIELD_VALUE_PHI_EXPONENT: float = 3.2
#: Moisture above this fraction begins to bridge particles aggressively.
MOISTURE_BRIDGING_THRESHOLD: float = 0.006
#: Multiplier on yield value per unit moisture above the threshold.
MOISTURE_BRIDGING_GAIN: float = 55.0
#: Lecithin reduces yield value more strongly than it reduces plastic viscosity.
LECITHIN_YIELD_REDUCTION: float = 0.62

#: Reference temperature for reported viscosities, degC.
REFERENCE_TEMPERATURE_C: Celsius = 40.0


def solids_volume_fraction(composition: Composition) -> float:
    """Volume fraction of dispersed solids in the continuous fat phase.

    Water is counted with the solids: at the levels present in chocolate it is
    adsorbed onto sugar surfaces rather than forming a free phase, and it
    behaves as part of the dispersed volume.
    """
    fat_mass = composition.fat
    solid_masses = (
        (composition.sugar, DENSITY_SUGAR),
        (composition.cocoa_solids_nonfat, DENSITY_COCOA_SOLIDS),
        (composition.milk_solids_nonfat, DENSITY_MILK_SOLIDS),
        (composition.other_solids + composition.moisture, DENSITY_OTHER_SOLIDS),
    )
    solid_volume = sum(mass / density for mass, density in solid_masses)
    fat_volume = fat_mass / DENSITY_FAT_LIQUID
    total = solid_volume + fat_volume
    if total <= 0.0:
        return 0.0
    return solid_volume / total


def fat_phase_viscosity(
    temperature_c: Celsius, milk_fat_share: float = 0.0
) -> PascalSeconds:
    """Viscosity of the continuous fat phase at a temperature.

    Arrhenius in absolute temperature. Milk fat, being a softer and more
    mobile triglyceride mixture, thins the phase in proportion to its share.
    """
    reference_k = REFERENCE_TEMPERATURE_C + 273.15
    temperature_k = max(temperature_c, 5.0) + 273.15
    factor = math.exp(
        FAT_VISCOSITY_ACTIVATION / 8.314462618 * (1.0 / temperature_k - 1.0 / reference_k)
    )
    thinning = 1.0 - MILK_FAT_THINNING * clamp(milk_fat_share, 0.0, 1.0)
    return FAT_VISCOSITY_40C * factor * thinning


def maximum_packing_fraction(
    d50_um: Micrometres,
    span: float = 1.6,
    lecithin_fraction: float = 0.0,
    emulsifier_efficiency: float = 1.0,
) -> float:
    """Maximum packing fraction of the solids.

    ``span`` is the distribution width ``(d90 - d10) / d50``. A monodisperse
    powder has a span near zero and packs badly; a well-refined chocolate runs
    around 1.5 to 2.0.

    ``emulsifier_efficiency`` reflects how much of the lecithin has actually
    reached particle surfaces. Freshly dosed lecithin sitting in the fat phase
    does nothing; it has to be sheared onto the solids, which is one of the
    things conching accomplishes.
    """
    phi_max = PHI_MAX_BASE

    if d50_um > 0.0:
        phi_max -= FINENESS_PHI_MAX_PENALTY_UM / max(d50_um, 1.0)

    polydispersity = clamp(span / 2.0, 0.0, 1.5)
    phi_max += POLYDISPERSITY_PHI_MAX_GAIN * math.tanh(polydispersity)

    if lecithin_fraction > 0.0:
        saturation = 1.0 - math.exp(-lecithin_fraction / LECITHIN_SATURATION)
        phi_max += (
            LECITHIN_PHI_MAX_GAIN
            * saturation
            * clamp(emulsifier_efficiency, 0.0, 1.0)
        )

    return clamp(phi_max, 0.30, 0.78)


class RheologyState(FrozenChocoModel):
    """Casson parameters of a chocolate mass."""

    plastic_viscosity_pas: PascalSeconds = Field(ge=0.0)
    yield_value_pa: float = Field(ge=0.0)
    temperature_c: Celsius
    solids_volume_fraction: float = Field(ge=0.0, le=1.0)
    maximum_packing: float = Field(gt=0.0, le=1.0)
    relative_viscosity: float = Field(ge=1.0)

    @property
    def crowding(self) -> float:
        """How close the suspension is to its packing limit.

        Approaching 1.0 the mass becomes unworkable regardless of what else is
        done to it, because there is no longer enough continuous phase to
        lubricate particle motion.
        """
        if self.maximum_packing <= 0.0:
            return 1.0
        return self.solids_volume_fraction / self.maximum_packing

    @property
    def is_workable(self) -> bool:
        """Whether the mass can realistically be pumped and moulded."""
        return self.crowding < 0.96 and self.plastic_viscosity_pas < 12.0

    def apparent_viscosity(self, shear_rate: float) -> PascalSeconds:
        """Apparent viscosity at a shear rate, from the Casson model.

        Shear-thinning falls out of the yield stress term: at low shear rates
        the yield value dominates and apparent viscosity is enormous, which is
        exactly why chocolate sits on a spoon and then runs off a warm one.
        """
        if shear_rate <= 0.0:
            return float("inf") if self.yield_value_pa > 0.0 else self.plastic_viscosity_pas
        root_tau = math.sqrt(self.yield_value_pa) + math.sqrt(
            self.plastic_viscosity_pas * shear_rate
        )
        return (root_tau**2) / shear_rate

    def at_temperature(self, temperature_c: Celsius, milk_fat_share: float = 0.0) -> RheologyState:
        """Re-evaluate at a different temperature.

        Only the continuous phase viscosity is temperature-dependent; the
        packing geometry does not change, and the yield value is dominated by
        particle contact rather than by the fat.
        """
        old_fat = fat_phase_viscosity(self.temperature_c, milk_fat_share)
        new_fat = fat_phase_viscosity(temperature_c, milk_fat_share)
        if old_fat <= 0.0:
            return self
        ratio = new_fat / old_fat
        return self.model_copy(
            update={
                "plastic_viscosity_pas": self.plastic_viscosity_pas * ratio,
                "temperature_c": temperature_c,
            }
        )

    def describe(self) -> str:
        """One-line rheology summary."""
        return (
            f"eta={self.plastic_viscosity_pas:.3f} Pa.s, "
            f"tau0={self.yield_value_pa:.2f} Pa, "
            f"phi={self.solids_volume_fraction:.3f}/{self.maximum_packing:.3f} "
            f"(crowding {self.crowding:.2f}) @ {self.temperature_c:.1f}C"
        )


def compute_rheology(
    composition: Composition,
    d50_um: Micrometres,
    span: float = 1.6,
    temperature_c: Celsius = REFERENCE_TEMPERATURE_C,
    lecithin_fraction: float = 0.0,
    emulsifier_efficiency: float = 1.0,
) -> RheologyState:
    """Compute the Casson parameters of a chocolate mass.

    This is the single entry point every other module uses. Passing the
    composition rather than a pre-computed fat fraction matters: the model
    needs to know how much of the fat is milk fat, which thins the continuous
    phase, and how much of the sugar is lactose, which does not crystallise
    the same way.
    """
    phi = solids_volume_fraction(composition)
    phi_max = maximum_packing_fraction(
        d50_um, span, lecithin_fraction, emulsifier_efficiency
    )

    milk_fat_share = (
        composition.milk_fat / composition.fat if composition.fat > 0.0 else 0.0
    )
    fat_viscosity = fat_phase_viscosity(temperature_c, milk_fat_share)

    # Krieger-Dougherty. Guarded against the singularity at phi -> phi_max:
    # a real mass that crowded simply will not flow, and the model should say
    # "unworkably viscous" rather than return infinity and poison the arithmetic
    # of every downstream cost calculation.
    crowding = phi / phi_max if phi_max > 0.0 else 1.0
    if crowding >= 0.985:
        relative = 5.0e3
    else:
        exponent = -INTRINSIC_VISCOSITY * phi_max
        relative = (1.0 - crowding) ** exponent
        relative = min(relative, 5.0e3)

    plastic_viscosity = fat_viscosity * relative

    # Casson yield value: particle contacts per unit volume scale as phi^n / d.
    yield_value = (
        YIELD_VALUE_SCALE
        * (phi**YIELD_VALUE_PHI_EXPONENT)
        / max(d50_um, 1.0)
    )

    excess_moisture = max(0.0, composition.moisture - MOISTURE_BRIDGING_THRESHOLD)
    yield_value *= 1.0 + MOISTURE_BRIDGING_GAIN * excess_moisture

    if lecithin_fraction > 0.0:
        saturation = 1.0 - math.exp(-lecithin_fraction / LECITHIN_SATURATION)
        yield_value *= 1.0 - LECITHIN_YIELD_REDUCTION * saturation * clamp(
            emulsifier_efficiency, 0.0, 1.0
        )

    return RheologyState(
        plastic_viscosity_pas=plastic_viscosity,
        yield_value_pa=max(0.0, yield_value),
        temperature_c=temperature_c,
        solids_volume_fraction=phi,
        maximum_packing=phi_max,
        relative_viscosity=max(1.0, relative),
    )


def cocoa_butter_to_target_viscosity(
    composition: Composition,
    d50_um: Micrometres,
    target_viscosity_pas: PascalSeconds,
    span: float = 1.6,
    lecithin_fraction: float = 0.0,
    temperature_c: Celsius = REFERENCE_TEMPERATURE_C,
    max_addition: float = 0.25,
) -> float:
    """Extra cocoa butter needed to reach a target plastic viscosity.

    Returns the mass fraction of cocoa butter to add to the existing mass, or
    zero if the mass is already thin enough. Solved by bisection because
    Krieger-Dougherty cannot be inverted in closed form.

    Practically useful: cocoa butter is the most expensive major ingredient, so
    "how little can I add and still mould cleanly" is a real question with real
    money attached.
    """
    current = compute_rheology(
        composition, d50_um, span, temperature_c, lecithin_fraction
    )
    if current.plastic_viscosity_pas <= target_viscosity_pas:
        return 0.0

    def viscosity_with(addition: float) -> float:
        # Adding pure cocoa butter dilutes every other component.
        scale = 1.0 / (1.0 + addition)
        diluted = Composition(
            fat=(composition.fat + addition) * scale,
            moisture=composition.moisture * scale,
            sugar=composition.sugar * scale,
            cocoa_solids_nonfat=composition.cocoa_solids_nonfat * scale,
            milk_solids_nonfat=composition.milk_solids_nonfat * scale,
            milk_fat=composition.milk_fat * scale,
            other_fat=composition.other_fat * scale,
            lactose=composition.lactose * scale,
            protein=composition.protein * scale,
        )
        return compute_rheology(
            diluted, d50_um, span, temperature_c, lecithin_fraction * scale
        ).plastic_viscosity_pas

    if viscosity_with(max_addition) > target_viscosity_pas:
        return max_addition

    low, high = 0.0, max_addition
    for _ in range(60):
        mid = 0.5 * (low + high)
        if viscosity_with(mid) > target_viscosity_pas:
            low = mid
        else:
            high = mid
    return 0.5 * (low + high)


__all__ = [
    "FAT_VISCOSITY_40C",
    "INTRINSIC_VISCOSITY",
    "PHI_MAX_BASE",
    "REFERENCE_TEMPERATURE_C",
    "RheologyState",
    "cocoa_butter_to_target_viscosity",
    "compute_rheology",
    "fat_phase_viscosity",
    "maximum_packing_fraction",
    "solids_volume_fraction",
]
