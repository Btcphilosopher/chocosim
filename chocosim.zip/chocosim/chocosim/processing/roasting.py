"""Roasting model.

Roasting does three things at once and the model tracks all three, because
they trade off against each other and that trade-off is the whole reason to
simulate a roast profile rather than just pick one.

**Drying.** Beans arrive at 6-8% moisture and leave at around 2%. The model
uses a first-order falling-rate drying law, ``dM/dt = -k (M - M_eq)``, with
``k`` following Arrhenius temperature dependence. Falling-rate rather than
constant-rate because a cocoa bean past its initial surface moisture is
diffusion-limited: the water has to get out through the shell.

**Flavour development.** Maillard and Strecker chemistry converts the amino
acids and reducing sugars produced during fermentation into the pyrazines that
make cocoa smell like cocoa. This is modelled as a thermal accumulation with
its own, higher, activation energy.

**Thermal damage.** Push further and the same chemistry burns: acrylamide
forms, volatile aromatics are driven off, the flavour flattens and goes
bitter. Modelled with a higher activation energy again, so damage overtakes
development as temperature rises.

The activation energies are literature-scale values for food systems, not
values fitted to any particular bean or roaster. The model is therefore useful
for asking "is roast A hotter and shorter than roast B in the way I think" and
not for setting a roaster's setpoint.
"""

from __future__ import annotations

import math
from typing import Any

import numpy as np
from pydantic import Field

from ..core.config import ChocoSimConfig
from ..core.fidelity import ModelProvenance
from ..core.models import FrozenChocoModel, MassBalance
from ..core.rng import RandomSource
from ..core.types import (
    Celsius,
    EnergyCarrier,
    Kilograms,
    KilowattHours,
    MaterialState,
    Minutes,
    ProcessStageKind,
)
from ..core.units import (
    CP_COCOA_BEAN,
    CP_WATER,
    GAS_CONSTANT_R,
    LATENT_HEAT_VAPORISATION_WATER,
    celsius_to_kelvin,
    minutes_to_hours,
)
from ..energy.model import (
    EnergyUse,
    heating_energy,
    latent_heat_kwh,
    mechanical_energy,
    sensible_heat_kwh,
)
from ..recipes.models import Recipe
from .base import MaterialStream, ProcessStage, StageResult

# --- Kinetic parameters (simulation inputs, see module docstring) -----------

#: Pre-exponential factor for moisture removal, 1/min.
DRYING_PREEXPONENTIAL: float = 5.0e3
#: Activation energy for moisture removal, J/mol.
DRYING_ACTIVATION_ENERGY: float = 38_000.0

#: Equilibrium moisture parameters. Equilibrium moisture content is *not* a
#: constant: it falls as air temperature rises, following the material's
#: sorption isotherm. Treating it as fixed makes every roast profile dry to
#: the same endpoint, which destroys the model's ability to distinguish
#: profiles -- the very thing it exists to do. A Henderson-type exponential
#: is used, referenced to 100 degC.
EMC_ASYMPTOTE: float = 0.0060
EMC_AMPLITUDE: float = 0.0225
EMC_REFERENCE_C: float = 100.0
EMC_DECAY_C: float = 85.0

#: Pre-exponential factor for flavour development, 1/min.
#: Calibrated so that the Roast B reference profile (145 degC for 35 min plus
#: a 7 min ramp) accumulates exactly 1.0 development units, which is what
#: FLAVOUR_TARGET then means. Without this anchoring the development ratio is
#: an arbitrary number and the quality index saturates.
FLAVOUR_PREEXPONENTIAL: float = 4.855446e8
#: Activation energy for Maillard flavour development, J/mol.
FLAVOUR_ACTIVATION_ENERGY: float = 82_000.0

#: Pre-exponential factor for thermal damage, 1/min.
#: Calibrated so the Roast B reference accumulates damage equal to 20% of its
#: flavour development -- a clean roast with headroom.
DAMAGE_PREEXPONENTIAL: float = 3.071957e12
#: Activation energy for thermal degradation, J/mol. Higher than the flavour
#: term, so damage overtakes development as temperature rises. This is the
#: whole reason a hotter, shorter roast is not a free lunch.
DAMAGE_ACTIVATION_ENERGY: float = 118_000.0

#: Flavour accumulation at which the roast is considered fully developed.
FLAVOUR_TARGET: float = 1.0

#: Mass fraction of volatile organics lost during roasting, dry basis.
VOLATILE_LOSS_FRACTION: float = 0.008

#: Rated drum power per tonne of charge, kW.
ROASTER_MECHANICAL_KW_PER_TONNE: float = 3.2


def equilibrium_moisture(temperature_c: Celsius) -> float:
    """Equilibrium moisture content of cocoa at an air temperature.

    Falls with temperature: hotter air holds more water vapour at a given
    relative humidity, so the bean equilibrates drier.
    """
    return EMC_ASYMPTOTE + EMC_AMPLITUDE * math.exp(
        -(temperature_c - EMC_REFERENCE_C) / EMC_DECAY_C
    )


def arrhenius_rate(
    preexponential: float, activation_energy: float, temperature_c: Celsius
) -> float:
    """Reaction rate constant at a temperature, 1/min."""
    return preexponential * math.exp(
        -activation_energy / (GAS_CONSTANT_R * celsius_to_kelvin(temperature_c))
    )


class RoastProfile(FrozenChocoModel):
    """A named roasting recipe.

    Ramp time matters: a roaster does not reach setpoint instantly, and the
    integrated thermal exposure during the ramp is a real part of the roast.
    The model integrates over the ramp rather than assuming a step change.
    """

    name: str
    temperature_c: Celsius = Field(gt=60.0, le=200.0)
    duration_minutes: Minutes = Field(gt=0.0, le=180.0)
    ramp_minutes: Minutes = Field(
        default=6.0, ge=0.0, description="Time to reach setpoint from charge."
    )
    charge_temperature_c: Celsius = Field(default=20.0)
    airflow_factor: float = Field(
        default=1.0,
        gt=0.0,
        le=2.0,
        description="Relative convective airflow; raises drying rate and fan load.",
    )
    description: str = ""

    def temperature_at(self, minute: float) -> Celsius:
        """Bean temperature at a point in the roast.

        Linear ramp to setpoint, then hold. A real roaster's bean curve is
        exponential rather than linear, but the integrated exposure differs by
        only a few percent over a ramp this short, and the linear form keeps
        the profile interpretable.
        """
        if minute <= 0.0:
            return self.charge_temperature_c
        if self.ramp_minutes <= 0.0 or minute >= self.ramp_minutes:
            return self.temperature_c
        fraction = minute / self.ramp_minutes
        return self.charge_temperature_c + fraction * (
            self.temperature_c - self.charge_temperature_c
        )

    @property
    def total_minutes(self) -> Minutes:
        """Total roast time including the ramp."""
        return self.duration_minutes + self.ramp_minutes


#: Standard profiles. Roast A and Roast B are the pair from the ChocoSim brief.
ROAST_A = RoastProfile(
    name="Roast A",
    temperature_c=160.0,
    duration_minutes=25.0,
    ramp_minutes=6.0,
    description="Hot and short. Fast throughput, higher damage risk.",
)

ROAST_B = RoastProfile(
    name="Roast B",
    temperature_c=145.0,
    duration_minutes=35.0,
    ramp_minutes=7.0,
    description="Cooler and longer. Gentler development, lower throughput.",
)

ROAST_LOW_SLOW = RoastProfile(
    name="Low and Slow",
    temperature_c=130.0,
    duration_minutes=85.0,
    ramp_minutes=9.0,
    airflow_factor=0.85,
    description=(
        "Fine-flavour profile preserving delicate volatiles. The 85 minutes is "
        "not arbitrary: at 130 degC the Maillard rate is 2.4x slower than at "
        "145 degC, so reaching the same development takes 2.4x the time."
    ),
)

ROAST_HIGH_INTENSITY = RoastProfile(
    name="High Intensity",
    temperature_c=175.0,
    duration_minutes=16.0,
    ramp_minutes=5.0,
    airflow_factor=1.3,
    description="Maximum throughput. Expect flattened flavour.",
)

STANDARD_ROAST_PROFILES: tuple[RoastProfile, ...] = (
    ROAST_A,
    ROAST_B,
    ROAST_LOW_SLOW,
    ROAST_HIGH_INTENSITY,
)


class RoastOutcome(FrozenChocoModel):
    """The measurable result of a roast, independent of the stream plumbing."""

    profile_name: str
    charge_kg: Kilograms
    output_kg: Kilograms

    initial_moisture: float = Field(ge=0.0, le=1.0)
    final_moisture: float = Field(ge=0.0, le=1.0)
    water_removed_kg: Kilograms = Field(ge=0.0)
    volatiles_lost_kg: Kilograms = Field(ge=0.0)

    flavour_development: float = Field(ge=0.0)
    thermal_damage: float = Field(ge=0.0)
    peak_temperature_c: Celsius

    duration_minutes: Minutes = Field(ge=0.0)
    energy: EnergyUse
    mass_yield: float = Field(ge=0.0, le=1.0)

    @property
    def specific_energy_kwh_per_kg(self) -> KilowattHours:
        """Energy per kilogram of roasted bean produced."""
        return self.energy.per_kg(self.output_kg)

    @property
    def development_ratio(self) -> float:
        """Flavour development relative to the fully-developed target."""
        return self.flavour_development / FLAVOUR_TARGET

    @property
    def damage_ratio(self) -> float:
        """Thermal damage relative to flavour development.

        Below about 0.35 the roast is clean; above 0.6 the damage chemistry is
        outrunning the flavour chemistry and the cocoa will taste burnt.
        """
        if self.flavour_development <= 0.0:
            return float("inf") if self.thermal_damage > 0.0 else 0.0
        return self.thermal_damage / self.flavour_development

    @property
    def quality_index(self) -> float:
        """Composite roast quality, 0-100.

        Rewards reaching full development and penalises both under-development
        and damage. Under-roasting is penalised more gently than over-roasting
        because an under-developed bean can still be conched into something
        acceptable, whereas a burnt one cannot be recovered.
        """
        development = min(1.0, self.development_ratio)
        under_penalty = (1.0 - development) * 45.0
        damage_penalty = min(60.0, self.damage_ratio * 85.0)
        return max(0.0, 100.0 - under_penalty - damage_penalty)

    def describe(self) -> str:
        """Plain-text roast summary."""
        return "\n".join(
            [
                f"{self.profile_name.upper()}",
                f"  Charge              {self.charge_kg:,.1f} kg",
                f"  Output              {self.output_kg:,.1f} kg "
                f"(yield {self.mass_yield:.2%})",
                f"  Moisture            {self.initial_moisture:.2%} -> "
                f"{self.final_moisture:.2%}",
                f"  Water removed       {self.water_removed_kg:,.2f} kg",
                f"  Duration            {self.duration_minutes:.1f} min",
                f"  Energy              {self.energy.total_kwh:,.1f} kWh "
                f"({self.specific_energy_kwh_per_kg:.4f} kWh/kg)",
                f"  Development         {self.development_ratio:.3f}",
                f"  Damage ratio        {self.damage_ratio:.3f}",
                f"  Roast quality       {self.quality_index:.1f} / 100",
            ]
        )


class RoastingModel(ProcessStage):
    """Simulates bean roasting."""

    kind = ProcessStageKind.ROASTING
    accepts = (MaterialState.WHOLE_BEAN,)

    #: Integration step, minutes. Fine enough that halving it changes the
    #: result by well under a tenth of a percent, coarse enough to stay fast.
    TIME_STEP: Minutes = 0.25

    def __init__(
        self, config: ChocoSimConfig | None = None, profile: RoastProfile | None = None
    ) -> None:
        super().__init__(config)
        self.profile = profile or ROAST_B

    # ------------------------------------------------------------------
    # Kinetics
    # ------------------------------------------------------------------

    def integrate(
        self, profile: RoastProfile, initial_moisture: float
    ) -> tuple[float, float, float, np.ndarray]:
        """Integrate the roast kinetics.

        Returns final moisture, flavour development, thermal damage, and the
        per-step trajectory as an array of ``(minute, temperature, moisture)``.
        """
        steps = max(1, int(round(profile.total_minutes / self.TIME_STEP)))
        moisture = initial_moisture
        flavour = 0.0
        damage = 0.0
        trajectory = np.zeros((steps + 1, 3), dtype=float)
        trajectory[0] = (0.0, profile.temperature_at(0.0), moisture)

        for step in range(1, steps + 1):
            minute = step * self.TIME_STEP
            temperature = profile.temperature_at(minute)

            drying_k = (
                arrhenius_rate(
                    DRYING_PREEXPONENTIAL, DRYING_ACTIVATION_ENERGY, temperature
                )
                * profile.airflow_factor
            )
            emc = equilibrium_moisture(temperature)
            driving_force = max(0.0, moisture - emc)
            # Analytic step for the linear ODE: exact for constant temperature
            # over the step, and unconditionally stable, unlike explicit Euler
            # which oscillates once k*dt exceeds 2.
            moisture = emc + driving_force * math.exp(-drying_k * self.TIME_STEP)

            flavour += (
                arrhenius_rate(
                    FLAVOUR_PREEXPONENTIAL, FLAVOUR_ACTIVATION_ENERGY, temperature
                )
                * self.TIME_STEP
            )
            damage += (
                arrhenius_rate(
                    DAMAGE_PREEXPONENTIAL, DAMAGE_ACTIVATION_ENERGY, temperature
                )
                * self.TIME_STEP
            )
            trajectory[step] = (minute, temperature, moisture)

        return moisture, flavour, damage, trajectory

    # ------------------------------------------------------------------
    # Energy
    # ------------------------------------------------------------------

    def energy_for(
        self,
        profile: RoastProfile,
        charge_kg: Kilograms,
        water_removed_kg: Kilograms,
        initial_moisture: float,
    ) -> EnergyUse:
        """Energy to execute a roast.

        Three terms: sensible heat to raise the charge from ambient to
        setpoint, latent heat to evaporate the water removed, and mechanical
        work for the drum and fans.
        """
        dry_mass = charge_kg * (1.0 - initial_moisture)
        water_mass = charge_kg * initial_moisture
        delta_t = profile.temperature_c - profile.charge_temperature_c

        sensible = sensible_heat_kwh(dry_mass, CP_COCOA_BEAN, delta_t) + sensible_heat_kwh(
            water_mass, CP_WATER, delta_t
        )
        latent = latent_heat_kwh(water_removed_kg, LATENT_HEAT_VAPORISATION_WATER)

        thermal = heating_energy(
            sensible + latent, self.config.energy, EnergyCarrier.NATURAL_GAS
        )

        hours = minutes_to_hours(profile.total_minutes)
        shaft_kwh = (
            ROASTER_MECHANICAL_KW_PER_TONNE
            * (charge_kg / 1000.0)
            * hours
            * profile.airflow_factor
        )
        mechanical = mechanical_energy(shaft_kwh, self.config.energy)

        return thermal + mechanical

    # ------------------------------------------------------------------
    # Standalone roast evaluation
    # ------------------------------------------------------------------

    def roast(
        self,
        profile: RoastProfile,
        charge_kg: Kilograms,
        initial_moisture: float,
        source: RandomSource | None = None,
    ) -> RoastOutcome:
        """Evaluate a roast profile on a charge of beans.

        Usable without the full stream machinery, which is what makes profile
        comparison convenient.
        """
        if charge_kg <= 0.0:
            raise ValueError(f"charge mass must be positive, got {charge_kg}")

        source = source or RandomSource(self.config.simulation.seed)
        final_moisture, flavour, damage, _ = self.integrate(profile, initial_moisture)

        # Process variability: burner control, bean size distribution, loading.
        final_moisture *= self._noise(source, "moisture", 0.03)
        final_moisture = max(0.0, min(initial_moisture, final_moisture))
        flavour *= self._noise(source, "flavour", 0.04)
        damage *= self._noise(source, "damage", 0.06)

        water_removed = charge_kg * (initial_moisture - final_moisture)
        volatiles = charge_kg * (1.0 - initial_moisture) * VOLATILE_LOSS_FRACTION
        output = charge_kg - water_removed - volatiles

        energy = self.energy_for(profile, charge_kg, water_removed, initial_moisture)

        return RoastOutcome(
            profile_name=profile.name,
            charge_kg=charge_kg,
            output_kg=output,
            initial_moisture=initial_moisture,
            final_moisture=final_moisture,
            water_removed_kg=water_removed,
            volatiles_lost_kg=volatiles,
            flavour_development=flavour,
            thermal_damage=damage,
            peak_temperature_c=profile.temperature_c,
            duration_minutes=profile.total_minutes,
            energy=energy,
            mass_yield=output / charge_kg,
        )

    def compare_profiles(
        self,
        profiles: tuple[RoastProfile, ...],
        charge_kg: Kilograms = 1_000.0,
        initial_moisture: float = 0.070,
        source: RandomSource | None = None,
    ) -> list[RoastOutcome]:
        """Evaluate several profiles on an identical charge.

        Each profile draws from its own RNG path, so adding a profile to the
        comparison does not perturb the others' results.
        """
        source = source or RandomSource(self.config.simulation.seed)
        return [
            self.roast(
                profile, charge_kg, initial_moisture, source.child(f"compare/{profile.name}")
            )
            for profile in profiles
        ]

    # ------------------------------------------------------------------
    # Stage interface
    # ------------------------------------------------------------------

    def _run(
        self,
        stream: MaterialStream,
        recipe: Recipe,
        source: RandomSource,
        machine_id: str | None = None,
        **kwargs: Any,
    ) -> StageResult:
        profile: RoastProfile = kwargs.get("profile") or self.profile_for(recipe)
        outcome = self.roast(
            profile, stream.mass_kg, stream.composition.moisture, source
        )

        removed_fraction = (
            (outcome.water_removed_kg / stream.mass_kg) if stream.mass_kg > 0 else 0.0
        )
        composition = stream.composition.after_moisture_loss(removed_fraction)

        stream_out = stream.evolve(
            mass_kg=outcome.output_kg,
            composition=composition,
            temperature_c=profile.temperature_c,
            state=MaterialState.ROASTED_BEAN,
            flavour_development=stream.flavour_development + outcome.flavour_development,
            thermal_damage=stream.thermal_damage + outcome.thermal_damage,
        )

        balance = MassBalance(
            stage=self.kind.value,
            mass_in=stream.mass_kg,
            mass_out=outcome.output_kg,
            mass_loss=outcome.water_removed_kg + outcome.volatiles_lost_kg,
            mass_waste=0.0,
        )

        notes: list[str] = []
        if outcome.damage_ratio > 0.6:
            notes.append(
                f"Thermal damage ratio {outcome.damage_ratio:.2f}: roast is "
                "over-developed and will taste burnt."
            )
        if outcome.development_ratio < 0.7:
            notes.append(
                f"Development ratio {outcome.development_ratio:.2f}: roast is "
                "under-developed; expect raw and acidic notes."
            )
        if outcome.final_moisture > 0.030:
            notes.append(
                f"Residual moisture {outcome.final_moisture:.2%} is high; downstream "
                "grinding and conching will be harder."
            )

        return StageResult(
            stage=self.kind,
            machine_id=machine_id,
            stream_in=stream,
            stream_out=stream_out,
            mass_balance=balance,
            duration_minutes=profile.total_minutes,
            energy=outcome.energy,
            provenance=self._provenance(
                basis=(
                    "First-order falling-rate drying with Arrhenius kinetics; "
                    "separate Arrhenius terms for Maillard development and "
                    "thermal degradation"
                ),
                assumptions=(
                    "Bean temperature follows the air setpoint after a linear ramp",
                    "Drying is diffusion-limited throughout, with no constant-rate period",
                    "Equilibrium moisture follows a Henderson-type isotherm in "
                    "temperature only; ambient humidity is not modelled",
                    "Activation energies are literature-scale, not fitted to a roaster",
                ),
            ),
            metrics={
                "final_moisture": outcome.final_moisture,
                "water_removed_kg": outcome.water_removed_kg,
                "flavour_development": outcome.flavour_development,
                "thermal_damage": outcome.thermal_damage,
                "damage_ratio": outcome.damage_ratio,
                "roast_quality": outcome.quality_index,
                "peak_temperature_c": profile.temperature_c,
            },
            notes=tuple(notes),
        )

    def profile_for(self, recipe: Recipe) -> RoastProfile:
        """Build a roast profile from a recipe's process specification."""
        return RoastProfile(
            name=f"{recipe.recipe_id} roast",
            temperature_c=recipe.process.roast_temperature_c,
            duration_minutes=recipe.process.roast_minutes,
        )


def find_equivalent_profile(
    model: RoastingModel,
    reference: RoastProfile,
    temperature_c: Celsius,
    initial_moisture: float = 0.070,
    tolerance: float = 1e-3,
) -> RoastProfile:
    """Find the time at a new temperature giving equal flavour development.

    The classic roasting question: "I want to run 15 degrees hotter, how much
    time do I take out?" Solved by bisection on duration, since development is
    strictly increasing in time at fixed temperature.

    The equal-development profile is *not* an equal-quality profile: running
    hotter accumulates damage faster than development, so the equivalent roast
    will be worse. Comparing the two quality indices is the point.
    """
    _, target_flavour, _, _ = model.integrate(reference, initial_moisture)

    def development(duration: Minutes) -> float:
        candidate = reference.model_copy(
            update={"temperature_c": temperature_c, "duration_minutes": duration}
        )
        return model.integrate(candidate, initial_moisture)[1]

    low, high = 0.5, 180.0
    if development(high) < target_flavour:
        return reference.model_copy(
            update={"temperature_c": temperature_c, "duration_minutes": high}
        )
    if development(low) > target_flavour:
        return reference.model_copy(
            update={"temperature_c": temperature_c, "duration_minutes": low}
        )

    for _ in range(80):
        mid = 0.5 * (low + high)
        if abs(development(mid) - target_flavour) < tolerance * target_flavour:
            break
        if development(mid) < target_flavour:
            low = mid
        else:
            high = mid
    duration = 0.5 * (low + high)

    return reference.model_copy(
        update={
            "name": f"{reference.name} @ {temperature_c:.0f}C",
            "temperature_c": temperature_c,
            "duration_minutes": duration,
            "description": (
                f"Equal-development equivalent of {reference.name} "
                f"({reference.temperature_c:.0f}C / {reference.duration_minutes:.0f} min)"
            ),
        }
    )


__all__ = [
    "DAMAGE_ACTIVATION_ENERGY",
    "EMC_AMPLITUDE",
    "EMC_ASYMPTOTE",
    "DRYING_ACTIVATION_ENERGY",
    "FLAVOUR_ACTIVATION_ENERGY",
    "FLAVOUR_TARGET",
    "ROAST_A",
    "ROAST_B",
    "ROAST_HIGH_INTENSITY",
    "ROAST_LOW_SLOW",
    "STANDARD_ROAST_PROFILES",
    "RoastOutcome",
    "RoastProfile",
    "RoastingModel",
    "arrhenius_rate",
    "equilibrium_moisture",
    "find_equivalent_profile",
]
