"""The factory digital twin.

Ties every subsystem together into one object that can run a production
programme end to end: materials are drawn from inventory, batches go through
the process chain, quality is assessed, product is packed, costs are booked
and finished goods land in the warehouse.

This is the integration point the API, dashboard and optimiser all talk to. It
deliberately owns no physics of its own -- every number it reports comes from
a subsystem that computed it -- so that there is exactly one implementation of
each model and no opportunity for the twin's view of the factory to drift away
from the components' view.
"""

from __future__ import annotations

import datetime as dt
from collections.abc import Sequence

from pydantic import Field

from ..core.config import ChocoSimConfig
from ..core.fidelity import ModelProvenance
from ..core.models import FrozenChocoModel, safe_divide
from ..core.rng import RandomSource
from ..core.types import BatchId, Kilograms, Money, RecipeId
from ..economics.costing import BatchCosting, EconomicsEngine, ProfitAndLoss
from ..energy.model import EnergyUse, combine, site_overhead_energy
from ..ingredients.registry import IngredientRegistry, build_default_registry
from ..inventory.manager import InventoryManager
from ..packaging.formats import PackagingFormat, PackagingLine, PackagingRun, standard_formats
from ..processing.pipeline import ProcessChain, ProcessRun
from ..quality.scoring import QualityAssessment, QualityEngine
from ..recipes.engine import RecipeEngine
from ..recipes.library import RecipeBook, build_standard_book
from ..recipes.models import Recipe


class BatchOutcome(FrozenChocoModel):
    """Everything the factory produced and learned from one batch."""

    batch_id: BatchId
    recipe_id: RecipeId
    recipe_name: str
    produced_on: dt.date

    process: ProcessRun
    quality: QualityAssessment
    costing: BatchCosting
    packaging: PackagingRun | None = None

    material_shortfall_kg: dict[str, float] = Field(default_factory=dict)

    @property
    def saleable_kg(self) -> Kilograms:
        """First-quality mass produced."""
        return self.costing.saleable_mass_kg

    @property
    def cost_per_kg(self) -> Money:
        """Full cost per saleable kilogram."""
        return self.costing.cost_per_kg

    @property
    def energy_kwh_per_kg(self) -> float:
        """Process energy per kilogram of output."""
        return self.process.specific_energy_kwh_per_kg

    @property
    def units_produced(self) -> int:
        """Finished units, if the batch was packed."""
        return self.packaging.units_produced if self.packaging else 0

    def summary(self) -> str:
        """One-line batch summary in the style of a shift report."""
        return (
            f"{self.batch_id}  {self.recipe_name:<32} "
            f"{self.saleable_kg:>9,.1f} kg  "
            f"score {self.quality.overall_score:>5.1f}  "
            f"{self.quality.verdict.value:<8}  "
            f"{self.energy_kwh_per_kg:>6.3f} kWh/kg  "
            f"{self.costing.currency_symbol}{self.cost_per_kg:>7.4f}/kg"
        )


class FactoryState(FrozenChocoModel):
    """A snapshot of the factory."""

    as_of: dt.date
    batches_produced: int = Field(ge=0)
    produced_kg: Kilograms = Field(ge=0.0)
    saleable_kg: Kilograms = Field(ge=0.0)
    waste_kg: Kilograms = Field(ge=0.0)

    raw_material_kg: Kilograms = Field(ge=0.0)
    raw_material_value: Money = Field(ge=0.0)
    wip_kg: Kilograms = Field(ge=0.0)
    finished_goods_kg: Kilograms = Field(ge=0.0)
    finished_goods_value: Money = Field(ge=0.0)

    total_energy_kwh: float = Field(ge=0.0)
    energy_kwh_per_kg: float = Field(ge=0.0)
    mean_quality_score: float = Field(ge=0.0, le=100.0)
    pass_rate: float = Field(ge=0.0, le=1.0)
    waste_fraction: float = Field(ge=0.0, le=1.0)

    provenance: ModelProvenance

    def report(self) -> str:
        """Plain-text factory state."""
        return "\n".join(
            [
                f"FACTORY STATE -- {self.as_of.isoformat()}",
                "=" * 54,
                f"Batches produced      {self.batches_produced:>14,}",
                f"Produced              {self.produced_kg:>14,.1f} kg",
                f"Saleable              {self.saleable_kg:>14,.1f} kg",
                f"Waste                 {self.waste_kg:>14,.1f} kg "
                f"({self.waste_fraction:.2%})",
                "",
                f"Raw materials         {self.raw_material_kg:>14,.1f} kg",
                f"Work in progress      {self.wip_kg:>14,.1f} kg",
                f"Finished goods        {self.finished_goods_kg:>14,.1f} kg",
                "",
                f"Energy                {self.total_energy_kwh:>14,.1f} kWh",
                f"Energy intensity      {self.energy_kwh_per_kg:>14,.3f} kWh/kg",
                f"Mean quality score    {self.mean_quality_score:>14,.1f}",
                f"Pass rate             {self.pass_rate:>14.1%}",
            ]
        )


class Factory:
    """The digital twin of the chocolate factory."""

    def __init__(
        self,
        config: ChocoSimConfig | None = None,
        registry: IngredientRegistry | None = None,
        recipe_book: RecipeBook | None = None,
    ) -> None:
        self.config = config or ChocoSimConfig.default()
        self.registry = registry or build_default_registry()
        self.recipe_book = recipe_book or build_standard_book()

        self.recipe_engine = RecipeEngine(self.registry)
        self.chain = ProcessChain(self.registry, self.config)
        self.quality_engine = QualityEngine(self.config)
        self.economics_engine = EconomicsEngine(self.recipe_engine, self.config)
        self.inventory = InventoryManager(self.registry, self.config)
        self.packaging_line = PackagingLine(self.config)
        self.formats = {fmt.format_id: fmt for fmt in standard_formats()}

        self.outcomes: list[BatchOutcome] = []
        self.source = RandomSource(self.config.simulation.seed)

    # ------------------------------------------------------------------
    # Setup
    # ------------------------------------------------------------------

    def stock_up(
        self,
        on: dt.date,
        days_of_cover: float = 21.0,
        daily_demand_kg: Kilograms = 6_000.0,
    ) -> dict[str, Kilograms]:
        """Fill the raw material store to a target days of cover.

        Sized from the actual formulations in the recipe book rather than a
        flat quantity per ingredient, so a material used in one recipe at 1%
        does not get the same stock as sugar.
        """
        usage: dict[str, float] = {}
        recipes = self.recipe_book.current_recipes()
        for recipe in recipes:
            share = daily_demand_kg / max(len(recipes), 1)
            for component in recipe.components:
                usage[component.ingredient_id] = (
                    usage.get(component.ingredient_id, 0.0)
                    + component.mass_fraction * share
                )

        received: dict[str, Kilograms] = {}
        for ingredient_id, daily in usage.items():
            quantity = daily * days_of_cover
            if quantity <= 0.0:
                continue
            self.registry.create_lot(ingredient_id, quantity, on)
            self.inventory.policy_from_usage(ingredient_id, daily)
            received[ingredient_id] = quantity
        return received

    # ------------------------------------------------------------------
    # Production
    # ------------------------------------------------------------------

    def produce_batch(
        self,
        recipe: Recipe | RecipeId,
        batch_mass_kg: Kilograms | None = None,
        on: dt.date | None = None,
        pack_format_id: str | None = "PKG-BAR-100",
        consume_inventory: bool = True,
        daily_production_kg: Kilograms | None = None,
        hour_of_day: float | None = None,
    ) -> BatchOutcome:
        """Run one batch through the whole factory."""
        if isinstance(recipe, str):
            recipe = self.recipe_book.get(recipe)
        date = on or dt.date.today()
        mass = batch_mass_kg or recipe.default_batch_size_kg

        shortfalls: dict[str, float] = {}
        if consume_inventory:
            for requirement in self.recipe_engine.requirements(recipe, mass):
                _, shortfall = self.inventory.consume_raw(
                    requirement.ingredient_id,
                    requirement.required_kg,
                    date,
                    reference=recipe.recipe_id,
                )
                if shortfall > 1e-9:
                    shortfalls[requirement.ingredient_id] = shortfall

        run = self.chain.run(recipe, mass, self.source)
        assessment = self.quality_engine.assess(run, recipe, self.source)

        pack_format = self.formats.get(pack_format_id) if pack_format_id else None
        packaging_run: PackagingRun | None = None
        packaging_cost_per_kg = 0.0
        if pack_format is not None:
            packaging_run = self.packaging_line.pack(
                pack_format, assessment.saleable_kg, recipe.recipe_id
            )
            packaging_cost_per_kg = safe_divide(
                packaging_run.material_cost, assessment.saleable_kg
            )

        costing = self.economics_engine.cost_batch(
            run,
            recipe,
            assessment,
            packaging_cost_per_kg=packaging_cost_per_kg,
            daily_production_kg=daily_production_kg,
            hour_of_day=hour_of_day,
        )

        if costing.saleable_mass_kg > 0.0:
            try:
                self.inventory.receive_finished(
                    batch_id=run.batch_id,
                    recipe_id=recipe.recipe_id,
                    product_name=recipe.name,
                    quantity_kg=costing.saleable_mass_kg,
                    unit_cost=costing.cost_per_kg,
                    produced_on=date,
                    shelf_life_days=365,
                    quality_score=assessment.overall_score,
                )
            except Exception:
                # A full warehouse is a real operational constraint, not a
                # reason to lose the batch record. The outcome is still
                # returned; the caller decides what to do about the space.
                pass

        outcome = BatchOutcome(
            batch_id=run.batch_id,
            recipe_id=recipe.recipe_id,
            recipe_name=recipe.name,
            produced_on=date,
            process=run,
            quality=assessment,
            costing=costing,
            packaging=packaging_run,
            material_shortfall_kg=shortfalls,
        )
        self.outcomes.append(outcome)
        return outcome

    def produce_schedule(
        self,
        schedule: Sequence[tuple[RecipeId, Kilograms]],
        start_date: dt.date,
        batches_per_day: int = 4,
        pack_format_id: str | None = "PKG-BAR-100",
        consume_inventory: bool = True,
    ) -> list[BatchOutcome]:
        """Run a production programme over successive days."""
        daily_total = sum(mass for _, mass in schedule[:batches_per_day]) or 1.0
        outcomes: list[BatchOutcome] = []
        for index, (recipe_id, mass) in enumerate(schedule):
            date = start_date + dt.timedelta(days=index // max(batches_per_day, 1))
            outcomes.append(
                self.produce_batch(
                    recipe_id,
                    mass,
                    on=date,
                    pack_format_id=pack_format_id,
                    consume_inventory=consume_inventory,
                    daily_production_kg=daily_total,
                )
            )
        return outcomes

    # ------------------------------------------------------------------
    # State and reporting
    # ------------------------------------------------------------------

    def total_energy(self, include_site_overhead: bool = True) -> EnergyUse:
        """Energy consumed across all production so far."""
        total = combine(outcome.process.total_energy for outcome in self.outcomes)
        if include_site_overhead and self.outcomes:
            hours = sum(
                outcome.process.total_minutes for outcome in self.outcomes
            ) / 60.0
            total = total + site_overhead_energy(hours, self.config.energy)
        return total

    def state(self, as_of: dt.date | None = None) -> FactoryState:
        """Snapshot the factory."""
        date = as_of or dt.date.today()
        produced = sum(outcome.process.output_kg for outcome in self.outcomes)
        saleable = sum(outcome.saleable_kg for outcome in self.outcomes)
        waste = sum(outcome.process.waste_kg for outcome in self.outcomes)
        input_mass = sum(
            outcome.process.overall_balance.mass_in for outcome in self.outcomes
        )
        energy = self.total_energy()

        scores = [outcome.quality.overall_score for outcome in self.outcomes]
        passes = sum(
            1
            for outcome in self.outcomes
            if outcome.quality.verdict.value == "pass"
        )

        raw_summary = self.registry.stock_summary(date)
        raw_kg = sum(entry["total_kg"] for entry in raw_summary.values())

        return FactoryState(
            as_of=date,
            batches_produced=len(self.outcomes),
            produced_kg=produced,
            saleable_kg=saleable,
            waste_kg=waste,
            raw_material_kg=raw_kg,
            raw_material_value=self.registry.total_value(),
            wip_kg=self.inventory.total_wip_kg,
            finished_goods_kg=self.inventory.finished_goods_kg,
            finished_goods_value=self.inventory.finished_goods_value,
            total_energy_kwh=energy.total_kwh,
            energy_kwh_per_kg=safe_divide(energy.total_kwh, max(saleable, 1e-9)),
            mean_quality_score=sum(scores) / len(scores) if scores else 0.0,
            pass_rate=safe_divide(passes, len(self.outcomes)),
            waste_fraction=safe_divide(waste, max(input_mass, 1e-9)),
            provenance=ModelProvenance.combine(
                "factory_twin",
                [outcome.process.provenance for outcome in self.outcomes[:1]],
                basis="Aggregation of per-batch simulation outputs",
            ),
        )

    def profit_and_loss(
        self,
        period_days: float,
        average_price_per_kg: Money | None = None,
    ) -> ProfitAndLoss:
        """Period profit statement from the batches produced."""
        return self.economics_engine.profit_and_loss(
            [outcome.costing for outcome in self.outcomes],
            period_days=period_days,
            average_price_per_kg=average_price_per_kg,
            average_inventory_value=self.inventory.total_value(),
            stockout_kg=sum(self.inventory.stockout_kg.values()),
        )

    def production_report(self) -> str:
        """Plain-text production log."""
        if not self.outcomes:
            return "No batches produced."
        lines = [
            "PRODUCTION LOG",
            "=" * 108,
        ]
        lines += [outcome.summary() for outcome in self.outcomes]
        state = self.state()
        lines += [
            "-" * 108,
            f"{len(self.outcomes)} batches, {state.saleable_kg:,.1f} kg saleable, "
            f"mean score {state.mean_quality_score:.1f}, "
            f"pass rate {state.pass_rate:.1%}, "
            f"{state.energy_kwh_per_kg:.3f} kWh/kg",
        ]
        return "\n".join(lines)

    def reset(self) -> None:
        """Clear production history, keeping configuration and stock."""
        self.outcomes.clear()


__all__ = ["BatchOutcome", "Factory", "FactoryState"]
