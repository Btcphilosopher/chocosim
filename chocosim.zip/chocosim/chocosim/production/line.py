"""Discrete-event simulation of the production line.

The process chain in :mod:`chocosim.processing.pipeline` answers "what happens
to one batch". This module answers the different and harder question of what
happens when many batches contend for the same machines: where they queue, how
much time is lost to changeovers and breakdowns, and which asset is actually
constraining output.

Built on SimPy. Each machine is a resource; each batch is a process that
acquires stages in sequence. The things worth noting in the model:

**Queueing is measured, not assumed.** Waiting time is recorded per stage, so
the bottleneck is identified from where work actually piles up rather than
from a throughput calculation on paper. Those two answers differ once
changeovers and failures enter, which is the entire reason to run a DES.

**Changeovers depend on sequence.** The cost of running batch B depends on
what ran before it on that machine, so the schedule order matters and the
optimiser has something real to optimise.

**Batch machines block.** A conche holds its charge for the full cycle
regardless of size, so a small batch wastes the same asset-hours as a large
one. This is what makes campaign scheduling worth doing.
"""

from __future__ import annotations

from collections.abc import Sequence
from dataclasses import dataclass, field

import simpy
from pydantic import Field

from ..core.config import ChocoSimConfig
from ..core.models import FrozenChocoModel, safe_divide
from ..core.rng import RandomSource
from ..core.types import (
    BatchId,
    Kilograms,
    MachineId,
    Minutes,
    ProcessStageKind,
    RecipeId,
    next_id,
)
from ..recipes.models import Recipe
from .machines import Machine, MachineSpec, default_machine_specs

#: Stages a batch passes through on the line, in order. Bean-front-end stages
#: are included only when the recipe requires them.
FULL_STAGE_SEQUENCE: tuple[ProcessStageKind, ...] = (
    ProcessStageKind.ROASTING,
    ProcessStageKind.WINNOWING,
    ProcessStageKind.GRINDING,
    ProcessStageKind.MIXING,
    ProcessStageKind.REFINING,
    ProcessStageKind.CONCHING,
    ProcessStageKind.TEMPERING,
    ProcessStageKind.MOULDING,
    ProcessStageKind.COOLING,
    ProcessStageKind.PACKAGING,
)

#: Stages for a recipe starting from bought-in liquor.
LIQUOR_STAGE_SEQUENCE: tuple[ProcessStageKind, ...] = FULL_STAGE_SEQUENCE[3:]


@dataclass
class BatchOrder:
    """A batch queued for production."""

    batch_id: BatchId
    recipe: Recipe
    mass_kg: Kilograms
    release_minute: float = 0.0
    priority: int = 0
    requires_bean_line: bool = False

    @property
    def stages(self) -> tuple[ProcessStageKind, ...]:
        """The stage sequence this batch needs."""
        return (
            FULL_STAGE_SEQUENCE if self.requires_bean_line else LIQUOR_STAGE_SEQUENCE
        )


@dataclass
class StageTiming:
    """Recorded timings for one batch at one stage."""

    stage: ProcessStageKind
    machine_id: MachineId
    arrived_minute: float
    started_minute: float
    finished_minute: float
    changeover_minutes: float = 0.0
    downtime_minutes: float = 0.0

    @property
    def wait_minutes(self) -> float:
        """Time spent queueing before the machine was free."""
        return max(0.0, self.started_minute - self.arrived_minute)

    @property
    def processing_minutes(self) -> float:
        """Time spent on the machine, excluding queueing."""
        return max(0.0, self.finished_minute - self.started_minute)


@dataclass
class BatchRecord:
    """Everything that happened to one batch on the line."""

    batch_id: BatchId
    recipe_id: RecipeId
    mass_kg: Kilograms
    released_minute: float
    completed_minute: float = 0.0
    timings: list[StageTiming] = field(default_factory=list)

    @property
    def cycle_time_minutes(self) -> float:
        """Total time from release to completion."""
        return max(0.0, self.completed_minute - self.released_minute)

    @property
    def total_wait_minutes(self) -> float:
        """Total time spent queueing across all stages."""
        return sum(timing.wait_minutes for timing in self.timings)

    @property
    def total_processing_minutes(self) -> float:
        """Total time spent on machines."""
        return sum(timing.processing_minutes for timing in self.timings)

    @property
    def flow_efficiency(self) -> float:
        """Share of cycle time spent actually being processed.

        Rarely above 50% on a real line, and the gap is where the money is.
        """
        return safe_divide(self.total_processing_minutes, self.cycle_time_minutes)


class StageStatistics(FrozenChocoModel):
    """Aggregate statistics for one stage across a run."""

    stage: ProcessStageKind
    machine_id: MachineId
    batches: int = Field(ge=0)
    processed_kg: Kilograms = Field(ge=0.0)
    busy_minutes: float = Field(ge=0.0)
    wait_minutes: float = Field(ge=0.0)
    changeover_minutes: float = Field(ge=0.0)
    downtime_minutes: float = Field(ge=0.0)
    horizon_minutes: float = Field(
        gt=0.0, description="Wall-clock length of the run, minutes."
    )
    parallel_units: int = Field(default=1, ge=1)
    breakdowns: int = Field(ge=0)

    @property
    def machine_minutes_available(self) -> float:
        """Total machine-minutes available: wall-clock time times units.

        Utilisation must be measured against this rather than wall-clock time,
        or a machine with four parallel units running flat out would report
        400% utilised.
        """
        return self.horizon_minutes * self.parallel_units

    @property
    def utilisation(self) -> float:
        """Share of available machine time spent processing."""
        return safe_divide(self.busy_minutes, self.machine_minutes_available)

    @property
    def availability(self) -> float:
        """Share of available machine time the machine was fit to run."""
        available = self.machine_minutes_available
        return safe_divide(available - self.downtime_minutes, available)

    @property
    def changeover_share(self) -> float:
        """Share of available machine time lost to changeovers."""
        return safe_divide(self.changeover_minutes, self.machine_minutes_available)

    @property
    def mean_wait_minutes(self) -> float:
        """Average queueing time per batch at this stage."""
        return safe_divide(self.wait_minutes, self.batches)

    @property
    def throughput_kg_per_hour(self) -> float:
        """Realised throughput over the run.

        Divided by wall-clock time, not machine-time: the line delivers
        kilograms per hour of elapsed time regardless of how many units it
        used to do it.
        """
        return safe_divide(self.processed_kg * 60.0, self.horizon_minutes)


class LineRunResult(FrozenChocoModel):
    """Result of a discrete-event production run."""

    horizon_minutes: float = Field(gt=0.0)
    batches_released: int = Field(ge=0)
    batches_completed: int = Field(ge=0)
    produced_kg: Kilograms = Field(ge=0.0)
    stage_statistics: tuple[StageStatistics, ...]
    mean_cycle_time_minutes: float = Field(ge=0.0)
    mean_wait_minutes: float = Field(ge=0.0)
    mean_flow_efficiency: float = Field(ge=0.0, le=1.0)
    total_changeover_minutes: float = Field(ge=0.0)
    total_downtime_minutes: float = Field(ge=0.0)

    @property
    def completion_rate(self) -> float:
        """Share of released batches that finished within the horizon."""
        return safe_divide(self.batches_completed, self.batches_released)

    @property
    def throughput_kg_per_hour(self) -> float:
        """Realised line throughput."""
        return safe_divide(self.produced_kg * 60.0, self.horizon_minutes)

    def bottleneck(self) -> StageStatistics | None:
        """The stage constraining the line.

        Identified by utilisation, with queueing as the tie-break. A machine
        can be highly utilised without being the constraint if nothing waits
        for it, so both signals are needed.
        """
        if not self.stage_statistics:
            return None
        return max(
            self.stage_statistics,
            key=lambda stat: (stat.utilisation, stat.mean_wait_minutes),
        )

    def utilisation_by_stage(self) -> dict[str, float]:
        """Utilisation of every stage, highest first."""
        return dict(
            sorted(
                ((stat.stage.value, stat.utilisation) for stat in self.stage_statistics),
                key=lambda item: -item[1],
            )
        )

    def report(self) -> str:
        """Plain-text line performance report."""
        lines = [
            "PRODUCTION LINE SIMULATION",
            "=" * 82,
            f"Horizon            {self.horizon_minutes / 60.0:,.1f} h",
            f"Batches            {self.batches_completed} of "
            f"{self.batches_released} completed ({self.completion_rate:.1%})",
            f"Produced           {self.produced_kg:,.1f} kg "
            f"({self.throughput_kg_per_hour:,.1f} kg/h)",
            f"Mean cycle time    {self.mean_cycle_time_minutes / 60.0:,.2f} h",
            f"Mean queueing      {self.mean_wait_minutes / 60.0:,.2f} h",
            f"Flow efficiency    {self.mean_flow_efficiency:.1%}",
            "",
            f"{'STAGE':<12}{'UNITS':>7}{'BATCHES':>9}{'UTIL':>8}"
            f"{'WAIT h':>9}{'C/O h':>8}{'DOWN h':>9}{'BRK':>5}{'kg/h':>10}",
            "-" * 82,
        ]
        for stat in self.stage_statistics:
            lines.append(
                f"{stat.stage.value:<12}"
                f"{stat.parallel_units:>7}"
                f"{stat.batches:>9}"
                f"{stat.utilisation:>8.1%}"
                f"{stat.mean_wait_minutes / 60.0:>9.2f}"
                f"{stat.changeover_minutes / 60.0:>8.1f}"
                f"{stat.downtime_minutes / 60.0:>9.1f}"
                f"{stat.breakdowns:>5}"
                f"{stat.throughput_kg_per_hour:>10.0f}"
            )
        bottleneck = self.bottleneck()
        if bottleneck is not None:
            lines += [
                "-" * 82,
                f"BOTTLENECK: {bottleneck.stage.value.upper()} "
                f"({bottleneck.utilisation:.1%} utilised, "
                f"{bottleneck.mean_wait_minutes / 60.0:.2f} h mean queue)",
            ]
        return "\n".join(lines)


class ProductionLine:
    """Discrete-event model of a production line."""

    def __init__(
        self,
        specs: Sequence[MachineSpec] | None = None,
        config: ChocoSimConfig | None = None,
    ) -> None:
        self.config = config or ChocoSimConfig.default()
        self.machines: dict[ProcessStageKind, Machine] = {}
        for spec in specs or default_machine_specs():
            self.machines[spec.stage] = Machine(spec, self.config)

    def machine_for(self, stage: ProcessStageKind) -> Machine | None:
        """The machine serving a stage."""
        return self.machines.get(stage)

    def nominal_capacity_kg_per_hour(
        self, stages: Sequence[ProcessStageKind] | None = None
    ) -> float:
        """Line capacity ignoring changeovers, failures and queueing.

        The paper number. Comparing it against the simulated throughput is the
        point: the gap is what scheduling and reliability actually cost.
        """
        sequence = stages or LIQUOR_STAGE_SEQUENCE
        rates = [
            self.machines[stage].spec.effective_throughput_kg_per_hour
            for stage in sequence
            if stage in self.machines
        ]
        positive = [rate for rate in rates if rate > 0.0]
        return min(positive) if positive else 0.0

    def theoretical_bottleneck(
        self, stages: Sequence[ProcessStageKind] | None = None
    ) -> tuple[ProcessStageKind | None, float]:
        """The slowest machine on paper, and its rate."""
        sequence = stages or LIQUOR_STAGE_SEQUENCE
        candidates = [
            (stage, self.machines[stage].spec.effective_throughput_kg_per_hour)
            for stage in sequence
            if stage in self.machines
            and self.machines[stage].spec.effective_throughput_kg_per_hour > 0.0
        ]
        if not candidates:
            return (None, 0.0)
        return min(candidates, key=lambda item: item[1])

    # ------------------------------------------------------------------
    # Simulation
    # ------------------------------------------------------------------

    def simulate(
        self,
        orders: Sequence[BatchOrder],
        horizon_minutes: float,
        source: RandomSource | None = None,
    ) -> LineRunResult:
        """Run the discrete-event simulation."""
        if horizon_minutes <= 0.0:
            raise ValueError("horizon must be positive")

        source = source or RandomSource(self.config.simulation.seed)
        env = simpy.Environment()

        resources: dict[ProcessStageKind, simpy.Resource] = {}
        for stage, machine in self.machines.items():
            resources[stage] = simpy.Resource(
                env, capacity=machine.spec.parallel_units
            )
            machine.status.busy_minutes = 0.0
            machine.status.down_minutes = 0.0
            machine.status.changeover_minutes = 0.0
            machine.status.processed_kg = 0.0
            machine.status.breakdown_count = 0
            machine.status.current_recipe_id = None

        records: dict[BatchId, BatchRecord] = {}
        stage_batches: dict[ProcessStageKind, int] = {
            stage: 0 for stage in self.machines
        }
        stage_waits: dict[ProcessStageKind, float] = {
            stage: 0.0 for stage in self.machines
        }

        def process_batch(order: BatchOrder):
            """SimPy process for one batch moving down the line."""
            yield env.timeout(max(0.0, order.release_minute - env.now))
            record = BatchRecord(
                batch_id=order.batch_id,
                recipe_id=order.recipe.recipe_id,
                mass_kg=order.mass_kg,
                released_minute=env.now,
            )
            records[order.batch_id] = record

            allergens = tuple(
                sorted(
                    {
                        allergen
                        for allergen in getattr(order.recipe, "_allergens", ())
                    }
                )
            )

            for stage in order.stages:
                machine = self.machines.get(stage)
                resource = resources.get(stage)
                if machine is None or resource is None:
                    continue

                arrived = env.now
                with resource.request() as request:
                    yield request
                    started = env.now
                    wait = started - arrived
                    stage_waits[stage] += wait
                    stage_batches[stage] += 1

                    changeover = 0.0
                    if self.config.simulation.enable_changeovers:
                        changeover = machine.apply_changeover(
                            order.recipe.recipe_id,
                            order.recipe.chocolate_type,
                            allergens,
                        )
                        if changeover > 0.0:
                            yield env.timeout(changeover)

                    processing = machine.spec.processing_minutes(order.mass_kg)

                    downtime = 0.0
                    if machine.will_fail_during(processing / 60.0, source):
                        downtime = machine.repair_minutes(source)
                        machine.record_downtime(downtime)
                        yield env.timeout(downtime)

                    yield env.timeout(processing)
                    machine.record_run(processing, order.mass_kg)

                    record.timings.append(
                        StageTiming(
                            stage=stage,
                            machine_id=machine.spec.machine_id,
                            arrived_minute=arrived,
                            started_minute=started,
                            finished_minute=env.now,
                            changeover_minutes=changeover,
                            downtime_minutes=downtime,
                        )
                    )

            record.completed_minute = env.now

        for order in orders:
            env.process(process_batch(order))

        env.run(until=horizon_minutes)

        completed = [
            record
            for record in records.values()
            if record.completed_minute > 0.0
            and len(record.timings) == len(FULL_STAGE_SEQUENCE)
            or (
                record.completed_minute > 0.0
                and len(record.timings) == len(LIQUOR_STAGE_SEQUENCE)
            )
        ]
        produced = sum(record.mass_kg for record in completed)

        statistics = tuple(
            StageStatistics(
                stage=stage,
                machine_id=machine.spec.machine_id,
                batches=stage_batches[stage],
                processed_kg=machine.status.processed_kg,
                busy_minutes=machine.status.busy_minutes,
                wait_minutes=stage_waits[stage],
                changeover_minutes=machine.status.changeover_minutes,
                downtime_minutes=machine.status.down_minutes,
                horizon_minutes=horizon_minutes,
                parallel_units=machine.spec.parallel_units,
                breakdowns=machine.status.breakdown_count,
            )
            for stage, machine in self.machines.items()
            if stage_batches[stage] > 0
        )

        mean_cycle = (
            sum(record.cycle_time_minutes for record in completed) / len(completed)
            if completed
            else 0.0
        )
        mean_wait = (
            sum(record.total_wait_minutes for record in completed) / len(completed)
            if completed
            else 0.0
        )
        mean_efficiency = (
            sum(record.flow_efficiency for record in completed) / len(completed)
            if completed
            else 0.0
        )

        return LineRunResult(
            horizon_minutes=horizon_minutes,
            batches_released=len(orders),
            batches_completed=len(completed),
            produced_kg=produced,
            stage_statistics=statistics,
            mean_cycle_time_minutes=mean_cycle,
            mean_wait_minutes=mean_wait,
            mean_flow_efficiency=min(1.0, mean_efficiency),
            total_changeover_minutes=sum(
                machine.status.changeover_minutes for machine in self.machines.values()
            ),
            total_downtime_minutes=sum(
                machine.status.down_minutes for machine in self.machines.values()
            ),
        )


def build_orders(
    recipes: Sequence[Recipe],
    batch_count: int,
    mass_kg: Kilograms | None = None,
    release_interval_minutes: float = 0.0,
    bean_recipes: frozenset[str] = frozenset(),
) -> list[BatchOrder]:
    """Build a round-robin sequence of batch orders.

    Round-robin deliberately: it is the *worst* case for changeovers, so it
    gives the scheduling optimiser something obvious to improve on.
    """
    orders: list[BatchOrder] = []
    for index in range(batch_count):
        recipe = recipes[index % len(recipes)]
        orders.append(
            BatchOrder(
                batch_id=next_id("BATCH", width=4),
                recipe=recipe,
                mass_kg=mass_kg or recipe.default_batch_size_kg,
                release_minute=index * release_interval_minutes,
                requires_bean_line=recipe.recipe_id in bean_recipes,
            )
        )
    return orders


__all__ = [
    "FULL_STAGE_SEQUENCE",
    "LIQUOR_STAGE_SEQUENCE",
    "BatchOrder",
    "BatchRecord",
    "LineRunResult",
    "ProductionLine",
    "StageStatistics",
    "StageTiming",
    "build_orders",
]
