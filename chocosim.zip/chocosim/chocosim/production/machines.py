"""Machines: capacity, reliability and changeovers.

A machine in ChocoSim is defined by what limits it. Some stages are
rate-limited (a refiner processes so many kilograms per hour, indefinitely);
others are batch-limited (a conche holds a charge for a fixed time regardless
of how much is in it). Modelling both correctly matters because they respond
to batch size in opposite directions: doubling the batch halves the specific
changeover cost on a batch machine but does nothing at all for a continuous
one.

Reliability uses a Weibull time-to-failure. The shape parameter distinguishes
infant mortality (below 1), constant hazard (equal to 1) and wear-out (above
1); food plant equipment typically sits between 1.2 and 2.0, so a machine that
has been running a while is *more* likely to fail, not less, which is what
makes preventive maintenance worth scheduling.
"""

from __future__ import annotations

from collections.abc import Sequence

from pydantic import Field

from ..core.config import ChocoSimConfig
from ..core.models import ChocoModel, FrozenChocoModel, safe_divide
from ..core.rng import RandomSource, weibull_time_to_failure
from ..core.types import (
    ChocolateType,
    Kilograms,
    MachineClass,
    MachineId,
    MachineState,
    Minutes,
    ProcessStageKind,
)


class MachineSpec(FrozenChocoModel):
    """Static specification of a machine."""

    machine_id: MachineId
    name: str
    machine_class: MachineClass
    stage: ProcessStageKind

    #: Continuous throughput, kg/h. Zero for pure batch machines.
    throughput_kg_per_hour: float = Field(default=0.0, ge=0.0)
    #: Batch capacity, kg. Zero for pure continuous machines.
    batch_capacity_kg: Kilograms = Field(default=0.0, ge=0.0)
    #: Fixed cycle time for a batch machine, minutes.
    batch_cycle_minutes: Minutes = Field(default=0.0, ge=0.0)

    rated_power_kw: float = Field(default=0.0, ge=0.0)

    #: Weibull scale (characteristic life) in operating hours.
    mtbf_hours: float = Field(default=420.0, gt=0.0)
    #: Weibull shape. Above 1 means wear-out.
    failure_shape: float = Field(default=1.6, gt=0.0)
    #: Mean time to repair, minutes.
    mttr_minutes: Minutes = Field(default=45.0, ge=0.0)

    capital_cost: float = Field(default=0.0, ge=0.0)
    parallel_units: int = Field(default=1, ge=1)

    @property
    def is_batch(self) -> bool:
        """Whether this machine processes discrete charges."""
        return self.batch_capacity_kg > 0.0

    @property
    def effective_throughput_kg_per_hour(self) -> float:
        """Throughput including parallel units.

        For a batch machine this is derived from capacity and cycle time,
        which is the only fair way to compare a conche against a refiner.
        """
        if self.is_batch:
            if self.batch_cycle_minutes <= 0.0:
                return 0.0
            per_unit = self.batch_capacity_kg / (self.batch_cycle_minutes / 60.0)
        else:
            per_unit = self.throughput_kg_per_hour
        return per_unit * self.parallel_units

    def processing_minutes(self, mass_kg: Kilograms) -> Minutes:
        """Time to process a quantity of material.

        A batch machine takes its cycle time however little is in it, and needs
        several cycles for more than one charge. That step function is exactly
        why batch sizing is an optimisation problem rather than an arithmetic
        one.
        """
        if mass_kg <= 0.0:
            return 0.0
        if self.is_batch:
            charges = max(1, -(-mass_kg // self.batch_capacity_kg))
            return self.batch_cycle_minutes * charges / self.parallel_units
        if self.throughput_kg_per_hour <= 0.0:
            return 0.0
        return mass_kg / self.throughput_kg_per_hour * 60.0 / self.parallel_units


class MachineStatus(ChocoModel):
    """Mutable running state of a machine."""

    machine_id: MachineId
    state: MachineState = MachineState.IDLE
    current_recipe_id: str | None = None
    current_type: ChocolateType | None = None
    current_allergens: tuple[str, ...] = ()

    operating_hours: float = 0.0
    hours_since_maintenance: float = 0.0
    processed_kg: Kilograms = 0.0

    busy_minutes: float = 0.0
    idle_minutes: float = 0.0
    down_minutes: float = 0.0
    changeover_minutes: float = 0.0
    breakdown_count: int = 0

    @property
    def total_minutes(self) -> float:
        """Total elapsed minutes accounted for."""
        return (
            self.busy_minutes
            + self.idle_minutes
            + self.down_minutes
            + self.changeover_minutes
        )

    @property
    def utilisation(self) -> float:
        """Share of elapsed time spent actually processing material."""
        return safe_divide(self.busy_minutes, self.total_minutes)

    @property
    def availability(self) -> float:
        """Share of elapsed time the machine was fit to run."""
        return safe_divide(
            self.total_minutes - self.down_minutes, self.total_minutes
        )


class Machine:
    """A machine with capacity, state and failure behaviour."""

    def __init__(
        self,
        spec: MachineSpec,
        config: ChocoSimConfig | None = None,
    ) -> None:
        self.spec = spec
        self.config = config or ChocoSimConfig.default()
        self.status = MachineStatus(machine_id=spec.machine_id)
        self._time_to_failure: float | None = None

    # ------------------------------------------------------------------
    # Changeovers
    # ------------------------------------------------------------------

    def changeover_minutes(
        self,
        to_recipe_id: str,
        to_type: ChocolateType,
        to_allergens: Sequence[str],
    ) -> Minutes:
        """Time to switch this machine to a different product.

        Three tiers, in increasing cost: same recipe is free, same chocolate
        type is a rinse, a different type is a full clean. An allergen
        introduction forces the longest changeover regardless of type, because
        the line has to be cleaned to a different standard.

        Note the asymmetry: going *from* an allergen product *to* a clean one
        requires the full wet clean; the reverse does not. Modelling that
        asymmetry is what lets the scheduler discover that grouping allergen
        products together at the end of a run is worth real money.
        """
        factory = self.config.factory
        if self.status.current_recipe_id is None:
            return 0.0
        if self.status.current_recipe_id == to_recipe_id:
            return 0.0

        incoming = set(to_allergens)
        outgoing = set(self.status.current_allergens)
        if outgoing - incoming:
            return factory.allergen_changeover_minutes

        if self.status.current_type is not None and self.status.current_type != to_type:
            return factory.changeover_minutes_different_type
        return factory.changeover_minutes_same_type

    def apply_changeover(
        self,
        to_recipe_id: str,
        to_type: ChocolateType,
        to_allergens: Sequence[str],
    ) -> Minutes:
        """Perform a changeover and return the time it cost."""
        minutes = self.changeover_minutes(to_recipe_id, to_type, to_allergens)
        self.status.current_recipe_id = to_recipe_id
        self.status.current_type = to_type
        self.status.current_allergens = tuple(to_allergens)
        self.status.changeover_minutes += minutes
        return minutes

    # ------------------------------------------------------------------
    # Reliability
    # ------------------------------------------------------------------

    def next_failure_hours(self, source: RandomSource) -> float:
        """Draw the operating hours until the next failure."""
        if not self.config.simulation.enable_breakdowns:
            return float("inf")
        generator = source.generator(f"machine/{self.spec.machine_id}/failure")
        return weibull_time_to_failure(
            generator, self.spec.mtbf_hours, self.spec.failure_shape
        )

    def repair_minutes(self, source: RandomSource) -> Minutes:
        """Draw a repair duration.

        Lognormal rather than exponential: most repairs are quick and a few
        are catastrophic, and an exponential understates that tail.
        """
        if self.spec.mttr_minutes <= 0.0:
            return 0.0
        if self.config.simulation.deterministic:
            return self.spec.mttr_minutes
        from ..core.rng import lognormal_from_moments

        generator = source.generator(f"machine/{self.spec.machine_id}/repair")
        return float(lognormal_from_moments(generator, self.spec.mttr_minutes, 0.55))

    def will_fail_during(self, hours: float, source: RandomSource) -> bool:
        """Whether the machine fails during the next block of running.

        Consumes the drawn time-to-failure so that failures are correlated
        with accumulated running rather than redrawn independently each time,
        which would erase the wear-out behaviour the Weibull shape encodes.
        """
        if not self.config.simulation.enable_breakdowns or hours <= 0.0:
            return False
        if self._time_to_failure is None:
            self._time_to_failure = self.next_failure_hours(source)
        self._time_to_failure -= hours
        if self._time_to_failure <= 0.0:
            self._time_to_failure = None
            return True
        return False

    def record_run(self, minutes: Minutes, mass_kg: Kilograms) -> None:
        """Record a period of productive running."""
        self.status.busy_minutes += minutes
        self.status.operating_hours += minutes / 60.0
        self.status.hours_since_maintenance += minutes / 60.0
        self.status.processed_kg += mass_kg

    def record_downtime(self, minutes: Minutes) -> None:
        """Record a breakdown."""
        self.status.down_minutes += minutes
        self.status.breakdown_count += 1

    def record_idle(self, minutes: Minutes) -> None:
        """Record idle time."""
        self.status.idle_minutes += minutes

    def maintain(self) -> None:
        """Reset the maintenance clock."""
        self.status.hours_since_maintenance = 0.0
        self._time_to_failure = None

    def __repr__(self) -> str:
        return (
            f"Machine({self.spec.machine_id}, {self.spec.stage.value}, "
            f"{self.spec.effective_throughput_kg_per_hour:.0f} kg/h)"
        )


def default_machine_specs() -> tuple[MachineSpec, ...]:
    """A balanced-ish factory whose bottleneck is the conche.

    Deliberately configured so that conching limits the line, because that is
    both realistic and the interesting case: the conche is the slowest and
    least flexible asset in a chocolate factory, and almost every capacity
    decision in the industry comes back to it.
    """
    return (
        MachineSpec(
            machine_id="MCH-ROAST-01",
            name="Drum Roaster 1",
            machine_class=MachineClass.ROASTER,
            stage=ProcessStageKind.ROASTING,
            batch_capacity_kg=900.0,
            batch_cycle_minutes=48.0,
            rated_power_kw=180.0,
            mtbf_hours=520.0,
            failure_shape=1.5,
            mttr_minutes=55.0,
            capital_cost=185_000.0,
        ),
        MachineSpec(
            machine_id="MCH-WINNOW-01",
            name="Winnower 1",
            machine_class=MachineClass.WINNOWER,
            stage=ProcessStageKind.WINNOWING,
            throughput_kg_per_hour=2_500.0,
            rated_power_kw=22.0,
            mtbf_hours=760.0,
            mttr_minutes=30.0,
            capital_cost=62_000.0,
        ),
        MachineSpec(
            machine_id="MCH-MILL-01",
            name="Liquor Mill 1",
            machine_class=MachineClass.GRINDER,
            stage=ProcessStageKind.GRINDING,
            throughput_kg_per_hour=1_800.0,
            rated_power_kw=145.0,
            mtbf_hours=610.0,
            failure_shape=1.7,
            mttr_minutes=70.0,
            capital_cost=210_000.0,
        ),
        MachineSpec(
            machine_id="MCH-MIX-01",
            name="Horizontal Mixer 1",
            machine_class=MachineClass.MIXER,
            stage=ProcessStageKind.MIXING,
            throughput_kg_per_hour=4_000.0,
            rated_power_kw=45.0,
            mtbf_hours=900.0,
            mttr_minutes=25.0,
            capital_cost=48_000.0,
        ),
        MachineSpec(
            machine_id="MCH-REFINE-01",
            name="Five-Roll Refiner 1",
            machine_class=MachineClass.REFINER,
            stage=ProcessStageKind.REFINING,
            throughput_kg_per_hour=1_200.0,
            rated_power_kw=200.0,
            mtbf_hours=480.0,
            failure_shape=1.8,
            mttr_minutes=95.0,
            capital_cost=340_000.0,
            parallel_units=2,
        ),
        MachineSpec(
            machine_id="MCH-CONCHE-01",
            name="Conche Bank",
            machine_class=MachineClass.CONCHE,
            stage=ProcessStageKind.CONCHING,
            batch_capacity_kg=2_500.0,
            batch_cycle_minutes=1_440.0,
            rated_power_kw=160.0,
            mtbf_hours=1_400.0,
            failure_shape=1.3,
            mttr_minutes=120.0,
            capital_cost=520_000.0,
            parallel_units=4,
        ),
        MachineSpec(
            machine_id="MCH-TEMPER-01",
            name="Continuous Temperer 1",
            machine_class=MachineClass.TEMPERER,
            stage=ProcessStageKind.TEMPERING,
            throughput_kg_per_hour=2_200.0,
            rated_power_kw=38.0,
            mtbf_hours=640.0,
            mttr_minutes=50.0,
            capital_cost=125_000.0,
        ),
        MachineSpec(
            machine_id="MCH-MOULD-01",
            name="Moulding Line 1",
            machine_class=MachineClass.MOULDER,
            stage=ProcessStageKind.MOULDING,
            throughput_kg_per_hour=1_600.0,
            rated_power_kw=64.0,
            mtbf_hours=390.0,
            failure_shape=1.4,
            mttr_minutes=40.0,
            capital_cost=410_000.0,
        ),
        MachineSpec(
            machine_id="MCH-TUNNEL-01",
            name="Cooling Tunnel 1",
            machine_class=MachineClass.COOLING_TUNNEL,
            stage=ProcessStageKind.COOLING,
            throughput_kg_per_hour=1_600.0,
            rated_power_kw=88.0,
            mtbf_hours=1_100.0,
            mttr_minutes=35.0,
            capital_cost=290_000.0,
        ),
        MachineSpec(
            machine_id="MCH-WRAP-01",
            name="Flow Wrapper 1",
            machine_class=MachineClass.PACKAGING_LINE,
            stage=ProcessStageKind.PACKAGING,
            throughput_kg_per_hour=1_500.0,
            rated_power_kw=32.0,
            mtbf_hours=300.0,
            failure_shape=1.2,
            mttr_minutes=28.0,
            capital_cost=175_000.0,
            parallel_units=2,
        ),
    )


__all__ = [
    "Machine",
    "MachineSpec",
    "MachineStatus",
    "default_machine_specs",
]
