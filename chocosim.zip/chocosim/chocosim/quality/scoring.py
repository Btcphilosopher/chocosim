"""Quality engine.

Produces the 0-100 batch score the specification calls for, but does so in a
way that can be argued with: every point lost is attributable to a named
metric, and every metric is scored against the recipe's own specification
rather than a global standard.

The scoring curve matters. A metric inside specification scores 100. Outside
it, the score falls as a power of the normalised deviation, with an exponent
above 1 so that being wildly out is punished disproportionately compared with
being marginally out. That is how sensory panels behave: a chocolate a
micrometre too coarse is indistinguishable, one ten micrometres too coarse is
a different product.

The weights are configuration, not physics. They encode a commercial judgement
about what matters -- temper and particle size dominate because they are what
a consumer notices first -- and a different business would weight them
differently, which is why they live in :class:`QualityConfig`.
"""

from __future__ import annotations

import math
from collections.abc import Sequence

from pydantic import Field

from ..core.config import ChocoSimConfig, QualityConfig
from ..core.fidelity import ModelProvenance
from ..core.models import FrozenChocoModel, Interval, clamp
from ..core.rng import RandomSource, bernoulli
from ..core.types import (
    BatchId,
    DefectKind,
    Kilograms,
    QualityVerdict,
    TemperGrade,
)
from ..processing.pipeline import ProcessRun
from ..recipes.models import Recipe
from ..tempering.crystals import CrystalState, bloom_risk


class MetricScore(FrozenChocoModel):
    """Score for a single quality metric."""

    name: str
    value: float
    specification: Interval | None = None
    score: float = Field(ge=0.0, le=100.0)
    weight: float = Field(ge=0.0)
    in_specification: bool

    @property
    def weighted_score(self) -> float:
        """Contribution of this metric to the overall score."""
        return self.score * self.weight

    @property
    def points_lost(self) -> float:
        """Points this metric cost the batch."""
        return (100.0 - self.score) * self.weight

    def describe(self) -> str:
        """One-line metric summary."""
        mark = "OK  " if self.in_specification else "OUT "
        spec = str(self.specification) if self.specification else "n/a"
        return (
            f"[{mark}] {self.name:<18} {self.value:>10.4f}  spec {spec:<18} "
            f"score {self.score:>6.1f}  weight {self.weight:.2f}"
        )


class Defect(FrozenChocoModel):
    """A defect observed in a batch."""

    kind: DefectKind
    rate: float = Field(ge=0.0, le=1.0, description="Share of units affected.")
    cause: str = ""

    @property
    def is_critical(self) -> bool:
        """Whether this defect makes the product unsaleable rather than second-grade."""
        return self.kind in (
            DefectKind.FAT_BLOOM,
            DefectKind.SUGAR_BLOOM,
            DefectKind.FOREIGN_BODY,
        )


class QualityAssessment(FrozenChocoModel):
    """Complete quality assessment of a batch."""

    batch_id: BatchId
    recipe_key: str
    recipe_name: str
    batch_mass_kg: Kilograms = Field(ge=0.0)

    metrics: tuple[MetricScore, ...]
    defects: tuple[Defect, ...]
    overall_score: float = Field(ge=0.0, le=100.0)
    verdict: QualityVerdict
    temper_grade: TemperGrade
    bloom_risk_90_days: float = Field(ge=0.0, le=1.0)
    provenance: ModelProvenance

    @property
    def defect_rate(self) -> float:
        """Combined probability that a unit carries at least one defect.

        Combined multiplicatively rather than by addition: defects are treated
        as independent, so two 3% defects give 5.9% affected units, not 6%.
        """
        survival = 1.0
        for defect in self.defects:
            survival *= 1.0 - defect.rate
        return 1.0 - survival

    @property
    def critical_defect_rate(self) -> float:
        """Rate of defects that make product unsaleable."""
        survival = 1.0
        for defect in self.defects:
            if defect.is_critical:
                survival *= 1.0 - defect.rate
        return 1.0 - survival

    @property
    def saleable_fraction(self) -> float:
        """Share of the batch that can be sold as first quality."""
        return max(0.0, 1.0 - self.defect_rate)

    @property
    def saleable_kg(self) -> Kilograms:
        """First-quality mass."""
        return self.batch_mass_kg * self.saleable_fraction

    @property
    def reworkable_kg(self) -> Kilograms:
        """Mass that can be reworked rather than scrapped.

        Non-critical defects -- a soft set, a dull surface, a weight variance --
        are remeltable. Bloom and foreign body are not.
        """
        non_critical = max(0.0, self.defect_rate - self.critical_defect_rate)
        return self.batch_mass_kg * non_critical

    @property
    def scrap_kg(self) -> Kilograms:
        """Mass that must be scrapped."""
        return self.batch_mass_kg * self.critical_defect_rate

    @property
    def failing_metrics(self) -> tuple[MetricScore, ...]:
        """Metrics that fell outside specification."""
        return tuple(metric for metric in self.metrics if not metric.in_specification)

    def worst_metric(self) -> MetricScore | None:
        """The metric that cost the most points."""
        if not self.metrics:
            return None
        return max(self.metrics, key=lambda metric: metric.points_lost)

    def report(self) -> str:
        """Plain-text quality report in the style of a certificate of analysis."""
        lines = [
            f"QUALITY ASSESSMENT -- {self.batch_id}",
            f"{self.recipe_name}  ({self.batch_mass_kg:,.1f} kg)",
            "=" * 78,
            f"OVERALL SCORE   {self.overall_score:.1f} / 100   [{self.verdict.value.upper()}]",
            f"TEMPER          {self.temper_grade.value}",
            f"BLOOM RISK      {self.bloom_risk_90_days:.1%} over 90 days",
            "",
            "METRICS",
        ]
        lines += [f"  {metric.describe()}" for metric in self.metrics]
        if self.defects:
            lines += ["", "DEFECTS"]
            for defect in sorted(self.defects, key=lambda d: -d.rate):
                tag = "CRITICAL" if defect.is_critical else "reworkable"
                lines.append(
                    f"  {defect.kind.value:<20} {defect.rate:>7.2%}  ({tag}) "
                    f"{defect.cause}"
                )
        lines += [
            "",
            "DISPOSITION",
            f"  First quality   {self.saleable_kg:>10.2f} kg "
            f"({self.saleable_fraction:.2%})",
            f"  Rework          {self.reworkable_kg:>10.2f} kg",
            f"  Scrap           {self.scrap_kg:>10.2f} kg",
        ]
        worst = self.worst_metric()
        if worst is not None and worst.points_lost > 0.5:
            lines += [
                "",
                f"Largest single deduction: {worst.name} "
                f"({worst.points_lost:.1f} points)",
            ]
        lines += ["", self.provenance.banner()]
        return "\n".join(lines)


class QualityEngine:
    """Scores batches against their recipe specifications."""

    MODEL_NAME = "quality_engine"

    def __init__(self, config: ChocoSimConfig | None = None) -> None:
        self.config = config or ChocoSimConfig.default()

    @property
    def quality_config(self) -> QualityConfig:
        """The quality weights and thresholds in force."""
        return self.config.quality

    # ------------------------------------------------------------------
    # Metric scoring
    # ------------------------------------------------------------------

    def score_metric(
        self, name: str, value: float, specification: Interval, weight: float
    ) -> MetricScore:
        """Score one metric against its specification interval."""
        deviation = specification.normalised_deviation(value)
        if deviation <= 0.0:
            score = 100.0
        else:
            penalty = 100.0 * (
                1.0 - math.exp(-(deviation**self.quality_config.penalty_steepness) / 2.0)
            )
            score = clamp(100.0 - penalty, 0.0, 100.0)
        return MetricScore(
            name=name,
            value=value,
            specification=specification,
            score=score,
            weight=weight,
            in_specification=deviation <= 0.0,
        )

    def score_temper(self, temper_index: float, specification: Interval, weight: float) -> MetricScore:
        """Score temper, which is asymmetric.

        Under-temper is worse than over-temper at equal distance from the
        target: an under-tempered bar blooms in the warehouse and comes back
        as a customer complaint, whereas an over-tempered one is merely dull
        and thick to mould.
        """
        deviation = specification.normalised_deviation(temper_index)
        if deviation <= 0.0:
            score = 100.0
        else:
            asymmetry = 1.45 if temper_index < specification.low else 1.0
            penalty = 100.0 * (
                1.0
                - math.exp(
                    -(
                        (deviation * asymmetry)
                        ** self.quality_config.penalty_steepness
                    )
                    / 2.0
                )
            )
            score = clamp(100.0 - penalty, 0.0, 100.0)
        return MetricScore(
            name="temper_index",
            value=temper_index,
            specification=specification,
            score=score,
            weight=weight,
            in_specification=deviation <= 0.0,
        )

    # ------------------------------------------------------------------
    # Defects
    # ------------------------------------------------------------------

    def infer_defects(
        self,
        run: ProcessRun,
        temper_index: float,
        bloom_probability: float,
        source: RandomSource,
    ) -> tuple[Defect, ...]:
        """Derive defect rates from what the process actually did.

        Each defect is traced to the stage that caused it, which is the point:
        a defect list that cannot be attributed to a cause tells an operator
        nothing about what to change.
        """
        defects: list[Defect] = []

        cooling = run.stage_metrics("cooling")
        moulding = run.stage_metrics("moulding")
        conching = run.stage_metrics("conching")
        refining = run.stage_metrics("refining")

        quench = cooling.get("quench_damage", 0.0)
        if quench > 0.01:
            defects.append(
                Defect(
                    kind=DefectKind.DULL_SURFACE,
                    rate=clamp(quench * 0.75, 0.0, 0.9),
                    cause="cooling tunnel quenched the surface into unstable forms",
                )
            )

        if temper_index < 4.0:
            shortfall = (4.0 - temper_index) / 4.0
            defects.append(
                Defect(
                    kind=DefectKind.SOFT_SET,
                    rate=clamp(shortfall * 0.55, 0.0, 0.9),
                    cause="insufficient stable crystal seed leaving the temperer",
                )
            )
        elif temper_index > 7.0:
            defects.append(
                Defect(
                    kind=DefectKind.STREAKING,
                    rate=clamp((temper_index - 7.0) / 3.0 * 0.35, 0.0, 0.6),
                    cause="over-seeded mass set before the mould filled evenly",
                )
            )

        if bloom_probability > 0.05:
            defects.append(
                Defect(
                    kind=DefectKind.FAT_BLOOM,
                    rate=clamp(bloom_probability * 0.4, 0.0, 0.8),
                    cause="unstable polymorphs converting in storage",
                )
            )

        yield_excess = moulding.get("yield_excess", 0.0)
        if yield_excess > 0.0:
            defects.append(
                Defect(
                    kind=DefectKind.AIR_BUBBLE,
                    rate=clamp(yield_excess * 0.30, 0.0, 0.7),
                    cause="mass too stiff to release entrained air at the depositor",
                )
            )
            defects.append(
                Defect(
                    kind=DefectKind.WEIGHT_VARIANCE,
                    rate=clamp(yield_excess * 0.22, 0.0, 0.6),
                    cause="depositor accuracy degraded by high yield value",
                )
            )

        perceptible = refining.get("perceptible_fraction", 0.0)
        if perceptible > 0.04:
            defects.append(
                Defect(
                    kind=DefectKind.GRITTY_TEXTURE,
                    rate=clamp((perceptible - 0.04) * 4.0, 0.0, 0.8),
                    cause="coarse tail of the particle size distribution",
                )
            )

        moisture = conching.get("final_moisture", 0.0)
        if moisture > 0.012:
            defects.append(
                Defect(
                    kind=DefectKind.SUGAR_BLOOM,
                    rate=clamp((moisture - 0.012) * 12.0, 0.0, 0.5),
                    cause="residual moisture from an incomplete dry conche",
                )
            )

        # A low-rate background of foreign body findings, which no amount of
        # process control eliminates entirely.
        if not self.config.simulation.deterministic and bernoulli(
            source.generator("quality/foreign_body"), 0.02
        ):
            defects.append(
                Defect(
                    kind=DefectKind.FOREIGN_BODY,
                    rate=0.0008,
                    cause="detected at the metal detector",
                )
            )

        return tuple(defects)

    # ------------------------------------------------------------------
    # Assessment
    # ------------------------------------------------------------------

    def assess(
        self,
        run: ProcessRun,
        recipe: Recipe,
        source: RandomSource | None = None,
        storage_temperature_c: float = 18.0,
        storage_days: float = 90.0,
    ) -> QualityAssessment:
        """Score a completed process run against its recipe specification."""
        source = source or RandomSource(self.config.simulation.seed)
        weights = self.quality_config.normalised_weights()
        specification = recipe.quality
        stream = run.final_stream

        conching = run.stage_metrics("conching")
        refining = run.stage_metrics("refining")
        tempering = run.stage_metrics("tempering")

        temper_index = tempering.get("temper_index", 0.0)
        crystal = CrystalState(
            fractions={}
        )
        form_v = tempering.get("form_v_fraction", 0.0)
        unstable = tempering.get("unstable_fraction", 0.0)
        if form_v > 0.0 or unstable > 0.0:
            from ..core.types import CrystalForm

            crystal = CrystalState(
                fractions={
                    CrystalForm.FORM_V: form_v,
                    CrystalForm.FORM_IV: unstable,
                }
            ).normalised()

        milk_fat_share = (
            stream.composition.milk_fat / stream.composition.fat
            if stream.composition.fat > 0.0
            else 0.0
        )
        bloom = bloom_risk(crystal, storage_temperature_c, storage_days, milk_fat_share)

        metrics = (
            self.score_metric(
                "particle_size_um",
                refining.get("d90_um", stream.particle_size_d90_um),
                specification.particle_size_um,
                weights["particle_size"],
            ),
            self.score_metric(
                "viscosity_pas",
                conching.get("viscosity_pas", stream.viscosity_pas),
                specification.viscosity_pas,
                weights["viscosity"],
            ),
            self.score_metric(
                "moisture_fraction",
                conching.get("final_moisture", stream.composition.moisture),
                specification.moisture_fraction,
                weights["moisture"],
            ),
            self.score_metric(
                "fat_fraction",
                stream.composition.fat,
                specification.fat_fraction,
                weights["fat"],
            ),
            self.score_temper(
                temper_index, specification.temper_index, weights["temper"]
            ),
        )

        defects = self.infer_defects(run, temper_index, bloom, source)
        defect_rate = 1.0 - math.prod(1.0 - defect.rate for defect in defects)

        appearance_score = clamp(
            100.0
            * (1.0 - 0.6 * bloom)
            * (1.0 - 0.8 * run.stage_metrics("cooling").get("quench_damage", 0.0)),
            0.0,
            100.0,
        )
        appearance = MetricScore(
            name="appearance",
            value=appearance_score,
            specification=None,
            score=appearance_score,
            weight=weights["appearance"],
            in_specification=appearance_score >= 80.0,
        )

        defect_score = clamp(
            100.0
            * (
                1.0
                - min(
                    1.0,
                    defect_rate / max(specification.max_defect_rate * 3.0, 1e-6),
                )
            ),
            0.0,
            100.0,
        )
        defect_metric = MetricScore(
            name="defect_rate",
            value=defect_rate,
            specification=Interval(low=0.0, high=specification.max_defect_rate),
            score=defect_score,
            weight=weights["defects"],
            in_specification=defect_rate <= specification.max_defect_rate,
        )

        all_metrics = (*metrics, appearance, defect_metric)
        overall = sum(metric.weighted_score for metric in all_metrics)
        overall = clamp(overall, 0.0, 100.0)

        if overall >= self.quality_config.pass_threshold:
            verdict = QualityVerdict.PASS
        elif overall >= self.quality_config.marginal_threshold:
            verdict = QualityVerdict.MARGINAL
        else:
            verdict = QualityVerdict.FAIL

        # A critical defect overrides a good score: a batch with bloom is not
        # saved by having excellent particle size.
        critical = 1.0 - math.prod(
            1.0 - defect.rate for defect in defects if defect.is_critical
        )
        if critical > 0.10 and verdict is QualityVerdict.PASS:
            verdict = QualityVerdict.MARGINAL

        return QualityAssessment(
            batch_id=run.batch_id,
            recipe_key=run.recipe_key,
            recipe_name=run.recipe_name,
            batch_mass_kg=run.output_kg,
            metrics=all_metrics,
            defects=defects,
            overall_score=overall,
            verdict=verdict,
            temper_grade=crystal.grade(),
            bloom_risk_90_days=bloom,
            provenance=ModelProvenance.simulation(
                self.MODEL_NAME,
                basis=(
                    "Weighted metric scoring against recipe specification with "
                    "power-law deviation penalties"
                ),
                assumptions=(
                    "Metric weights reflect commercial priorities, not physics",
                    "Defects are statistically independent",
                    "Sensory acceptability is inferred from instrument values, "
                    "not measured by a panel",
                ),
                extra_caveats=(
                    "Scores are a simulation construct for comparing process "
                    "options. They are not a substitute for laboratory release "
                    "testing or sensory panel assessment.",
                ),
            ),
        )

    def compare(
        self, assessments: Sequence[QualityAssessment]
    ) -> list[tuple[str, float, QualityVerdict]]:
        """Rank several assessments by score."""
        return sorted(
            (
                (assessment.batch_id, assessment.overall_score, assessment.verdict)
                for assessment in assessments
            ),
            key=lambda row: -row[1],
        )


__all__ = ["Defect", "MetricScore", "QualityAssessment", "QualityEngine"]
