"""Recipe engine: mass balance, costing, nutrition and compositional checks."""

from __future__ import annotations

from pydantic import Field

from ..core.fidelity import ModelProvenance
from ..core.models import Composition, FrozenChocoModel, blend_compositions, safe_divide
from ..core.types import ChocolateType, IngredientId, Kilograms, Micrometres, Money
from ..core.units import (
    KCAL_PER_G_CARBOHYDRATE,
    KCAL_PER_G_FAT,
    KCAL_PER_G_PROTEIN,
    KJ_PER_KCAL,
)
from ..ingredients.models import IngredientRequirement, NutritionProfile
from ..ingredients.registry import IngredientRegistry
from .models import Recipe

#: Compositional standards for chocolate sold in Great Britain, from the
#: Cocoa and Chocolate Products (England) Regulations and their equivalents.
#: Encoded here so the engine can flag a formulation that could not legally be
#: labelled as the type it claims. This is a formulation-development aid, not
#: a legal opinion: actual labelling compliance depends on the finished
#: product, the market and the current text of the applicable regulation.
COMPOSITIONAL_STANDARDS: dict[ChocolateType, dict[str, float]] = {
    ChocolateType.DARK: {
        "min_total_cocoa_solids": 0.35,
        "min_cocoa_butter": 0.18,
        "min_cocoa_solids_nonfat": 0.14,
    },
    ChocolateType.MILK: {
        "min_total_cocoa_solids": 0.25,
        "min_dry_milk_solids": 0.14,
        "min_milk_fat": 0.035,
        "min_total_fat": 0.25,
        "max_sugar": 0.55,
    },
    ChocolateType.WHITE: {
        "min_cocoa_butter": 0.20,
        "min_dry_milk_solids": 0.14,
        "min_milk_fat": 0.035,
        "max_sugar": 0.55,
    },
}


class CostBreakdown(FrozenChocoModel):
    """Ingredient cost of one batch, per line and in total."""

    requirements: tuple[IngredientRequirement, ...]
    batch_mass_kg: Kilograms = Field(gt=0.0)

    @property
    def total_cost(self) -> Money:
        """Total ingredient cost of the batch."""
        return sum(requirement.line_cost for requirement in self.requirements)

    @property
    def cost_per_kg(self) -> Money:
        """Ingredient cost per kilogram of formulation."""
        return safe_divide(self.total_cost, self.batch_mass_kg)

    def by_ingredient(self) -> dict[IngredientId, Money]:
        """Cost contribution of each ingredient."""
        return {
            requirement.ingredient_id: requirement.line_cost
            for requirement in self.requirements
        }

    def cost_share(self) -> dict[IngredientId, float]:
        """Each ingredient's share of total cost, largest first."""
        total = self.total_cost
        if total <= 0.0:
            return {}
        shares = {
            requirement.ingredient_id: requirement.line_cost / total
            for requirement in self.requirements
        }
        return dict(sorted(shares.items(), key=lambda item: -item[1]))

    def dominant_ingredient(self) -> tuple[IngredientId, float] | None:
        """The single largest cost contributor and its share."""
        shares = self.cost_share()
        if not shares:
            return None
        first = next(iter(shares.items()))
        return first


class ComplianceCheck(FrozenChocoModel):
    """Result of checking a formulation against a compositional standard."""

    chocolate_type: ChocolateType
    checks: dict[str, tuple[float, float, bool]] = Field(
        description="Rule name -> (actual value, limit, satisfied)."
    )

    @property
    def compliant(self) -> bool:
        """Whether every rule is satisfied."""
        return all(satisfied for _, _, satisfied in self.checks.values())

    @property
    def failures(self) -> dict[str, tuple[float, float]]:
        """Rules that are not satisfied, with actual value and limit."""
        return {
            rule: (actual, limit)
            for rule, (actual, limit, satisfied) in self.checks.items()
            if not satisfied
        }

    def describe(self) -> str:
        """Human-readable compliance summary."""
        if not self.checks:
            return f"No compositional standard encoded for {self.chocolate_type.value}."
        lines = [f"Compositional check: {self.chocolate_type.value}"]
        for rule, (actual, limit, satisfied) in sorted(self.checks.items()):
            mark = "OK " if satisfied else "FAIL"
            lines.append(f"  [{mark}] {rule}: actual {actual:.4f}, limit {limit:.4f}")
        if not self.compliant:
            lines.append(
                "  Formulation-development guidance only; labelling compliance "
                "requires assessment against the regulation in force in the "
                "target market."
            )
        return "\n".join(lines)


class RecipeAnalysis(FrozenChocoModel):
    """Complete analysis of a formulation at a given batch size."""

    recipe_key: str
    recipe_name: str
    chocolate_type: ChocolateType
    batch_mass_kg: Kilograms = Field(gt=0.0)

    requirements: tuple[IngredientRequirement, ...]
    composition: Composition
    nutrition: NutritionProfile
    compliance: ComplianceCheck

    ingredient_cost: Money = Field(ge=0.0)
    ingredient_cost_per_kg: Money = Field(ge=0.0)

    theoretical_yield_kg: Kilograms = Field(
        ge=0.0, description="Saleable mass after handling and process losses."
    )
    yield_fraction: float = Field(ge=0.0, le=1.0)

    coarsest_particle_um: Micrometres = Field(
        ge=0.0, description="Largest incoming particle size requiring refining."
    )
    base_composition: Composition = Field(
        description="Composition of the chocolate base, excluding inclusions."
    )
    inclusion_fraction: float = Field(
        default=0.0, ge=0.0, le=1.0, description="Share of mass that is inclusions."
    )
    declared_cocoa: float | None = Field(
        default=None, description="Cocoa percentage parsed from the recipe name."
    )
    declared_cocoa_consistent: bool = Field(
        default=True,
        description="Whether the declared percentage matches the computed base.",
    )
    allergens: tuple[str, ...] = ()
    provenance: ModelProvenance

    @property
    def cost_breakdown(self) -> CostBreakdown:
        """Cost analysis of this formulation."""
        return CostBreakdown(
            requirements=self.requirements, batch_mass_kg=self.batch_mass_kg
        )

    @property
    def effective_cost_per_kg(self) -> Money:
        """Ingredient cost per kilogram of *saleable* product.

        Higher than :attr:`ingredient_cost_per_kg` because losses are paid for
        but not sold. This is the number that belongs in a costing sheet.
        """
        return safe_divide(self.ingredient_cost, self.theoretical_yield_kg)

    def cost_per_unit(self, unit_mass_g: float) -> Money:
        """Ingredient cost of one finished unit of the given mass."""
        return self.effective_cost_per_kg * (unit_mass_g / 1000.0)

    def report(self) -> str:
        """Plain-text analysis report."""
        symbol = "\u00a3"
        lines = [
            self.recipe_name.upper(),
            "=" * 58,
            f"Type                 {self.chocolate_type.value}",
            f"Batch mass           {self.batch_mass_kg:,.1f} kg",
            f"Theoretical yield    {self.theoretical_yield_kg:,.1f} kg "
            f"({self.yield_fraction:.2%})",
            "",
            "FORMULATION",
        ]
        for requirement in sorted(
            self.requirements, key=lambda r: -r.mass_fraction
        ):
            lines.append(
                f"  {requirement.ingredient_name:<38} "
                f"{requirement.mass_fraction * 100:>6.2f}%  "
                f"{requirement.required_kg:>9.2f} kg  "
                f"{symbol}{requirement.line_cost:>9,.2f}"
            )
        lines += [
            "",
            "COMPOSITION (finished product)",
            f"  Total cocoa solids   {self.composition.total_cocoa_solids:.2%}",
            f"  Cocoa butter         {self.composition.cocoa_butter:.2%}",
            f"  Total fat            {self.composition.fat:.2%}",
            f"  Sugar                {self.composition.sugar:.2%}",
            f"  Dry milk solids      {self.composition.dry_milk_solids:.2%}",
            f"  Moisture             {self.composition.moisture:.2%}",
        ]
        if self.inclusion_fraction > 0.0:
            lines += [
                "",
                f"CHOCOLATE BASE ({1 - self.inclusion_fraction:.1%} of mass; "
                f"{self.inclusion_fraction:.1%} inclusions)",
                f"  Total cocoa solids   {self.base_composition.total_cocoa_solids:.2%}",
                f"  Total fat            {self.base_composition.fat:.2%}",
            ]
        if self.declared_cocoa is not None and not self.declared_cocoa_consistent:
            lines += [
                "",
                f"  ! Name declares {self.declared_cocoa:.0%} cocoa but the base "
                f"computes to {self.base_composition.total_cocoa_solids:.2%}",
            ]
        lines += [
            "",
            "COST",
            f"  Ingredient cost      {symbol}{self.ingredient_cost:,.2f}",
            f"  Per kg formulated    {symbol}{self.ingredient_cost_per_kg:,.4f}",
            f"  Per kg saleable      {symbol}{self.effective_cost_per_kg:,.4f}",
            f"  Per 100 g bar        {symbol}{self.cost_per_unit(100.0):,.4f}",
            "",
            self.compliance.describe(),
            "",
            self.provenance.banner(),
        ]
        return "\n".join(lines)


class RecipeEngine:
    """Computes everything derivable from a formulation and a price list."""

    MODEL_NAME = "recipe_engine"

    def __init__(self, registry: IngredientRegistry) -> None:
        self.registry = registry

    # ------------------------------------------------------------------
    # Requirements and cost
    # ------------------------------------------------------------------

    def requirements(
        self, recipe: Recipe, batch_mass_kg: Kilograms | None = None
    ) -> tuple[IngredientRequirement, ...]:
        """Ingredient quantities and costs for a batch.

        Quantities are computed so that they sum to the batch mass exactly:
        the largest component absorbs any rounding residue. Without this a
        1,000 kg batch of a five-component recipe can come to 999.9999997 kg,
        which then trips the mass-balance invariant downstream.
        """
        mass = batch_mass_kg if batch_mass_kg is not None else recipe.default_batch_size_kg
        if mass <= 0.0:
            raise ValueError(f"batch mass must be positive, got {mass}")

        raw = [
            (component, component.mass_fraction * mass)
            for component in recipe.components
        ]
        residue = mass - sum(quantity for _, quantity in raw)
        if raw:
            largest_index = max(range(len(raw)), key=lambda i: raw[i][1])
            component, quantity = raw[largest_index]
            raw[largest_index] = (component, quantity + residue)

        return tuple(
            IngredientRequirement(
                ingredient_id=component.ingredient_id,
                ingredient_name=self.registry.get(component.ingredient_id).name,
                mass_fraction=component.mass_fraction,
                required_kg=quantity,
                unit_cost=self.registry.unit_cost(component.ingredient_id),
            )
            for component, quantity in raw
        )

    def cost(
        self, recipe: Recipe, batch_mass_kg: Kilograms | None = None
    ) -> CostBreakdown:
        """Ingredient cost breakdown for a batch."""
        mass = batch_mass_kg if batch_mass_kg is not None else recipe.default_batch_size_kg
        return CostBreakdown(
            requirements=self.requirements(recipe, mass), batch_mass_kg=mass
        )

    def cost_per_kg(self, recipe: Recipe) -> Money:
        """Ingredient cost per kilogram of formulation."""
        return self.cost(recipe, 1.0).total_cost

    # ------------------------------------------------------------------
    # Composition
    # ------------------------------------------------------------------

    def composition(self, recipe: Recipe) -> Composition:
        """Mass-weighted composition of the finished product.

        Covers every component including inclusions, so this is the analysis
        of what the consumer eats.
        """
        parts = [
            (
                self.registry.get(component.ingredient_id).composition,
                component.mass_fraction,
            )
            for component in recipe.components
        ]
        blended, _ = blend_compositions(parts)
        return blended

    def base_composition(self, recipe: Recipe) -> tuple[Composition, float]:
        """Composition of the chocolate base alone, excluding inclusions.

        Returns the renormalised composition of the chocolate and the fraction
        of total product mass it represents.

        Inclusions -- whole nuts, fruit pieces, salt flakes deposited at the
        moulder -- are not part of the chocolate. A bar that is 18% hazelnut is
        still made from chocolate whose own cocoa content is unaffected by the
        nuts sitting in it, and compositional standards are assessed on that
        chocolate. Blending the nuts in before the assessment would wrongly
        condemn a perfectly ordinary formulation, which is exactly what a naive
        implementation does.
        """
        base = [
            component
            for component in recipe.components
            if component.added_at_stage != "moulding"
        ]
        if not base:
            return Composition(), 0.0
        base_fraction = sum(component.mass_fraction for component in base)
        if base_fraction <= 0.0:
            return Composition(), 0.0
        parts = [
            (
                self.registry.get(component.ingredient_id).composition,
                component.mass_fraction / base_fraction,
            )
            for component in base
        ]
        blended, _ = blend_compositions(parts)
        return blended, base_fraction

    def inclusion_fraction(self, recipe: Recipe) -> float:
        """Share of product mass made up of inclusions dosed at the moulder."""
        return sum(
            component.mass_fraction
            for component in recipe.components
            if component.added_at_stage == "moulding"
        )

    def declared_cocoa_check(
        self, recipe: Recipe, tolerance: float = 0.015
    ) -> tuple[float | None, float, bool]:
        """Compare a percentage in the recipe name against computed cocoa solids.

        Returns ``(declared, actual, consistent)``; ``declared`` is ``None``
        when the name carries no percentage. Catching a mismatch here is
        cheap; discovering it after a print run of wrappers is not.
        """
        import re

        match = re.search(r"(\d{1,3}(?:\.\d+)?)\s*%?", recipe.name)
        actual = self.base_composition(recipe)[0].total_cocoa_solids
        if match is None:
            return None, actual, True
        declared = float(match.group(1)) / 100.0
        if not 0.0 < declared <= 1.0:
            return None, actual, True
        return declared, actual, abs(declared - actual) <= tolerance

    def allergens(self, recipe: Recipe) -> tuple[str, ...]:
        """Union of allergens declared by the formulation's ingredients.

        Derived from ingredient specifications for changeover planning. Actual
        allergen declaration and cross-contamination control are governed by
        the site's food-safety plan, not by this calculation.
        """
        declared: set[str] = set()
        for component in recipe.components:
            declared.update(self.registry.get(component.ingredient_id).allergens)
        return tuple(sorted(declared))

    def coarsest_particle(self, recipe: Recipe) -> Micrometres:
        """Largest incoming particle size among components that need refining.

        Ingredients added after refining (nuts, fruit pieces) are excluded:
        they are meant to stay coarse and would otherwise dominate the figure
        and mislead the refining model.
        """
        sizes = [
            self.registry.get(component.ingredient_id).incoming_particle_size_um
            for component in recipe.components
            if component.added_at_stage in (None, "mixing")
        ]
        return max(sizes, default=0.0)

    # ------------------------------------------------------------------
    # Nutrition
    # ------------------------------------------------------------------

    def nutrition(self, recipe: Recipe) -> NutritionProfile:
        """Indicative nutrition panel per 100 g.

        Energy uses Atwater factors. Saturates are estimated from the fat
        profile: cocoa butter runs about 60% saturated (largely palmitic and
        stearic), milk fat about 65%, and other fats used here are
        predominantly unsaturated vegetable oils.

        Indicative simulation output for formulation work. A declarable panel
        requires laboratory analysis and compliance with the applicable
        food-labelling regulations.
        """
        composition = self.composition(recipe)
        fat_g = composition.fat * 100.0
        sugar_g = composition.sugar * 100.0
        protein_g = composition.protein * 100.0

        # Carbohydrate: sugars plus digestible non-sugar carbohydrate. Cocoa
        # non-fat solids are largely fibre and protein, so only a modest share
        # is counted as available carbohydrate.
        cocoa_carb_g = composition.cocoa_solids_nonfat * 100.0 * 0.22
        other_carb_g = composition.other_solids * 100.0 * 0.30
        carbohydrate_g = sugar_g + cocoa_carb_g + other_carb_g

        fibre_g = composition.cocoa_solids_nonfat * 100.0 * 0.33

        saturates_g = (
            composition.cocoa_butter * 100.0 * 0.60
            + composition.milk_fat * 100.0 * 0.65
            + composition.other_fat * 100.0 * 0.18
        )

        kcal = (
            fat_g * KCAL_PER_G_FAT
            + carbohydrate_g * KCAL_PER_G_CARBOHYDRATE
            + protein_g * KCAL_PER_G_PROTEIN
        )

        # Sodium arises from milk minerals and any added salt.
        salt_g = composition.milk_solids_nonfat * 100.0 * 0.019
        for component in recipe.components:
            ingredient = self.registry.get(component.ingredient_id)
            if "salt" in ingredient.name.lower():
                salt_g += component.mass_fraction * 100.0

        return NutritionProfile(
            energy_kcal_per_100g=kcal,
            energy_kj_per_100g=kcal * KJ_PER_KCAL,
            fat_g_per_100g=fat_g,
            saturates_g_per_100g=min(fat_g, saturates_g),
            carbohydrate_g_per_100g=carbohydrate_g,
            sugars_g_per_100g=sugar_g,
            protein_g_per_100g=protein_g,
            salt_g_per_100g=salt_g,
            fibre_g_per_100g=fibre_g,
        )

    # ------------------------------------------------------------------
    # Compliance
    # ------------------------------------------------------------------

    def check_compliance(self, recipe: Recipe) -> ComplianceCheck:
        """Check the formulation against the encoded compositional standard.

        Assessed on the chocolate base, excluding inclusions dosed at the
        moulder -- see :meth:`base_composition`.
        """
        standard = COMPOSITIONAL_STANDARDS.get(recipe.chocolate_type)
        if standard is None:
            return ComplianceCheck(chocolate_type=recipe.chocolate_type, checks={})

        composition, _ = self.base_composition(recipe)
        actual = {
            "min_total_cocoa_solids": composition.total_cocoa_solids,
            "min_cocoa_butter": composition.cocoa_butter,
            "min_cocoa_solids_nonfat": composition.cocoa_solids_nonfat,
            "min_dry_milk_solids": composition.dry_milk_solids,
            "min_milk_fat": composition.milk_fat,
            "min_total_fat": composition.fat,
            "max_sugar": composition.sugar,
        }

        checks: dict[str, tuple[float, float, bool]] = {}
        for rule, limit in standard.items():
            value = actual[rule]
            satisfied = value <= limit if rule.startswith("max_") else value >= limit
            checks[rule] = (value, limit, satisfied)
        return ComplianceCheck(chocolate_type=recipe.chocolate_type, checks=checks)

    # ------------------------------------------------------------------
    # Yield
    # ------------------------------------------------------------------

    def handling_loss_fraction(self, recipe: Recipe) -> float:
        """Mass-weighted handling loss across the formulation."""
        return sum(
            component.mass_fraction
            * self.registry.get(component.ingredient_id).handling_loss_fraction
            for component in recipe.components
        )

    def theoretical_yield(
        self,
        recipe: Recipe,
        batch_mass_kg: Kilograms,
        process_loss_fraction: float = 0.012,
    ) -> tuple[Kilograms, float]:
        """Saleable mass and yield fraction for a batch.

        Two loss terms: handling loss, which is a property of the materials,
        and process loss, which is a property of the line. Moisture driven off
        during conching is *not* counted as a loss here -- it is accounted for
        by the conching model, which knows how much water there was to remove.
        """
        handling = self.handling_loss_fraction(recipe)
        total_loss = min(0.95, handling + max(0.0, process_loss_fraction))
        yield_fraction = 1.0 - total_loss
        return batch_mass_kg * yield_fraction, yield_fraction

    # ------------------------------------------------------------------
    # Full analysis
    # ------------------------------------------------------------------

    def analyse(
        self,
        recipe: Recipe,
        batch_mass_kg: Kilograms | None = None,
        process_loss_fraction: float = 0.012,
    ) -> RecipeAnalysis:
        """Produce the complete analysis of a formulation."""
        mass = batch_mass_kg if batch_mass_kg is not None else recipe.default_batch_size_kg
        requirements = self.requirements(recipe, mass)
        breakdown = CostBreakdown(requirements=requirements, batch_mass_kg=mass)
        yield_kg, yield_fraction = self.theoretical_yield(
            recipe, mass, process_loss_fraction
        )
        base_composition, _ = self.base_composition(recipe)
        declared, _actual, consistent = self.declared_cocoa_check(recipe)

        provenance = ModelProvenance.simulation(
            self.MODEL_NAME,
            basis=(
                "Mass-weighted blending of ingredient specifications with "
                "Atwater energy factors"
            ),
            assumptions=(
                "Ingredient compositions match their specifications exactly",
                "Losses are proportional to mass and independent of batch size",
                "Nutrition is estimated, not laboratory-analysed",
            ),
            extra_caveats=(
                "Compositional standard checks are a formulation aid only and do "
                "not constitute a legal labelling assessment.",
            ),
        )

        return RecipeAnalysis(
            recipe_key=recipe.key,
            recipe_name=recipe.name,
            chocolate_type=recipe.chocolate_type,
            batch_mass_kg=mass,
            requirements=requirements,
            composition=self.composition(recipe),
            nutrition=self.nutrition(recipe),
            compliance=self.check_compliance(recipe),
            ingredient_cost=breakdown.total_cost,
            ingredient_cost_per_kg=breakdown.cost_per_kg,
            theoretical_yield_kg=yield_kg,
            yield_fraction=yield_fraction,
            coarsest_particle_um=self.coarsest_particle(recipe),
            base_composition=base_composition,
            inclusion_fraction=self.inclusion_fraction(recipe),
            declared_cocoa=declared,
            declared_cocoa_consistent=consistent,
            allergens=self.allergens(recipe),
            provenance=provenance,
        )

    def compare(
        self, recipes: list[Recipe], batch_mass_kg: Kilograms = 1_000.0
    ) -> list[RecipeAnalysis]:
        """Analyse several formulations at a common batch size."""
        return [self.analyse(recipe, batch_mass_kg) for recipe in recipes]


__all__ = [
    "COMPOSITIONAL_STANDARDS",
    "ComplianceCheck",
    "CostBreakdown",
    "RecipeAnalysis",
    "RecipeEngine",
]
