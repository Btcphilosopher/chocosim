"""Standard recipe library and the recipe book that holds versions."""

from __future__ import annotations

from collections.abc import Iterable, Iterator

from ..core.exceptions import RecipeNotFoundError
from ..core.models import Interval
from ..core.types import ChocolateType, RecipeId
from .models import ProcessSpec, QualitySpec, Recipe, RecipeComponent, RecipeLine


class RecipeBook:
    """Holds recipe lines and resolves versions."""

    def __init__(self, recipes: Iterable[Recipe] | None = None) -> None:
        self._lines: dict[RecipeId, RecipeLine] = {}
        for recipe in recipes or ():
            self.add(recipe)

    def add(self, recipe: Recipe) -> Recipe:
        """Add a recipe version, creating its line if necessary."""
        line = self._lines.get(recipe.recipe_id)
        if line is None:
            line = RecipeLine(recipe_id=recipe.recipe_id, versions=[])
            self._lines[recipe.recipe_id] = line
        line.append(recipe)
        return recipe

    def revise(self, recipe: Recipe, **kwargs: object) -> Recipe:
        """Create and register the next version of a recipe."""
        return self.add(recipe.revise(**kwargs))  # type: ignore[arg-type]

    def get(self, recipe_id: RecipeId, version: int | None = None) -> Recipe:
        """Return a recipe version, defaulting to the current one."""
        line = self._lines.get(recipe_id)
        if line is None:
            raise RecipeNotFoundError(
                f"Unknown recipe {recipe_id!r}. Available: {sorted(self._lines)}"
            )
        return line.current if version is None else line.version(version)

    def line(self, recipe_id: RecipeId) -> RecipeLine:
        """Return the full version history of a recipe."""
        line = self._lines.get(recipe_id)
        if line is None:
            raise RecipeNotFoundError(f"Unknown recipe {recipe_id!r}")
        return line

    def by_type(self, chocolate_type: ChocolateType) -> list[Recipe]:
        """Current versions of every recipe of a given type."""
        return [
            line.current
            for line in self._lines.values()
            if line.current.chocolate_type is chocolate_type
        ]

    @property
    def recipe_ids(self) -> list[RecipeId]:
        """All registered recipe identifiers."""
        return sorted(self._lines)

    def current_recipes(self) -> list[Recipe]:
        """Current version of every recipe line."""
        return [self._lines[recipe_id].current for recipe_id in self.recipe_ids]

    def __contains__(self, recipe_id: object) -> bool:
        return recipe_id in self._lines

    def __len__(self) -> int:
        return len(self._lines)

    def __iter__(self) -> Iterator[Recipe]:
        return iter(self.current_recipes())


# --------------------------------------------------------------------------
# Standard formulations
# --------------------------------------------------------------------------


def dark_55() -> Recipe:
    """Dark chocolate, the reference formulation from the ChocoSim brief.

    40% liquor, 15% butter, 43% sugar, 1% lecithin, 1% vanilla. Worth being
    precise about what this is: liquor carries roughly 97% cocoa solids and
    cocoa butter roughly 100%, so 40 + 15 parts gives about **55%** total
    cocoa solids, not 70%. A recipe is only "70% cocoa" if the liquor and
    butter together reach 70 parts. Naming it honestly here rather than
    rounding up is the difference between a costing model and a marketing
    document.
    """
    return Recipe(
        recipe_id="RCP-DARK-55",
        version=1,
        name="Dark Chocolate 55%",
        chocolate_type=ChocolateType.DARK,
        components=(
            RecipeComponent.from_percent("ING-LIQUOR", 40.0),
            RecipeComponent.from_percent("ING-BUTTER", 15.0),
            RecipeComponent.from_percent("ING-SUGAR", 43.0),
            RecipeComponent.from_percent(
                "ING-LECITHIN", 1.0, added_at_stage="conching",
                note="Added late; earlier addition reduces its viscosity effect.",
            ),
            RecipeComponent.from_percent("ING-VANILLA", 1.0, added_at_stage="conching"),
        ),
        process=ProcessSpec(
            roast_temperature_c=145.0,
            roast_minutes=32.0,
            target_particle_size_um=18.0,
            refining_passes=2,
            conche_temperature_c=68.0,
            conche_hours=24.0,
            conche_shear_intensity=0.7,
            temper_melt_c=50.0,
            temper_cool_c=27.0,
            temper_reheat_c=31.5,
            temper_cool_rate_c_per_min=1.1,
            mould_temperature_c=30.5,
            cooling_tunnel_c=11.0,
            cooling_minutes=24.0,
        ),
        quality=QualitySpec(
            particle_size_um=Interval(low=14.0, high=22.0),
            viscosity_pas=Interval(low=1.8, high=4.2),
            moisture_fraction=Interval(low=0.002, high=0.010),
            fat_fraction=Interval(low=0.32, high=0.42),
            temper_index=Interval(low=4.2, high=6.0),
            max_defect_rate=0.025,
            min_quality_score=82.0,
        ),
        default_batch_size_kg=1_500.0,
        min_batch_size_kg=400.0,
        max_batch_size_kg=4_000.0,
        author="ChocoSim reference library",
        change_note="Initial formulation.",
    )


def dark_70() -> Recipe:
    """Dark chocolate, a genuine 70% cocoa solids formulation.

    57 parts liquor plus 15 parts cocoa butter give 70.3% total cocoa solids.
    The extra butter over the liquor-only route is what keeps a 70% workable:
    liquor alone at this cocoa level yields a mass too viscous to mould
    cleanly. Long, hot conching to drive off the volatile acids that
    high-cocoa darks otherwise keep.
    """
    return Recipe(
        recipe_id="RCP-DARK-70",
        version=1,
        name="Dark Chocolate 70%",
        chocolate_type=ChocolateType.DARK,
        components=(
            RecipeComponent.from_percent("ING-LIQUOR", 57.0),
            RecipeComponent.from_percent("ING-BUTTER", 15.0),
            RecipeComponent.from_percent("ING-SUGAR", 27.2),
            RecipeComponent.from_percent("ING-LECITHIN", 0.6, added_at_stage="conching"),
            RecipeComponent.from_percent("ING-VANILLA", 0.2, added_at_stage="conching"),
        ),
        process=ProcessSpec(
            roast_temperature_c=142.0,
            roast_minutes=34.0,
            target_particle_size_um=17.0,
            refining_passes=2,
            conche_temperature_c=72.0,
            conche_hours=30.0,
            conche_shear_intensity=0.75,
            temper_melt_c=50.0,
            temper_cool_c=27.0,
            temper_reheat_c=31.8,
            temper_cool_rate_c_per_min=1.0,
            mould_temperature_c=31.0,
            cooling_tunnel_c=10.5,
            cooling_minutes=26.0,
        ),
        quality=QualitySpec(
            particle_size_um=Interval(low=13.0, high=21.0),
            viscosity_pas=Interval(low=2.0, high=5.0),
            moisture_fraction=Interval(low=0.001, high=0.009),
            fat_fraction=Interval(low=0.36, high=0.46),
            temper_index=Interval(low=4.4, high=6.0),
            max_defect_rate=0.02,
            min_quality_score=84.0,
        ),
        default_batch_size_kg=1_200.0,
        min_batch_size_kg=300.0,
        max_batch_size_kg=3_000.0,
        author="ChocoSim reference library",
    )


def milk_35() -> Recipe:
    """Milk chocolate, 35% cocoa solids.

    Conched cooler and shorter than dark: milk solids scorch and the
    Maillard notes that make milk chocolate taste right develop early.
    """
    return Recipe(
        recipe_id="RCP-MILK-35",
        version=1,
        name="Milk Chocolate 35%",
        chocolate_type=ChocolateType.MILK,
        components=(
            RecipeComponent.from_percent("ING-LIQUOR", 15.0),
            RecipeComponent.from_percent("ING-BUTTER", 21.0),
            RecipeComponent.from_percent("ING-SUGAR", 42.4),
            RecipeComponent.from_percent("ING-MILKPOWDER", 20.0),
            RecipeComponent.from_percent("ING-LECITHIN", 0.5, added_at_stage="conching"),
            RecipeComponent.from_percent("ING-VANILLIN", 0.1, added_at_stage="conching"),
            RecipeComponent.from_percent("ING-SALT", 1.0),
        ),
        process=ProcessSpec(
            roast_temperature_c=135.0,
            roast_minutes=22.0,
            target_particle_size_um=20.0,
            conche_temperature_c=55.0,
            conche_hours=10.0,
            conche_shear_intensity=0.55,
            temper_melt_c=45.0,
            temper_cool_c=26.0,
            temper_reheat_c=29.5,
            temper_cool_rate_c_per_min=1.3,
            mould_temperature_c=29.0,
            cooling_tunnel_c=13.0,
            cooling_minutes=20.0,
        ),
        quality=QualitySpec(
            particle_size_um=Interval(low=16.0, high=24.0),
            viscosity_pas=Interval(low=1.4, high=3.8),
            moisture_fraction=Interval(low=0.003, high=0.013),
            fat_fraction=Interval(low=0.28, high=0.36),
            temper_index=Interval(low=4.0, high=5.8),
            min_quality_score=80.0,
        ),
        default_batch_size_kg=2_500.0,
        min_batch_size_kg=600.0,
        max_batch_size_kg=5_000.0,
        author="ChocoSim reference library",
    )


def white_28() -> Recipe:
    """White chocolate. No cocoa solids, so tempering is driven purely by
    cocoa butter and the milk fat that softens it."""
    return Recipe(
        recipe_id="RCP-WHITE-28",
        version=1,
        name="White Chocolate 28%",
        chocolate_type=ChocolateType.WHITE,
        components=(
            RecipeComponent.from_percent("ING-BUTTER", 29.0),
            RecipeComponent.from_percent("ING-SUGAR", 43.4),
            RecipeComponent.from_percent("ING-MILKPOWDER", 25.0),
            RecipeComponent.from_percent("ING-MILKFAT", 2.0),
            RecipeComponent.from_percent("ING-LECITHIN", 0.5, added_at_stage="conching"),
            RecipeComponent.from_percent("ING-VANILLA", 0.1, added_at_stage="conching"),
        ),
        process=ProcessSpec(
            roast_temperature_c=120.0,
            roast_minutes=15.0,
            target_particle_size_um=24.0,
            conche_temperature_c=48.0,
            conche_hours=8.0,
            conche_shear_intensity=0.5,
            temper_melt_c=45.0,
            temper_cool_c=25.5,
            temper_reheat_c=28.5,
            temper_cool_rate_c_per_min=1.4,
            mould_temperature_c=28.0,
            cooling_tunnel_c=14.0,
            cooling_minutes=18.0,
        ),
        quality=QualitySpec(
            particle_size_um=Interval(low=18.0, high=28.0),
            viscosity_pas=Interval(low=1.2, high=3.5),
            fat_fraction=Interval(low=0.30, high=0.40),
            temper_index=Interval(low=3.8, high=5.5),
            min_quality_score=78.0,
        ),
        default_batch_size_kg=1_200.0,
        min_batch_size_kg=300.0,
        max_batch_size_kg=3_000.0,
        author="ChocoSim reference library",
    )


def dark_hazelnut() -> Recipe:
    """Dark chocolate with whole hazelnuts, added after conching."""
    return Recipe(
        recipe_id="RCP-DARK-HAZELNUT",
        version=1,
        name="Dark Chocolate with Hazelnuts",
        chocolate_type=ChocolateType.DARK,
        components=(
            RecipeComponent.from_percent("ING-LIQUOR", 32.0),
            RecipeComponent.from_percent("ING-BUTTER", 12.0),
            RecipeComponent.from_percent("ING-SUGAR", 36.4),
            RecipeComponent.from_percent(
                "ING-HAZELNUT", 18.0, added_at_stage="moulding",
                note="Whole nuts dosed at the depositor; must bypass refining.",
            ),
            RecipeComponent.from_percent("ING-LECITHIN", 0.8, added_at_stage="conching"),
            RecipeComponent.from_percent("ING-VANILLA", 0.8, added_at_stage="conching"),
        ),
        process=ProcessSpec(
            target_particle_size_um=19.0,
            conche_temperature_c=65.0,
            conche_hours=18.0,
            temper_melt_c=49.0,
            temper_cool_c=27.0,
            temper_reheat_c=31.0,
            cooling_minutes=28.0,
        ),
        quality=QualitySpec(
            particle_size_um=Interval(low=15.0, high=23.0),
            fat_fraction=Interval(low=0.32, high=0.46),
            max_defect_rate=0.04,
            min_quality_score=78.0,
        ),
        default_batch_size_kg=1_000.0,
        min_batch_size_kg=300.0,
        max_batch_size_kg=2_500.0,
        author="ChocoSim reference library",
    )


def milk_caramel_sea_salt() -> Recipe:
    """Milk chocolate with caramel and sea salt flakes."""
    return Recipe(
        recipe_id="RCP-MILK-CARAMEL",
        version=1,
        name="Salted Caramel Milk Chocolate",
        chocolate_type=ChocolateType.MILK,
        components=(
            RecipeComponent.from_percent("ING-LIQUOR", 13.0),
            RecipeComponent.from_percent("ING-BUTTER", 19.0),
            RecipeComponent.from_percent("ING-SUGAR", 32.0),
            RecipeComponent.from_percent("ING-MILKPOWDER", 22.0),
            RecipeComponent.from_percent(
                "ING-CARAMEL", 12.0, added_at_stage="conching",
                note="High moisture; added late and conched dry.",
            ),
            RecipeComponent.from_percent(
                "ING-SEA-SALT-FLAKE", 1.4, added_at_stage="moulding"
            ),
            RecipeComponent.from_percent("ING-LECITHIN", 0.6, added_at_stage="conching"),
        ),
        process=ProcessSpec(
            target_particle_size_um=21.0,
            conche_temperature_c=58.0,
            conche_hours=13.0,
            temper_melt_c=45.0,
            temper_cool_c=26.0,
            temper_reheat_c=29.5,
            cooling_minutes=22.0,
        ),
        quality=QualitySpec(
            particle_size_um=Interval(low=17.0, high=26.0),
            moisture_fraction=Interval(low=0.004, high=0.016),
            fat_fraction=Interval(low=0.27, high=0.36),
            max_defect_rate=0.045,
            min_quality_score=76.0,
        ),
        default_batch_size_kg=1_400.0,
        min_batch_size_kg=350.0,
        max_batch_size_kg=3_000.0,
        author="ChocoSim reference library",
    )


def dark_orange() -> Recipe:
    """Dark chocolate with orange oil and freeze-dried raspberry."""
    return Recipe(
        recipe_id="RCP-DARK-ORANGE",
        version=1,
        name="Dark Chocolate, Orange and Raspberry",
        chocolate_type=ChocolateType.DARK,
        components=(
            RecipeComponent.from_percent("ING-LIQUOR", 38.0),
            RecipeComponent.from_percent("ING-BUTTER", 13.5),
            RecipeComponent.from_percent("ING-SUGAR", 40.0),
            RecipeComponent.from_percent(
                "ING-FREEZEDRIED-RASPBERRY", 6.5, added_at_stage="moulding"
            ),
            RecipeComponent.from_percent(
                "ING-ORANGE-OIL", 1.2, added_at_stage="conching",
                note="Volatile; dosed in the last hour of conching.",
            ),
            RecipeComponent.from_percent("ING-LECITHIN", 0.8, added_at_stage="conching"),
        ),
        process=ProcessSpec(
            target_particle_size_um=18.0,
            conche_temperature_c=64.0,
            conche_hours=20.0,
            temper_melt_c=49.0,
            temper_cool_c=27.0,
            temper_reheat_c=31.2,
            cooling_minutes=25.0,
        ),
        quality=QualitySpec(
            particle_size_um=Interval(low=14.0, high=22.0),
            fat_fraction=Interval(low=0.30, high=0.40),
            max_defect_rate=0.035,
            min_quality_score=79.0,
        ),
        default_batch_size_kg=900.0,
        min_batch_size_kg=250.0,
        max_batch_size_kg=2_000.0,
        author="ChocoSim reference library",
    )


def dark_origin_bean_to_bar() -> Recipe:
    """Single-origin dark chocolate made from whole beans.

    The only recipe in the standard set that starts from unroasted beans, so
    it is the one that exercises roasting, winnowing and grinding. Everything
    else begins at bought-in liquor, which is how most plants actually run --
    but a model that could not represent a bean-to-bar line would be missing
    a third of the process.

    Formulated at 72 parts bean to reach roughly 70% cocoa solids after the
    12% shell loss at winnowing.
    """
    return Recipe(
        recipe_id="RCP-DARK-ORIGIN",
        version=1,
        name="Single Origin Dark 68%",
        chocolate_type=ChocolateType.DARK,
        components=(
            RecipeComponent.from_percent("ING-BEAN-FINE", 68.0),
            RecipeComponent.from_percent("ING-BUTTER", 6.0),
            RecipeComponent.from_percent("ING-SUGAR", 25.4),
            RecipeComponent.from_percent("ING-LECITHIN", 0.4, added_at_stage="conching"),
            RecipeComponent.from_percent("ING-VANILLA", 0.2, added_at_stage="conching"),
        ),
        process=ProcessSpec(
            roast_temperature_c=132.0,
            roast_minutes=76.0,
            target_particle_size_um=18.0,
            refining_passes=2,
            conche_temperature_c=66.0,
            conche_hours=26.0,
            conche_shear_intensity=0.7,
            temper_melt_c=50.0,
            temper_cool_c=27.0,
            temper_reheat_c=31.6,
            mould_temperature_c=30.5,
            cooling_tunnel_c=11.0,
            cooling_minutes=25.0,
        ),
        quality=QualitySpec(
            particle_size_um=Interval(low=14.0, high=22.0),
            fat_fraction=Interval(low=0.33, high=0.44),
            min_quality_score=83.0,
        ),
        default_batch_size_kg=800.0,
        min_batch_size_kg=200.0,
        max_batch_size_kg=2_000.0,
        author="ChocoSim reference library",
    )


def standard_recipes() -> tuple[Recipe, ...]:
    """The reference recipe set used by examples, tests and the demo factory."""
    return (
        dark_55(),
        dark_70(),
        dark_origin_bean_to_bar(),
        milk_35(),
        white_28(),
        dark_hazelnut(),
        milk_caramel_sea_salt(),
        dark_orange(),
    )


def build_standard_book() -> RecipeBook:
    """Construct a recipe book containing the standard formulations."""
    return RecipeBook(standard_recipes())


__all__ = [
    "RecipeBook",
    "build_standard_book",
    "dark_55",
    "dark_70",
    "dark_hazelnut",
    "dark_origin_bean_to_bar",
    "dark_orange",
    "milk_35",
    "milk_caramel_sea_salt",
    "standard_recipes",
    "white_28",
]
