"""Recipe domain models with immutable versioning.

A :class:`Recipe` is one immutable version of a formulation. A
:class:`RecipeLine` links it to a family of versions under a stable
``recipe_id``, so a batch can record exactly which formulation it was made to
even after the recipe has moved on. Formulations are never edited in place --
:meth:`Recipe.revise` returns a new version, which is the only way the history
stays trustworthy.
"""

from __future__ import annotations

import datetime as dt
from typing import Self

from pydantic import Field, model_validator

from ..core.exceptions import RecipeError
from ..core.models import ChocoModel, FrozenChocoModel, Interval
from ..core.types import (
    ChocolateType,
    IngredientId,
    Kilograms,
    Micrometres,
    Minutes,
    RecipeId,
)

#: Tolerance on the sum of recipe mass fractions.
FRACTION_TOLERANCE: float = 1e-6


class RecipeComponent(FrozenChocoModel):
    """One ingredient's share of a formulation.

    ``mass_fraction`` is a share of the *total* formulation mass, so the
    components of a valid recipe sum to exactly 1.0. Percentages are the usual
    way of writing this down, hence :meth:`from_percent`.
    """

    ingredient_id: IngredientId
    mass_fraction: float = Field(gt=0.0, le=1.0)
    #: Added at a stage other than the initial mix. Cocoa butter is routinely
    #: split, part at mixing and part at the end of conching, to control
    #: viscosity without over-refining. Nuts and fruit go in after conching so
    #: they are not destroyed by the refiner.
    added_at_stage: str | None = Field(default=None)
    note: str = Field(default="")

    @classmethod
    def from_percent(
        cls,
        ingredient_id: IngredientId,
        percent: float,
        added_at_stage: str | None = None,
        note: str = "",
    ) -> Self:
        """Build a component from a percentage of total mass."""
        return cls(
            ingredient_id=ingredient_id,
            mass_fraction=percent / 100.0,
            added_at_stage=added_at_stage,
            note=note,
        )

    @property
    def percent(self) -> float:
        """Mass fraction expressed as a percentage."""
        return self.mass_fraction * 100.0


class ProcessSpec(FrozenChocoModel):
    """Target process conditions for a formulation.

    These are the setpoints a recipe asks for. Whether the plant can hit them
    is a question for the process and production models, which is exactly the
    tension the simulator exists to explore.
    """

    roast_temperature_c: float = Field(default=140.0, ge=80.0, le=200.0)
    roast_minutes: Minutes = Field(default=25.0, gt=0.0, le=180.0)

    target_particle_size_um: Micrometres = Field(default=22.0, gt=0.0, le=200.0)
    refining_passes: int = Field(default=1, ge=1, le=5)

    conche_temperature_c: float = Field(default=60.0, ge=30.0, le=95.0)
    conche_hours: float = Field(default=12.0, gt=0.0, le=96.0)
    conche_shear_intensity: float = Field(
        default=0.6,
        gt=0.0,
        le=1.0,
        description="Normalised mixing intensity, 1.0 being the machine maximum.",
    )

    temper_melt_c: float = Field(default=48.0, ge=40.0, le=60.0)
    temper_cool_c: float = Field(default=27.0, ge=20.0, le=34.0)
    temper_reheat_c: float = Field(default=31.5, ge=25.0, le=36.0)
    temper_cool_rate_c_per_min: float = Field(default=1.2, gt=0.0, le=10.0)

    mould_temperature_c: float = Field(default=30.0, ge=20.0, le=40.0)
    cooling_tunnel_c: float = Field(default=12.0, ge=-5.0, le=25.0)
    cooling_minutes: Minutes = Field(default=22.0, gt=0.0, le=180.0)

    @model_validator(mode="after")
    def _check_temper_profile(self) -> Self:
        if not (self.temper_cool_c < self.temper_reheat_c < self.temper_melt_c):
            raise RecipeError(
                "tempering profile must satisfy cool < reheat < melt, got "
                f"cool={self.temper_cool_c}, reheat={self.temper_reheat_c}, "
                f"melt={self.temper_melt_c}"
            )
        return self


class QualitySpec(FrozenChocoModel):
    """Acceptance limits for a formulation."""

    particle_size_um: Interval = Field(
        default_factory=lambda: Interval(low=15.0, high=25.0)
    )
    viscosity_pas: Interval = Field(
        default_factory=lambda: Interval(low=1.5, high=4.5)
    )
    moisture_fraction: Interval = Field(
        default_factory=lambda: Interval(low=0.002, high=0.012)
    )
    fat_fraction: Interval = Field(
        default_factory=lambda: Interval(low=0.28, high=0.38)
    )
    temper_index: Interval = Field(
        default_factory=lambda: Interval(low=4.0, high=6.0),
        description="Conventional temper meter reading; ~5 is well tempered.",
    )
    max_defect_rate: float = Field(default=0.03, ge=0.0, le=1.0)
    min_quality_score: float = Field(default=80.0, ge=0.0, le=100.0)


class Recipe(FrozenChocoModel):
    """One immutable version of a formulation."""

    recipe_id: RecipeId
    version: int = Field(ge=1)
    name: str
    chocolate_type: ChocolateType

    components: tuple[RecipeComponent, ...] = Field(min_length=1)
    process: ProcessSpec = Field(default_factory=ProcessSpec)
    quality: QualitySpec = Field(default_factory=QualitySpec)

    default_batch_size_kg: Kilograms = Field(default=1_000.0, gt=0.0)
    min_batch_size_kg: Kilograms = Field(default=250.0, gt=0.0)
    max_batch_size_kg: Kilograms = Field(default=5_000.0, gt=0.0)

    created_on: dt.date = Field(default_factory=dt.date.today)
    author: str = Field(default="")
    change_note: str = Field(default="")
    active: bool = Field(default=True)

    @model_validator(mode="after")
    def _validate(self) -> Self:
        total = sum(component.mass_fraction for component in self.components)
        if abs(total - 1.0) > FRACTION_TOLERANCE:
            raise RecipeError(
                f"recipe {self.recipe_id!r} v{self.version}: component mass "
                f"fractions sum to {total:.8f}, expected 1.0 "
                f"(off by {total - 1.0:+.2e})"
            )

        seen: set[IngredientId] = set()
        for component in self.components:
            if component.ingredient_id in seen:
                raise RecipeError(
                    f"recipe {self.recipe_id!r} v{self.version}: ingredient "
                    f"{component.ingredient_id!r} appears more than once"
                )
            seen.add(component.ingredient_id)

        if self.min_batch_size_kg > self.max_batch_size_kg:
            raise RecipeError(
                f"recipe {self.recipe_id!r}: min batch size "
                f"{self.min_batch_size_kg} exceeds max {self.max_batch_size_kg}"
            )
        if not (
            self.min_batch_size_kg
            <= self.default_batch_size_kg
            <= self.max_batch_size_kg
        ):
            raise RecipeError(
                f"recipe {self.recipe_id!r}: default batch size "
                f"{self.default_batch_size_kg} lies outside "
                f"[{self.min_batch_size_kg}, {self.max_batch_size_kg}]"
            )
        return self

    @property
    def key(self) -> str:
        """Stable identifier for this exact version."""
        return f"{self.recipe_id}@v{self.version}"

    @property
    def ingredient_ids(self) -> tuple[IngredientId, ...]:
        """Identifiers of every ingredient in the formulation."""
        return tuple(component.ingredient_id for component in self.components)

    def fraction_of(self, ingredient_id: IngredientId) -> float:
        """Mass fraction of one ingredient, zero if absent."""
        for component in self.components:
            if component.ingredient_id == ingredient_id:
                return component.mass_fraction
        return 0.0

    def clamp_batch_size(self, requested_kg: Kilograms) -> Kilograms:
        """Clamp a requested batch size into the recipe's permitted range."""
        return min(self.max_batch_size_kg, max(self.min_batch_size_kg, requested_kg))

    def revise(
        self,
        components: tuple[RecipeComponent, ...] | None = None,
        process: ProcessSpec | None = None,
        quality: QualitySpec | None = None,
        change_note: str = "",
        author: str = "",
        **overrides: object,
    ) -> Recipe:
        """Return the next version of this recipe with the given changes."""
        update: dict[str, object] = {
            "version": self.version + 1,
            "created_on": dt.date.today(),
            "change_note": change_note,
            "author": author or self.author,
        }
        if components is not None:
            update["components"] = components
        if process is not None:
            update["process"] = process
        if quality is not None:
            update["quality"] = quality
        update.update(overrides)
        return self.model_copy(update=update)

    def rescale(self, fractions: dict[IngredientId, float]) -> Recipe:
        """Return a new version with the given fractions, renormalised.

        Renormalisation is deliberate: an optimiser that adjusts three of five
        components would otherwise produce a formulation that does not close.
        Any ingredient omitted from ``fractions`` keeps its current fraction
        before renormalisation.
        """
        raw = {
            component.ingredient_id: fractions.get(
                component.ingredient_id, component.mass_fraction
            )
            for component in self.components
        }
        total = sum(raw.values())
        if total <= 0.0:
            raise RecipeError("rescaled fractions sum to zero")
        components = tuple(
            component.model_copy(
                update={"mass_fraction": raw[component.ingredient_id] / total}
            )
            for component in self.components
            if raw[component.ingredient_id] > 0.0
        )
        return self.revise(components=components, change_note="rescaled")

    def summary_table(self) -> str:
        """Render the formulation in the conventional recipe-card layout."""
        width = max((len(c.ingredient_id) for c in self.components), default=20)
        lines = [self.name.upper(), ""]
        for component in sorted(
            self.components, key=lambda c: -c.mass_fraction
        ):
            lines.append(
                f"{component.ingredient_id:<{width}}  {component.percent:>6.2f}%"
            )
        lines.append("")
        lines.append(f"{'TOTAL':<{width}}  {100.0:>6.2f}%")
        return "\n".join(lines)


class RecipeLine(ChocoModel):
    """A family of recipe versions sharing one identifier."""

    recipe_id: RecipeId
    versions: list[Recipe] = Field(default_factory=list)

    @model_validator(mode="after")
    def _check_versions(self) -> Self:
        for recipe in self.versions:
            if recipe.recipe_id != self.recipe_id:
                raise RecipeError(
                    f"version {recipe.key} does not belong to line {self.recipe_id!r}"
                )
        numbers = [recipe.version for recipe in self.versions]
        if len(numbers) != len(set(numbers)):
            raise RecipeError(f"duplicate version numbers in line {self.recipe_id!r}")
        return self

    @property
    def latest(self) -> Recipe:
        """The highest-numbered version."""
        if not self.versions:
            raise RecipeError(f"recipe line {self.recipe_id!r} has no versions")
        return max(self.versions, key=lambda recipe: recipe.version)

    @property
    def current(self) -> Recipe:
        """The highest-numbered *active* version, falling back to the latest."""
        active = [recipe for recipe in self.versions if recipe.active]
        if not active:
            return self.latest
        return max(active, key=lambda recipe: recipe.version)

    def version(self, number: int) -> Recipe:
        """Return a specific version or raise."""
        for recipe in self.versions:
            if recipe.version == number:
                return recipe
        raise RecipeError(
            f"recipe {self.recipe_id!r} has no version {number}; "
            f"available: {sorted(r.version for r in self.versions)}"
        )

    def append(self, recipe: Recipe) -> Recipe:
        """Add a version to the line."""
        if recipe.recipe_id != self.recipe_id:
            raise RecipeError(
                f"cannot add {recipe.key} to line {self.recipe_id!r}"
            )
        if any(existing.version == recipe.version for existing in self.versions):
            raise RecipeError(
                f"version {recipe.version} already exists in line {self.recipe_id!r}"
            )
        self.versions.append(recipe)
        return recipe

    def diff(self, from_version: int, to_version: int) -> dict[IngredientId, float]:
        """Change in each ingredient's mass fraction between two versions.

        Ingredients added or removed appear with their full fraction as a
        positive or negative change.
        """
        before = self.version(from_version)
        after = self.version(to_version)
        ingredient_ids = set(before.ingredient_ids) | set(after.ingredient_ids)
        return {
            ingredient_id: after.fraction_of(ingredient_id)
            - before.fraction_of(ingredient_id)
            for ingredient_id in sorted(ingredient_ids)
            if abs(
                after.fraction_of(ingredient_id) - before.fraction_of(ingredient_id)
            )
            > FRACTION_TOLERANCE
        }


__all__ = [
    "FRACTION_TOLERANCE",
    "ProcessSpec",
    "QualitySpec",
    "Recipe",
    "RecipeComponent",
    "RecipeLine",
]
