"""Scenario analysis and Monte Carlo simulation.

Three capabilities the specification asks for, built on the same foundation.

**What-if scenarios.** A scenario is a named set of modifications to the
configuration and the ingredient prices, applied to a fresh factory, run, and
compared against a baseline. Because every model parameter lives in the
configuration, a scenario can move any of them without touching code.

**Monte Carlo.** Repeated replications with independent random streams,
reported as P10, P50 and P90. The seed tree in :mod:`chocosim.core.rng`
guarantees that replicate *i* is identical however many replicates are
requested and whatever order they run in, so a Monte Carlo result is
reproducible in a way that a naive shared-generator implementation is not.

**Current versus optimised.** Runs the factory as configured, then applies the
optimisers, then runs it again, and reports the difference across capacity,
utilisation, energy and waste.

One honesty note carried throughout: a P90 from this model is the 90th
percentile *of the model*, not of the factory. It reflects the variability the
model was told about. Real plants have failure modes nobody parameterised.
"""

from __future__ import annotations

import datetime as dt
from collections.abc import Callable, Sequence

import numpy as np
from pydantic import Field

from ..core.config import ChocoSimConfig
from ..core.fidelity import ModelProvenance
from ..core.models import FrozenChocoModel, safe_divide
from ..core.rng import RandomSource, percentiles
from ..core.types import IngredientClass, Kilograms, Money, RecipeId
from ..ingredients.registry import IngredientRegistry, build_default_registry
from ..production.factory import Factory, FactoryState
from ..recipes.library import RecipeBook, build_standard_book


class ScenarioModification(FrozenChocoModel):
    """One change a scenario makes to the world."""

    kind: str = Field(
        description="One of: price_class, price_ingredient, config, energy_price."
    )
    target: str = Field(description="What the change applies to.")
    value: float = Field(description="Multiplier or absolute value.")
    note: str = ""


class Scenario(FrozenChocoModel):
    """A named set of modifications applied to the baseline."""

    name: str
    description: str = ""
    modifications: tuple[ScenarioModification, ...] = ()

    def apply_to_registry(self, registry: IngredientRegistry) -> None:
        """Apply price modifications to an ingredient registry."""
        for modification in self.modifications:
            if modification.kind == "price_class":
                registry.shock_class(
                    IngredientClass(modification.target), modification.value
                )
            elif modification.kind == "price_cocoa_complex":
                registry.shock_cocoa_complex(modification.value)
            elif modification.kind == "price_ingredient":
                registry.set_price_multiplier(modification.target, modification.value)

    def apply_to_config(self, config: ChocoSimConfig) -> ChocoSimConfig:
        """Return a configuration with this scenario's changes applied."""
        updated = config.model_copy(deep=True)
        for modification in self.modifications:
            if modification.kind == "energy_price":
                updated.energy = updated.energy.scaled(modification.value)
            elif modification.kind == "config":
                # Dotted path into the configuration, e.g.
                # "economics.labour_rate_per_hour".
                parts = modification.target.split(".")
                node = updated
                for part in parts[:-1]:
                    node = getattr(node, part)
                setattr(node, parts[-1], modification.value)
        return updated


class ScenarioResult(FrozenChocoModel):
    """Outcome of running one scenario."""

    scenario_name: str
    state: FactoryState
    cost_per_kg: Money = Field(ge=0.0)
    ingredient_cost_per_kg: Money = Field(ge=0.0)
    energy_cost_per_kg: Money = Field(ge=0.0)
    saleable_kg: Kilograms = Field(ge=0.0)
    mean_quality_score: float = Field(ge=0.0, le=100.0)

    def delta_against(self, baseline: ScenarioResult) -> dict[str, float]:
        """Change against a baseline, as proportions where meaningful."""
        return {
            "cost_per_kg": self.cost_per_kg - baseline.cost_per_kg,
            "cost_per_kg_pct": safe_divide(
                self.cost_per_kg - baseline.cost_per_kg, baseline.cost_per_kg
            ),
            "saleable_kg": self.saleable_kg - baseline.saleable_kg,
            "energy_kwh_per_kg": self.state.energy_kwh_per_kg
            - baseline.state.energy_kwh_per_kg,
            "quality_score": self.mean_quality_score - baseline.mean_quality_score,
            "waste_fraction": self.state.waste_fraction - baseline.state.waste_fraction,
        }


class ScenarioComparison(FrozenChocoModel):
    """Baseline against one or more scenarios."""

    baseline: ScenarioResult
    scenarios: tuple[ScenarioResult, ...]
    provenance: ModelProvenance

    def report(self, symbol: str = "\u00a3") -> str:
        """Plain-text comparison table."""
        lines = [
            "SCENARIO COMPARISON",
            "=" * 86,
            f"{'SCENARIO':<28}{'COST/kg':>11}{'DELTA':>10}{'DELTA %':>10}"
            f"{'kWh/kg':>10}{'SCORE':>8}{'WASTE':>9}",
            "-" * 86,
            f"{self.baseline.scenario_name:<28}"
            f"{symbol + f'{self.baseline.cost_per_kg:.4f}':>11}"
            f"{'--':>10}{'--':>10}"
            f"{self.baseline.state.energy_kwh_per_kg:>10.3f}"
            f"{self.baseline.mean_quality_score:>8.1f}"
            f"{self.baseline.state.waste_fraction:>9.2%}",
        ]
        for scenario in self.scenarios:
            delta = scenario.delta_against(self.baseline)
            lines.append(
                f"{scenario.scenario_name:<28}"
                f"{symbol + f'{scenario.cost_per_kg:.4f}':>11}"
                f"{delta['cost_per_kg']:>+10.4f}"
                f"{delta['cost_per_kg_pct']:>+10.2%}"
                f"{scenario.state.energy_kwh_per_kg:>10.3f}"
                f"{scenario.mean_quality_score:>8.1f}"
                f"{scenario.state.waste_fraction:>9.2%}"
            )
        lines += ["", self.provenance.banner()]
        return "\n".join(lines)


class ScenarioEngine:
    """Runs what-if scenarios against a baseline factory."""

    MODEL_NAME = "scenario_engine"

    def __init__(
        self,
        config: ChocoSimConfig | None = None,
        recipe_book: RecipeBook | None = None,
    ) -> None:
        self.config = config or ChocoSimConfig.default()
        self.recipe_book = recipe_book or build_standard_book()

    def _build_factory(self, scenario: Scenario | None) -> Factory:
        """Construct a fresh factory with a scenario applied.

        A fresh registry every time. Reusing one would let a price shock from
        an earlier scenario leak into a later one, which is the kind of bug
        that silently corrupts every number in a comparison table.
        """
        registry = build_default_registry()
        config = self.config
        if scenario is not None:
            scenario.apply_to_registry(registry)
            config = scenario.apply_to_config(config)
        return Factory(config, registry, self.recipe_book)

    def run_scenario(
        self,
        scenario: Scenario | None,
        schedule: Sequence[tuple[RecipeId, Kilograms]],
        start_date: dt.date,
        name: str | None = None,
    ) -> ScenarioResult:
        """Run one scenario and summarise it."""
        factory = self._build_factory(scenario)
        factory.stock_up(start_date, days_of_cover=45.0, daily_demand_kg=10_000.0)
        factory.produce_schedule(schedule, start_date, batches_per_day=4)

        state = factory.state(start_date)
        costings = [outcome.costing for outcome in factory.outcomes]
        total_cost = sum(costing.total_cost for costing in costings)
        saleable = sum(costing.saleable_mass_kg for costing in costings)

        ingredient_cost = sum(
            costing.by_category().get("ingredients", 0.0) for costing in costings
        )
        energy_cost = sum(
            costing.by_category().get("energy", 0.0) for costing in costings
        )

        return ScenarioResult(
            scenario_name=name or (scenario.name if scenario else "baseline"),
            state=state,
            cost_per_kg=safe_divide(total_cost, saleable),
            ingredient_cost_per_kg=safe_divide(ingredient_cost, saleable),
            energy_cost_per_kg=safe_divide(energy_cost, saleable),
            saleable_kg=saleable,
            mean_quality_score=state.mean_quality_score,
        )

    def compare(
        self,
        scenarios: Sequence[Scenario],
        schedule: Sequence[tuple[RecipeId, Kilograms]],
        start_date: dt.date,
    ) -> ScenarioComparison:
        """Run a baseline and several scenarios, and compare them."""
        baseline = self.run_scenario(None, schedule, start_date, name="Baseline")
        results = [
            self.run_scenario(scenario, schedule, start_date) for scenario in scenarios
        ]
        return ScenarioComparison(
            baseline=baseline,
            scenarios=tuple(results),
            provenance=ModelProvenance.simulation(
                self.MODEL_NAME,
                basis="Repeated deterministic factory runs under modified parameters",
                assumptions=(
                    "Only the parameters named in the scenario change",
                    "The production schedule is held fixed across scenarios",
                    "Operational response to the shock is not modelled",
                ),
                extra_caveats=(
                    "Scenarios show the mechanical consequence of a parameter "
                    "change, not what a business would actually do about it.",
                ),
            ),
        )


# --------------------------------------------------------------------------
# Standard scenarios
# --------------------------------------------------------------------------


def cocoa_price_rise(magnitude: float = 1.20) -> Scenario:
    """The specification's worked example: cocoa prices rise 20%."""
    return Scenario(
        name=f"Cocoa +{(magnitude - 1.0):.0%}",
        description=(
            "Market-wide cocoa price shock applied across beans, nibs, liquor, "
            "butter and powder together."
        ),
        modifications=(
            ScenarioModification(
                kind="price_cocoa_complex",
                target="cocoa",
                value=magnitude,
                note="Applied to the whole cocoa complex.",
            ),
        ),
    )


def energy_price_rise(magnitude: float = 1.50) -> Scenario:
    """Energy costs rise across every carrier."""
    return Scenario(
        name=f"Energy +{(magnitude - 1.0):.0%}",
        description="All energy carriers rise together.",
        modifications=(
            ScenarioModification(
                kind="energy_price", target="all", value=magnitude
            ),
        ),
    )


def sugar_price_rise(magnitude: float = 1.40) -> Scenario:
    """Sugar prices rise."""
    return Scenario(
        name=f"Sugar +{(magnitude - 1.0):.0%}",
        description="Sugar price shock.",
        modifications=(
            ScenarioModification(
                kind="price_class", target="sugar", value=magnitude
            ),
        ),
    )


def labour_cost_rise(rate: float = 21.0) -> Scenario:
    """Labour rates rise to a new hourly figure."""
    return Scenario(
        name=f"Labour to {rate:.2f}/h",
        description="Direct labour rate increase.",
        modifications=(
            ScenarioModification(
                kind="config",
                target="economics.labour_rate_per_hour",
                value=rate,
            ),
        ),
    )


def combined_input_shock() -> Scenario:
    """Cocoa, sugar and energy all rise together."""
    return Scenario(
        name="Combined input shock",
        description="Cocoa +20%, sugar +40%, energy +50% simultaneously.",
        modifications=(
            ScenarioModification(
                kind="price_cocoa_complex", target="cocoa", value=1.20
            ),
            ScenarioModification(kind="price_class", target="sugar", value=1.40),
            ScenarioModification(kind="energy_price", target="all", value=1.50),
        ),
    )


def standard_scenarios() -> tuple[Scenario, ...]:
    """The reference scenario set."""
    return (
        cocoa_price_rise(1.20),
        sugar_price_rise(1.40),
        energy_price_rise(1.50),
        labour_cost_rise(21.0),
        combined_input_shock(),
    )


# --------------------------------------------------------------------------
# Monte Carlo
# --------------------------------------------------------------------------


class MonteCarloResult(FrozenChocoModel):
    """Distribution of an outcome across replications."""

    metric: str
    replications: int = Field(gt=0)
    samples: tuple[float, ...]
    mean: float
    std: float = Field(ge=0.0)
    p10: float
    p50: float
    p90: float
    minimum: float
    maximum: float

    @property
    def coefficient_of_variation(self) -> float:
        """Relative dispersion of the outcome."""
        return safe_divide(self.std, abs(self.mean))

    @property
    def p90_p10_ratio(self) -> float:
        """Spread between the optimistic and pessimistic deciles."""
        return safe_divide(self.p90, self.p10)

    def probability_below(self, threshold: float) -> float:
        """Share of replications falling below a threshold."""
        if not self.samples:
            return 0.0
        return sum(1 for sample in self.samples if sample < threshold) / len(
            self.samples
        )

    def probability_above(self, threshold: float) -> float:
        """Share of replications exceeding a threshold."""
        return 1.0 - self.probability_below(threshold)

    def summary(self) -> str:
        """One-line distribution summary."""
        return (
            f"{self.metric:<24} P10 {self.p10:>10.4f}  P50 {self.p50:>10.4f}  "
            f"P90 {self.p90:>10.4f}  (mean {self.mean:>10.4f}, "
            f"CV {self.coefficient_of_variation:.1%})"
        )

    @classmethod
    def from_samples(cls, metric: str, samples: Sequence[float]) -> MonteCarloResult:
        """Build a result from raw replication outputs."""
        if not samples:
            raise ValueError(f"no samples for metric {metric!r}")
        array = np.asarray(samples, dtype=float)
        quantiles = percentiles(array, 10, 50, 90)
        return cls(
            metric=metric,
            replications=len(array),
            samples=tuple(float(value) for value in array),
            mean=float(array.mean()),
            std=float(array.std(ddof=1)) if len(array) > 1 else 0.0,
            p10=quantiles["p10"],
            p50=quantiles["p50"],
            p90=quantiles["p90"],
            minimum=float(array.min()),
            maximum=float(array.max()),
        )


class MonteCarloReport(FrozenChocoModel):
    """A set of Monte Carlo distributions from one study."""

    replications: int = Field(gt=0)
    results: dict[str, MonteCarloResult]
    provenance: ModelProvenance

    def get(self, metric: str) -> MonteCarloResult | None:
        """One metric's distribution."""
        return self.results.get(metric)

    def report(self) -> str:
        """Plain-text Monte Carlo summary."""
        lines = [
            f"MONTE CARLO -- {self.replications} replications",
            "=" * 88,
        ]
        lines += [result.summary() for result in self.results.values()]
        lines += ["", self.provenance.banner()]
        return "\n".join(lines)


class MonteCarloEngine:
    """Runs replicated simulations and summarises the distributions."""

    MODEL_NAME = "monte_carlo"

    def __init__(
        self,
        config: ChocoSimConfig | None = None,
        recipe_book: RecipeBook | None = None,
    ) -> None:
        self.config = config or ChocoSimConfig.default()
        self.recipe_book = recipe_book or build_standard_book()

    def run(
        self,
        schedule: Sequence[tuple[RecipeId, Kilograms]],
        start_date: dt.date,
        replications: int = 100,
        scenario: Scenario | None = None,
        extractor: Callable[[Factory], dict[str, float]] | None = None,
    ) -> MonteCarloReport:
        """Run replicated factory simulations.

        Each replication gets an independent seed derived from the root, so
        results are reproducible and adding replications does not change the
        ones already computed.
        """
        if replications <= 0:
            raise ValueError("replications must be positive")

        root = RandomSource(self.config.simulation.seed)
        collected: dict[str, list[float]] = {}

        for index in range(replications):
            replicate_source = root.replicate(index)
            config = self.config.model_copy(deep=True)
            config.simulation.seed = replicate_source.seed
            config.simulation.deterministic = False

            registry = build_default_registry()
            if scenario is not None:
                scenario.apply_to_registry(registry)
                config = scenario.apply_to_config(config)

            factory = Factory(config, registry, self.recipe_book)
            factory.stock_up(start_date, days_of_cover=45.0, daily_demand_kg=10_000.0)
            factory.produce_schedule(schedule, start_date, batches_per_day=4)

            metrics = (
                extractor(factory) if extractor else self.default_metrics(factory)
            )
            for name, value in metrics.items():
                collected.setdefault(name, []).append(value)

        results = {
            name: MonteCarloResult.from_samples(name, values)
            for name, values in collected.items()
        }

        return MonteCarloReport(
            replications=replications,
            results=results,
            # Deliberately SIMULATION, not PREDICTION. Running an uncalibrated
            # model a thousand times produces a very precise description of
            # the model and tells you nothing new about the factory. The
            # fidelity registry enforces this: claiming PREDICTION without a
            # calibration record raises.
            provenance=ModelProvenance.simulation(
                self.MODEL_NAME,
                basis="Independent replications over the model's stochastic inputs",
                assumptions=(
                    "Input distributions are as configured",
                    "Replications are independent",
                    "The model captures the dominant sources of variability",
                ),
                extra_caveats=(
                    "Percentiles describe the variability the model was given. "
                    "They do not bound outcomes the model does not represent.",
                ),
            ),
        )

    @staticmethod
    def default_metrics(factory: Factory) -> dict[str, float]:
        """The metrics collected when no extractor is supplied."""
        state = factory.state()
        costings = [outcome.costing for outcome in factory.outcomes]
        total_cost = sum(costing.total_cost for costing in costings)
        saleable = sum(costing.saleable_mass_kg for costing in costings)
        return {
            "saleable_kg": saleable,
            "cost_per_kg": safe_divide(total_cost, saleable),
            "energy_kwh_per_kg": state.energy_kwh_per_kg,
            "mean_quality_score": state.mean_quality_score,
            "waste_fraction": state.waste_fraction,
            "pass_rate": state.pass_rate,
        }


__all__ = [
    "MonteCarloEngine",
    "MonteCarloReport",
    "MonteCarloResult",
    "Scenario",
    "ScenarioComparison",
    "ScenarioEngine",
    "ScenarioModification",
    "ScenarioResult",
    "cocoa_price_rise",
    "combined_input_shock",
    "energy_price_rise",
    "labour_cost_rise",
    "standard_scenarios",
    "sugar_price_rise",
]
