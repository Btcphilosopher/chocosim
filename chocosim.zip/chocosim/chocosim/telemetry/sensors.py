"""Telemetry: synthetic sensors and an event store.

The specification asks for a simulation-first system: no real plant, no real
sensors, everything virtual. This module provides the virtual instrumentation
layer -- synthetic sensor readings with realistic noise, drift and occasional
faults, plus a store that keeps them queryable.

Sensor realism matters more than it might appear. A perfect sensor makes a
control or monitoring model look far better than it will be in practice,
because half the difficulty in a real plant is deciding whether a reading is
the process moving or the instrument lying. Each sensor here therefore carries
noise, a slow drift, a quantisation step and a small probability of a stuck or
spiking fault.

Nothing here is a substitute for real instrumentation. These readings are
generated *from* the simulation, so using them to validate the simulation
would be circular.
"""

from __future__ import annotations

import datetime as dt
import math
from collections.abc import Iterable, Sequence

import polars as pl
from pydantic import Field

from ..core.models import ChocoModel, FrozenChocoModel, clamp
from ..core.rng import RandomSource, bernoulli
from ..core.types import MachineId, ProcessStageKind


class SensorSpec(FrozenChocoModel):
    """Specification of a virtual sensor."""

    sensor_id: str
    name: str
    unit: str
    machine_id: MachineId | None = None
    stage: ProcessStageKind | None = None

    noise_sigma: float = Field(
        default=0.0, ge=0.0, description="Standard deviation of measurement noise."
    )
    drift_per_hour: float = Field(
        default=0.0, description="Slow calibration drift, units per hour."
    )
    quantisation: float = Field(
        default=0.0, ge=0.0, description="Resolution of the reading."
    )
    range_low: float = Field(default=-1e9)
    range_high: float = Field(default=1e9)

    stuck_probability: float = Field(
        default=0.0005,
        ge=0.0,
        le=1.0,
        description="Chance per reading that the sensor repeats its last value.",
    )
    spike_probability: float = Field(
        default=0.0008,
        ge=0.0,
        le=1.0,
        description="Chance per reading of a gross outlier.",
    )
    spike_magnitude: float = Field(default=8.0, ge=0.0)

    def quantise(self, value: float) -> float:
        """Round a value to the sensor's resolution."""
        if self.quantisation <= 0.0:
            return value
        return round(value / self.quantisation) * self.quantisation


class Reading(FrozenChocoModel):
    """One sensor reading."""

    sensor_id: str
    timestamp: dt.datetime
    value: float
    true_value: float
    unit: str
    machine_id: MachineId | None = None
    quality_flag: str = "ok"

    @property
    def error(self) -> float:
        """Difference between the reading and the underlying truth."""
        return self.value - self.true_value

    @property
    def is_suspect(self) -> bool:
        """Whether the reading carries a fault flag."""
        return self.quality_flag != "ok"


class SyntheticSensor:
    """A virtual sensor that corrupts a true value realistically."""

    def __init__(self, spec: SensorSpec) -> None:
        self.spec = spec
        self._elapsed_hours = 0.0
        self._last_value: float | None = None

    def read(
        self,
        true_value: float,
        timestamp: dt.datetime,
        source: RandomSource,
        elapsed_hours: float | None = None,
    ) -> Reading:
        """Produce a reading of a true value."""
        spec = self.spec
        if elapsed_hours is not None:
            self._elapsed_hours = elapsed_hours

        generator = source.generator(f"sensor/{spec.sensor_id}")
        flag = "ok"

        if bernoulli(generator, spec.stuck_probability) and self._last_value is not None:
            value = self._last_value
            flag = "stuck"
        else:
            value = true_value + spec.drift_per_hour * self._elapsed_hours
            if spec.noise_sigma > 0.0:
                value += float(generator.normal(0.0, spec.noise_sigma))
            if bernoulli(generator, spec.spike_probability):
                direction = 1.0 if generator.random() < 0.5 else -1.0
                value += direction * spec.spike_magnitude * max(spec.noise_sigma, 1.0)
                flag = "spike"

        value = spec.quantise(clamp(value, spec.range_low, spec.range_high))
        self._last_value = value

        return Reading(
            sensor_id=spec.sensor_id,
            timestamp=timestamp,
            value=value,
            true_value=true_value,
            unit=spec.unit,
            machine_id=spec.machine_id,
            quality_flag=flag,
        )

    def advance(self, hours: float) -> None:
        """Age the sensor, accumulating drift."""
        self._elapsed_hours += hours

    def calibrate(self) -> None:
        """Reset accumulated drift."""
        self._elapsed_hours = 0.0


class TelemetryStore:
    """Collects readings and answers queries over them."""

    def __init__(self) -> None:
        self.readings: list[Reading] = []
        self.sensors: dict[str, SyntheticSensor] = {}

    def register(self, spec: SensorSpec) -> SyntheticSensor:
        """Add a sensor to the store."""
        sensor = SyntheticSensor(spec)
        self.sensors[spec.sensor_id] = sensor
        return sensor

    def record(
        self,
        sensor_id: str,
        true_value: float,
        timestamp: dt.datetime,
        source: RandomSource,
    ) -> Reading:
        """Take and store a reading."""
        sensor = self.sensors[sensor_id]
        reading = sensor.read(true_value, timestamp, source)
        self.readings.append(reading)
        return reading

    def record_batch(
        self,
        values: dict[str, float],
        timestamp: dt.datetime,
        source: RandomSource,
    ) -> list[Reading]:
        """Take readings from several sensors at one instant."""
        return [
            self.record(sensor_id, value, timestamp, source)
            for sensor_id, value in values.items()
            if sensor_id in self.sensors
        ]

    def frame(self) -> pl.DataFrame:
        """Readings as a Polars data frame.

        Polars rather than pandas because telemetry is the one place in this
        system where row counts get large, and the columnar representation and
        lazy grouping matter once a run generates hundreds of thousands of
        readings.
        """
        if not self.readings:
            return pl.DataFrame(
                schema={
                    "sensor_id": pl.Utf8,
                    "timestamp": pl.Datetime,
                    "value": pl.Float64,
                    "true_value": pl.Float64,
                    "unit": pl.Utf8,
                    "machine_id": pl.Utf8,
                    "quality_flag": pl.Utf8,
                }
            )
        return pl.DataFrame(
            {
                "sensor_id": [r.sensor_id for r in self.readings],
                "timestamp": [r.timestamp for r in self.readings],
                "value": [r.value for r in self.readings],
                "true_value": [r.true_value for r in self.readings],
                "unit": [r.unit for r in self.readings],
                "machine_id": [r.machine_id or "" for r in self.readings],
                "quality_flag": [r.quality_flag for r in self.readings],
            }
        )

    def series(self, sensor_id: str) -> pl.DataFrame:
        """All readings from one sensor, in time order."""
        frame = self.frame()
        if frame.height == 0:
            return frame
        return frame.filter(pl.col("sensor_id") == sensor_id).sort("timestamp")

    def summary(self) -> pl.DataFrame:
        """Per-sensor summary statistics, including measurement error."""
        frame = self.frame()
        if frame.height == 0:
            return frame
        return (
            frame.with_columns((pl.col("value") - pl.col("true_value")).alias("error"))
            .group_by("sensor_id")
            .agg(
                pl.len().alias("readings"),
                pl.col("value").mean().alias("mean"),
                pl.col("value").std().alias("std"),
                pl.col("value").min().alias("min"),
                pl.col("value").max().alias("max"),
                pl.col("error").abs().mean().alias("mean_abs_error"),
                (pl.col("quality_flag") != "ok").sum().alias("suspect_readings"),
            )
            .sort("sensor_id")
        )

    def suspect_rate(self) -> float:
        """Share of readings carrying a fault flag."""
        if not self.readings:
            return 0.0
        return sum(1 for r in self.readings if r.is_suspect) / len(self.readings)

    def clear(self) -> None:
        """Discard stored readings, keeping sensor registrations."""
        self.readings.clear()


def default_sensor_specs() -> tuple[SensorSpec, ...]:
    """A representative instrument set for the line."""
    return (
        SensorSpec(
            sensor_id="TT-ROAST-01",
            name="Roaster bean temperature",
            unit="degC",
            machine_id="MCH-ROAST-01",
            stage=ProcessStageKind.ROASTING,
            noise_sigma=0.8,
            drift_per_hour=0.004,
            quantisation=0.1,
            range_low=0.0,
            range_high=250.0,
        ),
        SensorSpec(
            sensor_id="MT-ROAST-01",
            name="Roaster exhaust moisture",
            unit="fraction",
            machine_id="MCH-ROAST-01",
            stage=ProcessStageKind.ROASTING,
            noise_sigma=0.0015,
            drift_per_hour=0.00002,
            quantisation=0.0001,
            range_low=0.0,
            range_high=0.2,
        ),
        SensorSpec(
            sensor_id="PS-REFINE-01",
            name="Refiner outlet particle size d90",
            unit="um",
            machine_id="MCH-REFINE-01",
            stage=ProcessStageKind.REFINING,
            noise_sigma=0.6,
            drift_per_hour=0.002,
            quantisation=0.1,
            range_low=0.0,
            range_high=200.0,
        ),
        SensorSpec(
            sensor_id="VI-CONCHE-01",
            name="Conche mass viscosity",
            unit="Pa.s",
            machine_id="MCH-CONCHE-01",
            stage=ProcessStageKind.CONCHING,
            noise_sigma=0.08,
            drift_per_hour=0.001,
            quantisation=0.01,
            range_low=0.0,
            range_high=50.0,
        ),
        SensorSpec(
            sensor_id="TT-CONCHE-01",
            name="Conche mass temperature",
            unit="degC",
            machine_id="MCH-CONCHE-01",
            stage=ProcessStageKind.CONCHING,
            noise_sigma=0.35,
            drift_per_hour=0.003,
            quantisation=0.1,
            range_low=0.0,
            range_high=120.0,
        ),
        SensorSpec(
            sensor_id="TI-TEMPER-01",
            name="Temper meter index",
            unit="index",
            machine_id="MCH-TEMPER-01",
            stage=ProcessStageKind.TEMPERING,
            noise_sigma=0.18,
            drift_per_hour=0.002,
            quantisation=0.05,
            range_low=0.0,
            range_high=10.0,
            spike_probability=0.0015,
        ),
        SensorSpec(
            sensor_id="TT-TUNNEL-01",
            name="Cooling tunnel air temperature",
            unit="degC",
            machine_id="MCH-TUNNEL-01",
            stage=ProcessStageKind.COOLING,
            noise_sigma=0.4,
            drift_per_hour=0.002,
            quantisation=0.1,
            range_low=-20.0,
            range_high=40.0,
        ),
        SensorSpec(
            sensor_id="WT-PACK-01",
            name="Checkweigher pack weight",
            unit="g",
            machine_id="MCH-WRAP-01",
            stage=ProcessStageKind.PACKAGING,
            noise_sigma=0.25,
            quantisation=0.1,
            range_low=0.0,
            range_high=10_000.0,
        ),
        SensorSpec(
            sensor_id="PW-SITE-01",
            name="Site electrical demand",
            unit="kW",
            noise_sigma=4.5,
            drift_per_hour=0.01,
            quantisation=0.5,
            range_low=0.0,
            range_high=5_000.0,
        ),
    )


def build_default_store() -> TelemetryStore:
    """A telemetry store with the standard instrument set registered."""
    store = TelemetryStore()
    for spec in default_sensor_specs():
        store.register(spec)
    return store


__all__ = [
    "Reading",
    "SensorSpec",
    "SyntheticSensor",
    "TelemetryStore",
    "build_default_store",
    "default_sensor_specs",
]
