"""Cocoa butter polymorphism.

Cocoa butter is polymorphic: the same triglycerides crystallise into six
distinct solid forms with different melting points and different physical
properties. Only one of them, Form V, gives chocolate the properties consumers
recognise -- a hard snap, a glossy surface, contraction on setting so the bar
releases from the mould, and stability in storage.

    Form   Melting point   Character
    I      17.3 degC       Unstable, forms on rapid quenching
    II     23.3 degC       Unstable
    III    25.5 degC       Unstable
    IV     27.5 degC       Soft, crumbly, dull; the classic mistemper
    V      33.8 degC       The target: snap, gloss, contraction
    VI     36.3 degC       Most stable; forms slowly in storage as bloom

Two consequences drive the entire tempering operation. First, the forms melt
at different temperatures, so a controlled thermal cycle can melt out the
unstable ones while leaving Form V seeds intact. Second, Form VI is *more*
stable than Form V, so a well-tempered bar is thermodynamically metastable and
will eventually convert -- which is what fat bloom is, and why storage
temperature matters as much as tempering did.
"""

from __future__ import annotations

import math
from collections.abc import Iterator

from pydantic import Field

from ..core.models import FrozenChocoModel, clamp
from ..core.types import Celsius, CrystalForm, TemperGrade

#: Melting points of the cocoa butter polymorphs, degC.
MELTING_POINTS: dict[CrystalForm, Celsius] = {
    CrystalForm.FORM_I: 17.3,
    CrystalForm.FORM_II: 23.3,
    CrystalForm.FORM_III: 25.5,
    CrystalForm.FORM_IV: 27.5,
    CrystalForm.FORM_V: 33.8,
    CrystalForm.FORM_VI: 36.3,
}

#: Enthalpy of fusion of each polymorph, kJ/kg. More stable forms pack more
#: tightly and take more energy to melt.
ENTHALPY_OF_FUSION: dict[CrystalForm, float] = {
    CrystalForm.FORM_I: 86.0,
    CrystalForm.FORM_II: 107.0,
    CrystalForm.FORM_III: 114.0,
    CrystalForm.FORM_IV: 119.0,
    CrystalForm.FORM_V: 135.0,
    CrystalForm.FORM_VI: 148.0,
}

#: Relative nucleation rate of each form at its own optimum supercooling.
#: Unstable forms nucleate far faster, which is precisely the problem: left to
#: itself, chocolate crystallises into forms IV and below.
NUCLEATION_PROPENSITY: dict[CrystalForm, float] = {
    CrystalForm.FORM_I: 12.0,
    CrystalForm.FORM_II: 8.5,
    CrystalForm.FORM_III: 5.0,
    CrystalForm.FORM_IV: 3.2,
    CrystalForm.FORM_V: 1.0,
    CrystalForm.FORM_VI: 0.04,
}

#: Order in which the forms convert towards stability.
STABILITY_ORDER: tuple[CrystalForm, ...] = (
    CrystalForm.FORM_I,
    CrystalForm.FORM_II,
    CrystalForm.FORM_III,
    CrystalForm.FORM_IV,
    CrystalForm.FORM_V,
    CrystalForm.FORM_VI,
)

#: Width of the melting transition, degC. Real polymorphs melt over a range
#: rather than at a point, because the triglyceride mixture is not pure.
MELTING_WIDTH_C: float = 1.6

#: Solid fat fraction at which a temper meter reads 5.0 on pure Form V seed.
TEMPER_INDEX_REFERENCE_SOLIDS: float = 0.070

#: Temper index below which a mass is under-seeded and will bloom.
UNDER_TEMPER_INDEX: float = 3.5
#: Temper index above which a mass is over-seeded: thick, dull, poor release.
OVER_TEMPER_INDEX: float = 7.0

#: Milk fat depresses the melting point of cocoa butter: it is mutually
#: soluble and disrupts the crystal lattice. This is why milk chocolate is
#: tempered a couple of degrees cooler than dark, and why high milk-fat
#: recipes are softer at room temperature.
MILK_FAT_DEPRESSION_C_PER_FRACTION: float = 9.0


def melting_point(
    form: CrystalForm, milk_fat_share: float = 0.0
) -> Celsius:
    """Melting point of a polymorph, adjusted for milk fat content."""
    return MELTING_POINTS[form] - MILK_FAT_DEPRESSION_C_PER_FRACTION * clamp(
        milk_fat_share, 0.0, 1.0
    )


def molten_fraction(
    form: CrystalForm, temperature_c: Celsius, milk_fat_share: float = 0.0
) -> float:
    """Fraction of a polymorph that is molten at a temperature.

    A smooth sigmoid across the melting range rather than a step, because a
    step makes the tempering ODE stiff and produces spurious sensitivity to
    tenths of a degree that the process does not actually have.
    """
    point = melting_point(form, milk_fat_share)
    z = (temperature_c - point) / MELTING_WIDTH_C
    return 1.0 / (1.0 + math.exp(-2.2 * z))


class CrystalState(FrozenChocoModel):
    """Distribution of fat crystal forms in a mass.

    Fractions are of the *fat phase*, not the total mass, and sum to at most
    1.0 with the remainder molten.
    """

    fractions: dict[CrystalForm, float] = Field(default_factory=dict)

    @classmethod
    def molten(cls) -> CrystalState:
        """A fully molten fat phase with no crystals."""
        return cls(fractions={})

    @classmethod
    def well_tempered(cls, solid_fraction: float = 0.035) -> CrystalState:
        """A correctly seeded mass: a small amount of pure Form V.

        Well-tempered chocolate leaving a temperer carries only 1-4% solid fat.
        The rest crystallises in the cooling tunnel, templated by those seeds.
        Too many seeds and the mass is too viscous to mould; too few and it
        sets in whatever form it likes.
        """
        return cls(fractions={CrystalForm.FORM_V: solid_fraction})

    @property
    def total_solid(self) -> float:
        """Total crystallised fraction of the fat phase."""
        return sum(self.fractions.values())

    @property
    def liquid_fraction(self) -> float:
        """Molten fraction of the fat phase."""
        return max(0.0, 1.0 - self.total_solid)

    def fraction_of(self, form: CrystalForm) -> float:
        """Fraction present as a given polymorph."""
        return self.fractions.get(form, 0.0)

    @property
    def stable_fraction(self) -> float:
        """Fraction present as Form V or VI."""
        return self.fraction_of(CrystalForm.FORM_V) + self.fraction_of(
            CrystalForm.FORM_VI
        )

    @property
    def unstable_fraction(self) -> float:
        """Fraction present as Forms I to IV."""
        return sum(
            self.fractions.get(form, 0.0)
            for form in (
                CrystalForm.FORM_I,
                CrystalForm.FORM_II,
                CrystalForm.FORM_III,
                CrystalForm.FORM_IV,
            )
        )

    @property
    def purity(self) -> float:
        """Share of the crystallised fat that is in Form V.

        The single most diagnostic number in tempering. A mass can be 3% solid
        and perfectly tempered, or 3% solid and ruined, depending entirely on
        which forms those crystals are.
        """
        total = self.total_solid
        if total <= 1e-12:
            return 0.0
        return self.fraction_of(CrystalForm.FORM_V) / total

    def temper_index(self) -> float:
        """Conventional temper meter reading, roughly 0 to 10.

        Temper meters work by cooling a sample and watching the crystallisation
        exotherm; the instrument reports a slope. Around 5 indicates correct
        temper, below 4 under-temper (too few seeds, will bloom), above 6
        over-temper (too many seeds, thick and dull, poor mould release).

        Modelled here from seed quantity and purity, which is what the
        instrument is indirectly measuring.
        """
        solid = self.total_solid
        if solid <= 1e-9:
            return 0.0
        # The instrument responds to the size of the crystallisation exotherm,
        # which scales with how much seed the sample already carries, weighted
        # by how much of that seed is the form that templates further growth.
        # Anchored so that 3.5% solid fat of pure Form V -- the textbook
        # correct temper -- reads exactly 5.0.
        quantity_term = 10.0 * solid / TEMPER_INDEX_REFERENCE_SOLIDS
        return clamp(quantity_term * (0.35 + 0.65 * self.purity), 0.0, 10.0)

    def grade(self) -> TemperGrade:
        """Categorical temper assessment.

        Quantity and purity are judged separately because they fail in
        different ways. Too little seed and the bar bloom;, too much and it is
        thick and dull. Impure seed reads acceptably on quantity alone but
        carries unstable crystals that will convert in storage, so purity
        gates the upper grades independently.
        """
        index = self.temper_index()
        if index < 1.0:
            return TemperGrade.UNTEMPERED
        if index < UNDER_TEMPER_INDEX:
            return TemperGrade.UNDER_TEMPERED
        if index > OVER_TEMPER_INDEX:
            return TemperGrade.OVER_TEMPERED
        if self.purity >= 0.92:
            return TemperGrade.EXCELLENT
        if self.purity >= 0.82:
            return TemperGrade.GOOD
        if self.purity >= 0.70:
            return TemperGrade.ACCEPTABLE
        return TemperGrade.UNDER_TEMPERED

    @property
    def is_acceptable(self) -> bool:
        """Whether the mass is fit to mould."""
        return self.grade() in (
            TemperGrade.ACCEPTABLE,
            TemperGrade.GOOD,
            TemperGrade.EXCELLENT,
        )

    def normalised(self) -> CrystalState:
        """Clamp fractions into a physically valid state."""
        cleaned = {
            form: max(0.0, value)
            for form, value in self.fractions.items()
            if value > 1e-12
        }
        total = sum(cleaned.values())
        if total > 1.0:
            cleaned = {form: value / total for form, value in cleaned.items()}
        return CrystalState(fractions=cleaned)

    def melt(
        self, temperature_c: Celsius, milk_fat_share: float = 0.0, dt_minutes: float = 1.0
    ) -> CrystalState:
        """Melt out crystals that are above their melting point.

        Melting is fast relative to crystallisation -- there is no nucleation
        barrier to overcome -- so a short exposure above a form's melting point
        removes it almost completely. That asymmetry is what makes tempering
        work at all.
        """
        updated: dict[CrystalForm, float] = {}
        for form, fraction in self.fractions.items():
            molten = molten_fraction(form, temperature_c, milk_fat_share)
            survival = math.exp(-4.0 * molten * dt_minutes)
            remaining = fraction * survival
            if remaining > 1e-12:
                updated[form] = remaining
        return CrystalState(fractions=updated)

    def with_form(self, form: CrystalForm, fraction: float) -> CrystalState:
        """Return a copy with a form's fraction set."""
        updated = dict(self.fractions)
        if fraction <= 1e-12:
            updated.pop(form, None)
        else:
            updated[form] = fraction
        return CrystalState(fractions=updated)

    def add(self, form: CrystalForm, amount: float) -> CrystalState:
        """Return a copy with crystal added to a form."""
        return self.with_form(form, self.fraction_of(form) + amount)

    def __iter__(self) -> Iterator[tuple[CrystalForm, float]]:
        for form in STABILITY_ORDER:
            fraction = self.fractions.get(form, 0.0)
            if fraction > 0.0:
                yield form, fraction

    def describe(self) -> str:
        """Plain-text crystal state summary."""
        if not self.fractions:
            return "fully molten"
        parts = ", ".join(
            f"{form.value}={fraction:.3%}" for form, fraction in self
        )
        return (
            f"{parts} | solid={self.total_solid:.2%} purity={self.purity:.1%} "
            f"index={self.temper_index():.2f} ({self.grade().value})"
        )


def bloom_risk(
    state: CrystalState,
    storage_temperature_c: Celsius,
    days: float,
    milk_fat_share: float = 0.0,
) -> float:
    """Probability that visible fat bloom develops in storage, 0 to 1.

    Two mechanisms, both modelled:

    Poorly tempered chocolate blooms because its unstable crystals convert to
    Form VI, which recrystallises at the surface as a grey film. This happens
    regardless of storage conditions and is essentially a manufacturing defect.

    Well-tempered chocolate blooms when partial melting lets liquid fat migrate
    to the surface and recrystallise, which needs the storage temperature to
    approach the Form V melting point. This is a distribution and retail
    problem, not a factory one.
    """
    form_v_melt = melting_point(CrystalForm.FORM_V, milk_fat_share)

    # Mechanism 1: intrinsic instability from poor temper.
    intrinsic = state.unstable_fraction / max(state.total_solid, 1e-9)
    if state.total_solid <= 1e-9:
        intrinsic = 1.0
    intrinsic_risk = 1.0 - math.exp(-2.4 * intrinsic * (days / 30.0))

    # Mechanism 2: thermal cycling near the melting point.
    excess = storage_temperature_c - (form_v_melt - 12.0)
    if excess <= 0.0:
        thermal_risk = 0.0
    else:
        thermal_risk = 1.0 - math.exp(-((excess / 9.0) ** 2.2) * (days / 60.0))

    combined = 1.0 - (1.0 - intrinsic_risk) * (1.0 - thermal_risk)
    return clamp(combined, 0.0, 1.0)


__all__ = [
    "ENTHALPY_OF_FUSION",
    "MELTING_POINTS",
    "NUCLEATION_PROPENSITY",
    "STABILITY_ORDER",
    "CrystalState",
    "bloom_risk",
    "melting_point",
    "molten_fraction",
]
