"""Tempering: the thermal cycle that seeds Form V crystals.

The operation is a four-phase thermal cycle, and each phase exists for a
reason that falls directly out of the polymorph physics in
:mod:`chocosim.tempering.crystals`.

    HEAT     to ~50 degC   Melt out every existing crystal, including any
                           Form VI, so the mass starts with no memory.
    COOL     to ~27 degC   Below the melting point of every form, so
                           everything nucleates -- deliberately including the
                           unstable forms, because Form V will not nucleate on
                           its own at any useful rate.
    AGITATE  at ~27 degC   Shear promotes nucleation and breaks growing
                           crystals into more seeds.
    REHEAT   to ~31.5 degC Above the melting points of Forms I-IV but below
                           Form V. The unstable crystals melt out; the Form V
                           seeds survive. This is the whole trick.

The model integrates nucleation and growth for each polymorph on a short time
step. Nucleation follows classical theory: rate rises with supercooling
because the driving force grows, then falls again because molecular mobility
collapses as the melt thickens. That maximum is why holding at the wrong
temperature produces no crystals at all in either direction.

Rate constants are literature-scale and produce the qualitative behaviour a
temperer exhibits -- correct temper in a narrow window, under-temper if the
cycle is rushed, over-temper if the cool phase runs long. They are not fitted
to a specific machine and must not be used to set one.
"""

from __future__ import annotations

import math
from collections.abc import Sequence
from typing import Any

import numpy as np
from pydantic import Field

from ..core.config import ChocoSimConfig
from ..core.exceptions import TemperingError
from ..core.models import FrozenChocoModel, MassBalance, clamp
from ..core.rng import RandomSource
from ..core.types import (
    Celsius,
    CrystalForm,
    Kilograms,
    MaterialState,
    Minutes,
    ProcessStageKind,
    TemperGrade,
)
from ..core.units import CP_CHOCOLATE_LIQUID
from ..energy.model import (
    EnergyUse,
    cooling_energy,
    heating_energy,
    mechanical_energy,
    sensible_heat_kwh,
)
from ..processing.base import MaterialStream, ProcessStage, StageResult
from ..recipes.models import Recipe
from .crystals import (
    ENTHALPY_OF_FUSION,
    NUCLEATION_PROPENSITY,
    STABILITY_ORDER,
    CrystalState,
    melting_point,
    molten_fraction,
)

#: Base nucleation rate constant, per minute.
NUCLEATION_RATE_CONSTANT: float = 0.055

#: Supercooling at which nucleation is fastest, degC below the melting point.
OPTIMAL_SUPERCOOLING_C: float = 6.5

#: Width of the nucleation window in supercooling, degC.
NUCLEATION_WINDOW_C: float = 5.5

#: Crystal growth rate constant, per minute per unit supercooling.
GROWTH_RATE_CONSTANT: float = 0.0135

#: Shear multiplier on nucleation at full agitation. Agitation both promotes
#: nucleation and fragments growing crystals into fresh seeds, which is why a
#: scraped-surface temperer works and a static tank does not.
SHEAR_NUCLEATION_GAIN: float = 3.4

#: Maximum solid fat fraction a temperer will drive the mass to before it
#: becomes too viscous to pump.
MAXIMUM_WORKING_SOLIDS: float = 0.085

#: Ostwald ripening rate: unstable forms convert to the next more stable form.
RIPENING_RATE: float = 0.012

#: Specific mechanical power of a temperer, kW per tonne.
TEMPERER_POWER_KW_PER_TONNE: float = 6.5


class TemperPhase(FrozenChocoModel):
    """One phase of a tempering cycle."""

    name: str
    target_temperature_c: Celsius
    duration_minutes: Minutes = Field(gt=0.0)
    shear_intensity: float = Field(default=0.5, ge=0.0, le=1.0)


class TemperProfile(FrozenChocoModel):
    """A complete tempering cycle."""

    name: str
    phases: tuple[TemperPhase, ...] = Field(min_length=1)

    @property
    def total_minutes(self) -> Minutes:
        """Total cycle time."""
        return sum(phase.duration_minutes for phase in self.phases)

    @classmethod
    def standard(
        cls,
        melt_c: Celsius = 50.0,
        cool_c: Celsius = 27.0,
        reheat_c: Celsius = 31.5,
        name: str = "standard",
        agitate_minutes: Minutes = 6.0,
    ) -> TemperProfile:
        """Build the conventional four-phase cycle."""
        if not cool_c < reheat_c < melt_c:
            raise TemperingError(
                f"tempering profile requires cool < reheat < melt, got "
                f"{cool_c} / {reheat_c} / {melt_c}"
            )
        return cls(
            name=name,
            phases=(
                TemperPhase(
                    name="HEAT",
                    target_temperature_c=melt_c,
                    duration_minutes=8.0,
                    shear_intensity=0.3,
                ),
                TemperPhase(
                    name="COOL",
                    target_temperature_c=cool_c,
                    duration_minutes=10.0,
                    shear_intensity=0.7,
                ),
                TemperPhase(
                    name="AGITATE",
                    target_temperature_c=cool_c,
                    duration_minutes=agitate_minutes,
                    shear_intensity=1.0,
                ),
                TemperPhase(
                    name="REHEAT",
                    target_temperature_c=reheat_c,
                    duration_minutes=6.0,
                    shear_intensity=0.6,
                ),
            ),
        )

    @classmethod
    def from_recipe(cls, recipe: Recipe) -> TemperProfile:
        """Build the cycle a recipe specifies."""
        return cls.standard(
            melt_c=recipe.process.temper_melt_c,
            cool_c=recipe.process.temper_cool_c,
            reheat_c=recipe.process.temper_reheat_c,
            name=f"{recipe.recipe_id} temper",
        )


class TemperOutcome(FrozenChocoModel):
    """Result of a tempering cycle."""

    profile_name: str
    crystal_state: CrystalState
    final_temperature_c: Celsius
    duration_minutes: Minutes = Field(ge=0.0)
    energy: EnergyUse
    trajectory_minutes: tuple[float, ...] = ()
    trajectory_temperature_c: tuple[float, ...] = ()
    trajectory_solid_fraction: tuple[float, ...] = ()
    trajectory_purity: tuple[float, ...] = ()

    @property
    def temper_index(self) -> float:
        """Temper meter reading."""
        return self.crystal_state.temper_index()

    @property
    def grade(self) -> TemperGrade:
        """Categorical temper assessment."""
        return self.crystal_state.grade()

    @property
    def is_acceptable(self) -> bool:
        """Whether the mass is fit to mould."""
        return self.crystal_state.is_acceptable

    def describe(self) -> str:
        """Plain-text tempering summary."""
        return "\n".join(
            [
                f"{self.profile_name}",
                f"  Duration      {self.duration_minutes:.1f} min",
                f"  Final temp    {self.final_temperature_c:.2f} C",
                f"  Crystals      {self.crystal_state.describe()}",
                f"  Temper index  {self.temper_index:.2f} ({self.grade.value})",
                f"  Energy        {self.energy.total_kwh:.2f} kWh",
            ]
        )


class TemperingModel(ProcessStage):
    """Simulates the tempering cycle."""

    kind = ProcessStageKind.TEMPERING
    accepts = (MaterialState.CONCHED_MASS, MaterialState.PASTE, MaterialState.TEMPERED_MASS)

    #: Integration step, minutes.
    TIME_STEP: Minutes = 0.1

    def nucleation_rate(
        self,
        form: CrystalForm,
        temperature_c: Celsius,
        shear_intensity: float,
        milk_fat_share: float,
    ) -> float:
        """Nucleation rate of a polymorph, fraction per minute.

        Zero above the melting point: a crystal cannot nucleate into a form
        that is molten at that temperature. Below it, a Gaussian in
        supercooling captures the competition between thermodynamic driving
        force (grows with supercooling) and molecular mobility (collapses with
        it).
        """
        point = melting_point(form, milk_fat_share)
        supercooling = point - temperature_c
        if supercooling <= 0.0:
            return 0.0

        window = math.exp(
            -(((supercooling - OPTIMAL_SUPERCOOLING_C) / NUCLEATION_WINDOW_C) ** 2)
        )
        shear = 1.0 + SHEAR_NUCLEATION_GAIN * clamp(shear_intensity, 0.0, 1.0)
        return (
            NUCLEATION_RATE_CONSTANT
            * NUCLEATION_PROPENSITY[form]
            * window
            * shear
        )

    def growth_rate(
        self, form: CrystalForm, temperature_c: Celsius, milk_fat_share: float
    ) -> float:
        """Growth rate of existing crystals of a polymorph, per minute."""
        point = melting_point(form, milk_fat_share)
        supercooling = point - temperature_c
        if supercooling <= 0.0:
            return 0.0
        # Growth slows again at very deep supercooling as viscosity rises.
        mobility = math.exp(-max(0.0, supercooling - 14.0) / 8.0)
        return GROWTH_RATE_CONSTANT * supercooling * mobility

    def step(
        self,
        state: CrystalState,
        temperature_c: Celsius,
        shear_intensity: float,
        milk_fat_share: float,
        dt: Minutes,
    ) -> CrystalState:
        """Advance the crystal state by one time step."""
        fractions = dict(state.fractions)
        liquid = max(0.0, 1.0 - sum(fractions.values()))

        # --- melting ---
        for form in list(fractions):
            molten = molten_fraction(form, temperature_c, milk_fat_share)
            if molten > 1e-6:
                survival = math.exp(-4.0 * molten * dt)
                melted = fractions[form] * (1.0 - survival)
                fractions[form] -= melted
                liquid += melted

        # --- nucleation and growth ---
        headroom = max(0.0, MAXIMUM_WORKING_SOLIDS - sum(fractions.values()))
        for form in STABILITY_ORDER:
            if liquid <= 1e-12 or headroom <= 1e-12:
                break
            existing = fractions.get(form, 0.0)

            nucleated = (
                self.nucleation_rate(form, temperature_c, shear_intensity, milk_fat_share)
                * liquid
                * dt
                * 0.01
            )
            grown = (
                self.growth_rate(form, temperature_c, milk_fat_share)
                * existing
                * liquid
                * dt
            )

            added = min(nucleated + grown, liquid, headroom)
            if added > 0.0:
                fractions[form] = existing + added
                liquid -= added
                headroom -= added

        # --- Ostwald ripening: unstable forms convert towards stability ---
        for index in range(len(STABILITY_ORDER) - 1):
            form = STABILITY_ORDER[index]
            nxt = STABILITY_ORDER[index + 1]
            present = fractions.get(form, 0.0)
            if present <= 1e-12:
                continue
            # Ripening accelerates near the form's melting point, where the
            # lattice is loosest.
            proximity = math.exp(
                -abs(temperature_c - melting_point(form, milk_fat_share)) / 4.0
            )
            converted = present * RIPENING_RATE * proximity * dt
            fractions[form] = present - converted
            fractions[nxt] = fractions.get(nxt, 0.0) + converted

        return CrystalState(
            fractions={f: v for f, v in fractions.items() if v > 1e-12}
        ).normalised()

    def run_profile(
        self,
        profile: TemperProfile,
        mass_kg: Kilograms,
        initial_temperature_c: Celsius,
        milk_fat_share: float = 0.0,
        initial_state: CrystalState | None = None,
        source: RandomSource | None = None,
        record_trajectory: bool = True,
    ) -> TemperOutcome:
        """Execute a tempering profile on a mass."""
        source = source or RandomSource(self.config.simulation.seed)
        state = initial_state or CrystalState.molten()
        temperature = initial_temperature_c

        minutes: list[float] = []
        temperatures: list[float] = []
        solids: list[float] = []
        purities: list[float] = []

        elapsed = 0.0
        heating_duty = 0.0
        cooling_duty = 0.0
        shaft_kwh = 0.0

        for phase in profile.phases:
            steps = max(1, int(round(phase.duration_minutes / self.TIME_STEP)))
            # Exponential approach to setpoint: a heat exchanger cannot step.
            time_constant = max(1.0, phase.duration_minutes / 3.0)

            for _ in range(steps):
                previous_temperature = temperature
                temperature += (phase.target_temperature_c - temperature) * (
                    1.0 - math.exp(-self.TIME_STEP / time_constant)
                )

                duty = sensible_heat_kwh(
                    mass_kg, CP_CHOCOLATE_LIQUID, temperature - previous_temperature
                )
                if temperature > previous_temperature:
                    heating_duty += duty
                else:
                    cooling_duty += duty

                # Crystallisation releases latent heat, which the temperer has
                # to remove on top of the sensible load. On a large machine
                # this is a significant share of the refrigeration duty.
                before = state.total_solid
                state = self.step(
                    state,
                    temperature,
                    phase.shear_intensity,
                    milk_fat_share,
                    self.TIME_STEP,
                )
                crystallised = max(0.0, state.total_solid - before)
                if crystallised > 0.0:
                    latent = (
                        crystallised
                        * mass_kg
                        * ENTHALPY_OF_FUSION[CrystalForm.FORM_V]
                        / 3600.0
                    )
                    cooling_duty += latent

                shaft_kwh += (
                    TEMPERER_POWER_KW_PER_TONNE
                    * phase.shear_intensity
                    * (mass_kg / 1000.0)
                    * (self.TIME_STEP / 60.0)
                )

                elapsed += self.TIME_STEP
                if record_trajectory:
                    minutes.append(elapsed)
                    temperatures.append(temperature)
                    solids.append(state.total_solid)
                    purities.append(state.purity)

        # Process variability: heat exchanger fouling, flow variation.
        noise = self._noise(source, "seed_fraction", 0.06)
        if noise != 1.0 and state.total_solid > 0.0:
            state = CrystalState(
                fractions={f: v * noise for f, v in state.fractions.items()}
            ).normalised()

        energy = (
            heating_energy(heating_duty, self.config.energy)
            + cooling_energy(cooling_duty, self.config.energy)
            + mechanical_energy(shaft_kwh, self.config.energy)
        )

        return TemperOutcome(
            profile_name=profile.name,
            crystal_state=state,
            final_temperature_c=temperature,
            duration_minutes=profile.total_minutes,
            energy=energy,
            trajectory_minutes=tuple(minutes),
            trajectory_temperature_c=tuple(temperatures),
            trajectory_solid_fraction=tuple(solids),
            trajectory_purity=tuple(purities),
        )

    def _run(
        self,
        stream: MaterialStream,
        recipe: Recipe,
        source: RandomSource,
        machine_id: str | None = None,
        **kwargs: Any,
    ) -> StageResult:
        profile: TemperProfile = kwargs.get("profile") or TemperProfile.from_recipe(
            recipe
        )
        composition = stream.composition
        milk_fat_share = (
            composition.milk_fat / composition.fat if composition.fat > 0.0 else 0.0
        )

        outcome = self.run_profile(
            profile,
            stream.mass_kg,
            stream.temperature_c,
            milk_fat_share,
            source=source,
            record_trajectory=False,
        )

        waste_fraction = 0.0018 * self._noise(source, "waste", 0.2)
        output_mass = stream.mass_kg * (1.0 - waste_fraction)

        stream_out = stream.evolve(
            mass_kg=output_mass,
            state=MaterialState.TEMPERED_MASS,
            temperature_c=outcome.final_temperature_c,
            stable_crystal_fraction=outcome.crystal_state.stable_fraction,
        )

        notes: list[str] = []
        grade = outcome.grade
        if grade is TemperGrade.UNDER_TEMPERED:
            notes.append(
                f"Under-tempered (index {outcome.temper_index:.2f}, purity "
                f"{outcome.crystal_state.purity:.0%}): product will set soft and "
                "bloom in storage."
            )
        elif grade is TemperGrade.OVER_TEMPERED:
            notes.append(
                f"Over-tempered (index {outcome.temper_index:.2f}): mass will be "
                "thick, dull, and prone to poor mould release."
            )
        elif grade is TemperGrade.UNTEMPERED:
            notes.append(
                "No usable seed crystals formed; the cycle has failed entirely."
            )

        return StageResult(
            stage=self.kind,
            machine_id=machine_id,
            stream_in=stream,
            stream_out=stream_out,
            mass_balance=MassBalance(
                stage=self.kind.value,
                mass_in=stream.mass_kg,
                mass_out=output_mass,
                mass_loss=0.0,
                mass_waste=stream.mass_kg * waste_fraction,
            ),
            duration_minutes=outcome.duration_minutes,
            energy=outcome.energy,
            provenance=self._provenance(
                basis=(
                    "Polymorph-resolved nucleation and growth kinetics with a "
                    "Gaussian supercooling window and Ostwald ripening"
                ),
                assumptions=(
                    "Nucleation rate peaks at a fixed supercooling for every form",
                    "The mass is thermally uniform; no gradients within the temperer",
                    "Rate constants are literature-scale, not fitted to a machine",
                ),
            ),
            metrics={
                "temper_index": outcome.temper_index,
                "solid_fat_fraction": outcome.crystal_state.total_solid,
                "form_v_fraction": outcome.crystal_state.fraction_of(CrystalForm.FORM_V),
                "crystal_purity": outcome.crystal_state.purity,
                "unstable_fraction": outcome.crystal_state.unstable_fraction,
                "final_temperature_c": outcome.final_temperature_c,
            },
            notes=tuple(notes),
        )

    def sweep_reheat(
        self,
        recipe: Recipe,
        reheat_temperatures: Sequence[float],
        mass_kg: Kilograms = 1_000.0,
    ) -> list[dict[str, float]]:
        """Sweep the reheat setpoint and report the resulting temper.

        The reheat temperature is the most sensitive parameter in the whole
        process: a degree too low leaves unstable crystals alive, a degree too
        high melts the Form V seeds as well. This sweep shows the window.
        """
        composition_milk_fat = 0.0
        rows: list[dict[str, float]] = []
        for reheat in reheat_temperatures:
            profile = TemperProfile.standard(
                melt_c=recipe.process.temper_melt_c,
                cool_c=recipe.process.temper_cool_c,
                reheat_c=reheat,
                name=f"reheat {reheat:.1f}C",
            )
            outcome = self.run_profile(
                profile,
                mass_kg,
                45.0,
                composition_milk_fat,
                record_trajectory=False,
            )
            rows.append(
                {
                    "reheat_c": reheat,
                    "temper_index": outcome.temper_index,
                    "solid_fraction": outcome.crystal_state.total_solid,
                    "purity": outcome.crystal_state.purity,
                    "unstable_fraction": outcome.crystal_state.unstable_fraction,
                    "acceptable": float(outcome.is_acceptable),
                }
            )
        return rows


__all__ = [
    "MAXIMUM_WORKING_SOLIDS",
    "TemperOutcome",
    "TemperPhase",
    "TemperProfile",
    "TemperingModel",
]
