"""Test suite for ChocoSim."""
