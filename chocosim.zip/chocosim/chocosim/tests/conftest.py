"""Shared fixtures.

Every fixture returns a *fresh* object. Sharing a registry or a factory
between tests would let a price shock or a consumed lot in one test change the
result of another, which is the classic way a test suite becomes
order-dependent and stops being trustworthy.
"""

from __future__ import annotations

import datetime as dt

import pytest

from chocosim.core.config import ChocoSimConfig
from chocosim.core.rng import RandomSource
from chocosim.economics.costing import EconomicsEngine
from chocosim.ingredients.registry import build_default_registry
from chocosim.inventory.manager import InventoryManager
from chocosim.processing.pipeline import ProcessChain
from chocosim.production.factory import Factory
from chocosim.quality.scoring import QualityEngine
from chocosim.recipes.engine import RecipeEngine
from chocosim.recipes.library import build_standard_book


@pytest.fixture
def config() -> ChocoSimConfig:
    """A deterministic configuration for reproducible tests."""
    return ChocoSimConfig.default().deterministic()


@pytest.fixture
def stochastic_config() -> ChocoSimConfig:
    """A configuration with stochastic behaviour enabled."""
    return ChocoSimConfig.default()


@pytest.fixture
def registry():
    """A fresh ingredient registry."""
    return build_default_registry()


@pytest.fixture
def book():
    """A fresh recipe book."""
    return build_standard_book()


@pytest.fixture
def recipe_engine(registry):
    """A recipe engine over a fresh registry."""
    return RecipeEngine(registry)


@pytest.fixture
def chain(registry, config):
    """A process chain."""
    return ProcessChain(registry, config)


@pytest.fixture
def quality_engine(config):
    """A quality engine."""
    return QualityEngine(config)


@pytest.fixture
def economics_engine(recipe_engine, config):
    """An economics engine."""
    return EconomicsEngine(recipe_engine, config)


@pytest.fixture
def inventory(registry, config):
    """An inventory manager."""
    return InventoryManager(registry, config)


@pytest.fixture
def factory(config, registry, book):
    """A factory digital twin."""
    return Factory(config, registry, book)


@pytest.fixture
def source() -> RandomSource:
    """A random source with a fixed seed."""
    return RandomSource(seed=12345)


@pytest.fixture
def today() -> dt.date:
    """A fixed date, so tests do not depend on when they run."""
    return dt.date(2026, 6, 15)


@pytest.fixture
def dark_recipe(book):
    """The reference dark chocolate recipe."""
    return book.get("RCP-DARK-70")


@pytest.fixture
def milk_recipe(book):
    """The reference milk chocolate recipe."""
    return book.get("RCP-MILK-35")
