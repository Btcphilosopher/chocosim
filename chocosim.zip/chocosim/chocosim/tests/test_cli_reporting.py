"""Tests for the command line interface and the reporting surfaces."""

from __future__ import annotations

import pytest

from chocosim.cli import build_parser, main
from chocosim.core.units import (
    celsius_to_kelvin,
    joules_to_kwh,
    kelvin_to_celsius,
    kj_to_kwh,
    kw_for,
    kwh_to_joules,
    minutes_to_hours,
)


class TestCli:
    """Every command must run and exit cleanly."""

    def test_parser_builds(self):
        parser = build_parser()
        assert parser.prog == "chocosim"

    def test_recipes_command(self, capsys):
        assert main(["recipes"]) == 0
        output = capsys.readouterr().out
        assert "RCP-DARK-70" in output

    def test_recipe_command(self, capsys):
        assert main(["recipe", "RCP-DARK-70"]) == 0
        output = capsys.readouterr().out
        assert "DARK CHOCOLATE 70%" in output
        assert "SIMULATION" in output

    def test_recipe_command_rejects_unknown(self, capsys):
        assert main(["recipe", "NOT-REAL"]) == 2
        assert "Unknown recipe" in capsys.readouterr().err

    def test_batch_command(self, capsys):
        assert main(["batch", "RCP-DARK-70", "--batch-kg", "800"]) == 0
        output = capsys.readouterr().out
        assert "PROCESS RUN" in output
        assert "QUALITY ASSESSMENT" in output
        assert "COSTING" in output

    def test_batch_command_rejects_unknown(self):
        assert main(["batch", "NOT-REAL"]) == 2

    def test_roast_command(self, capsys):
        assert main(["roast"]) == 0
        output = capsys.readouterr().out
        assert "Roast A" in output
        assert "Roast B" in output

    def test_roast_equivalence(self, capsys):
        assert main(["roast", "--equivalent-at", "165"]) == 0
        assert "Equal-development equivalent" in capsys.readouterr().out

    def test_line_command(self, capsys):
        assert main(["line", "--batches", "8", "--days", "7"]) == 0
        assert "BOTTLENECK" in capsys.readouterr().out

    def test_schedule_command(self, capsys):
        assert main(["schedule", "--batches", "6"]) == 0
        assert "SCHEDULE" in capsys.readouterr().out

    def test_optimise_command(self, capsys):
        assert main(["optimise", "--batches", "6", "--days", "7"]) == 0
        assert "FACTORY OPTIMISATION" in capsys.readouterr().out

    def test_scenario_command(self, capsys):
        assert main(["scenario", "--batches", "2"]) == 0
        output = capsys.readouterr().out
        assert "SCENARIO COMPARISON" in output
        assert "Baseline" in output

    def test_montecarlo_command(self, capsys):
        assert main(["montecarlo", "--replications", "4", "--batches", "2"]) == 0
        output = capsys.readouterr().out
        assert "MONTE CARLO" in output
        assert "P10" in output

    def test_reformulate_command(self, capsys):
        assert main(["reformulate", "RCP-MILK-35"]) == 0
        assert "LEAST-COST FORMULATION" in capsys.readouterr().out

    def test_reformulate_allows_cocoa_change(self, capsys):
        assert main(["reformulate", "RCP-DARK-55", "--allow-cocoa-change"]) == 0
        assert "FORMULATION" in capsys.readouterr().out

    def test_dashboard_console(self, capsys):
        assert main(["dashboard", "--batches", "3", "--days", "7"]) == 0
        output = capsys.readouterr().out
        assert "CHOCOSIM FACTORY STATUS" in output
        assert "SIMULATION OUTPUT" in output

    def test_dashboard_html(self, tmp_path, capsys):
        target = tmp_path / "dash.html"
        assert main(["dashboard", "--batches", "3", "--days", "7", "-o", str(target)]) == 0
        assert target.exists()
        content = target.read_text(encoding="utf-8")
        assert content.startswith("<!DOCTYPE html>")
        assert "Simulation output" in content

    def test_seed_is_accepted(self, capsys):
        assert main(["--seed", "999", "recipes"]) == 0

    def test_stochastic_flag_is_accepted(self, capsys):
        assert main(["--stochastic", "batch", "RCP-MILK-35", "--batch-kg", "600"]) == 0


class TestReports:
    """Report rendering must include the fidelity statement."""

    def test_process_report_carries_provenance(self, chain, dark_recipe):
        report = chain.run(dark_recipe, 1000.0).report()
        assert "SIMULATION" in report
        assert "Bottleneck" in report

    def test_quality_report_lists_metrics(self, chain, quality_engine, dark_recipe):
        run = chain.run(dark_recipe, 1000.0)
        report = quality_engine.assess(run, dark_recipe).report()
        assert "OVERALL SCORE" in report
        assert "particle_size_um" in report
        assert "DISPOSITION" in report

    def test_costing_report_sums_to_total(
        self, chain, quality_engine, economics_engine, dark_recipe
    ):
        run = chain.run(dark_recipe, 1000.0)
        assessment = quality_engine.assess(run, dark_recipe)
        report = economics_engine.cost_batch(run, dark_recipe, assessment).report()
        assert "TOTAL" in report
        assert "ingredients" in report

    def test_recipe_analysis_report(self, recipe_engine, dark_recipe):
        report = recipe_engine.analyse(dark_recipe, 1000.0).report()
        assert "COMPOSITION" in report
        assert "Compositional check" in report

    def test_compliance_describe_flags_failures(self, recipe_engine, book):
        check = recipe_engine.check_compliance(book.get("RCP-DARK-70"))
        assert "OK" in check.describe()

    def test_line_report_names_the_bottleneck(self, config, book):
        from chocosim.production.line import ProductionLine, build_orders

        line = ProductionLine(config=config)
        result = line.simulate(
            build_orders(book.current_recipes()[:3], 9, 1200.0),
            horizon_minutes=21 * 24 * 60,
        )
        assert "BOTTLENECK" in result.report()

    def test_inventory_report(self, factory, today):
        factory.stock_up(today, 30.0, 8_000.0)
        report = factory.inventory.report(today)
        assert "INVENTORY POSITION" in report
        assert "raw_material" in report

    def test_production_log(self, factory, today):
        factory.stock_up(today, 30.0, 8_000.0)
        factory.produce_batch("RCP-DARK-70", 900.0, on=today)
        assert "PRODUCTION LOG" in factory.production_report()

    def test_empty_production_log(self, factory):
        assert "No batches" in factory.production_report()

    def test_supply_chain_report(self, registry, inventory, config, today):
        from chocosim.logistics.supply_chain import (
            SupplyChainSimulator,
            cocoa_complex_shock,
        )

        simulator = SupplyChainSimulator(registry, inventory, config)
        for disruption in cocoa_complex_shock(1.2, 10, 60):
            simulator.add_disruption(disruption)
        registry.create_lot("ING-SUGAR", 4000.0, today)
        result = simulator.run({"ING-SUGAR": 300.0}, 60, today)
        report = result.report()
        assert "SUPPLY CHAIN" in report
        assert "DISRUPTIONS" in report


class TestUnits:
    """Unit conversions."""

    def test_kelvin_conversion(self):
        assert celsius_to_kelvin(0.0) == pytest.approx(273.15)
        assert celsius_to_kelvin(100.0) == pytest.approx(373.15)

    def test_energy_round_trip(self):
        assert joules_to_kwh(kwh_to_joules(2.5)) == pytest.approx(2.5)

    def test_kj_to_kwh(self):
        assert kj_to_kwh(3600.0) == pytest.approx(1.0)

    def test_kelvin_round_trip(self):
        assert kelvin_to_celsius(celsius_to_kelvin(42.0)) == pytest.approx(42.0)

    def test_average_power(self):
        assert kw_for(2.0, 60.0) == pytest.approx(2.0)

    def test_minutes_to_hours(self):
        assert minutes_to_hours(90.0) == pytest.approx(1.5)
