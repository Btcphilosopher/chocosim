"""Tests for core primitives: mass balance, composition, RNG, fidelity."""

from __future__ import annotations

import math

import pytest
from pydantic import ValidationError

from chocosim.core.exceptions import FidelityError, MassBalanceError
from chocosim.core.fidelity import (
    CalibrationRecord,
    ModelFidelity,
    ModelProvenance,
)
from chocosim.core.models import (
    Composition,
    Interval,
    MassBalance,
    blend_compositions,
    clamp,
    safe_divide,
)
from chocosim.core.rng import (
    RandomSource,
    lognormal_from_moments,
    percentiles,
    truncated_normal,
)


class TestMassBalance:
    """Mass conservation is the invariant everything else rests on."""

    def test_balanced_construction_succeeds(self):
        balance = MassBalance(
            stage="test", mass_in=100.0, mass_out=90.0, mass_loss=8.0, mass_waste=2.0
        )
        assert balance.yield_fraction == pytest.approx(0.90)
        assert balance.loss_fraction == pytest.approx(0.08)
        assert balance.waste_fraction == pytest.approx(0.02)

    def test_unbalanced_construction_raises(self):
        with pytest.raises(MassBalanceError):
            MassBalance(stage="broken", mass_in=100.0, mass_out=95.0, mass_loss=2.0)

    def test_mass_cannot_be_created(self):
        with pytest.raises(MassBalanceError):
            MassBalance(stage="creation", mass_in=100.0, mass_out=105.0)

    def test_from_yield_closes_exactly(self):
        balance = MassBalance.from_yield(
            "roasting", 1234.5678, loss_fraction=0.061, waste_fraction=0.013
        )
        assert balance.mass_out + balance.mass_loss + balance.mass_waste == pytest.approx(
            balance.mass_in, abs=1e-9
        )

    def test_from_yield_rejects_impossible_losses(self):
        with pytest.raises(ValueError):
            MassBalance.from_yield("x", 100.0, loss_fraction=0.7, waste_fraction=0.5)

    def test_composition_of_consecutive_stages(self):
        first = MassBalance.from_yield("a", 1000.0, loss_fraction=0.05)
        second = MassBalance.from_yield("b", first.mass_out, waste_fraction=0.02)
        combined = first.then(second)
        assert combined.mass_in == pytest.approx(1000.0)
        assert combined.mass_out == pytest.approx(second.mass_out)
        assert combined.mass_loss == pytest.approx(first.mass_loss)
        assert combined.mass_waste == pytest.approx(second.mass_waste)

    def test_mismatched_stages_raise(self):
        first = MassBalance.from_yield("a", 1000.0, loss_fraction=0.05)
        second = MassBalance.from_yield("b", 800.0)
        with pytest.raises(MassBalanceError):
            first.then(second)

    def test_zero_input_gives_zero_yield_not_division_error(self):
        balance = MassBalance(stage="empty", mass_in=0.0, mass_out=0.0)
        assert balance.yield_fraction == 0.0

    def test_tolerance_scales_with_magnitude(self):
        # A tonne-scale batch accumulates float error; the balance must still
        # accept a genuinely conserved result.
        mass_in = 1_000_000.0
        out = mass_in * 0.7
        loss = mass_in * 0.2
        waste = mass_in - out - loss
        MassBalance(
            stage="large", mass_in=mass_in, mass_out=out, mass_loss=loss, mass_waste=waste
        )


class TestComposition:
    """Composition must not double-count constituents."""

    def test_closure_fields_may_not_exceed_one(self):
        with pytest.raises(ValidationError):
            Composition(fat=0.5, sugar=0.4, moisture=0.2, cocoa_solids_nonfat=0.3)

    def test_overlay_may_not_exceed_parent(self):
        with pytest.raises(ValidationError):
            Composition(fat=0.30, milk_fat=0.40)

    def test_milk_and_other_fat_together_bounded_by_fat(self):
        with pytest.raises(ValidationError):
            Composition(fat=0.30, milk_fat=0.20, other_fat=0.20)

    def test_lactose_bounded_by_sugar(self):
        with pytest.raises(ValidationError):
            Composition(sugar=0.10, lactose=0.20)

    def test_protein_cannot_exceed_available_solids(self):
        with pytest.raises(ValidationError):
            Composition(fat=0.90, moisture=0.05, protein=0.50)

    def test_cocoa_butter_excludes_other_fats(self):
        composition = Composition(fat=0.40, milk_fat=0.10, other_fat=0.05)
        assert composition.cocoa_butter == pytest.approx(0.25)

    def test_dry_milk_solids_recombines_lactose(self):
        composition = Composition(
            fat=0.265,
            milk_fat=0.265,
            moisture=0.028,
            sugar=0.380,
            lactose=0.380,
            milk_solids_nonfat=0.305,
        )
        assert composition.dry_milk_solids == pytest.approx(0.95)

    def test_other_solids_is_the_remainder(self):
        composition = Composition(fat=0.30, sugar=0.40, moisture=0.02)
        assert composition.other_solids == pytest.approx(0.28)

    def test_moisture_loss_concentrates_remaining_components(self):
        composition = Composition(fat=0.40, moisture=0.10, sugar=0.30)
        dried = composition.after_moisture_loss(0.05)
        assert dried.moisture == pytest.approx(0.05 / 0.95)
        assert dried.fat == pytest.approx(0.40 / 0.95)
        # Absolute masses are unchanged.
        assert dried.fat * 0.95 == pytest.approx(0.40)

    def test_cannot_remove_more_water_than_present(self):
        composition = Composition(moisture=0.05, fat=0.5)
        with pytest.raises(ValueError):
            composition.after_moisture_loss(0.10)

    def test_blend_is_mass_weighted(self):
        a = Composition(fat=1.0)
        b = Composition(sugar=1.0)
        blended, mass = blend_compositions([(a, 25.0), (b, 75.0)])
        assert mass == pytest.approx(100.0)
        assert blended.fat == pytest.approx(0.25)
        assert blended.sugar == pytest.approx(0.75)

    def test_blend_of_nothing_is_empty(self):
        blended, mass = blend_compositions([])
        assert mass == 0.0
        assert blended.fat == 0.0

    def test_blend_ignores_zero_mass_parts(self):
        blended, _ = blend_compositions(
            [(Composition(fat=1.0), 100.0), (Composition(sugar=1.0), 0.0)]
        )
        assert blended.fat == pytest.approx(1.0)


class TestInterval:
    """Specification intervals."""

    def test_contains(self):
        interval = Interval(low=1.0, high=2.0)
        assert interval.contains(1.5)
        assert interval.contains(1.0)
        assert not interval.contains(2.1)

    def test_reversed_bounds_raise(self):
        with pytest.raises(ValidationError):
            Interval(low=5.0, high=1.0)

    def test_normalised_deviation_zero_inside(self):
        assert Interval(low=1.0, high=3.0).normalised_deviation(2.0) == 0.0

    def test_normalised_deviation_scales_by_half_width(self):
        interval = Interval(low=1.0, high=3.0)
        assert interval.normalised_deviation(4.0) == pytest.approx(1.0)
        assert interval.normalised_deviation(0.0) == pytest.approx(1.0)

    def test_clamp(self):
        interval = Interval(low=1.0, high=3.0)
        assert interval.clamp(0.0) == 1.0
        assert interval.clamp(9.0) == 3.0


class TestRandomSource:
    """Reproducibility guarantees."""

    def test_same_seed_same_stream(self):
        a = RandomSource(seed=99).generator("path/one").normal(size=5)
        b = RandomSource(seed=99).generator("path/one").normal(size=5)
        assert (a == b).all()

    def test_different_paths_are_independent(self):
        source = RandomSource(seed=99)
        first = source.generator("alpha").normal()
        # Draw heavily from a different path.
        source.generator("beta").normal(size=1000)
        # A fresh source must reproduce the original draw regardless.
        assert RandomSource(seed=99).generator("alpha").normal() == pytest.approx(first)

    def test_namespaced_child_isolates_paths(self):
        source = RandomSource(seed=7)
        child = source.child("stage")
        assert child.generator("noise") is source.generator("stage/noise")

    def test_replicates_are_independent_and_stable(self):
        root = RandomSource(seed=2026)
        first = [root.replicate(i).generator("x").normal() for i in range(5)]
        # Requesting more replicates must not change the earlier ones.
        root_again = RandomSource(seed=2026)
        second = [root_again.replicate(i).generator("x").normal() for i in range(20)]
        assert first == pytest.approx(second[:5])

    def test_replicates_differ_from_each_other(self):
        root = RandomSource(seed=2026)
        draws = [root.replicate(i).generator("x").normal() for i in range(10)]
        assert len(set(draws)) == 10

    def test_truncated_normal_respects_bounds(self):
        generator = RandomSource(seed=3).generator("t")
        samples = truncated_normal(generator, 0.0, 5.0, low=-1.0, high=1.0, size=500)
        assert samples.min() >= -1.0
        assert samples.max() <= 1.0

    def test_lognormal_matches_requested_mean(self):
        generator = RandomSource(seed=4).generator("ln")
        samples = lognormal_from_moments(generator, 10.0, 0.25, size=200_000)
        assert samples.mean() == pytest.approx(10.0, rel=0.02)

    def test_percentiles_of_empty_are_nan(self):
        result = percentiles([], 10, 50, 90)
        assert all(math.isnan(value) for value in result.values())


class TestFidelity:
    """The fidelity system must refuse unsupported claims."""

    def test_simulation_provenance_carries_a_caveat(self):
        provenance = ModelProvenance.simulation("m", basis="b")
        assert provenance.fidelity is ModelFidelity.SIMULATION
        assert provenance.caveats

    def test_prediction_without_calibration_raises(self):
        with pytest.raises(FidelityError):
            ModelProvenance(
                model_name="m", fidelity=ModelFidelity.PREDICTION, basis="b"
            )

    def test_calibration_promotes_to_prediction(self):
        record = CalibrationRecord(
            dataset_reference="plant trial 2026",
            sample_count=48,
            residual_rmse=0.4,
            residual_units="kWh/kg",
        )
        provenance = ModelProvenance.simulation("m").calibrated(record)
        assert provenance.fidelity is ModelFidelity.PREDICTION

    def test_validation_requires_calibration_first(self):
        from chocosim.core.fidelity import ValidationRecord

        record = ValidationRecord(
            validated_by="Process Engineering",
            evidence_references=("REP-2026-014",),
        )
        with pytest.raises(FidelityError):
            ModelProvenance.simulation("m").validated(record)

    def test_combine_takes_the_weakest_fidelity(self):
        record = CalibrationRecord(
            dataset_reference="d",
            sample_count=10,
            residual_rmse=1.0,
            residual_units="kWh/kg",
        )
        strong = ModelProvenance.simulation("a").calibrated(record)
        weak = ModelProvenance.simulation("b")
        combined = ModelProvenance.combine("c", [strong, weak])
        assert combined.fidelity is ModelFidelity.SIMULATION


class TestHelpers:
    """Small numeric helpers."""

    def test_clamp(self):
        assert clamp(5.0, 0.0, 1.0) == 1.0
        assert clamp(-5.0, 0.0, 1.0) == 0.0
        assert clamp(0.5, 0.0, 1.0) == 0.5

    def test_safe_divide_returns_default_on_zero(self):
        assert safe_divide(1.0, 0.0) == 0.0
        assert safe_divide(1.0, 0.0, default=99.0) == 99.0
        assert safe_divide(6.0, 3.0) == 2.0
