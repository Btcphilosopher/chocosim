"""Tests for the ingredient catalogue and recipe engine."""

from __future__ import annotations

import datetime as dt

import pytest

from chocosim.core.exceptions import IngredientNotFoundError, RecipeError
from chocosim.core.types import ChocolateType, IngredientClass
from chocosim.ingredients.models import IngredientLot
from chocosim.recipes.models import Recipe, RecipeComponent, RecipeLine


class TestCatalogue:
    """The default catalogue must be internally consistent."""

    def test_every_composition_closes(self, registry):
        for ingredient in registry:
            assert ingredient.composition.closure_total <= 1.0 + 1e-9, (
                f"{ingredient.ingredient_id} composition exceeds unity"
            )

    def test_every_ingredient_has_a_known_supplier(self, registry):
        for ingredient in registry:
            if ingredient.default_supplier_id is not None:
                assert registry.supplier(ingredient.default_supplier_id) is not None

    def test_cocoa_materials_are_flagged_as_cocoa(self, registry):
        cocoa_classes = {
            IngredientClass.COCOA_BEAN,
            IngredientClass.COCOA_NIB,
            IngredientClass.COCOA_LIQUOR,
            IngredientClass.COCOA_BUTTER,
            IngredientClass.COCOA_POWDER,
        }
        for ingredient in registry:
            if ingredient.ingredient_class in cocoa_classes:
                assert ingredient.counts_as_cocoa

    def test_milk_materials_declare_the_allergen(self, registry):
        for ingredient in registry:
            if ingredient.composition.dry_milk_solids > 0.01:
                assert "milk" in ingredient.allergens, ingredient.ingredient_id

    def test_cocoa_butter_is_almost_entirely_cocoa_fat(self, registry):
        butter = registry.get("ING-BUTTER")
        assert butter.composition.cocoa_butter > 0.99

    def test_unknown_ingredient_raises(self, registry):
        with pytest.raises(IngredientNotFoundError):
            registry.get("ING-DOES-NOT-EXIST")


class TestPricing:
    """Scenario price shocks."""

    def test_shock_moves_the_whole_cocoa_complex(self, registry):
        before = {
            ingredient_id: registry.unit_cost(ingredient_id)
            for ingredient_id in ("ING-LIQUOR", "ING-BUTTER", "ING-POWDER", "ING-NIB")
        }
        count = registry.shock_cocoa_complex(1.20)
        assert count >= 5
        for ingredient_id, price in before.items():
            assert registry.unit_cost(ingredient_id) == pytest.approx(price * 1.20)

    def test_shock_leaves_other_classes_alone(self, registry):
        sugar_before = registry.unit_cost("ING-SUGAR")
        registry.shock_cocoa_complex(1.50)
        assert registry.unit_cost("ING-SUGAR") == pytest.approx(sugar_before)

    def test_reset_restores_prices(self, registry):
        before = registry.unit_cost("ING-LIQUOR")
        registry.shock_cocoa_complex(2.0)
        registry.reset_prices()
        assert registry.unit_cost("ING-LIQUOR") == pytest.approx(before)

    def test_negative_multiplier_rejected(self, registry):
        with pytest.raises(ValueError):
            registry.set_price_multiplier("ING-SUGAR", -1.0)


class TestLots:
    """Lot traceability and FEFO issue."""

    def test_lot_expiry_follows_shelf_life(self, registry, today):
        lot = registry.create_lot("ING-SUGAR", 1000.0, today)
        expected = today + dt.timedelta(days=registry.get("ING-SUGAR").shelf_life_days)
        assert lot.expires_on == expected

    def test_consumption_is_first_expired_first_out(self, registry, today):
        late = registry.create_lot("ING-SUGAR", 500.0, today)
        early = registry.create_lot(
            "ING-SUGAR", 500.0, today - dt.timedelta(days=200)
        )
        draws, shortfall = registry.consume("ING-SUGAR", 300.0, today)
        assert shortfall == 0.0
        assert draws[0][0] == early.lot_id

    def test_shortfall_is_reported_not_raised(self, registry, today):
        registry.create_lot("ING-SUGAR", 100.0, today)
        _, shortfall = registry.consume("ING-SUGAR", 250.0, today)
        assert shortfall == pytest.approx(150.0)

    def test_expired_lots_are_not_issued(self, registry, today):
        registry.create_lot(
            "ING-HAZELNUT", 500.0, today - dt.timedelta(days=400)
        )
        _, shortfall = registry.consume("ING-HAZELNUT", 100.0, today)
        assert shortfall == pytest.approx(100.0)

    def test_expire_writes_off_value(self, registry, today):
        registry.create_lot(
            "ING-HAZELNUT", 500.0, today - dt.timedelta(days=400)
        )
        written = registry.expire_lots(today)
        assert written
        assert written[0][1] == pytest.approx(500.0)

    def test_lot_cannot_hold_more_than_it_received(self):
        with pytest.raises(Exception):
            IngredientLot(
                lot_id="L1",
                ingredient_id="ING-SUGAR",
                quantity_kg=200.0,
                original_quantity_kg=100.0,
                unit_cost=1.0,
                received_on=dt.date(2026, 1, 1),
                expires_on=dt.date(2027, 1, 1),
            )


class TestRecipeValidation:
    """Recipe invariants."""

    def test_fractions_must_sum_to_one(self):
        with pytest.raises(RecipeError):
            Recipe(
                recipe_id="R",
                version=1,
                name="bad",
                chocolate_type=ChocolateType.DARK,
                components=(
                    RecipeComponent.from_percent("ING-LIQUOR", 50.0),
                    RecipeComponent.from_percent("ING-SUGAR", 40.0),
                ),
            )

    def test_duplicate_ingredients_rejected(self):
        with pytest.raises(RecipeError):
            Recipe(
                recipe_id="R",
                version=1,
                name="dup",
                chocolate_type=ChocolateType.DARK,
                components=(
                    RecipeComponent.from_percent("ING-SUGAR", 50.0),
                    RecipeComponent.from_percent("ING-SUGAR", 50.0),
                ),
            )

    def test_all_standard_recipes_are_valid(self, book):
        assert len(book) >= 7
        for recipe in book.current_recipes():
            total = sum(c.mass_fraction for c in recipe.components)
            assert total == pytest.approx(1.0, abs=1e-9)

    def test_revision_increments_version_and_preserves_history(self, book):
        recipe = book.get("RCP-DARK-70")
        revised = book.revise(recipe, change_note="test")
        assert revised.version == recipe.version + 1
        line = book.line("RCP-DARK-70")
        assert line.version(1) is recipe
        assert line.current is revised

    def test_rescale_renormalises(self, book):
        recipe = book.get("RCP-DARK-70")
        rescaled = recipe.rescale({"ING-SUGAR": 0.50})
        assert sum(c.mass_fraction for c in rescaled.components) == pytest.approx(1.0)

    def test_diff_reports_changed_components(self, book):
        recipe = book.get("RCP-DARK-70")
        book.add(recipe.rescale({"ING-SUGAR": 0.40}))
        difference = book.line("RCP-DARK-70").diff(1, 2)
        assert "ING-SUGAR" in difference


class TestRecipeEngine:
    """Costing, composition and compliance."""

    def test_requirements_sum_exactly_to_batch_mass(self, recipe_engine, book):
        for recipe in book.current_recipes():
            requirements = recipe_engine.requirements(recipe, 1234.5678)
            total = sum(r.required_kg for r in requirements)
            assert total == pytest.approx(1234.5678, abs=1e-9)

    def test_cost_scales_linearly_with_batch(self, recipe_engine, dark_recipe):
        small = recipe_engine.cost(dark_recipe, 100.0).total_cost
        large = recipe_engine.cost(dark_recipe, 1000.0).total_cost
        assert large == pytest.approx(small * 10.0, rel=1e-9)

    def test_composition_matches_blended_ingredients(self, recipe_engine, dark_recipe):
        composition = recipe_engine.composition(dark_recipe)
        assert composition.closure_total <= 1.0 + 1e-9
        assert composition.fat > 0.3

    def test_declared_cocoa_matches_the_name(self, recipe_engine, book):
        for recipe in book.current_recipes():
            declared, actual, consistent = recipe_engine.declared_cocoa_check(recipe)
            if declared is not None:
                assert consistent, (
                    f"{recipe.name} declares {declared:.0%} but computes to "
                    f"{actual:.2%}"
                )

    def test_all_standard_recipes_are_compliant(self, recipe_engine, book):
        for recipe in book.current_recipes():
            check = recipe_engine.check_compliance(recipe)
            assert check.compliant, f"{recipe.name}: {check.failures}"

    def test_inclusions_are_excluded_from_the_base(self, recipe_engine, book):
        hazelnut = book.get("RCP-DARK-HAZELNUT")
        product = recipe_engine.composition(hazelnut)
        base, fraction = recipe_engine.base_composition(hazelnut)
        assert fraction < 1.0
        # Removing the nuts must raise the cocoa content of what remains.
        assert base.total_cocoa_solids > product.total_cocoa_solids

    def test_nutrition_energy_is_plausible(self, recipe_engine, book):
        for recipe in book.current_recipes():
            nutrition = recipe_engine.nutrition(recipe)
            assert 400 < nutrition.energy_kcal_per_100g < 700, recipe.name
            assert nutrition.saturates_g_per_100g <= nutrition.fat_g_per_100g

    def test_yield_is_below_one(self, recipe_engine, dark_recipe):
        mass, fraction = recipe_engine.theoretical_yield(dark_recipe, 1000.0)
        assert 0.9 < fraction < 1.0
        assert mass == pytest.approx(1000.0 * fraction)

    def test_allergens_are_collected_from_ingredients(self, recipe_engine, book):
        assert "milk" in recipe_engine.allergens(book.get("RCP-MILK-35"))
        hazelnut = recipe_engine.allergens(book.get("RCP-DARK-HAZELNUT"))
        assert "hazelnut" in hazelnut

    def test_coarsest_particle_ignores_late_inclusions(self, recipe_engine, book):
        hazelnut = book.get("RCP-DARK-HAZELNUT")
        # Whole nuts are 9 mm; they must not drive the refining target.
        assert recipe_engine.coarsest_particle(hazelnut) < 1000.0
