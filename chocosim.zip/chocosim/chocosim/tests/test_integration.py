"""Integration tests: factory twin, scenarios, telemetry, API and dashboards."""

from __future__ import annotations

import datetime as dt

import pytest
from fastapi.testclient import TestClient

from chocosim.api.app import create_app
from chocosim.core.config import ChocoSimConfig
from chocosim.core.rng import RandomSource
from chocosim.dashboard.console import bar, sparkline, status_panel
from chocosim.dashboard.report import render_dashboard
from chocosim.optimisation.factory_opt import FactoryOptimiser
from chocosim.production.line import ProductionLine, build_orders
from chocosim.simulation.scenarios import (
    MonteCarloEngine,
    ScenarioEngine,
    cocoa_price_rise,
    energy_price_rise,
    standard_scenarios,
)
from chocosim.telemetry.sensors import build_default_store


@pytest.fixture
def stocked_factory(factory, today):
    """A factory with raw materials on hand."""
    factory.stock_up(today, days_of_cover=45.0, daily_demand_kg=10_000.0)
    return factory


class TestFactoryTwin:
    """The integrated factory."""

    def test_batch_production_records_an_outcome(self, stocked_factory, today):
        outcome = stocked_factory.produce_batch("RCP-DARK-70", 1200.0, on=today)
        assert outcome.saleable_kg > 0.0
        assert outcome.quality.overall_score > 0.0
        assert outcome.costing.total_cost > 0.0
        assert stocked_factory.outcomes == [outcome]

    def test_production_consumes_raw_materials(self, stocked_factory, today):
        before = stocked_factory.registry.available_quantity("ING-SUGAR", today)
        stocked_factory.produce_batch("RCP-DARK-70", 1200.0, on=today)
        after = stocked_factory.registry.available_quantity("ING-SUGAR", today)
        assert after < before

    def test_production_creates_finished_goods(self, stocked_factory, today):
        outcome = stocked_factory.produce_batch("RCP-DARK-70", 1200.0, on=today)
        assert stocked_factory.inventory.finished_goods_kg == pytest.approx(
            outcome.saleable_kg, rel=1e-6
        )

    def test_schedule_produces_every_batch(self, stocked_factory, today, book):
        schedule = [(recipe.recipe_id, 1200.0) for recipe in book.current_recipes()]
        outcomes = stocked_factory.produce_schedule(schedule, today)
        assert len(outcomes) == len(schedule)

    def test_state_reconciles_with_outcomes(self, stocked_factory, today, book):
        schedule = [(recipe.recipe_id, 1200.0) for recipe in book.current_recipes()[:4]]
        stocked_factory.produce_schedule(schedule, today)
        state = stocked_factory.state(today)
        assert state.batches_produced == 4
        assert state.saleable_kg == pytest.approx(
            sum(o.saleable_kg for o in stocked_factory.outcomes)
        )

    def test_energy_intensity_is_plausible(self, stocked_factory, today, book):
        schedule = [(recipe.recipe_id, 1500.0) for recipe in book.current_recipes()[:4]]
        stocked_factory.produce_schedule(schedule, today)
        state = stocked_factory.state(today)
        assert 0.1 < state.energy_kwh_per_kg < 5.0

    def test_waste_fraction_is_small_but_nonzero(self, stocked_factory, today, book):
        schedule = [(recipe.recipe_id, 1500.0) for recipe in book.current_recipes()[:4]]
        stocked_factory.produce_schedule(schedule, today)
        state = stocked_factory.state(today)
        assert 0.0 < state.waste_fraction < 0.10

    def test_profit_statement_is_produced(self, stocked_factory, today, book):
        schedule = [(recipe.recipe_id, 1500.0) for recipe in book.current_recipes()[:4]]
        stocked_factory.produce_schedule(schedule, today)
        statement = stocked_factory.profit_and_loss(period_days=1.0)
        assert statement.revenue > 0.0
        assert statement.total_cost > 0.0

    def test_reset_clears_history_not_stock(self, stocked_factory, today):
        stocked_factory.produce_batch("RCP-DARK-70", 1200.0, on=today)
        stocked_factory.reset()
        assert stocked_factory.outcomes == []
        assert stocked_factory.registry.total_value() > 0.0

    def test_determinism_across_identical_factories(self, config, book, today):
        from chocosim.ingredients.registry import build_default_registry
        from chocosim.production.factory import Factory

        results = []
        for _ in range(2):
            factory = Factory(config, build_default_registry(), book)
            factory.stock_up(today, 45.0, 10_000.0)
            outcome = factory.produce_batch("RCP-DARK-70", 1200.0, on=today)
            results.append((outcome.saleable_kg, outcome.cost_per_kg))
        assert results[0] == pytest.approx(results[1])


class TestScenarios:
    """What-if analysis."""

    def test_cocoa_shock_raises_cost(self, config, book, today):
        engine = ScenarioEngine(config, book)
        schedule = [("RCP-DARK-70", 1200.0), ("RCP-MILK-35", 1500.0)]
        comparison = engine.compare([cocoa_price_rise(1.20)], schedule, today)
        assert comparison.scenarios[0].cost_per_kg > comparison.baseline.cost_per_kg

    def test_dark_is_more_exposed_to_cocoa_than_milk(self, config, book, today):
        engine = ScenarioEngine(config, book)
        dark = engine.compare([cocoa_price_rise(1.30)], [("RCP-DARK-70", 1200.0)], today)
        milk = engine.compare([cocoa_price_rise(1.30)], [("RCP-MILK-35", 1200.0)], today)
        dark_delta = dark.scenarios[0].delta_against(dark.baseline)["cost_per_kg_pct"]
        milk_delta = milk.scenarios[0].delta_against(milk.baseline)["cost_per_kg_pct"]
        assert dark_delta > milk_delta

    def test_energy_shock_has_a_smaller_effect_than_cocoa(self, config, book, today):
        engine = ScenarioEngine(config, book)
        schedule = [("RCP-DARK-70", 1200.0)]
        comparison = engine.compare(
            [cocoa_price_rise(1.20), energy_price_rise(1.20)], schedule, today
        )
        cocoa, energy = comparison.scenarios
        assert cocoa.cost_per_kg > energy.cost_per_kg

    def test_scenarios_do_not_leak_between_runs(self, config, book, today):
        engine = ScenarioEngine(config, book)
        schedule = [("RCP-DARK-70", 1200.0)]
        first = engine.compare(standard_scenarios(), schedule, today)
        second = engine.compare([], schedule, today)
        assert second.baseline.cost_per_kg == pytest.approx(first.baseline.cost_per_kg)

    def test_baseline_is_unaffected_by_scenarios(self, config, book, today):
        engine = ScenarioEngine(config, book)
        schedule = [("RCP-DARK-70", 1200.0)]
        plain = engine.run_scenario(None, schedule, today)
        comparison = engine.compare([cocoa_price_rise(2.0)], schedule, today)
        assert comparison.baseline.cost_per_kg == pytest.approx(plain.cost_per_kg)


class TestMonteCarlo:
    """Replicated simulation."""

    def test_percentiles_are_ordered(self, book, today):
        engine = MonteCarloEngine(ChocoSimConfig.default(), book)
        report = engine.run([("RCP-DARK-70", 1200.0)], today, replications=12)
        for result in report.results.values():
            assert result.p10 <= result.p50 <= result.p90

    def test_replication_count_is_honoured(self, book, today):
        engine = MonteCarloEngine(ChocoSimConfig.default(), book)
        report = engine.run([("RCP-DARK-70", 1200.0)], today, replications=8)
        assert report.replications == 8
        for result in report.results.values():
            assert result.replications == 8

    def test_results_are_reproducible(self, book, today):
        config = ChocoSimConfig.default().with_seed(4242)
        first = MonteCarloEngine(config, book).run(
            [("RCP-DARK-70", 1200.0)], today, replications=6
        )
        second = MonteCarloEngine(config, book).run(
            [("RCP-DARK-70", 1200.0)], today, replications=6
        )
        assert first.get("cost_per_kg").p50 == pytest.approx(
            second.get("cost_per_kg").p50
        )

    def test_output_is_simulation_grade_not_prediction(self, book, today):
        from chocosim.core.fidelity import ModelFidelity

        report = MonteCarloEngine(ChocoSimConfig.default(), book).run(
            [("RCP-DARK-70", 1200.0)], today, replications=4
        )
        # Repeating an uncalibrated model does not make it a prediction.
        assert report.provenance.fidelity is ModelFidelity.SIMULATION

    def test_zero_replications_rejected(self, book, today):
        with pytest.raises(ValueError):
            MonteCarloEngine(ChocoSimConfig.default(), book).run(
                [("RCP-DARK-70", 1200.0)], today, replications=0
            )


class TestFactoryOptimiser:
    """Current versus optimised."""

    def test_optimisation_reduces_changeover_time(self, config, book):
        optimiser = FactoryOptimiser(config, book)
        programme = [
            ("RCP-DARK-55", 1500.0), ("RCP-MILK-35", 1500.0),
            ("RCP-DARK-70", 1500.0), ("RCP-WHITE-28", 1500.0),
            ("RCP-DARK-55", 1500.0), ("RCP-MILK-35", 1500.0),
        ]
        result = optimiser.optimise(programme, horizon_hours=336.0)
        assert result.optimised.changeover_hours <= result.current.changeover_hours

    def test_programme_content_is_preserved(self, config, book):
        optimiser = FactoryOptimiser(config, book)
        programme = [
            ("RCP-DARK-55", 1500.0), ("RCP-MILK-35", 1200.0),
            ("RCP-DARK-70", 1000.0), ("RCP-WHITE-28", 900.0),
        ]
        result = optimiser.optimise(programme, horizon_hours=336.0)
        assert result.schedule is not None
        assert len(result.schedule.sequence) == len(programme)

    def test_unknown_recipe_is_rejected(self, config, book):
        with pytest.raises(KeyError):
            FactoryOptimiser(config, book).optimise([("NOT-A-RECIPE", 1000.0)])


class TestTelemetry:
    """Synthetic instrumentation."""

    def test_readings_track_the_truth(self):
        store = build_default_store()
        source = RandomSource(7)
        start = dt.datetime(2026, 5, 1, 6, 0)
        for index in range(400):
            store.record(
                "TT-CONCHE-01", 68.0, start + dt.timedelta(seconds=30 * index), source
            )
        frame = store.series("TT-CONCHE-01")
        assert frame["value"].mean() == pytest.approx(68.0, abs=0.5)

    def test_quantisation_is_applied(self):
        store = build_default_store()
        source = RandomSource(7)
        reading = store.record(
            "TT-ROAST-01", 145.037, dt.datetime(2026, 5, 1), source
        )
        assert reading.value == pytest.approx(round(reading.value, 1))

    def test_readings_stay_in_range(self):
        store = build_default_store()
        source = RandomSource(3)
        start = dt.datetime(2026, 5, 1)
        for index in range(500):
            store.record(
                "TI-TEMPER-01", 5.0, start + dt.timedelta(seconds=30 * index), source
            )
        frame = store.series("TI-TEMPER-01")
        assert frame["value"].min() >= 0.0
        assert frame["value"].max() <= 10.0

    def test_faults_are_rare_but_present(self):
        store = build_default_store()
        source = RandomSource(5)
        start = dt.datetime(2026, 5, 1)
        for index in range(4000):
            store.record_batch(
                {"TT-ROAST-01": 145.0, "TI-TEMPER-01": 5.0},
                start + dt.timedelta(seconds=30 * index),
                source,
            )
        assert 0.0 < store.suspect_rate() < 0.05

    def test_empty_store_yields_an_empty_frame(self):
        assert build_default_store().frame().height == 0


class TestApi:
    """HTTP surface."""

    @pytest.fixture
    def client(self):
        return TestClient(create_app(ChocoSimConfig.default().deterministic()))

    def test_root_declares_fidelity(self, client):
        payload = client.get("/").json()
        assert "SIMULATION" in payload["fidelity"]

    def test_health(self, client):
        assert client.get("/health").json()["status"] == "ok"

    def test_recipes_listing(self, client):
        payload = client.get("/recipes").json()
        assert payload["count"] >= 7
        assert all(entry["compliant"] for entry in payload["recipes"])

    def test_unknown_recipe_returns_404(self, client):
        assert client.get("/recipes/NOPE").status_code == 404

    def test_simulation_run(self, client):
        response = client.post(
            "/simulation/run",
            json={"batches": [{"recipe_id": "RCP-DARK-70", "mass_kg": 1200}]},
        )
        assert response.status_code == 200
        payload = response.json()
        assert payload["batches"][0]["saleable_kg"] > 0
        assert payload["provenance"]["fidelity"] == "SIMULATION"

    def test_simulation_rejects_unknown_recipe(self, client):
        response = client.post(
            "/simulation/run",
            json={"batches": [{"recipe_id": "NOPE", "mass_kg": 1000}]},
        )
        assert response.status_code == 404

    def test_simulation_rejects_negative_mass(self, client):
        response = client.post(
            "/simulation/run",
            json={"batches": [{"recipe_id": "RCP-DARK-70", "mass_kg": -5}]},
        )
        assert response.status_code == 422

    def test_monte_carlo_mode(self, client):
        response = client.post(
            "/simulation/run",
            json={
                "batches": [{"recipe_id": "RCP-DARK-70", "mass_kg": 1200}],
                "replications": 5,
            },
        )
        payload = response.json()
        assert payload["mode"] == "monte_carlo"
        assert payload["replications"] == 5
        assert "p10" in payload["results"]["cost_per_kg"]

    def test_replications_are_capped(self, client):
        response = client.post(
            "/simulation/run",
            json={
                "batches": [{"recipe_id": "RCP-DARK-70", "mass_kg": 1000}],
                "replications": 100_000,
            },
        )
        payload = response.json()
        assert payload["replications_capped"] is True

    def test_optimisation_run(self, client):
        response = client.post(
            "/optimisation/run",
            json={
                "batches": [
                    {"recipe_id": "RCP-DARK-55", "mass_kg": 1500},
                    {"recipe_id": "RCP-MILK-35", "mass_kg": 1500},
                    {"recipe_id": "RCP-DARK-70", "mass_kg": 1500},
                    {"recipe_id": "RCP-MILK-35", "mass_kg": 1500},
                ]
            },
        )
        assert response.status_code == 200
        assert response.json()["schedule"]["changeover_saving_hours"] >= 0.0

    def test_scenario_run(self, client):
        response = client.post(
            "/scenario/run",
            json={
                "batches": [{"recipe_id": "RCP-DARK-70", "mass_kg": 1200}],
                "cocoa_multiplier": 1.2,
            },
        )
        assert response.status_code == 200
        assert response.json()["scenarios"][0]["delta"]["cost_per_kg"] > 0

    def test_scenario_requires_a_modification(self, client):
        response = client.post(
            "/scenario/run",
            json={"batches": [{"recipe_id": "RCP-DARK-70", "mass_kg": 1200}]},
        )
        assert response.status_code == 422

    @pytest.mark.parametrize(
        "endpoint",
        ["/factory/state", "/inventory", "/production", "/economics", "/ingredients"],
    )
    def test_get_endpoints_respond(self, client, endpoint):
        assert client.get(endpoint).status_code == 200


class TestDashboards:
    """Rendering."""

    def test_bar_is_the_right_width(self):
        assert len(bar(0.5, 20)) == 20
        assert len(bar(0.0, 20)) == 20
        assert len(bar(1.0, 20)) == 20

    def test_bar_clamps_out_of_range(self):
        assert len(bar(5.0, 10)) == 10
        assert len(bar(-1.0, 10)) == 10

    def test_sparkline_handles_flat_series(self):
        assert sparkline([1.0, 1.0, 1.0])

    def test_sparkline_of_nothing_is_empty(self):
        assert sparkline([]) == ""

    def test_console_panel_includes_the_caveat(self, stocked_factory, today):
        stocked_factory.produce_batch("RCP-DARK-70", 1200.0, on=today)
        panel = status_panel(stocked_factory.state(today))
        assert "SIMULATION OUTPUT" in panel

    def test_html_dashboard_is_self_contained(
        self, stocked_factory, today, config, book
    ):
        stocked_factory.produce_schedule(
            [(recipe.recipe_id, 1200.0) for recipe in book.current_recipes()[:3]],
            today,
        )
        line = ProductionLine(config=config)
        result = line.simulate(
            build_orders(book.current_recipes()[:3], 12, 1500.0),
            horizon_minutes=14 * 24 * 60,
        )
        html = render_dashboard(
            state=stocked_factory.state(today),
            outcomes=stocked_factory.outcomes,
            line=result,
        )
        assert html.startswith("<!DOCTYPE html>")
        assert "Simulation output" in html
        assert "plotly" in html.lower()
        assert len(html) > 10_000
