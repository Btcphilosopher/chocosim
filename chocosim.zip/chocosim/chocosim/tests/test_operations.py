"""Tests for production, inventory, supply chain, economics and optimisation."""

from __future__ import annotations

import datetime as dt

import pytest

from chocosim.core.types import ChocolateType, IngredientClass, SolverStatus
from chocosim.inventory.manager import ReorderPolicy, service_level_z
from chocosim.logistics.supply_chain import (
    SupplyChainSimulator,
    cocoa_complex_shock,
    west_africa_crop_failure,
)
from chocosim.optimisation.solvers import (
    EnergyOptimiser,
    ProductionScheduler,
    RecipeOptimiser,
    ScheduleJob,
    optimal_batch_size,
)
from chocosim.production.line import ProductionLine, build_orders
from chocosim.production.machines import MachineSpec, default_machine_specs


class TestMachines:
    """Machine capacity and changeovers."""

    def test_batch_machine_needs_whole_cycles(self):
        spec = MachineSpec(
            machine_id="M",
            name="conche",
            machine_class=default_machine_specs()[5].machine_class,
            stage=default_machine_specs()[5].stage,
            batch_capacity_kg=1000.0,
            batch_cycle_minutes=600.0,
        )
        # 1,001 kg needs two cycles, not 1.001.
        assert spec.processing_minutes(1001.0) == pytest.approx(1200.0)
        assert spec.processing_minutes(500.0) == pytest.approx(600.0)

    def test_continuous_machine_scales_linearly(self):
        spec = MachineSpec(
            machine_id="M",
            name="refiner",
            machine_class=default_machine_specs()[4].machine_class,
            stage=default_machine_specs()[4].stage,
            throughput_kg_per_hour=1200.0,
        )
        assert spec.processing_minutes(1200.0) == pytest.approx(60.0)
        assert spec.processing_minutes(600.0) == pytest.approx(30.0)

    def test_parallel_units_raise_effective_throughput(self):
        base = default_machine_specs()[4]
        assert base.effective_throughput_kg_per_hour == pytest.approx(
            base.throughput_kg_per_hour * base.parallel_units
        )

    def test_zero_mass_takes_no_time(self):
        assert default_machine_specs()[4].processing_minutes(0.0) == 0.0


class TestProductionLine:
    """Discrete-event line behaviour."""

    def test_all_batches_complete_given_enough_time(self, config, book):
        line = ProductionLine(config=config)
        orders = build_orders(book.current_recipes()[:3], 6, 1200.0)
        result = line.simulate(orders, horizon_minutes=30 * 24 * 60)
        assert result.batches_completed == result.batches_released

    def test_conche_is_the_paper_bottleneck(self, config):
        line = ProductionLine(config=config)
        stage, rate = line.theoretical_bottleneck()
        assert stage.value == "conching"
        assert rate > 0.0

    def test_simulation_finds_the_same_bottleneck(self, config, book):
        line = ProductionLine(config=config)
        orders = build_orders(book.current_recipes()[:3], 24, 1500.0)
        result = line.simulate(orders, horizon_minutes=21 * 24 * 60)
        assert result.bottleneck().stage.value == "conching"

    def test_utilisation_never_exceeds_one(self, config, book):
        line = ProductionLine(config=config)
        orders = build_orders(book.current_recipes(), 40, 1800.0)
        result = line.simulate(orders, horizon_minutes=14 * 24 * 60)
        for stat in result.stage_statistics:
            assert 0.0 <= stat.utilisation <= 1.0, stat.stage

    def test_throughput_is_consistent_across_stages(self, config, book):
        line = ProductionLine(config=config)
        orders = build_orders(book.current_recipes()[:3], 20, 1500.0)
        result = line.simulate(orders, horizon_minutes=21 * 24 * 60)
        rates = {round(stat.throughput_kg_per_hour, 3) for stat in result.stage_statistics}
        assert len(rates) == 1

    def test_flow_efficiency_is_a_fraction(self, config, book):
        line = ProductionLine(config=config)
        orders = build_orders(book.current_recipes(), 30, 1500.0)
        result = line.simulate(orders, horizon_minutes=21 * 24 * 60)
        assert 0.0 <= result.mean_flow_efficiency <= 1.0

    def test_disabling_changeovers_removes_the_cost(self, config, book):
        config.simulation.enable_changeovers = False
        line = ProductionLine(config=config)
        orders = build_orders(book.current_recipes(), 12, 1500.0)
        result = line.simulate(orders, horizon_minutes=21 * 24 * 60)
        assert result.total_changeover_minutes == 0.0

    def test_zero_horizon_rejected(self, config, book):
        line = ProductionLine(config=config)
        with pytest.raises(ValueError):
            line.simulate(build_orders(book.current_recipes(), 2, 100.0), 0.0)


class TestInventory:
    """Reorder policy and stock movement."""

    def test_safety_stock_rises_with_service_level(self):
        def policy(level: float) -> ReorderPolicy:
            return ReorderPolicy(
                ingredient_id="I",
                daily_demand_kg=100.0,
                demand_sigma_kg=20.0,
                lead_time_days=14.0,
                lead_time_sigma_days=3.0,
                service_level=level,
            )

        assert policy(0.99).safety_stock_kg > policy(0.90).safety_stock_kg

    def test_safety_stock_accounts_for_lead_time_variance(self):
        steady = ReorderPolicy(
            ingredient_id="I",
            daily_demand_kg=100.0,
            demand_sigma_kg=20.0,
            lead_time_days=14.0,
            lead_time_sigma_days=0.0,
        )
        volatile = steady.model_copy(update={"lead_time_sigma_days": 8.0})
        assert volatile.safety_stock_kg > steady.safety_stock_kg

    def test_no_order_above_the_reorder_point(self):
        policy = ReorderPolicy(
            ingredient_id="I", daily_demand_kg=100.0, lead_time_days=10.0
        )
        assert policy.order_quantity(policy.reorder_point_kg + 1.0) == 0.0

    def test_order_below_the_reorder_point(self):
        policy = ReorderPolicy(
            ingredient_id="I", daily_demand_kg=100.0, lead_time_days=10.0
        )
        assert policy.order_quantity(0.0) > 0.0

    def test_service_level_quantiles_are_monotonic(self):
        assert service_level_z(0.99) > service_level_z(0.95) > service_level_z(0.80)

    def test_consumption_records_a_movement(self, inventory, registry, today):
        registry.create_lot("ING-SUGAR", 1000.0, today)
        inventory.consume_raw("ING-SUGAR", 250.0, today)
        assert any(move.item_id == "ING-SUGAR" for move in inventory.moves)

    def test_shortfall_is_recorded(self, inventory, registry, today):
        registry.create_lot("ING-SUGAR", 100.0, today)
        inventory.consume_raw("ING-SUGAR", 400.0, today)
        assert inventory.stockout_kg["ING-SUGAR"] == pytest.approx(300.0)

    def test_finished_goods_ship_fefo(self, inventory, today):
        inventory.receive_finished(
            "B2", "R", "P", 500.0, 5.0, today, shelf_life_days=400
        )
        inventory.receive_finished(
            "B1", "R", "P", 500.0, 5.0, today, shelf_life_days=100
        )
        shipped, _, shortfall = inventory.ship("R", 400.0, today)
        assert shipped == pytest.approx(400.0)
        assert shortfall == 0.0

    def test_warehouse_capacity_is_enforced(self, inventory, config, today):
        with pytest.raises(Exception):
            inventory.receive_finished(
                "B",
                "R",
                "P",
                config.factory.warehouse_capacity_kg * 2,
                5.0,
                today,
            )


class TestSupplyChain:
    """Disruptions and delivery performance."""

    def test_price_shock_raises_delivered_cost(self, registry, inventory, config, today):
        simulator = SupplyChainSimulator(registry, inventory, config)
        for disruption in cocoa_complex_shock(1.25, 0, 100):
            simulator.add_disruption(disruption)
        assert simulator.price_multiplier(10, "ING-LIQUOR") == pytest.approx(1.25)

    def test_shock_does_not_touch_other_classes(
        self, registry, inventory, config
    ):
        simulator = SupplyChainSimulator(registry, inventory, config)
        for disruption in cocoa_complex_shock(1.25, 0, 100):
            simulator.add_disruption(disruption)
        assert simulator.price_multiplier(10, "ING-SUGAR") == pytest.approx(1.0)

    def test_disruption_expires(self, registry, inventory, config):
        simulator = SupplyChainSimulator(registry, inventory, config)
        for disruption in cocoa_complex_shock(1.25, 0, 50):
            simulator.add_disruption(disruption)
        assert simulator.price_multiplier(80, "ING-LIQUOR") == pytest.approx(1.0)

    def test_crop_failure_restricts_supply(self, registry, inventory, config):
        simulator = SupplyChainSimulator(registry, inventory, config)
        simulator.add_disruption(west_africa_crop_failure(0.40, 0, 90))
        assert simulator.supply_fraction(30, "ING-BEAN-WA") == pytest.approx(0.60)

    def test_simulation_produces_deliveries(self, registry, inventory, config, today):
        simulator = SupplyChainSimulator(registry, inventory, config)
        registry.create_lot("ING-SUGAR", 5000.0, today)
        result = simulator.run({"ING-SUGAR": 400.0}, 90, today)
        assert result.deliveries
        assert 0.0 <= result.on_time_in_full_rate <= 1.0


class TestEconomics:
    """Costing and profitability."""

    def test_cost_categories_sum_to_the_total(
        self, chain, quality_engine, economics_engine, dark_recipe
    ):
        run = chain.run(dark_recipe, 1500.0)
        assessment = quality_engine.assess(run, dark_recipe)
        costing = economics_engine.cost_batch(run, dark_recipe, assessment)
        assert sum(costing.by_category().values()) == pytest.approx(costing.total_cost)

    def test_ingredients_dominate_the_cost(
        self, chain, quality_engine, economics_engine, dark_recipe
    ):
        run = chain.run(dark_recipe, 1500.0)
        assessment = quality_engine.assess(run, dark_recipe)
        costing = economics_engine.cost_batch(run, dark_recipe, assessment)
        assert costing.category_shares()["ingredients"] > 0.4

    def test_cost_per_kg_uses_saleable_mass(
        self, chain, quality_engine, economics_engine, dark_recipe
    ):
        run = chain.run(dark_recipe, 1500.0)
        assessment = quality_engine.assess(run, dark_recipe)
        costing = economics_engine.cost_batch(run, dark_recipe, assessment)
        assert costing.cost_per_kg > costing.total_cost / costing.input_mass_kg

    def test_lower_volume_raises_absorbed_overhead(
        self, chain, quality_engine, economics_engine, dark_recipe
    ):
        run = chain.run(dark_recipe, 1500.0)
        assessment = quality_engine.assess(run, dark_recipe)
        busy = economics_engine.cost_batch(
            run, dark_recipe, assessment, daily_production_kg=20_000.0
        )
        quiet = economics_engine.cost_batch(
            run, dark_recipe, assessment, daily_production_kg=4_000.0
        )
        assert quiet.cost_per_kg > busy.cost_per_kg

    def test_indicative_price_hits_the_target_margin(
        self, chain, quality_engine, economics_engine, dark_recipe, config
    ):
        run = chain.run(dark_recipe, 1500.0)
        assessment = quality_engine.assess(run, dark_recipe)
        costing = economics_engine.cost_batch(run, dark_recipe, assessment)
        price = costing.indicative_price(config.economics)
        margin = (price - costing.cost_per_kg) / price
        assert margin == pytest.approx(config.economics.target_gross_margin)

    def test_unit_economics_add_up(
        self, chain, quality_engine, economics_engine, dark_recipe
    ):
        run = chain.run(dark_recipe, 1500.0)
        assessment = quality_engine.assess(run, dark_recipe)
        costing = economics_engine.cost_batch(run, dark_recipe, assessment)
        product = economics_engine.product_economics(costing, 100.0, 0.08)
        assert product.total_cost_per_unit == pytest.approx(
            product.production_cost_per_unit
            + product.packaging_cost_per_unit
            + product.energy_cost_per_unit
        )
        assert product.margin_per_unit == pytest.approx(
            product.wholesale_price_per_unit - product.total_cost_per_unit
        )

    def test_profit_statement_reconciles(
        self, chain, quality_engine, economics_engine, book
    ):
        costings = []
        for recipe in book.current_recipes()[:4]:
            run = chain.run(recipe, 1200.0)
            assessment = quality_engine.assess(run, recipe)
            costings.append(economics_engine.cost_batch(run, recipe, assessment))
        statement = economics_engine.profit_and_loss(costings, period_days=1.0)
        assert statement.gross_profit == pytest.approx(
            statement.revenue - statement.variable_cost
        )
        assert statement.operating_profit == pytest.approx(
            statement.revenue - statement.total_cost
        )


class TestOptimisation:
    """Solver behaviour."""

    def _jobs(self, book, recipe_engine, order):
        return [
            ScheduleJob(
                job_id=f"J{index}",
                recipe_id=recipe_id,
                chocolate_type=book.get(recipe_id).chocolate_type,
                mass_kg=1500.0,
                processing_minutes=180.0,
                allergens=recipe_engine.allergens(book.get(recipe_id)),
            )
            for index, recipe_id in enumerate(order)
        ]

    def test_scheduler_reduces_changeover_time(self, config, book, recipe_engine):
        order = [
            "RCP-DARK-55", "RCP-MILK-35", "RCP-DARK-70", "RCP-MILK-CARAMEL",
            "RCP-DARK-55", "RCP-MILK-35", "RCP-DARK-70", "RCP-WHITE-28",
        ]
        result = ProductionScheduler(config).optimise(
            self._jobs(book, recipe_engine, order)
        )
        assert result.status is SolverStatus.OPTIMAL
        assert result.total_changeover_minutes < result.baseline_changeover_minutes

    def test_scheduler_keeps_every_job(self, config, book, recipe_engine):
        order = ["RCP-DARK-55", "RCP-MILK-35", "RCP-DARK-70", "RCP-WHITE-28"]
        result = ProductionScheduler(config).optimise(
            self._jobs(book, recipe_engine, order)
        )
        assert len(result.sequence) == len(order)
        assert len(set(result.sequence)) == len(order)

    def test_single_job_needs_no_changeover(self, config, book, recipe_engine):
        result = ProductionScheduler(config).optimise(
            self._jobs(book, recipe_engine, ["RCP-DARK-55"])
        )
        assert result.total_changeover_minutes == 0.0

    def test_identical_products_need_no_changeover(self, config, book, recipe_engine):
        result = ProductionScheduler(config).optimise(
            self._jobs(book, recipe_engine, ["RCP-DARK-55"] * 5)
        )
        assert result.total_changeover_minutes == 0.0

    def test_reformulation_never_costs_more(
        self, registry, recipe_engine, config, book
    ):
        optimiser = RecipeOptimiser(registry, recipe_engine, config)
        for recipe in book.current_recipes():
            result = optimiser.optimise(recipe, max_deviation=0.15)
            if result.feasible:
                assert result.cost_per_kg <= result.baseline_cost_per_kg + 1e-6

    def test_reformulation_preserves_cocoa_by_default(
        self, registry, recipe_engine, config, book
    ):
        optimiser = RecipeOptimiser(registry, recipe_engine, config)
        recipe = book.get("RCP-DARK-55")
        result = optimiser.optimise(recipe, max_deviation=0.30)
        assert result.cocoa_solids_after >= result.cocoa_solids_before - 0.01

    def test_unconstrained_reformulation_can_cheapen_the_product(
        self, registry, recipe_engine, config, book
    ):
        optimiser = RecipeOptimiser(registry, recipe_engine, config)
        recipe = book.get("RCP-DARK-55")
        loose = optimiser.optimise(
            recipe, max_deviation=0.30, preserve_cocoa_content=False
        )
        tight = optimiser.optimise(recipe, max_deviation=0.30)
        # Dropping the constraint buys more saving, at the cost of the product.
        assert loose.cost_per_kg <= tight.cost_per_kg + 1e-9
        assert loose.cocoa_solids_after < tight.cocoa_solids_after

    def test_reformulated_recipe_still_closes(
        self, registry, recipe_engine, config, book
    ):
        optimiser = RecipeOptimiser(registry, recipe_engine, config)
        recipe = book.get("RCP-MILK-35")
        result = optimiser.optimise(recipe, max_deviation=0.20)
        applied = optimiser.apply(recipe, result)
        assert sum(c.mass_fraction for c in applied.components) == pytest.approx(1.0)
        assert recipe_engine.check_compliance(applied).compliant

    def test_energy_shifting_never_costs_more(self, config):
        optimiser = EnergyOptimiser(config)
        tasks = {f"t{i}": (400.0, 3) for i in range(6)}
        result = optimiser.shift_load(tasks, 24, max_concurrent=2, earliest_hour=8)
        assert result.feasible
        assert result.optimised_cost <= result.baseline_cost + 1e-6

    def test_energy_shifting_schedules_every_task(self, config):
        optimiser = EnergyOptimiser(config)
        tasks = {f"t{i}": (400.0, 3) for i in range(6)}
        result = optimiser.shift_load(tasks, 24, max_concurrent=3, earliest_hour=0)
        assert set(result.start_hours) == set(tasks)

    def test_impossible_task_is_rejected(self, config):
        with pytest.raises(Exception):
            EnergyOptimiser(config).shift_load({"t": (100.0, 30)}, horizon_hours=24)

    def test_batch_size_optimum_is_in_range(self):
        size, cost = optimal_batch_size(90.0, 1200.0, 0.02, 500.0, 100.0, 8000.0)
        assert 100.0 <= size <= 8000.0
        assert cost > 0.0

    def test_costlier_changeovers_favour_larger_batches(self):
        cheap, _ = optimal_batch_size(20.0, 1200.0, 0.02, 500.0, 100.0, 8000.0)
        dear, _ = optimal_batch_size(240.0, 1200.0, 0.02, 500.0, 100.0, 8000.0)
        assert dear >= cheap
