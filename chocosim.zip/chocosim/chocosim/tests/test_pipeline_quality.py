"""Tests for the process chain, quality engine and packaging."""

from __future__ import annotations

import pytest

from chocosim.core.types import ProcessStageKind, QualityVerdict
from chocosim.packaging.formats import PackagingLine, standard_formats, underweight_z


class TestProcessChain:
    """End-to-end process runs."""

    def test_every_recipe_runs_end_to_end(self, chain, book):
        for recipe in book.current_recipes():
            run = chain.run(recipe, 1000.0)
            assert run.output_kg > 0.0
            assert run.results

    def test_overall_mass_balance_closes(self, chain, book):
        for recipe in book.current_recipes():
            run = chain.run(recipe, 1000.0)
            balance = run.overall_balance
            accounted = balance.mass_out + balance.mass_loss + balance.mass_waste
            assert accounted == pytest.approx(balance.mass_in, rel=1e-9, abs=1e-6)

    def test_stage_balances_compose_to_the_overall(self, chain, dark_recipe):
        run = chain.run(dark_recipe, 1000.0)
        loss = sum(r.mass_balance.mass_loss for r in run.results)
        waste = sum(r.mass_balance.mass_waste for r in run.results)
        assert run.overall_balance.mass_loss == pytest.approx(loss)
        assert run.overall_balance.mass_waste == pytest.approx(waste)

    def test_bean_recipes_use_the_front_end(self, chain, book):
        run = chain.run(book.get("RCP-DARK-ORIGIN"), 1000.0)
        stages = {result.stage for result in run.results}
        assert ProcessStageKind.ROASTING in stages
        assert ProcessStageKind.WINNOWING in stages
        assert ProcessStageKind.GRINDING in stages

    def test_liquor_recipes_skip_the_front_end(self, chain, dark_recipe):
        run = chain.run(dark_recipe, 1000.0)
        stages = {result.stage for result in run.results}
        assert ProcessStageKind.ROASTING not in stages
        assert ProcessStageKind.MIXING in stages

    def test_bean_line_loses_shell(self, chain, book):
        bean = chain.run(book.get("RCP-DARK-ORIGIN"), 1000.0)
        liquor = chain.run(book.get("RCP-DARK-70"), 1000.0)
        # Shell removal makes a bean-to-bar line materially lower yielding.
        assert bean.overall_balance.yield_fraction < liquor.overall_balance.yield_fraction
        assert bean.overall_balance.loss_fraction > 0.08

    def test_energy_is_positive_and_attributed(self, chain, dark_recipe):
        run = chain.run(dark_recipe, 1000.0)
        assert run.total_energy.total_kwh > 0.0
        by_stage = run.energy_by_stage()
        assert sum(by_stage.values()) == pytest.approx(run.total_energy.total_kwh)

    def test_specific_energy_is_plausible(self, chain, book):
        for recipe in book.current_recipes():
            run = chain.run(recipe, 1000.0)
            assert 0.05 < run.specific_energy_kwh_per_kg < 3.0, recipe.name

    def test_conching_is_the_slowest_stage(self, chain, dark_recipe):
        run = chain.run(dark_recipe, 1000.0)
        stage, _ = run.bottleneck_stage()
        assert stage == "conching"

    def test_determinism(self, chain, dark_recipe):
        first = chain.run(dark_recipe, 1000.0)
        second = chain.run(dark_recipe, 1000.0)
        assert first.output_kg == pytest.approx(second.output_kg)
        assert first.total_energy.total_kwh == pytest.approx(
            second.total_energy.total_kwh
        )

    def test_output_scales_with_batch_size(self, chain, dark_recipe):
        small = chain.run(dark_recipe, 500.0)
        large = chain.run(dark_recipe, 1000.0)
        assert large.output_kg == pytest.approx(small.output_kg * 2.0, rel=0.02)

    def test_inclusions_reach_the_finished_product(self, chain, book):
        run = chain.run(book.get("RCP-DARK-HAZELNUT"), 1000.0)
        moulding = run.stage("moulding" and ProcessStageKind.MOULDING)
        assert moulding is not None
        assert moulding.metrics.get("inclusion_mass_kg", 0.0) > 0.0

    def test_stage_metrics_of_absent_stage_is_empty(self, chain, dark_recipe):
        run = chain.run(dark_recipe, 1000.0)
        assert run.stage_metrics("roasting") == {}

    def test_attended_time_excludes_conching(self, chain, dark_recipe):
        run = chain.run(dark_recipe, 1000.0)
        assert run.attended_minutes < run.total_minutes


class TestQuality:
    """Batch scoring."""

    def test_every_recipe_produces_a_score(self, chain, quality_engine, book):
        for recipe in book.current_recipes():
            run = chain.run(recipe, 1000.0)
            assessment = quality_engine.assess(run, recipe)
            assert 0.0 <= assessment.overall_score <= 100.0

    def test_weights_sum_to_one(self, quality_engine):
        weights = quality_engine.quality_config.normalised_weights()
        assert sum(weights.values()) == pytest.approx(1.0)

    def test_metric_weights_match_the_score(self, chain, quality_engine, dark_recipe):
        run = chain.run(dark_recipe, 1000.0)
        assessment = quality_engine.assess(run, dark_recipe)
        expected = sum(metric.weighted_score for metric in assessment.metrics)
        assert assessment.overall_score == pytest.approx(min(100.0, expected))

    def test_in_specification_metrics_score_full_marks(
        self, chain, quality_engine, dark_recipe
    ):
        run = chain.run(dark_recipe, 1000.0)
        assessment = quality_engine.assess(run, dark_recipe)
        for metric in assessment.metrics:
            if metric.in_specification and metric.specification is not None:
                assert metric.score == pytest.approx(100.0)

    def test_verdict_follows_the_threshold(self, chain, quality_engine, dark_recipe):
        run = chain.run(dark_recipe, 1000.0)
        assessment = quality_engine.assess(run, dark_recipe)
        threshold = quality_engine.quality_config.pass_threshold
        if assessment.overall_score >= threshold and not assessment.defects:
            assert assessment.verdict is QualityVerdict.PASS

    def test_disposition_masses_reconcile(self, chain, quality_engine, book):
        for recipe in book.current_recipes():
            run = chain.run(recipe, 1000.0)
            assessment = quality_engine.assess(run, recipe)
            total = (
                assessment.saleable_kg
                + assessment.reworkable_kg
                + assessment.scrap_kg
            )
            assert total == pytest.approx(assessment.batch_mass_kg, rel=1e-6)

    def test_defects_are_independent_not_additive(self, chain, quality_engine, book):
        run = chain.run(book.get("RCP-WHITE-28"), 1000.0)
        assessment = quality_engine.assess(run, book.get("RCP-WHITE-28"))
        if len(assessment.defects) >= 2:
            naive = sum(defect.rate for defect in assessment.defects)
            assert assessment.defect_rate <= naive + 1e-9

    def test_defects_carry_a_cause(self, chain, quality_engine, book):
        for recipe in book.current_recipes():
            run = chain.run(recipe, 1000.0)
            for defect in quality_engine.assess(run, recipe).defects:
                assert defect.cause

    def test_viscosity_is_compared_at_the_reference_temperature(
        self, chain, quality_engine, dark_recipe
    ):
        run = chain.run(dark_recipe, 1000.0)
        metrics = run.stage_metrics("conching")
        # The specification value must not be the hot conche reading.
        assert metrics["viscosity_pas"] > metrics["viscosity_at_process_temp_pas"]


class TestPackaging:
    """Pack formats and give-away."""

    def test_target_fill_exceeds_nominal(self):
        for fmt in standard_formats():
            assert fmt.target_fill_g > fmt.unit_mass_g
            assert 0.0 < fmt.giveaway_fraction < 0.06

    def test_tighter_filling_reduces_giveaway(self):
        base = standard_formats()[0]
        tight = base.model_copy(update={"fill_sigma_fraction": 0.004})
        assert tight.giveaway_fraction < base.giveaway_fraction

    def test_tighter_tolerance_raises_giveaway(self):
        base = standard_formats()[0]
        strict = base.model_copy(update={"underweight_tolerance": 0.005})
        assert strict.giveaway_fraction > base.giveaway_fraction

    def test_underweight_quantile_decreases_with_tolerance(self):
        assert underweight_z(0.005) > underweight_z(0.10)

    def test_packing_conserves_mass(self, config):
        line = PackagingLine(config)
        for fmt in standard_formats():
            run = line.pack(fmt, 2000.0, "R")
            assert run.packed_mass_kg + run.remnant_kg == pytest.approx(2000.0, abs=1e-6)

    def test_case_and_pallet_counts_are_consistent(self, config):
        line = PackagingLine(config)
        fmt = standard_formats()[0]
        run = line.pack(fmt, 2000.0, "R")
        assert run.cases == -(-run.units_produced // fmt.units_per_case)
        assert run.pallets == -(-run.cases // fmt.cases_per_pallet)

    def test_zero_mass_packs_nothing(self, config):
        run = PackagingLine(config).pack(standard_formats()[0], 0.0, "R")
        assert run.units_produced == 0
        assert run.material_cost == 0.0

    def test_giveaway_cost_scales_with_volume(self, config):
        line = PackagingLine(config)
        fmt = standard_formats()[0]
        one = line.giveaway_cost_per_year(fmt, 1_000_000, 8.0)
        ten = line.giveaway_cost_per_year(fmt, 10_000_000, 8.0)
        assert ten == pytest.approx(one * 10.0)
        assert one > 0.0
