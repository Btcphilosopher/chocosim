"""Tests for the process engine: roasting, rheology, refining, conching, tempering."""

from __future__ import annotations

import pytest

from chocosim.core.exceptions import StageSequenceError
from chocosim.core.models import Composition
from chocosim.core.types import CrystalForm, MaterialState, ProcessStageKind
from chocosim.processing.base import MaterialStream
from chocosim.processing.conching import ConchingModel
from chocosim.processing.grinding import comminution_energy_kwh_per_tonne
from chocosim.processing.refining import ParticleSizeDistribution, RefiningModel
from chocosim.processing.rheology import (
    cocoa_butter_to_target_viscosity,
    compute_rheology,
    fat_phase_viscosity,
    maximum_packing_fraction,
    solids_volume_fraction,
)
from chocosim.processing.roasting import (
    ROAST_A,
    ROAST_B,
    ROAST_HIGH_INTENSITY,
    ROAST_LOW_SLOW,
    RoastingModel,
    equilibrium_moisture,
    find_equivalent_profile,
)
from chocosim.tempering.crystals import CrystalState, bloom_risk, melting_point
from chocosim.tempering.model import TemperingModel, TemperProfile


class TestRoasting:
    """Roast kinetics."""

    def test_moisture_falls_but_never_below_equilibrium(self, config):
        model = RoastingModel(config)
        for profile in (ROAST_A, ROAST_B, ROAST_LOW_SLOW, ROAST_HIGH_INTENSITY):
            outcome = model.roast(profile, 1000.0, 0.070)
            assert outcome.final_moisture < 0.070
            assert outcome.final_moisture > 0.0

    def test_profiles_give_distinguishable_moisture(self, config):
        model = RoastingModel(config)
        moistures = {
            profile.name: model.roast(profile, 1000.0, 0.070).final_moisture
            for profile in (ROAST_A, ROAST_B, ROAST_LOW_SLOW, ROAST_HIGH_INTENSITY)
        }
        # A model where every profile dries identically cannot compare profiles.
        assert max(moistures.values()) - min(moistures.values()) > 0.002

    def test_reference_profile_is_fully_developed(self, config):
        model = RoastingModel(config)
        outcome = model.roast(ROAST_B, 1000.0, 0.070)
        assert outcome.development_ratio == pytest.approx(1.0, abs=0.02)

    def test_hotter_roast_accumulates_more_damage(self, config):
        model = RoastingModel(config)
        cool = model.roast(ROAST_LOW_SLOW, 1000.0, 0.070)
        hot = model.roast(ROAST_HIGH_INTENSITY, 1000.0, 0.070)
        assert hot.damage_ratio > cool.damage_ratio

    def test_gentler_roast_scores_higher(self, config):
        model = RoastingModel(config)
        assert (
            model.roast(ROAST_LOW_SLOW, 1000.0, 0.070).quality_index
            > model.roast(ROAST_HIGH_INTENSITY, 1000.0, 0.070).quality_index
        )

    def test_equilibrium_moisture_falls_with_temperature(self):
        assert equilibrium_moisture(180.0) < equilibrium_moisture(120.0)

    def test_mass_is_conserved_across_the_roast(self, config):
        model = RoastingModel(config)
        outcome = model.roast(ROAST_B, 1000.0, 0.070)
        accounted = (
            outcome.output_kg + outcome.water_removed_kg + outcome.volatiles_lost_kg
        )
        assert accounted == pytest.approx(1000.0, abs=1e-6)

    def test_equal_development_equivalent_costs_quality(self, config):
        model = RoastingModel(config)
        equivalent = find_equivalent_profile(model, ROAST_B, 165.0)
        reference = model.roast(ROAST_B, 1000.0, 0.070)
        candidate = model.roast(equivalent, 1000.0, 0.070)
        assert candidate.development_ratio == pytest.approx(
            reference.development_ratio, rel=0.02
        )
        # Same development, more damage: hotter and shorter is not free.
        assert candidate.damage_ratio > reference.damage_ratio
        assert equivalent.duration_minutes < ROAST_B.duration_minutes

    def test_energy_is_positive_and_scales_with_charge(self, config):
        model = RoastingModel(config)
        small = model.roast(ROAST_B, 500.0, 0.070)
        large = model.roast(ROAST_B, 1000.0, 0.070)
        assert large.energy.total_kwh > small.energy.total_kwh > 0.0

    def test_wrong_input_state_is_rejected(self, config, book, source):
        model = RoastingModel(config)
        stream = MaterialStream(
            mass_kg=100.0, composition=Composition(fat=0.5), state=MaterialState.LIQUOR
        )
        with pytest.raises(StageSequenceError):
            model.run(stream, book.get("RCP-DARK-70"), source)


class TestRheology:
    """Casson rheology behaviour."""

    def test_more_fat_thins_the_mass(self):
        lean = Composition(fat=0.30, sugar=0.45, cocoa_solids_nonfat=0.24, moisture=0.01)
        rich = Composition(fat=0.42, sugar=0.36, cocoa_solids_nonfat=0.21, moisture=0.01)
        assert (
            compute_rheology(rich, 10.0).plastic_viscosity_pas
            < compute_rheology(lean, 10.0).plastic_viscosity_pas
        )

    def test_finer_grind_thickens_the_mass(self):
        composition = Composition(
            fat=0.35, sugar=0.42, cocoa_solids_nonfat=0.22, moisture=0.01
        )
        coarse = compute_rheology(composition, 14.0)
        fine = compute_rheology(composition, 7.0)
        assert fine.plastic_viscosity_pas > coarse.plastic_viscosity_pas

    def test_lecithin_reduces_viscosity_with_diminishing_returns(self):
        composition = Composition(
            fat=0.33, sugar=0.44, cocoa_solids_nonfat=0.22, moisture=0.01
        )
        none = compute_rheology(composition, 10.0, lecithin_fraction=0.0)
        some = compute_rheology(composition, 10.0, lecithin_fraction=0.002)
        lots = compute_rheology(composition, 10.0, lecithin_fraction=0.010)
        assert some.plastic_viscosity_pas < none.plastic_viscosity_pas
        assert lots.plastic_viscosity_pas < some.plastic_viscosity_pas
        first_gain = none.plastic_viscosity_pas - some.plastic_viscosity_pas
        second_gain = some.plastic_viscosity_pas - lots.plastic_viscosity_pas
        assert second_gain < first_gain

    def test_moisture_raises_yield_value_sharply(self):
        dry = Composition(fat=0.35, sugar=0.42, cocoa_solids_nonfat=0.21, moisture=0.004)
        wet = Composition(fat=0.35, sugar=0.42, cocoa_solids_nonfat=0.21, moisture=0.020)
        assert (
            compute_rheology(wet, 10.0).yield_value_pa
            > compute_rheology(dry, 10.0).yield_value_pa * 1.5
        )

    def test_heat_thins_the_fat_phase(self):
        assert fat_phase_viscosity(50.0) < fat_phase_viscosity(35.0)

    def test_milk_fat_thins_the_continuous_phase(self):
        assert fat_phase_viscosity(40.0, milk_fat_share=0.5) < fat_phase_viscosity(40.0)

    def test_wider_distribution_packs_better(self):
        narrow = maximum_packing_fraction(10.0, span=0.6)
        wide = maximum_packing_fraction(10.0, span=2.4)
        assert wide > narrow

    def test_solids_fraction_is_bounded(self):
        composition = Composition(fat=0.35, sugar=0.42, cocoa_solids_nonfat=0.22)
        phi = solids_volume_fraction(composition)
        assert 0.0 < phi < 1.0

    def test_standard_formulations_are_workable(self, recipe_engine, book):
        for recipe in book.current_recipes():
            composition = recipe_engine.composition(recipe)
            state = compute_rheology(
                composition,
                recipe.process.target_particle_size_um * 0.55,
                lecithin_fraction=recipe.fraction_of("ING-LECITHIN"),
            )
            assert state.is_workable, recipe.name
            assert 0.1 < state.plastic_viscosity_pas < 12.0, recipe.name

    def test_added_butter_reaches_the_target(self):
        composition = Composition(
            fat=0.30, sugar=0.46, cocoa_solids_nonfat=0.23, moisture=0.01
        )
        before = compute_rheology(composition, 9.0).plastic_viscosity_pas
        addition = cocoa_butter_to_target_viscosity(composition, 9.0, before * 0.6)
        assert addition > 0.0

    def test_no_butter_needed_when_already_thin(self):
        composition = Composition(fat=0.45, sugar=0.33, cocoa_solids_nonfat=0.21)
        assert cocoa_butter_to_target_viscosity(composition, 12.0, 99.0) == 0.0


class TestComminution:
    """Size reduction energy and distributions."""

    def test_energy_rises_as_target_gets_finer(self):
        coarse = comminution_energy_kwh_per_tonne(100.0, 25.0, 405.0)
        fine = comminution_energy_kwh_per_tonne(100.0, 12.0, 405.0)
        assert fine > coarse > 0.0

    def test_no_energy_when_already_fine_enough(self):
        assert comminution_energy_kwh_per_tonne(20.0, 25.0, 405.0) == 0.0

    def test_refining_energy_is_in_a_plausible_band(self):
        energy = comminution_energy_kwh_per_tonne(100.0, 18.0, 405.0)
        assert 30.0 < energy < 120.0

    def test_distribution_percentiles_are_ordered(self):
        psd = ParticleSizeDistribution.from_d90(18.0)
        assert psd.d10_um < psd.d50_um < psd.d90_um < psd.d99_um

    def test_from_d90_round_trips(self):
        psd = ParticleSizeDistribution.from_d90(22.0, 1.9)
        assert psd.d90_um == pytest.approx(22.0, rel=1e-6)

    def test_finer_grind_has_more_surface_area(self):
        fine = ParticleSizeDistribution.from_d90(14.0)
        coarse = ParticleSizeDistribution.from_d90(28.0)
        assert (
            fine.specific_surface_area_m2_per_kg
            > coarse.specific_surface_area_m2_per_kg
        )

    def test_coarse_product_is_more_perceptible(self):
        assert (
            ParticleSizeDistribution.from_d90(35.0).perceptible_fraction
            > ParticleSizeDistribution.from_d90(16.0).perceptible_fraction
        )


class TestConching:
    """Conche kinetics and diminishing returns."""

    def test_moisture_falls_towards_an_asymptote(self, config):
        model = ConchingModel(config)
        short = model.conche(1000.0, 0.014, 4.0, 68.0, 0.7, False)
        long = model.conche(1000.0, 0.014, 24.0, 68.0, 0.7, False)
        assert long.final_moisture < short.final_moisture < 0.014

    def test_acid_removal_saturates(self, config):
        model = ConchingModel(config)
        curve = model.marginal_benefit_curve(
            _DummyRecipe(), initial_moisture=0.014, max_hours=48.0, step_hours=6.0
        )
        marginals = [row["marginal_quality_per_hour"] for row in curve]
        # Returns must diminish monotonically after the first block.
        assert all(
            later <= earlier + 1e-9
            for earlier, later in zip(marginals, marginals[1:], strict=False)
        )

    def test_energy_grows_with_duration(self, config):
        model = ConchingModel(config)
        short = model.conche(1000.0, 0.014, 6.0, 68.0, 0.7, False)
        long = model.conche(1000.0, 0.014, 30.0, 68.0, 0.7, False)
        assert long.energy.total_kwh > short.energy.total_kwh

    def test_emulsifier_activation_needs_shear_work(self, config):
        model = ConchingModel(config)
        gentle = model.conche(1000.0, 0.012, 6.0, 60.0, 0.2, False)
        vigorous = model.conche(1000.0, 0.012, 6.0, 60.0, 1.0, False)
        assert vigorous.emulsifier_efficiency > gentle.emulsifier_efficiency

    def test_hot_milk_conching_causes_damage(self, config):
        model = ConchingModel(config)
        safe = model.conche(1000.0, 0.012, 12.0, 55.0, 0.6, True)
        hot = model.conche(1000.0, 0.012, 12.0, 78.0, 0.6, True)
        assert hot.thermal_damage_gain > safe.thermal_damage_gain
        assert safe.thermal_damage_gain == 0.0


class _DummyRecipe:
    """Minimal stand-in for the conche benefit curve."""

    class _Process:
        conche_temperature_c = 68.0
        conche_shear_intensity = 0.7

    class _Type:
        value = "dark"

    process = _Process()
    chocolate_type = _Type()


class TestTempering:
    """Polymorph behaviour and the tempering cycle."""

    def test_form_v_melts_above_form_iv(self):
        assert melting_point(CrystalForm.FORM_V) > melting_point(CrystalForm.FORM_IV)

    def test_milk_fat_depresses_melting_points(self):
        assert melting_point(CrystalForm.FORM_V, 0.2) < melting_point(CrystalForm.FORM_V)

    def test_pure_form_v_reads_higher_than_mixed(self):
        pure = CrystalState(fractions={CrystalForm.FORM_V: 0.035})
        mixed = CrystalState(
            fractions={CrystalForm.FORM_V: 0.018, CrystalForm.FORM_IV: 0.017}
        )
        assert pure.temper_index() > mixed.temper_index()
        assert pure.purity > mixed.purity

    def test_reference_seed_reads_five(self):
        state = CrystalState(fractions={CrystalForm.FORM_V: 0.035})
        assert state.temper_index() == pytest.approx(5.0, abs=0.05)

    def test_no_crystal_is_untempered(self):
        assert CrystalState.molten().temper_index() == 0.0
        assert not CrystalState.molten().is_acceptable

    def test_cycle_produces_usable_seed(self, config):
        model = TemperingModel(config)
        outcome = model.run_profile(
            TemperProfile.standard(), 1000.0, 45.0, record_trajectory=False
        )
        assert 0.01 < outcome.crystal_state.total_solid < 0.09
        assert outcome.crystal_state.purity > 0.7
        assert outcome.is_acceptable

    def test_reheat_window_is_narrow(self, config, dark_recipe):
        model = TemperingModel(config)
        rows = model.sweep_reheat(dark_recipe, [28.0, 31.5, 34.0])
        low, middle, high = rows
        # Too cool over-seeds, too hot melts the seed out.
        assert low["solid_fraction"] > middle["solid_fraction"]
        assert high["solid_fraction"] < middle["solid_fraction"]
        assert middle["acceptable"] == 1.0

    def test_every_standard_recipe_tempers(self, config, book, recipe_engine):
        model = TemperingModel(config)
        for recipe in book.current_recipes():
            composition = recipe_engine.composition(recipe)
            share = (
                composition.milk_fat / composition.fat if composition.fat > 0 else 0.0
            )
            outcome = model.run_profile(
                TemperProfile.from_recipe(recipe),
                1000.0,
                45.0,
                share,
                record_trajectory=False,
            )
            assert outcome.is_acceptable, f"{recipe.name}: {outcome.grade.value}"

    def test_bloom_risk_rises_with_unstable_crystal(self):
        good = CrystalState(fractions={CrystalForm.FORM_V: 0.035})
        bad = CrystalState(
            fractions={CrystalForm.FORM_V: 0.010, CrystalForm.FORM_IV: 0.025}
        )
        assert bloom_risk(bad, 18.0, 90.0) > bloom_risk(good, 18.0, 90.0)

    def test_bloom_risk_rises_with_storage_temperature(self):
        state = CrystalState(fractions={CrystalForm.FORM_V: 0.035})
        assert bloom_risk(state, 28.0, 90.0) > bloom_risk(state, 15.0, 90.0)

    def test_invalid_profile_rejected(self):
        with pytest.raises(Exception):
            TemperProfile.standard(melt_c=45.0, cool_c=32.0, reheat_c=30.0)
