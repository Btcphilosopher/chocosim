"""End-to-end demonstration: a week of production, analysed.

Runs the whole system in one script -- stock the store, produce a programme,
score it, cost it, simulate the line, optimise the sequence, price a cocoa
shock, and write the dashboard. Every number printed comes from a model that
computed it rather than a constant typed in here.

Run with:  python -m examples.full_factory_run
"""

from __future__ import annotations

import datetime as dt

from chocosim.core.config import ChocoSimConfig
from chocosim.dashboard.console import batch_table, optimisation_panel, status_panel
from chocosim.dashboard.report import write_dashboard
from chocosim.ingredients.registry import build_default_registry
from chocosim.optimisation.factory_opt import FactoryOptimiser
from chocosim.processing.roasting import STANDARD_ROAST_PROFILES, RoastingModel
from chocosim.production.factory import Factory
from chocosim.production.line import ProductionLine, build_orders
from chocosim.recipes.library import build_standard_book
from chocosim.simulation.scenarios import ScenarioEngine, standard_scenarios


def main() -> int:
    """Run the demonstration."""
    config = ChocoSimConfig.default().deterministic()
    book = build_standard_book()
    start = dt.date(2026, 9, 7)

    print("=" * 78)
    print("  CHOCOSIM -- FULL FACTORY DEMONSTRATION")
    print("=" * 78)

    # --- 1. Roast profile comparison ---------------------------------
    print("\n1. ROAST PROFILE COMPARISON\n")
    roaster = RoastingModel(config)
    print(
        f"{'PROFILE':<18}{'MOISTURE':>10}{'DEVEL':>8}{'DAMAGE':>8}{'QUALITY':>9}"
    )
    print("-" * 53)
    for outcome in roaster.compare_profiles(STANDARD_ROAST_PROFILES, 1000.0, 0.070):
        print(
            f"{outcome.profile_name:<18}{outcome.final_moisture:>10.2%}"
            f"{outcome.development_ratio:>8.3f}{outcome.damage_ratio:>8.3f}"
            f"{outcome.quality_index:>9.1f}"
        )

    # --- 2. Production ------------------------------------------------
    print("\n2. PRODUCTION PROGRAMME\n")
    factory = Factory(config, build_default_registry(), book)
    factory.stock_up(start, days_of_cover=45.0, daily_demand_kg=12_000.0)
    schedule = [(recipe.recipe_id, 1_500.0) for recipe in book.current_recipes()]
    factory.produce_schedule(schedule, start, batches_per_day=4)
    print(batch_table(factory.outcomes))

    # --- 3. Line simulation -------------------------------------------
    print("\n3. LINE SIMULATION\n")
    line = ProductionLine(config=ChocoSimConfig.default())
    result = line.simulate(
        build_orders(book.current_recipes(), 40, 1_800.0),
        horizon_minutes=14 * 24 * 60,
    )
    print(result.report())

    # --- 4. Factory status --------------------------------------------
    print("\n4. FACTORY STATUS\n")
    state = factory.state(start)
    print(status_panel(state, result))

    # --- 5. Optimisation ----------------------------------------------
    print("\n5. OPTIMISATION\n")
    optimiser = FactoryOptimiser(ChocoSimConfig.default(), book)
    programme = [
        (recipe.recipe_id, 1_500.0)
        for _ in range(3)
        for recipe in book.current_recipes()
    ]
    optimisation = optimiser.optimise(
        programme,
        horizon_hours=336.0,
        energy_kwh_per_kg=state.energy_kwh_per_kg,
        waste_fraction=state.waste_fraction,
    )
    print(optimisation_panel(optimisation))

    # --- 6. Scenarios --------------------------------------------------
    print("\n6. WHAT-IF SCENARIOS\n")
    scenario_engine = ScenarioEngine(config, book)
    comparison = scenario_engine.compare(
        standard_scenarios(),
        [(recipe.recipe_id, 1_500.0) for recipe in book.current_recipes()[:4]],
        start,
    )
    print(comparison.report())

    # --- 7. Economics --------------------------------------------------
    print("\n7. UNIT ECONOMICS\n")
    for outcome in factory.outcomes[:4]:
        pack_cost = (
            outcome.packaging.material_cost_per_unit if outcome.packaging else 0.08
        )
        product = factory.economics_engine.product_economics(
            outcome.costing, 100.0, pack_cost
        )
        print(f"  {product.summary()}")

    # --- 8. Dashboard --------------------------------------------------
    print("\n8. DASHBOARD\n")
    path = write_dashboard(
        "chocosim_dashboard.html",
        state=state,
        outcomes=factory.outcomes,
        line=result,
        optimisation=optimisation,
        scenarios=comparison,
    )
    print(f"  Written to {path}")

    print("\n" + "=" * 78)
    print("  All output above is SIMULATION grade: physically motivated but")
    print("  not calibrated against or validated on any real plant.")
    print("=" * 78)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
